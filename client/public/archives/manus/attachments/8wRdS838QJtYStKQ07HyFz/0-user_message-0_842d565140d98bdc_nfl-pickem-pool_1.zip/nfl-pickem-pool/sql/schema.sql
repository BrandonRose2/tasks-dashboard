-- Requires pgcrypto for gen_random_uuid()
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TYPE card_status AS ENUM ('pending', 'paid', 'void');
CREATE TYPE payment_method AS ENUM ('zelle', 'cashapp');

CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  phone TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  is_admin BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE weekly_contests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  week_num INTEGER NOT NULL UNIQUE,
  lock_at TIMESTAMPTZ NOT NULL,
  tiebreaker_game_id TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE cards (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id),
  contest_id UUID NOT NULL REFERENCES weekly_contests(id),
  card_number INTEGER NOT NULL,
  status card_status NOT NULL DEFAULT 'pending',
  submitted_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, contest_id, card_number)
);

-- reported_paid_at = participant says they paid
-- marked_paid_at / marked_paid_by = admin confirmed it
CREATE TABLE payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  card_id UUID NOT NULL UNIQUE REFERENCES cards(id),
  method payment_method NOT NULL,
  amount NUMERIC(6,2) NOT NULL DEFAULT 10.00,
  reported_paid_at TIMESTAMPTZ,
  marked_paid_by UUID REFERENCES users(id),
  marked_paid_at TIMESTAMPTZ
);

CREATE TABLE picks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  card_id UUID NOT NULL REFERENCES cards(id),
  game_id TEXT NOT NULL,
  picked_team TEXT NOT NULL,
  tiebreaker_score INTEGER,
  UNIQUE (card_id, game_id)
);

-- Exception log: voids, corrections, admin actions, disputes
CREATE TABLE audit_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_id UUID REFERENCES users(id),
  action TEXT NOT NULL,
  target_id UUID,
  detail JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_cards_contest ON cards(contest_id);
CREATE INDEX idx_payments_pending_review ON payments(reported_paid_at)
  WHERE marked_paid_at IS NULL;
