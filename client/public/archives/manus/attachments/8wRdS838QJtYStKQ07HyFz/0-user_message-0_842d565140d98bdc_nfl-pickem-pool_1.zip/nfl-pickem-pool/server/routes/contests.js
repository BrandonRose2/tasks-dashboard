const express = require('express');
const pool = require('../db');
const { requireAuth, requireAdmin } = require('../middleware/auth');
const { fetchWeekSchedule, computeLockAt } = require('../lib/espn');
const { refreshScores, getLeaderboard } = require('../lib/scoring');

const router = express.Router();

// Whatever the frontend should show "right now" — most recent contest by week number.
router.get('/current', requireAuth, async (req, res) => {
  const { rows } = await pool.query('SELECT * FROM weekly_contests ORDER BY week_num DESC LIMIT 1');
  if (!rows[0]) return res.status(404).json({ error: 'No contest set up yet.' });
  res.json(rows[0]);
});

// Admin creates a new week's contest — pulls that week's slate from ESPN and stores it.
router.post('/', requireAuth, requireAdmin, async (req, res) => {
  const { weekNum, tiebreakerGameId } = req.body;
  const games = await fetchWeekSchedule(weekNum);
  const lockAt = computeLockAt(games);

  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const { rows } = await client.query(
      `INSERT INTO weekly_contests (week_num, lock_at, tiebreaker_game_id)
       VALUES ($1, $2, $3) RETURNING *`,
      [weekNum, lockAt, tiebreakerGameId || null]
    );
    const contest = rows[0];
    for (const g of games) {
      await client.query(
        `INSERT INTO games (id, contest_id, home_team, away_team, kickoff, is_tiebreaker)
         VALUES ($1, $2, $3, $4, $5, $6)`,
        [g.gameId, contest.id, g.homeTeam.abbr, g.awayTeam.abbr, g.kickoff, g.gameId === tiebreakerGameId]
      );
    }
    await client.query('COMMIT');
    res.json(contest);
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
});

// Any signed-in participant can view a contest's matchups to build their picks screen.
router.get('/:contestId/games', requireAuth, async (req, res) => {
  const { rows } = await pool.query(
    'SELECT * FROM games WHERE contest_id = $1 ORDER BY kickoff',
    [req.params.contestId]
  );
  res.json(rows);
});

// Admin pulls current/final scores from ESPN into the stored games.
router.post('/:contestId/refresh-scores', requireAuth, requireAdmin, async (req, res) => {
  const { weekNum } = req.body;
  await refreshScores(req.params.contestId, weekNum);
  res.json({ refreshed: true });
});

router.get('/:contestId/leaderboard', requireAuth, async (req, res) => {
  const rows = await getLeaderboard(req.params.contestId);
  res.json(rows);
});

module.exports = router;
