const express = require('express');
const pool = require('../db');
const { requireAuth, requireAdmin } = require('../middleware/auth');

const router = express.Router();
router.use(requireAuth, requireAdmin);

// Cards where the participant reported paying but an admin hasn't confirmed yet.
router.get('/payments/pending', async (req, res) => {
  const { rows } = await pool.query(
    `SELECT c.id AS card_id, c.card_number, u.name, p.method, p.reported_paid_at
     FROM cards c
     JOIN users u ON u.id = c.user_id
     JOIN payments p ON p.card_id = c.id
     WHERE p.reported_paid_at IS NOT NULL AND p.marked_paid_at IS NULL
     ORDER BY p.reported_paid_at ASC`
  );
  res.json(rows);
});

router.get('/audit-log', async (req, res) => {
  const { rows } = await pool.query(
    `SELECT al.*, u.name AS actor_name
     FROM audit_log al LEFT JOIN users u ON u.id = al.actor_id
     ORDER BY al.created_at DESC LIMIT 200`
  );
  res.json(rows);
});

router.post('/contests/:contestId/declare-winner', async (req, res) => {
  const { contestId } = req.params;
  const { cardId } = req.body;
  const { rows } = await pool.query(
    `UPDATE weekly_contests SET winner_card_id = $1, winner_declared_at = now()
     WHERE id = $2 RETURNING *`,
    [cardId, contestId]
  );
  if (!rows[0]) return res.status(404).json({ error: 'Contest not found.' });
  await pool.query(
    "INSERT INTO audit_log (actor_id, action, target_id) VALUES ($1, 'declare_winner', $2)",
    [req.user.id, cardId]
  );
  res.json(rows[0]);
});

router.post('/contests/:contestId/mark-payout-sent', async (req, res) => {
  const { contestId } = req.params;
  const { rows } = await pool.query(
    `UPDATE weekly_contests SET payout_sent_at = now() WHERE id = $1 RETURNING *`,
    [contestId]
  );
  if (!rows[0]) return res.status(404).json({ error: 'Contest not found.' });
  await pool.query(
    "INSERT INTO audit_log (actor_id, action, target_id) VALUES ($1, 'mark_payout_sent', $2)",
    [req.user.id, contestId]
  );
  res.json(rows[0]);
});

// Real money collected so far, the organizer's cut, and what's left for the prize pool.
router.get('/contests/:contestId/finances', async (req, res) => {
  const { contestId } = req.params;
  const { rows } = await pool.query(
    `SELECT COALESCE(SUM(p.amount), 0) AS total_collected
     FROM cards c JOIN payments p ON p.card_id = c.id
     WHERE c.contest_id = $1 AND c.status = 'paid'`,
    [contestId]
  );
  const totalCollected = Number(rows[0].total_collected);
  const percentage = Number(process.env.ORGANIZER_PERCENTAGE || 0.10);
  const organizerCut = Math.round(totalCollected * percentage * 100) / 100;
  const prizePool = Math.round((totalCollected - organizerCut) * 100) / 100;
  res.json({ totalCollected, percentage, organizerCut, prizePool });
});

module.exports = router;
