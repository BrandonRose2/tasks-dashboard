const API = '/api';
let token = localStorage.getItem('token');
let user = JSON.parse(localStorage.getItem('user') || 'null');
let currentContest = null;
let activeCardId = null;

async function api(path, opts = {}) {
  const headers = { 'Content-Type': 'application/json', ...(opts.headers || {}) };
  if (token) headers.Authorization = `Bearer ${token}`;
  const res = await fetch(API + path, { ...opts, headers });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Request failed.');
  return data;
}

// ---------- Login ----------
document.getElementById('send-code-btn').onclick = async () => {
  const phone = document.getElementById('phone-input').value.trim();
  const err = document.getElementById('login-error');
  err.textContent = '';
  if (!phone) { err.textContent = 'Enter a phone number first.'; return; }
  try {
    await api('/auth/request-otp', { method: 'POST', body: JSON.stringify({ phone }) });
    document.getElementById('phone-step').style.display = 'none';
    document.getElementById('code-step').style.display = 'block';
  } catch (e) { err.textContent = e.message; }
};

document.getElementById('verify-code-btn').onclick = async () => {
  const phone = document.getElementById('phone-input').value.trim();
  const code = document.getElementById('code-input').value.trim();
  const name = document.getElementById('name-input').value.trim();
  const err = document.getElementById('login-error');
  err.textContent = '';
  if (!code) { err.textContent = 'Enter the code first.'; return; }
  try {
    const data = await api('/auth/verify-otp', { method: 'POST', body: JSON.stringify({ phone, code, name }) });
    token = data.token;
    user = data.user;
    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify(user));
    boot();
  } catch (e) { err.textContent = e.message; }
};

// ---------- Nav ----------
document.querySelectorAll('.nav-btn').forEach((btn) => { btn.onclick = () => showView(btn.dataset.view); });

function showView(name) {
  ['picks', 'cards', 'leaderboard', 'admin'].forEach((v) => {
    document.getElementById(`view-${v}`).style.display = v === name ? 'block' : 'none';
  });
  document.querySelectorAll('.nav-btn').forEach((btn) => {
    btn.classList.toggle('active-tab', btn.dataset.view === name);
  });
  if (name === 'picks') renderPicks();
  if (name === 'cards') renderCards();
  if (name === 'leaderboard') renderLeaderboard();
  if (name === 'admin') renderAdmin();
}

async function boot() {
  document.getElementById('login-view').style.display = 'none';
  document.getElementById('app-view').style.display = 'block';
  if (user.isAdmin) document.querySelector('.admin-only').style.display = 'inline-block';
  try { currentContest = await api('/contests/current'); } catch { currentContest = null; }
  showView('picks');
}

// ---------- Picks ----------
async function renderPicks() {
  const el = document.getElementById('view-picks');
  if (!currentContest) { el.innerHTML = '<p>No contest set up yet.</p>'; return; }

  if (!activeCardId) {
    const info = await api('/config/payment-info');
    el.innerHTML = `
      <p>Start a new $10 card for week ${currentContest.week_num}.</p>
      <select id="pay-method">
        <option value="zelle">Zelle</option>
        <option value="cashapp">Cash App</option>
      </select>
      <p class="meta" id="pay-instructions"></p>
      <button id="new-card-btn">Start card</button>`;
    const instructions = document.getElementById('pay-instructions');
    const methodSelect = document.getElementById('pay-method');
    const updateInstructions = () => {
      const val = methodSelect.value;
      const handle = val === 'zelle' ? info.zelle : info.cashapp;
      instructions.textContent = handle
        ? `Send $10 via ${val === 'zelle' ? 'Zelle' : 'Cash App'} to ${handle}, then come back and submit picks.`
        : 'Payment handle not set up yet — ask the admin.';
    };
    methodSelect.onchange = updateInstructions;
    updateInstructions();
    document.getElementById('new-card-btn').onclick = async () => {
      const method = methodSelect.value;
      const card = await api('/cards', { method: 'POST', body: JSON.stringify({ contestId: currentContest.id, method }) });
      activeCardId = card.id;
      renderPicks();
    };
    return;
  }

  const games = await api(`/contests/${currentContest.id}/games`);
  const tiebreaker = games.find((g) => g.is_tiebreaker);
  el.innerHTML = games.map((g) => `
    <div class="game-card">
      <p class="meta">${new Date(g.kickoff).toLocaleString()}${g.is_tiebreaker ? ' · tiebreaker' : ''}</p>
      <div class="teams">
        <button class="team-btn" data-game="${g.id}" data-team="${g.away_team}">${g.away_team}</button>
        <button class="team-btn" data-game="${g.id}" data-team="${g.home_team}">${g.home_team}</button>
      </div>
    </div>`).join('')
    + (tiebreaker ? `<label>Combined score, ${tiebreaker.away_team} @ ${tiebreaker.home_team}<input id="tb-score" type="number"></label>` : '')
    + '<p id="picks-error" class="error"></p><button id="submit-picks-btn">Submit picks</button>';

  document.querySelectorAll('.team-btn').forEach((btn) => {
    btn.onclick = () => {
      document.querySelectorAll(`.team-btn[data-game="${btn.dataset.game}"]`).forEach((b) => b.classList.remove('selected'));
      btn.classList.add('selected');
    };
  });

  document.getElementById('submit-picks-btn').onclick = async () => {
    const err = document.getElementById('picks-error');
    const picks = games.map((g) => {
      const sel = document.querySelector(`.team-btn.selected[data-game="${g.id}"]`);
      return sel ? { gameId: g.id, pickedTeam: sel.dataset.team } : null;
    });
    if (picks.includes(null)) { err.textContent = 'Pick a team for every game first.'; return; }
    const tbInput = document.getElementById('tb-score');
    if (tbInput && !tbInput.value) { err.textContent = 'Enter a tiebreaker score first.'; return; }
    try {
      await api(`/cards/${activeCardId}/picks`, {
        method: 'POST',
        body: JSON.stringify({ picks, tiebreakerScore: tbInput ? Number(tbInput.value) : null }),
      });
      err.style.color = '#4fd1e5';
      err.textContent = 'Picks submitted.';
    } catch (e) { err.textContent = e.message; }
  };
}

// ---------- My cards ----------
async function renderCards() {
  const el = document.getElementById('view-cards');
  const cards = await api('/cards/mine');
  if (!cards.length) { el.innerHTML = '<p>No cards yet — start one from the Picks tab.</p>'; return; }
  el.innerHTML = cards.map((c) => `
    <div class="row">
      <div>
        <p><strong>Card ${c.card_number}</strong> — ${c.method}</p>
        <p class="meta">${c.submitted_at ? 'Picks submitted' : 'Picks not submitted'} ·
          ${c.marked_paid_at ? 'Paid' : c.reported_paid_at ? 'Payment pending review' : 'Not paid yet'}</p>
      </div>
      ${!c.reported_paid_at ? `<button class="paid-btn" data-card="${c.id}">I've paid</button>` : ''}
    </div>`).join('');
  document.querySelectorAll('.paid-btn').forEach((btn) => {
    btn.onclick = async () => { await api(`/payments/${btn.dataset.card}/report-paid`, { method: 'POST' }); renderCards(); };
  });
}

// ---------- Leaderboard ----------
async function renderLeaderboard() {
  const el = document.getElementById('view-leaderboard');
  if (!currentContest) { el.innerHTML = '<p>No contest yet.</p>'; return; }
  const rows = await api(`/contests/${currentContest.id}/leaderboard`);
  el.innerHTML = `<table><tr><th>Name</th><th>Card</th><th>Correct</th><th>Paid</th></tr>
    ${rows.map((r) => `<tr><td>${r.name}</td><td>${r.card_number}</td><td>${r.correct_picks}</td><td>${r.paid ? 'Yes' : 'No'}</td></tr>`).join('')}
  </table>`;
}

// ---------- Admin ----------
async function renderAdmin() {
  const el = document.getElementById('view-admin');
  const pending = await api('/admin/payments/pending');
  const finances = currentContest ? await api(`/admin/contests/${currentContest.id}/finances`) : null;
  const site = await fetch('/api/config/site').then((r) => r.json());
  el.innerHTML = `
    <h3>Branding</h3>
    <input id="bg-file" type="file" accept="image/*">
    <button id="save-bg-btn">Upload background photo</button>
    ${site.hasBackgroundPhoto ? '<button id="remove-bg-btn">Remove photo</button>' : ''}
    <h3>New contest</h3>
    <input id="week-num" type="number" placeholder="Week #">
    <input id="tb-game-id" type="text" placeholder="Tiebreaker game ID (optional)">
    <button id="create-contest-btn">Create</button>
    <button id="refresh-scores-btn">Refresh scores</button>
    ${finances ? `
      <h3>This week's money</h3>
      <p class="meta">Collected: $${finances.totalCollected.toFixed(2)} ·
        Organizer cut (${(finances.percentage * 100).toFixed(0)}%): $${finances.organizerCut.toFixed(2)} ·
        Prize pool: $${finances.prizePool.toFixed(2)}</p>` : ''}
    <h3>Payments pending review</h3>
    ${pending.map((p) => `
      <div class="row"><span>${p.name} — card ${p.card_number} (${p.method})</span>
      <button class="mark-paid-btn" data-card="${p.card_id}">Mark paid</button></div>`).join('') || '<p>None pending.</p>'}
    <h3>Winner / payout</h3>
    <input id="winner-card-id" type="text" placeholder="Winning card ID">
    <button id="declare-winner-btn">Declare winner</button>
    <button id="mark-payout-btn">Mark payout sent</button>`;

  document.getElementById('save-bg-btn').onclick = async () => {
    const file = document.getElementById('bg-file').files[0];
    if (!file) { alert('Choose a photo first.'); return; }
    const formData = new FormData();
    formData.append('photo', file);
    const res = await fetch('/api/config/background-photo', {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` },
      body: formData,
    });
    if (!res.ok) { alert('Upload failed — try a smaller photo (5MB max).'); return; }
    applyBranding();
    alert('Background photo saved.');
  };
  const removeBtn = document.getElementById('remove-bg-btn');
  if (removeBtn) {
    removeBtn.onclick = async () => {
      await fetch('/api/config/background-photo', { method: 'DELETE', headers: { Authorization: `Bearer ${token}` } });
      applyBranding();
      renderAdmin();
    };
  }
  document.getElementById('create-contest-btn').onclick = async () => {
    const weekNum = Number(document.getElementById('week-num').value);
    const tiebreakerGameId = document.getElementById('tb-game-id').value || undefined;
    await api('/contests', { method: 'POST', body: JSON.stringify({ weekNum, tiebreakerGameId }) });
    currentContest = await api('/contests/current');
    alert('Contest created.');
  };
  document.getElementById('refresh-scores-btn').onclick = async () => {
    if (!currentContest) return;
    await api(`/contests/${currentContest.id}/refresh-scores`, {
      method: 'POST',
      body: JSON.stringify({ weekNum: currentContest.week_num }),
    });
    alert('Scores refreshed.');
  };
  document.querySelectorAll('.mark-paid-btn').forEach((btn) => {
    btn.onclick = async () => { await api(`/payments/${btn.dataset.card}/mark-paid`, { method: 'POST' }); renderAdmin(); };
  });
  document.getElementById('declare-winner-btn').onclick = async () => {
    const cardId = document.getElementById('winner-card-id').value;
    await api(`/admin/contests/${currentContest.id}/declare-winner`, { method: 'POST', body: JSON.stringify({ cardId }) });
    alert('Winner declared.');
  };
  document.getElementById('mark-payout-btn').onclick = async () => {
    await api(`/admin/contests/${currentContest.id}/mark-payout-sent`, { method: 'POST' });
    alert('Payout marked sent.');
  };
}

async function applyBranding() {
  try {
    const site = await fetch('/api/config/site').then((r) => r.json());
    const loginView = document.getElementById('login-view');
    loginView.style.backgroundImage = site.hasBackgroundPhoto
      ? `linear-gradient(rgba(10,10,10,.72), rgba(10,10,10,.92)), url('/api/config/background-photo?t=${Date.now()}')`
      : 'none';
  } catch { /* no background set yet — plain dark card is fine */ }
}
applyBranding();

// ---------- Init ----------
if (token && user) { boot(); } else { document.getElementById('login-view').style.display = 'block'; }
