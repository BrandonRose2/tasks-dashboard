# NFL pick'em pool

## Setup
1. `npm install`
2. Create a Postgres database, then run the migrations in order:
   `sql/schema.sql`, `sql/002_add_games.sql`, `sql/003_add_winner_payout.sql`,
   `sql/004_add_app_settings.sql`, `sql/005_add_background_photo.sql`.
3. Copy `.env.example` to `.env` and fill in `DATABASE_URL`, `JWT_SECRET`, your Twilio
   credentials, and `CRON_SECRET` (any long random string — it's what Cloud Scheduler
   presents so the internal endpoints know a request is legitimate).
4. `npm start` — the app (frontend + API) serves on `PORT` (default 8080).

## What's here

**Frontend** (`public/`) — plain HTML/JS, no build step. Phone OTP login, a picks screen
that pulls that week's matchups (with kickoff time and the tiebreaker game flagged), a
"my cards" screen with the "I've paid" button, a leaderboard, and an admin panel
(create contest, refresh scores, mark payments paid, declare winner, mark payout sent).

**API** (`server/`)
- `routes/auth.js` — phone OTP login, rate-limited to 5 requests per 15 minutes per IP
- `routes/cards.js` — create a card, submit picks (blocked once locked), list your own cards
- `routes/payments.js` — participant "I've paid" report (texts every admin), admin "mark paid"
- `routes/contests.js` — admin creates a week's contest from ESPN's schedule, anyone can view
  that week's matchups or leaderboard, admin refreshes scores
- `routes/admin.js` — payments pending review, audit log, declare winner, mark payout sent
- `routes/internal.js` — cron-only endpoints (`/refresh-scores`, `/send-reminders`), guarded by
  the `x-cron-secret` header rather than a user session
- `lib/espn.js` — schedule/scores/logos from ESPN's public API; computes lock time as the
  earliest kickoff that week
- `lib/scoring.js` — ranks cards by correct picks, tiebreaker resolves ties; unpaid cards still
  appear (flagged `paid: false`) rather than being excluded
- `lib/reminders.js` — texts everyone who hasn't submitted a card yet, called by the cron route
- `lib/twilio.js` — OTP codes, payment-reported alerts, deadline reminders

**Database** — `sql/schema.sql` + two follow-up migrations. `users`, `weekly_contests`,
`games`, `cards`, `payments`, `picks`, `audit_log`.

## First-time admin setup
Every login creates a normal (non-admin) user — including Robert's own first one. After
he logs in once, promote him manually:
```sql
UPDATE users SET is_admin = true WHERE phone = '+1XXXXXXXXXX';
```
Do this before anyone else signs in, so he has the admin tab before real cards start
coming in.

## Payment handles and organizer cut
Set these in `.env` before launch — the app reads them, nothing is hardcoded:
- `ORGANIZER_ZELLE_HANDLE` / `ORGANIZER_CASHAPP_HANDLE` — Robert's real Zelle and Cash App
  info. Shown to participants on the "start a card" screen via `GET /api/config/payment-info`.
  Only Zelle and Cash App are supported (Venmo was dropped — not one of the confirmed methods).
- `ORGANIZER_PERCENTAGE` — defaults to `0.10`. The admin panel's "This week's money" section
  shows total collected, the organizer's cut, and the resulting prize pool
  (`GET /api/admin/contests/:contestId/finances`), computed from actual paid cards each week.

## Background photo
The login screen is a bordered "hero card" ready to take a photo behind the sign-in form
(dark gradient overlay keeps the gold/cyan text readable over anything). Admin uploads it
straight from their device in the Branding section — no URL to find or host. The photo is
stored as bytes directly in Postgres (`background_photo` table, 5MB cap), not on disk,
since Cloud Run's filesystem doesn't survive a redeploy or a second instance. Remove it
from the same panel to fall back to a plain dark card.

## Wiring up the scheduled jobs
These need to actually be triggered by something — Cloud Scheduler is the natural fit next
to Cloud Run. Two jobs:
- Score refresh, every 15–30 min during game windows:
  `POST /api/internal/refresh-scores` with header `x-cron-secret: <your CRON_SECRET>`
  and body `{ "contestId": "...", "weekNum": ... }`
- Reminders, a few times before each week's deadline:
  `POST /api/internal/send-reminders` with the same header and `{ "contestId": "..." }`

## Genuinely still open — not code, judgment calls
- **Legal review.** Robert's own requirements doc flags this: entry fees plus an organizer
  percentage can implicate gambling/contest law depending on the state. That's a real
  attorney's call, not something to ship around.
- **OTP store is in-memory** (a plain `Map` in `auth.js`). Fine for one server process;
  swap for Redis or a DB table before running more than one instance, or restarts will
  silently invalidate pending codes.
- **Hosting/deploy itself** — this is code-complete, but actually standing up Cloud Run,
  Postgres, and Twilio accounts, and pointing DNS at it, is a deployment task, not something
  built into the repo.
