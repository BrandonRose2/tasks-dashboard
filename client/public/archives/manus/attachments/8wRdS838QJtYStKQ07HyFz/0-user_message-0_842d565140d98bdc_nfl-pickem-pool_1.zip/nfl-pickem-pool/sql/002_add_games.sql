CREATE TABLE games (
  id TEXT PRIMARY KEY, -- ESPN's event id, reused as-is
  contest_id UUID NOT NULL REFERENCES weekly_contests(id),
  home_team TEXT NOT NULL,
  away_team TEXT NOT NULL,
  kickoff TIMESTAMPTZ NOT NULL,
  is_tiebreaker BOOLEAN NOT NULL DEFAULT false,
  home_score INTEGER,
  away_score INTEGER,
  status TEXT NOT NULL DEFAULT 'scheduled'
);

CREATE INDEX idx_games_contest ON games(contest_id);

-- Now that games exist, picks should reference real rows instead of a bare string.
ALTER TABLE picks
  ADD CONSTRAINT fk_picks_game FOREIGN KEY (game_id) REFERENCES games(id);
