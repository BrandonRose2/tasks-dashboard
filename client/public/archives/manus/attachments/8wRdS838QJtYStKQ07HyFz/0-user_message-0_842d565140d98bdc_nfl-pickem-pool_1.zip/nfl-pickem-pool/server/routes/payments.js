const express = require('express');
const pool = require('../db');
const { requireAuth, requireAdmin } = require('../middleware/auth');
const { alertAdminPaymentReported } = require('../lib/twilio');

const router = express.Router();

// Participant taps "I've paid" — texts every admin, doesn't confirm payment itself.
router.post('/:cardId/report-paid', requireAuth, async (req, res) => {
  const { cardId } = req.params;

  const { rows } = await pool.query(
    `UPDATE payments SET reported_paid_at = now()
     WHERE card_id = $1 AND card_id IN (SELECT id FROM cards WHERE user_id = $2)
     RETURNING *`,
    [cardId, req.user.id]
  );
  if (!rows[0]) return res.status(404).json({ error: 'Card not found.' });

  const { rows: cardRows } = await pool.query(
    `SELECT c.card_number, u.name, p.method
     FROM cards c
     JOIN users u ON u.id = c.user_id
     JOIN payments p ON p.card_id = c.id
     WHERE c.id = $1`,
    [cardId]
  );
  const { name, card_number, method } = cardRows[0];

  const { rows: admins } = await pool.query('SELECT phone FROM users WHERE is_admin = true');
  await Promise.all(admins.map((a) => alertAdminPaymentReported(a.phone, name, card_number, method)));

  res.json({ reported: true });
});

// Admin confirms a payment — the only thing that actually marks a card paid.
router.post('/:cardId/mark-paid', requireAuth, requireAdmin, async (req, res) => {
  const { cardId } = req.params;

  const { rows } = await pool.query(
    `UPDATE payments SET marked_paid_by = $1, marked_paid_at = now()
     WHERE card_id = $2 RETURNING *`,
    [req.user.id, cardId]
  );
  if (!rows[0]) return res.status(404).json({ error: 'Card not found.' });

  await pool.query("UPDATE cards SET status = 'paid' WHERE id = $1", [cardId]);
  await pool.query(
    "INSERT INTO audit_log (actor_id, action, target_id) VALUES ($1, 'mark_paid', $2)",
    [req.user.id, cardId]
  );

  res.json({ marked: true });
});

module.exports = router;
