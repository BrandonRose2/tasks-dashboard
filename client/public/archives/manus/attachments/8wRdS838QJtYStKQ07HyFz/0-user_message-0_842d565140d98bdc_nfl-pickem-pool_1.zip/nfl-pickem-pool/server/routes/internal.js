const express = require('express');
const { refreshScores } = require('../lib/scoring');
const { sendReminders } = require('../lib/reminders');

const router = express.Router();

// Not a user route — Cloud Scheduler (or any cron) calls these with a shared secret header.
// No JWT involved on purpose: there's no signed-in "user" behind a scheduled job.
function requireCronSecret(req, res, next) {
  if (!process.env.CRON_SECRET || req.headers['x-cron-secret'] !== process.env.CRON_SECRET) {
    return res.status(403).json({ error: 'Forbidden.' });
  }
  next();
}

router.use(requireCronSecret);

router.post('/refresh-scores', async (req, res) => {
  const { contestId, weekNum } = req.body;
  await refreshScores(contestId, weekNum);
  res.json({ refreshed: true });
});

router.post('/send-reminders', async (req, res) => {
  const { contestId } = req.body;
  const result = await sendReminders(contestId);
  res.json(result);
});

module.exports = router;
