const express = require('express');
const multer = require('multer');
const pool = require('../db');
const { requireAuth, requireAdmin } = require('../middleware/auth');

const router = express.Router();
// Memory storage — no disk write, since Cloud Run's filesystem doesn't persist anyway.
// 5MB cap keeps someone from accidentally storing a huge file in the database.
const upload = multer({ limits: { fileSize: 5 * 1024 * 1024 } });

// Real handles live in env, not in code — update .env and redeploy if they ever change.
router.get('/payment-info', requireAuth, (req, res) => {
  res.json({
    zelle: process.env.ORGANIZER_ZELLE_HANDLE || null,
    cashapp: process.env.ORGANIZER_CASHAPP_HANDLE || null,
  });
});

// Public — the login screen checks this before anyone's signed in.
router.get('/site', async (req, res) => {
  const { rows } = await pool.query('SELECT 1 FROM background_photo WHERE id = 1');
  res.json({ hasBackgroundPhoto: rows.length > 0 });
});

// Public — actually serves the stored image bytes, used directly as a CSS background-image URL.
router.get('/background-photo', async (req, res) => {
  const { rows } = await pool.query(
    'SELECT image_data, content_type FROM background_photo WHERE id = 1'
  );
  if (!rows[0]) return res.status(404).end();
  res.set('Content-Type', rows[0].content_type);
  res.set('Cache-Control', 'public, max-age=300');
  res.send(rows[0].image_data);
});

// Admin uploads a photo straight from their device — no URL needed.
router.post('/background-photo', requireAuth, requireAdmin, upload.single('photo'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Choose a photo first.' });
  await pool.query(
    `INSERT INTO background_photo (id, image_data, content_type, updated_at)
     VALUES (1, $1, $2, now())
     ON CONFLICT (id) DO UPDATE SET image_data = EXCLUDED.image_data,
       content_type = EXCLUDED.content_type, updated_at = now()`,
    [req.file.buffer, req.file.mimetype]
  );
  res.json({ saved: true });
});

router.delete('/background-photo', requireAuth, requireAdmin, async (req, res) => {
  await pool.query('DELETE FROM background_photo WHERE id = 1');
  res.json({ removed: true });
});

module.exports = router;
