-- Single-row table: one background photo for the whole app.
CREATE TABLE background_photo (
  id INTEGER PRIMARY KEY DEFAULT 1,
  image_data BYTEA NOT NULL,
  content_type TEXT NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT single_row CHECK (id = 1)
);
