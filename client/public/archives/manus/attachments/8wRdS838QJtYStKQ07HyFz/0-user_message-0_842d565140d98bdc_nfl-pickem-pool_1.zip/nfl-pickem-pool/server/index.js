require('dotenv').config();
const path = require('path');
const express = require('express');

const authRoutes = require('./routes/auth');
const cardRoutes = require('./routes/cards');
const paymentRoutes = require('./routes/payments');
const adminRoutes = require('./routes/admin');
const contestRoutes = require('./routes/contests');
const internalRoutes = require('./routes/internal');
const configRoutes = require('./routes/config');

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

app.use('/api/auth', authRoutes);
app.use('/api/cards', cardRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/contests', contestRoutes);
app.use('/api/internal', internalRoutes);
app.use('/api/config', configRoutes);

const port = process.env.PORT || 8080;
app.listen(port, () => console.log(`Server running on port ${port}`));
