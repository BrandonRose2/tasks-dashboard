ALTER TABLE weekly_contests
  ADD COLUMN winner_card_id UUID REFERENCES cards(id),
  ADD COLUMN winner_declared_at TIMESTAMPTZ,
  ADD COLUMN payout_sent_at TIMESTAMPTZ;
