const express = require('express');
const pool = require('../db');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

// Create a new card for a given week's contest — each call adds one more entry.
router.post('/', requireAuth, async (req, res) => {
  const { contestId, method } = req.body;

  const { rows: existing } = await pool.query(
    'SELECT COUNT(*)::int AS count FROM cards WHERE user_id = $1 AND contest_id = $2',
    [req.user.id, contestId]
  );
  const cardNumber = existing[0].count + 1;

  const { rows } = await pool.query(
    'INSERT INTO cards (user_id, contest_id, card_number) VALUES ($1, $2, $3) RETURNING *',
    [req.user.id, contestId, cardNumber]
  );
  const card = rows[0];

  await pool.query('INSERT INTO payments (card_id, method) VALUES ($1, $2)', [card.id, method]);
  res.json(card);
});

// Submit (or update) picks for a card — rejected once the contest has locked.
router.post('/:cardId/picks', requireAuth, async (req, res) => {
  const { cardId } = req.params;
  const { picks, tiebreakerScore } = req.body; // picks: [{ gameId, pickedTeam }]

  const { rows: cardRows } = await pool.query(
    `SELECT c.*, wc.lock_at FROM cards c
     JOIN weekly_contests wc ON wc.id = c.contest_id
     WHERE c.id = $1 AND c.user_id = $2`,
    [cardId, req.user.id]
  );
  const card = cardRows[0];
  if (!card) return res.status(404).json({ error: 'Card not found.' });
  if (new Date() >= new Date(card.lock_at)) {
    return res.status(400).json({ error: 'Picks are locked for this week.' });
  }

  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    for (const pick of picks) {
      await client.query(
        `INSERT INTO picks (card_id, game_id, picked_team, tiebreaker_score)
         VALUES ($1, $2, $3, $4)
         ON CONFLICT (card_id, game_id)
         DO UPDATE SET picked_team = EXCLUDED.picked_team, tiebreaker_score = EXCLUDED.tiebreaker_score`,
        [cardId, pick.gameId, pick.pickedTeam, tiebreakerScore]
      );
    }
    await client.query('UPDATE cards SET submitted_at = now() WHERE id = $1', [cardId]);
    await client.query('COMMIT');
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }

  res.json({ submitted: true });
});

// List the signed-in participant's own cards, with payment status.
router.get('/mine', requireAuth, async (req, res) => {
  const { rows } = await pool.query(
    `SELECT c.*, p.method, p.reported_paid_at, p.marked_paid_at
     FROM cards c LEFT JOIN payments p ON p.card_id = c.id
     WHERE c.user_id = $1 ORDER BY c.created_at DESC`,
    [req.user.id]
  );
  res.json(rows);
});

module.exports = router;
