const express = require('express');
const jwt = require('jsonwebtoken');
const rateLimit = require('express-rate-limit');
const pool = require('../db');
const { sendOtp } = require('../lib/twilio');

const router = express.Router();

// Swap this Map for Redis or a DB table before running multiple server instances.
const otpStore = new Map(); // phone -> { code, expiresAt }

const otpLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many code requests. Wait a bit and try again.' },
});

router.post('/request-otp', otpLimiter, async (req, res) => {
  const { phone } = req.body;
  if (!phone) return res.status(400).json({ error: 'Enter a phone number.' });

  const code = String(Math.floor(100000 + Math.random() * 900000));
  otpStore.set(phone, { code, expiresAt: Date.now() + 10 * 60 * 1000 });
  await sendOtp(phone, code);
  res.json({ sent: true });
});

router.post('/verify-otp', async (req, res) => {
  const { phone, code, name } = req.body;
  const entry = otpStore.get(phone);

  if (!entry || entry.code !== code || Date.now() > entry.expiresAt) {
    return res.status(400).json({ error: 'That code is wrong or expired.' });
  }
  otpStore.delete(phone);

  let { rows } = await pool.query('SELECT * FROM users WHERE phone = $1', [phone]);
  let user = rows[0];
  if (!user) {
    ({ rows } = await pool.query(
      'INSERT INTO users (phone, name) VALUES ($1, $2) RETURNING *',
      [phone, name || phone]
    ));
    user = rows[0];
  }

  const token = jwt.sign({ userId: user.id }, process.env.JWT_SECRET, { expiresIn: '30d' });
  res.json({ token, user: { id: user.id, name: user.name, isAdmin: user.is_admin } });
});

module.exports = router;
