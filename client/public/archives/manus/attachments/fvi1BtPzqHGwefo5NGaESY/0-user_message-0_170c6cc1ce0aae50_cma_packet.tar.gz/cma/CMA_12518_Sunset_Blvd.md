# Comparative Market Analysis (CMA)

## Subject Property: 12518 W Sunset Blvd, Los Angeles, CA 90049

---

## Property Overview

| Detail | Information |
|--------|-------------|
| **Address** | 12518 W Sunset Blvd, Los Angeles, CA 90049 |
| **Neighborhood** | Brentwood |
| **Property Type** | Single Family Residence |
| **Style** | Modern Tudor Estate |
| **Bedrooms** | 4 |
| **Bathrooms** | 4 Full / 1 Half |
| **Living Area** | 4,500 sq ft |
| **Lot Size** | 8,359 sq ft (0.19 acres) |
| **Year Built** | 1938 (completely reimagined/rebuilt) |
| **Parking** | 3-car garage with EV charging |
| **List Price** | $5,799,000 |
| **Price/Sq Ft** | $1,289 |
| **MLS #** | 26867967 |
| **Listed** | August 10, 2026 |
| **Listed By** | Shelene Atanacio, Engel & Volkers Beverly Hills |

---

## Property Description

Welcome to **Sunset Sanctuary**, a modern Tudor estate completely reimagined from the ground up, minutes from Brentwood Country Club and neighboring $25M+ homes — exceptional value for the area.

**Key Features:**
- Enclosed behind a private 6-foot gate with mature hedges for privacy, safety & discretion
- Circular motor court with EV charging
- Dramatic foyer with open-concept layout connecting dining, kitchen, family room, living room & ADU
- Book-matched Calacatta & Arabescato fireplace surrounds
- Gold-bronze finishes throughout
- Full Thermador suite with built-in espresso machine
- All bedrooms en suite; primary suite with private balcony overlooking pool and giant walk-in closet
- Indoor-outdoor living: pool, fire lounge & outdoor kitchen with entertaining terrace
- Rooftop deck above garage with sweeping views to the west and Getty Museum
- Mr. Steam shower, personal dry-cleaning closet, surround sound, full smart home integration
- Flexible ADU/guest suite, rec room, or income potential
- Located between the ocean and Beverly Hills

---

## Sale History

| Date | Event | Price | $/Sq Ft |
|------|-------|-------|---------|
| Aug 10, 2026 | Listed | $5,799,000 | $1,289 |
| Aug 4, 2026 | Coming Soon | $5,799,000 | $1,289 |
| Nov 23, 2020 | Sold | $2,300,000 | $511 |
| Sep 27, 2020 | Listed | $2,499,000 | $555 |

**Note:** Property was purchased in 2020 for $2.3M and has undergone a complete ground-up reimagination/renovation. The current asking price represents a $3.5M increase over the 2020 purchase price, reflecting the extensive rebuild.

---

## Comparable Sales (Recent Nearby Sold Properties)

### Comp 1: 154 S Anita Ave, Los Angeles, CA 90049

| Detail | Information |
|--------|-------------|
| **Sold Date** | May 29, 2026 |
| **Sold Price** | $5,295,000 |
| **Beds/Baths** | 5 bd / 4 ba |
| **Sq Ft** | 4,150 |
| **Price/Sq Ft** | $1,276 |
| **Lot Size** | Smaller lot than subject |
| **Notes** | Most similar in size and price point |

---

### Comp 2: 12321 20th Helena Dr, Los Angeles, CA 90049

| Detail | Information |
|--------|-------------|
| **Sold Date** | October 22, 2025 |
| **Sold Price** | $6,250,000 |
| **Beds/Baths** | 5 bd / 6 ba |
| **Sq Ft** | 3,600 |
| **Price/Sq Ft** | $1,736 |
| **Lot Size** | Larger lot than subject |
| **Year Built** | 4 years newer |
| **Notes** | Higher $/sqft due to larger lot premium |

---

### Comp 3: 919 S Gretna Green Way, Los Angeles, CA 90049

| Detail | Information |
|--------|-------------|
| **Sold Date** | June 22, 2026 |
| **Sold Price** | $4,892,500 |
| **Beds/Baths** | 5 bd / 5 ba |
| **Sq Ft** | 5,498 |
| **Price/Sq Ft** | $890 |
| **Lot Size** | Smaller lot than subject |
| **Year Built** | 2 years newer |
| **Notes** | Larger home but lower $/sqft; smaller lot reduces value |

---

### Comp 4: 154 N Carmelina Ave, Los Angeles, CA 90049

| Detail | Information |
|--------|-------------|
| **Sold Date** | December 15, 2025 |
| **Sold Price** | $6,937,350 |
| **Beds/Baths** | 5 bd / 7 ba |
| **Sq Ft** | 6,000 |
| **Price/Sq Ft** | $1,156 |
| **Lot Size** | Comparable |
| **Year Built** | 52 years newer |
| **Notes** | Newer construction commands premium |

---

### Comp 5: 1639 Mandeville Canyon Rd, Los Angeles, CA 90049

| Detail | Information |
|--------|-------------|
| **Sold Date** | March 19, 2026 |
| **Sold Price** | $7,625,000 |
| **Beds/Baths** | 5 bd / 6 ba |
| **Sq Ft** | 3,954 |
| **Price/Sq Ft** | $1,928 |
| **Lot Size** | Larger lot than subject |
| **Year Built** | 10 years newer |
| **Notes** | Premium location in Mandeville Canyon; larger lot drives price |

---

### Comp 6: 378 N Skyewiay Rd, Los Angeles, CA 90049

| Detail | Information |
|--------|-------------|
| **Sold Date** | October 21, 2025 |
| **Sold Price** | $5,950,000 |
| **Beds/Baths** | 5 bd / 5 ba |
| **Sq Ft** | 4,675 |
| **Price/Sq Ft** | $1,273 |
| **Lot Size** | Smaller lot than subject |
| **Year Built** | 73 years newer |
| **Notes** | Very comparable in size; newer build but smaller lot |

---

## Market Analysis Summary

| Metric | Value |
|--------|-------|
| **Comparable Sales Range** | $4,892,500 – $7,625,000 |
| **Average Sold Price** | $6,158,308 |
| **Median Sold Price** | $6,100,000 |
| **Average $/Sq Ft** | $1,377 |
| **Subject List Price** | $5,799,000 |
| **Subject $/Sq Ft** | $1,289 |
| **Redfin Estimate** | $5,490,400 |
| **Zillow Zestimate** | $4,737,500 |
| **Days on Market (area avg)** | 41 days |
| **Sale-to-List Ratio (area)** | 100.5% |

---

## Valuation Opinion

| Approach | Estimated Value |
|----------|----------------|
| **Comparable Sales Approach** | $5,400,000 – $6,200,000 |
| **Price Per Sq Ft Approach** (avg $1,377 × 4,500) | $6,196,500 |
| **Redfin Automated Estimate** | $5,490,400 |
| **Zillow Automated Estimate** | $4,737,500 |
| **Suggested Market Value Range** | $5,200,000 – $5,800,000 |

---

## Key Observations

1. **Priced competitively for the area** — At $1,289/sqft, the subject is below the comparable average of $1,377/sqft, positioning it as a value play near $25M+ homes.

2. **Complete renovation adds significant value** — Purchased for $2.3M in 2020 and completely rebuilt. The renovation quality (Thermador, Calacatta marble, smart home, ADU) justifies the premium over the 2020 basis.

3. **Lot size is the constraint** — At 8,359 sqft (0.19 acres), the lot is on the smaller side for Brentwood. Larger lot comps ($6.25M–$7.6M) command premiums specifically for land value.

4. **Strong market conditions** — Brentwood homes priced correctly are selling at or above list in 1–32 days. The area's sale-to-list ratio of 100.5% suggests the subject could achieve full ask.

5. **ADU/income potential** — The flexible guest suite/ADU adds value that most comps don't offer, potentially supporting the upper range of valuation.

6. **Fire risk consideration** — The property has a 5/10 fire factor (6% chance of wildfire in 30 years), which is moderate for the area but worth noting for insurance purposes.

---

## Brentwood Market Context (2026)

- Brentwood Park's 10 biggest sales in H1 2026 totaled ~$121.9M
- Entry point to Brentwood Park: ~$7M+
- Correctly priced homes selling in 1–32 days
- Overpriced homes taking 96 days to 18+ months, closing 20–30% below original ask
- Land value drives the market — buyers underwrite lots, not kitchens
- Off-market activity is significant at the top of the market

---

*CMA prepared August 11, 2026*
*Data sources: Redfin, Zillow, TheMLS, Paul Salazar Group market analysis*
*This analysis is for informational purposes only and does not constitute an appraisal.*
