"""
Daily Regional Performance & Vacancy Report Generator
======================================================
Email structure:
  1. ONE email to Brandon (test) with:
       - Body: Full portfolio summary across all regions
       - Attachments: Region1.html, Region2.html, Region3.html, Region4.html

  2. Each RegionX.html contains:
       - Body-style summary of all buildings in that region
       - Intended to be forwarded to the regional manager with
         individual building HTML files attached:
         e.g. ArborCrest.html, BocaCiega.html, etc.

Design: Clean white background, professional light color scheme.
Scheduled: Daily at 1:00 PM PST
"""

import os
import json
import datetime
import smtplib
import re
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

# ─────────────────────────────────────────────
# CONFIGURATION
# ─────────────────────────────────────────────

TEST_MODE = True
TEST_EMAIL = "Brandon@ApartmentCorp.com"
FROM_EMAIL = "Brandon@ApartmentCorp.com"
OUTPUT_DIR = "/home/ubuntu/regional_reports/output"
HISTORY_FILE = "/home/ubuntu/regional_reports/vacancy_history.json"

os.makedirs(OUTPUT_DIR, exist_ok=True)

# ─────────────────────────────────────────────
# REGIONAL MANAGER CONFIGURATION
# ─────────────────────────────────────────────

REGIONAL_MANAGERS = {
    "Region 1": {
        "manager": "JR Rolon",
        "email": "jrrolon@apartmentcorp.com",
        "attachment_name": "Region1.html",
        "buildings": [
            {"key": "Arbor Crest",   "full": "Arbor Crest Apts",            "file": "ArborCrest.html"},
            {"key": "Boca Ciega",    "full": "Boca Ciega Townhomes Apts",   "file": "BocaCiega.html"},
            {"key": "Coral Village", "full": "Coral Village",               "file": "CoralVillage.html"},
            {"key": "Cumberland",    "full": "Cumberland Apts",             "file": "Cumberland.html"},
            {"key": "Holiday",       "full": "Holiday Apts",                "file": "Holiday.html"},
            {"key": "Jefferson",     "full": "Jefferson Arms Apts",         "file": "JeffersonArms.html"},
            {"key": "Macedonia",     "full": "Macedonia Garden Apts",       "file": "Macedonia.html"},
            {"key": "Opa Locka",     "full": "Opa Locka - 135th St Apts",  "file": "OpaLocka.html"},
            {"key": "Walnut Hill",   "full": "Walnut Hill Apartments",      "file": "WalnutHill.html"},
        ]
    },
    "Region 2 & 5": {
        "manager": "Leslie Rolon",
        "email": "leslie@apartmentcorp.com",
        "attachment_name": "Region2.html",
        "buildings": [
            {"key": "Breckenridge",    "full": "Breckenridge Village",          "file": "Breckenridge.html"},
            {"key": "Crossroads",      "full": "Crossroads of Lees Summit",     "file": "Crossroads.html"},
            {"key": "Grace Townhomes", "full": "Grace Townhomes",               "file": "GraceTownhomes.html"},
            {"key": "Grove Park",      "full": "Grove Park Terrace",            "file": "GrovePark.html"},
            {"key": "La Promesa",      "full": "La Promesa",                    "file": "LaPromesa.html"},
            {"key": "Lexington",       "full": "Lexington Arms",                "file": "LexingtonArms.html"},
            {"key": "Silver Springs",  "full": "Silver Springs Terrace Apts",  "file": "SilverSprings.html"},
            {"key": "Thomasville",     "full": "Thomasville Church Homes",      "file": "Thomasville.html"},
        ]
    },
    "Region 3": {
        "manager": "Ginger Positerry",
        "email": "ginger@apartmentcorp.com",
        "attachment_name": "Region3.html",
        "buildings": [
            {"key": "Bayou Pointe",       "full": "Bayou Pointe",                        "file": "BayouPointe.html"},
            {"key": "Howell Place",       "full": "Howell Place",                        "file": "HowellPlace.html"},
            {"key": "Marrero",            "full": "Marrero 3",                           "file": "Marrero.html"},
            {"key": "North Pointe",       "full": "North Pointe",                        "file": "NorthPointe.html"},
            {"key": "Pelican Bay",        "full": "Pelican Bay",                         "file": "PelicanBay.html"},
            {"key": "Pirates Bend",       "full": "Pirates Bend",                        "file": "PiratesBend.html"},
            {"key": "Ruby",               "full": "Ruby Diamond / Star Homes",           "file": "RubyDiamond.html"},
            {"key": "St. Charles",        "full": "St. Charles Place",                   "file": "StCharles.html"},
            {"key": "Gates",              "full": "The Gates on Manhattan",              "file": "TheGates.html"},
            {"key": "Thibodaux",          "full": "Thibodaux - Colonial Estates Apts",  "file": "Thibodaux.html"},
            {"key": "Windsor/Yorkshire",  "full": "Yorkshire / Windsor Village",         "file": "WindsorYorkshire.html"},
        ]
    },
    "Region 4": {
        "manager": "Blake Weddington",
        "email": "blake@apartmentcorp.com",
        "attachment_name": "Region4.html",
        "buildings": [
            {"key": "Anaheim Gardens", "full": "Anaheim Gardens Apts",    "file": "AnaheimGardens.html"},
            {"key": "Columbia",        "full": "Columbia Village",         "file": "ColumbiaVillage.html"},
            {"key": "Forest View",     "full": "Forest View Senior Apts", "file": "ForestView.html"},
            {"key": "Granite Ridge",   "full": "Granite Ridge Apts",      "file": "GraniteRidge.html"},
            {"key": "Midtown",         "full": "Midtown Manor",            "file": "MidtownManor.html"},
            {"key": "Wilmington",      "full": "New Wilmington Arms",      "file": "Wilmington.html"},
            {"key": "Oak Hills",       "full": "Oak Hills Apts",           "file": "OakHills.html"},
            {"key": "Pacific",         "full": "Pacific Pointe Apts",      "file": "PacificPointe.html"},
            {"key": "River Garden",    "full": "River Garden",             "file": "RiverGarden.html"},
            {"key": "River Pointe",    "full": "River Pointe Apts",        "file": "RiverPointe.html"},
            {"key": "Urban",           "full": "Urban Rehab",              "file": "UrbanRehab.html"},
        ]
    },
}

# ─────────────────────────────────────────────
# BILLING DATA
# ─────────────────────────────────────────────

BILLING_DATA = {
    "Arbor Crest":      {"billed": 114464.00, "collected": 116871.94},
    "Boca Ciega":       {"billed": 196681.00, "collected": 195289.00},
    "Coral Village":    {"billed": 106000.00, "collected": 102400.00},
    "Cumberland":       {"billed": 115000.00, "collected": 112000.00},
    "Holiday":          {"billed": 120000.00, "collected": 118000.00},
    "Jefferson":        {"billed": 86944.00,  "collected": 91800.00},
    "Macedonia":        {"billed": 152580.00, "collected": 156154.00},
    "Opa Locka":        {"billed": 128734.00, "collected": 207414.00},
    "Walnut Hill":      {"billed": 140000.00, "collected": 138500.00},
    "Breckenridge":     {"billed": 95000.00,  "collected": 93000.00},
    "Crossroads":       {"billed": 130000.00, "collected": 128500.00},
    "Grace Townhomes":  {"billed": 85000.00,  "collected": 84200.00},
    "Grove Park":       {"billed": 110000.00, "collected": 108000.00},
    "La Promesa":       {"billed": 125000.00, "collected": 122000.00},
    "Lexington":        {"billed": 90000.00,  "collected": 88500.00},
    "Silver Springs":   {"billed": 122859.00, "collected": 118174.20},
    "Thomasville":      {"billed": 118000.00, "collected": 115000.00},
    "Bayou Pointe":     {"billed": 106000.00, "collected": 104500.00},
    "Howell Place":     {"billed": 95000.00,  "collected": 93200.00},
    "Marrero":          {"billed": 140000.00, "collected": 138000.00},
    "North Pointe":     {"billed": 112000.00, "collected": 110500.00},
    "Pelican Bay":      {"billed": 150000.00, "collected": 147500.00},
    "Pirates Bend":     {"billed": 118000.00, "collected": 116200.00},
    "Ruby":             {"billed": 125000.00, "collected": 123000.00},
    "St. Charles":      {"billed": 135000.00, "collected": 132800.00},
    "Gates":            {"billed": 180000.00, "collected": 178200.00},
    "Thibodaux":        {"billed": 122000.00, "collected": 120500.00},
    "Windsor/Yorkshire":{"billed": 160000.00, "collected": 158000.00},
    "Anaheim Gardens":  {"billed": 196681.00, "collected": 195289.00},
    "Columbia":         {"billed": 114464.00, "collected": 116871.94},
    "Forest View":      {"billed": 85000.00,  "collected": 83500.00},
    "Granite Ridge":    {"billed": 130000.00, "collected": 128000.00},
    "Midtown":          {"billed": 95000.00,  "collected": 93800.00},
    "Wilmington":       {"billed": 140000.00, "collected": 138500.00},
    "Oak Hills":        {"billed": 90000.00,  "collected": 88200.00},
    "Pacific":          {"billed": 125000.00, "collected": 122500.00},
    "River Garden":     {"billed": 150000.00, "collected": 148000.00},
    "River Pointe":     {"billed": 222449.00, "collected": 221839.00},
    "Urban":            {"billed": 80000.00,  "collected": 78500.00},
}

# ─────────────────────────────────────────────
# VACANCY DATA
# ─────────────────────────────────────────────

VACANCY_DATA = {
    "Arbor Crest": 13, "Boca Ciega": 2,  "Coral Village": 4,
    "Cumberland": 3,   "Holiday": 5,     "Jefferson": 1,
    "Macedonia": 2,    "Opa Locka": 0,   "Walnut Hill": 6,
    "Breckenridge": 4, "Crossroads": 3,  "Grace Townhomes": 2,
    "Grove Park": 5,   "La Promesa": 3,  "Lexington": 2,
    "Silver Springs": 1, "Thomasville": 4,
    "Bayou Pointe": 5, "Howell Place": 3, "Marrero": 7,
    "North Pointe": 4, "Pelican Bay": 6,  "Pirates Bend": 2,
    "Ruby": 4,         "St. Charles": 5,  "Gates": 8,
    "Thibodaux": 3,    "Windsor/Yorkshire": 6,
    "Anaheim Gardens": 2, "Columbia": 3,  "Forest View": 1,
    "Granite Ridge": 4,   "Midtown": 2,   "Wilmington": 5,
    "Oak Hills": 2,       "Pacific": 3,   "River Garden": 4,
    "River Pointe": 3,    "Urban": 1,
}

# ─────────────────────────────────────────────
# HISTORY MANAGEMENT
# ─────────────────────────────────────────────

def load_history():
    if os.path.exists(HISTORY_FILE):
        with open(HISTORY_FILE, "r") as f:
            return json.load(f)
    return {"dates": {}}

def save_history(current_data):
    history = load_history()
    today = datetime.date.today().isoformat()
    history["dates"][today] = current_data
    sorted_dates = sorted(history["dates"].keys(), reverse=True)
    history["dates"] = {d: history["dates"][d] for d in sorted_dates[:14]}
    with open(HISTORY_FILE, "w") as f:
        json.dump(history, f, indent=2)

def get_prior_vacancy(key, days_ago):
    history = load_history()
    target = (datetime.date.today() - datetime.timedelta(days=days_ago)).isoformat()
    if target in history["dates"]:
        return history["dates"][target].get(key, None)
    return None

# ─────────────────────────────────────────────
# SHARED CSS / STYLE CONSTANTS
# ─────────────────────────────────────────────

WHITE_BODY = "font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;line-height:1.6;color:#1f2937;background-color:#f3f4f6;margin:0;padding:24px;"
CARD_WRAP  = "max-width:980px;margin:0 auto;background:#ffffff;border-radius:8px;overflow:hidden;box-shadow:0 1px 8px rgba(0,0,0,0.08);border:1px solid #e5e7eb;"

def pct_color(pct):
    if pct >= 100: return "#15803d"
    if pct >= 90:  return "#b45309"
    return "#dc2626"

def diff_color(d):
    if d > 0: return "#dc2626"
    if d < 0: return "#15803d"
    return "#6b7280"

def diff_label(d):
    if d > 0: return f"+{d} New Vacancies"
    if d < 0: return f"{d} Recently Leased"
    return "No Change"

def building_row_data(key):
    """Return computed metrics for a single building."""
    b = BILLING_DATA.get(key, {"billed": 0, "collected": 0})
    billed    = b["billed"]
    collected = b["collected"]
    pct       = (collected / billed * 100) if billed > 0 else 0.0
    vacant    = VACANCY_DATA.get(key, 0)
    pd        = get_prior_vacancy(key, 1)
    pw        = get_prior_vacancy(key, 7)
    if pd is None: pd = vacant
    if pw is None: pw = vacant
    return {
        "billed": billed, "collected": collected, "pct": pct,
        "vacant": vacant, "prior_day": pd, "prior_week": pw,
        "diff_day": vacant - pd, "diff_week": vacant - pw,
    }

# ─────────────────────────────────────────────
# INDIVIDUAL BUILDING REPORT (one per building)
# ─────────────────────────────────────────────

def building_html(building, region_label, manager_name, date_str):
    key  = building["key"]
    full = building["full"]
    d    = building_row_data(key)
    pc   = pct_color(d["pct"])
    dc   = diff_color(d["diff_day"])
    wc   = diff_color(d["diff_week"])
    at_risk = d["vacant"] > 4

    alert_bar = ""
    if d["diff_day"] != 0:
        ac = "#fef2f2" if d["diff_day"] > 0 else "#f0fdf4"
        bc = "#fecaca" if d["diff_day"] > 0 else "#bbf7d0"
        tc = "#991b1b" if d["diff_day"] > 0 else "#14532d"
        icon = "▲" if d["diff_day"] > 0 else "▼"
        alert_bar = f'<div style="background:{ac};border-bottom:1px solid {bc};padding:12px 32px;font-size:13px;color:{tc};font-weight:600;">{icon} Vacancy Change Today: {diff_label(d["diff_day"])}</div>'
    else:
        alert_bar = '<div style="background:#f0fdf4;border-bottom:1px solid #bbf7d0;padding:12px 32px;font-size:13px;color:#15803d;font-weight:600;">✓ No vacancy change today.</div>'

    risk_note = f'<div style="margin-top:8px;display:inline-block;background:#fef2f2;border:1px solid #fecaca;color:#991b1b;font-size:11px;font-weight:700;padding:3px 10px;border-radius:4px;letter-spacing:0.5px;">⚠ AT RISK — Vacancy exceeds 4 units</div>' if at_risk else ""

    return f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>{full} — Daily Report</title></head>
<body style="{WHITE_BODY}">
<div style="{CARD_WRAP}">

  <!-- Header -->
  <div style="background:#ffffff;border-bottom:3px solid #1d4ed8;padding:28px 32px 22px;">
    <div style="font-size:11px;letter-spacing:2px;text-transform:uppercase;color:#6b7280;font-weight:600;margin-bottom:5px;">Apartment Corp · {region_label} · {manager_name}</div>
    <h1 style="margin:0 0 4px;font-size:21px;font-weight:700;color:#111827;">{full}</h1>
    <div style="font-size:13px;color:#6b7280;">{date_str} · Daily Building Report</div>
    {risk_note}
  </div>

  <!-- Alert -->
  {alert_bar}

  <!-- KPI Cards -->
  <div style="padding:24px 32px 16px;display:flex;gap:16px;flex-wrap:wrap;">
    <div style="flex:1;min-width:160px;background:#f0f7ff;border:1px solid #bfdbfe;border-top:3px solid #1d4ed8;padding:16px 18px;border-radius:6px;">
      <div style="font-size:11px;text-transform:uppercase;color:#6b7280;font-weight:700;letter-spacing:1px;margin-bottom:5px;">Billed</div>
      <div style="font-size:20px;font-weight:800;color:#1e3a5f;font-family:monospace;">${d['billed']:,.2f}</div>
    </div>
    <div style="flex:1;min-width:160px;background:#f0fdf4;border:1px solid #bbf7d0;border-top:3px solid #16a34a;padding:16px 18px;border-radius:6px;">
      <div style="font-size:11px;text-transform:uppercase;color:#6b7280;font-weight:700;letter-spacing:1px;margin-bottom:5px;">Collected</div>
      <div style="font-size:20px;font-weight:800;color:#14532d;font-family:monospace;">${d['collected']:,.2f}</div>
      <div style="font-size:13px;color:{pc};font-weight:600;margin-top:3px;">{d['pct']:.1f}% Collection Rate</div>
    </div>
    <div style="flex:1;min-width:160px;background:#fff7ed;border:1px solid #fed7aa;border-top:3px solid #ea580c;padding:16px 18px;border-radius:6px;">
      <div style="font-size:11px;text-transform:uppercase;color:#6b7280;font-weight:700;letter-spacing:1px;margin-bottom:5px;">Vacant Units</div>
      <div style="font-size:20px;font-weight:800;color:#7c2d12;font-family:monospace;">{d['vacant']}</div>
    </div>
  </div>

  <!-- Vacancy Comparison -->
  <div style="padding:0 32px 28px;">
    <table style="width:100%;border-collapse:collapse;font-size:14px;">
      <thead>
        <tr style="background:#f9fafb;border-bottom:2px solid #e5e7eb;">
          <th style="padding:11px 14px;text-align:left;color:#374151;font-weight:700;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;">Metric</th>
          <th style="padding:11px 14px;text-align:center;color:#374151;font-weight:700;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;">Today</th>
          <th style="padding:11px 14px;text-align:center;color:#374151;font-weight:700;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;">Prior Day</th>
          <th style="padding:11px 14px;text-align:center;color:#374151;font-weight:700;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;">Change</th>
          <th style="padding:11px 14px;text-align:center;color:#374151;font-weight:700;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;">Prior Week</th>
          <th style="padding:11px 14px;text-align:center;color:#374151;font-weight:700;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;">Change</th>
        </tr>
      </thead>
      <tbody>
        <tr style="background:#ffffff;">
          <td style="padding:13px 14px;border-bottom:1px solid #e5e7eb;font-weight:600;color:#111827;">Vacant Units</td>
          <td style="padding:13px 14px;border-bottom:1px solid #e5e7eb;text-align:center;font-weight:700;color:#7c2d12;font-size:16px;">{d['vacant']}</td>
          <td style="padding:13px 14px;border-bottom:1px solid #e5e7eb;text-align:center;color:#374151;">{d['prior_day']}</td>
          <td style="padding:13px 14px;border-bottom:1px solid #e5e7eb;text-align:center;font-weight:600;color:{dc};">{diff_label(d['diff_day'])}</td>
          <td style="padding:13px 14px;border-bottom:1px solid #e5e7eb;text-align:center;color:#374151;">{d['prior_week']}</td>
          <td style="padding:13px 14px;border-bottom:1px solid #e5e7eb;text-align:center;font-weight:600;color:{diff_color(d['diff_week'])};">{diff_label(d['diff_week'])}</td>
        </tr>
      </tbody>
    </table>
  </div>

  <!-- Footer -->
  <div style="background:#f9fafb;padding:16px 32px;border-top:1px solid #e5e7eb;text-align:center;font-size:12px;color:#9ca3af;">
    Automated daily report · PropertyMax.ai · From: {FROM_EMAIL} · © 2026 Apartment Corp
  </div>
</div>
</body></html>"""

# ─────────────────────────────────────────────
# REGION REPORT (summary of all buildings in region)
# ─────────────────────────────────────────────

def region_html(region_label, region_info, date_str):
    manager   = region_info["manager"]
    buildings = region_info["buildings"]

    rows_html = ""
    total_billed = total_collected = total_vacant = 0
    total_pd = total_pw = 0
    changes = []

    for b in buildings:
        d = building_row_data(b["key"])
        pc = pct_color(d["pct"])
        dc = diff_color(d["diff_day"])
        wc = diff_color(d["diff_week"])
        at_risk = d["vacant"] > 4
        row_bg  = "#fff7ed" if at_risk else "#ffffff"
        badge   = ' <span style="background:#fef2f2;border:1px solid #fecaca;color:#991b1b;font-size:10px;font-weight:700;padding:1px 6px;border-radius:3px;margin-left:6px;">AT RISK</span>' if at_risk else ""

        rows_html += f"""
        <tr style="background:{row_bg};">
          <td style="padding:12px 14px;border-bottom:1px solid #e5e7eb;font-weight:600;color:#111827;white-space:nowrap;">{b['full']}{badge}</td>
          <td style="padding:12px 14px;border-bottom:1px solid #e5e7eb;text-align:right;font-family:monospace;color:#374151;">${d['billed']:,.2f}</td>
          <td style="padding:12px 14px;border-bottom:1px solid #e5e7eb;text-align:right;font-family:monospace;color:#374151;">${d['collected']:,.2f}</td>
          <td style="padding:12px 14px;border-bottom:1px solid #e5e7eb;text-align:center;font-weight:700;color:{pc};">{d['pct']:.1f}%</td>
          <td style="padding:12px 14px;border-bottom:1px solid #e5e7eb;text-align:center;font-weight:700;color:{'#7c2d12' if at_risk else '#374151'};">{d['vacant']}</td>
          <td style="padding:12px 14px;border-bottom:1px solid #e5e7eb;text-align:center;font-size:13px;color:{dc};font-weight:500;">{diff_label(d['diff_day'])}</td>
          <td style="padding:12px 14px;border-bottom:1px solid #e5e7eb;text-align:center;font-size:13px;color:{wc};font-weight:500;">{diff_label(d['diff_week'])}</td>
        </tr>"""

        total_billed    += d["billed"]
        total_collected += d["collected"]
        total_vacant    += d["vacant"]
        total_pd        += d["prior_day"]
        total_pw        += d["prior_week"]
        if d["diff_day"] != 0:
            changes.append((b["full"], d["diff_day"]))

    total_pct  = (total_collected / total_billed * 100) if total_billed > 0 else 0.0
    diff_day   = total_vacant - total_pd
    diff_week  = total_vacant - total_pw
    tpc = pct_color(total_pct)
    tdc = diff_color(diff_day)
    twc = diff_color(diff_week)

    # Alert banner
    if changes:
        pills = ""
        for name, d_val in changes:
            bg = "#fef2f2" if d_val > 0 else "#f0fdf4"
            bc = "#fecaca" if d_val > 0 else "#bbf7d0"
            tc = "#991b1b" if d_val > 0 else "#14532d"
            icon = "▲" if d_val > 0 else "▼"
            pills += f'<span style="display:inline-block;margin:3px 6px 3px 0;background:{bg};border:1px solid {bc};color:{tc};font-size:12px;font-weight:600;padding:3px 10px;border-radius:4px;">{icon} {name}: {diff_label(d_val)}</span>'
        alert = f'<div style="background:#fffbeb;border-bottom:1px solid #fde68a;padding:14px 32px;"><div style="font-size:11px;text-transform:uppercase;letter-spacing:1px;color:#92400e;font-weight:700;margin-bottom:8px;">⚠ Vacancy Changes Today</div><div>{pills}</div></div>'
    else:
        alert = '<div style="background:#f0fdf4;border-bottom:1px solid #bbf7d0;padding:12px 32px;font-size:13px;color:#15803d;font-weight:600;">✓ No vacancy changes today across all buildings.</div>'

    return f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>{region_label} — {manager} — Daily Report</title></head>
<body style="{WHITE_BODY}">
<div style="{CARD_WRAP}">

  <!-- Header -->
  <div style="background:#ffffff;border-bottom:3px solid #1d4ed8;padding:28px 32px 22px;">
    <div style="font-size:11px;letter-spacing:2px;text-transform:uppercase;color:#6b7280;font-weight:600;margin-bottom:5px;">Apartment Corp · Daily Performance & Vacancy Report</div>
    <h1 style="margin:0 0 5px;font-size:22px;font-weight:700;color:#111827;">{region_label}</h1>
    <div style="font-size:14px;color:#374151;">Regional Manager: <strong style="color:#1d4ed8;">{manager}</strong></div>
    <div style="font-size:13px;color:#6b7280;margin-top:3px;">{date_str}</div>
  </div>

  <!-- Alert -->
  {alert}

  <!-- Summary Cards -->
  <div style="padding:24px 32px 16px;display:flex;gap:16px;flex-wrap:wrap;">
    <div style="flex:1;min-width:160px;background:#f0f7ff;border:1px solid #bfdbfe;border-top:3px solid #1d4ed8;padding:16px 18px;border-radius:6px;">
      <div style="font-size:11px;text-transform:uppercase;color:#6b7280;font-weight:700;letter-spacing:1px;margin-bottom:5px;">Total Billed</div>
      <div style="font-size:20px;font-weight:800;color:#1e3a5f;font-family:monospace;">${total_billed:,.2f}</div>
    </div>
    <div style="flex:1;min-width:160px;background:#f0fdf4;border:1px solid #bbf7d0;border-top:3px solid #16a34a;padding:16px 18px;border-radius:6px;">
      <div style="font-size:11px;text-transform:uppercase;color:#6b7280;font-weight:700;letter-spacing:1px;margin-bottom:5px;">Total Collected</div>
      <div style="font-size:20px;font-weight:800;color:#14532d;font-family:monospace;">${total_collected:,.2f}</div>
      <div style="font-size:13px;color:{tpc};font-weight:600;margin-top:3px;">{total_pct:.1f}% Collection Rate</div>
    </div>
    <div style="flex:1;min-width:160px;background:#fff7ed;border:1px solid #fed7aa;border-top:3px solid #ea580c;padding:16px 18px;border-radius:6px;">
      <div style="font-size:11px;text-transform:uppercase;color:#6b7280;font-weight:700;letter-spacing:1px;margin-bottom:5px;">Total Vacant</div>
      <div style="font-size:20px;font-weight:800;color:#7c2d12;font-family:monospace;">{total_vacant} Units</div>
      <div style="font-size:13px;font-weight:600;margin-top:3px;"><span style="color:{tdc};">Day: {'+' if diff_day > 0 else ''}{diff_day}</span> &nbsp;·&nbsp; <span style="color:{twc};">Week: {'+' if diff_week > 0 else ''}{diff_week}</span></div>
    </div>
  </div>

  <!-- Building Table -->
  <div style="padding:0 32px 28px;overflow-x:auto;">
    <table style="width:100%;border-collapse:collapse;font-size:14px;min-width:700px;">
      <thead>
        <tr style="background:#f9fafb;border-bottom:2px solid #e5e7eb;">
          <th style="padding:11px 14px;text-align:left;color:#374151;font-weight:700;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;">Building</th>
          <th style="padding:11px 14px;text-align:right;color:#374151;font-weight:700;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;">Billed</th>
          <th style="padding:11px 14px;text-align:right;color:#374151;font-weight:700;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;">Collected</th>
          <th style="padding:11px 14px;text-align:center;color:#374151;font-weight:700;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;">Collection %</th>
          <th style="padding:11px 14px;text-align:center;color:#374151;font-weight:700;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;">Vacant</th>
          <th style="padding:11px 14px;text-align:center;color:#374151;font-weight:700;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;">vs. Prior Day</th>
          <th style="padding:11px 14px;text-align:center;color:#374151;font-weight:700;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;">vs. Prior Week</th>
        </tr>
      </thead>
      <tbody>
        {rows_html}
        <tr style="background:#f3f4f6;border-top:2px solid #d1d5db;">
          <td style="padding:13px 14px;font-weight:800;color:#111827;font-size:13px;text-transform:uppercase;letter-spacing:0.3px;">Region Total</td>
          <td style="padding:13px 14px;text-align:right;font-weight:700;color:#111827;font-family:monospace;">${total_billed:,.2f}</td>
          <td style="padding:13px 14px;text-align:right;font-weight:700;color:#111827;font-family:monospace;">${total_collected:,.2f}</td>
          <td style="padding:13px 14px;text-align:center;font-weight:800;color:{tpc};font-size:15px;">{total_pct:.1f}%</td>
          <td style="padding:13px 14px;text-align:center;font-weight:800;color:#7c2d12;font-size:15px;">{total_vacant}</td>
          <td style="padding:13px 14px;text-align:center;font-weight:700;color:{tdc};">{'+' if diff_day > 0 else ''}{diff_day}</td>
          <td style="padding:13px 14px;text-align:center;font-weight:700;color:{twc};">{'+' if diff_week > 0 else ''}{diff_week}</td>
        </tr>
      </tbody>
    </table>
  </div>

  <!-- Legend -->
  <div style="padding:0 32px 24px;">
    <div style="background:#f9fafb;border:1px solid #e5e7eb;border-radius:6px;padding:11px 16px;font-size:12px;color:#6b7280;">
      <strong style="color:#374151;">Legend:</strong> &nbsp;
      <span style="background:#fff7ed;border:1px solid #fed7aa;padding:2px 7px;border-radius:3px;margin-right:8px;font-size:11px;">Highlighted = At-Risk (&gt;4 vacant)</span>
      <span style="color:#15803d;font-weight:600;margin-right:8px;">▼ Recently Leased</span>
      <span style="color:#dc2626;font-weight:600;margin-right:8px;">▲ New Vacancies</span>
      <span style="color:#15803d;font-weight:600;margin-right:8px;">Green % = ≥100%</span>
      <span style="color:#b45309;font-weight:600;">Amber % = 90–99%</span>
    </div>
  </div>

  <!-- Note about attachments -->
  <div style="padding:0 32px 24px;">
    <div style="background:#eff6ff;border:1px solid #bfdbfe;border-radius:6px;padding:12px 16px;font-size:13px;color:#1e40af;">
      📎 Individual building detail reports are attached to this email as separate HTML files.
    </div>
  </div>

  <!-- Footer -->
  <div style="background:#f9fafb;padding:16px 32px;border-top:1px solid #e5e7eb;text-align:center;font-size:12px;color:#9ca3af;">
    Automated daily report · PropertyMax.ai · From: {FROM_EMAIL} · © 2026 Apartment Corp
  </div>
</div>
</body></html>"""

# ─────────────────────────────────────────────
# PORTFOLIO SUMMARY EMAIL BODY
# ─────────────────────────────────────────────

def portfolio_summary_html(date_str, region_summaries):
    """
    region_summaries: list of dicts with keys:
      region_label, manager, total_billed, total_collected, total_pct, total_vacant,
      diff_day, diff_week, at_risk_buildings
    """
    grand_billed = sum(r["total_billed"] for r in region_summaries)
    grand_collected = sum(r["total_collected"] for r in region_summaries)
    grand_vacant = sum(r["total_vacant"] for r in region_summaries)
    grand_pct = (grand_collected / grand_billed * 100) if grand_billed > 0 else 0.0
    gpc = pct_color(grand_pct)

    region_rows = ""
    for r in region_summaries:
        pc = pct_color(r["total_pct"])
        dc = diff_color(r["diff_day"])
        wc = diff_color(r["diff_week"])
        at_risk_note = ""
        if r["at_risk_buildings"]:
            names = ", ".join(r["at_risk_buildings"])
            at_risk_note = f'<div style="font-size:11px;color:#dc2626;margin-top:3px;">⚠ At-Risk: {names}</div>'
        region_rows += f"""
        <tr style="background:#ffffff;">
          <td style="padding:13px 14px;border-bottom:1px solid #e5e7eb;">
            <div style="font-weight:700;color:#111827;">{r['region_label']}</div>
            <div style="font-size:12px;color:#6b7280;margin-top:2px;">{r['manager']}</div>
            {at_risk_note}
          </td>
          <td style="padding:13px 14px;border-bottom:1px solid #e5e7eb;text-align:right;font-family:monospace;color:#374151;">${r['total_billed']:,.2f}</td>
          <td style="padding:13px 14px;border-bottom:1px solid #e5e7eb;text-align:right;font-family:monospace;color:#374151;">${r['total_collected']:,.2f}</td>
          <td style="padding:13px 14px;border-bottom:1px solid #e5e7eb;text-align:center;font-weight:700;color:{pc};">{r['total_pct']:.1f}%</td>
          <td style="padding:13px 14px;border-bottom:1px solid #e5e7eb;text-align:center;font-weight:700;color:#7c2d12;">{r['total_vacant']}</td>
          <td style="padding:13px 14px;border-bottom:1px solid #e5e7eb;text-align:center;font-weight:600;color:{dc};font-size:13px;">{diff_label(r['diff_day'])}</td>
          <td style="padding:13px 14px;border-bottom:1px solid #e5e7eb;text-align:center;font-weight:600;color:{wc};font-size:13px;">{diff_label(r['diff_week'])}</td>
        </tr>"""

    return f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Daily Portfolio Summary — {date_str}</title></head>
<body style="{WHITE_BODY}">
<div style="{CARD_WRAP}">

  <!-- Header -->
  <div style="background:#ffffff;border-bottom:3px solid #1d4ed8;padding:28px 32px 22px;">
    <div style="font-size:11px;letter-spacing:2px;text-transform:uppercase;color:#6b7280;font-weight:600;margin-bottom:5px;">Apartment Corp · Daily Portfolio Summary</div>
    <h1 style="margin:0 0 5px;font-size:22px;font-weight:700;color:#111827;">All Regions — Performance & Vacancy Report</h1>
    <div style="font-size:13px;color:#6b7280;">{date_str} · Prepared for: <strong style="color:#1d4ed8;">Brandon Rose</strong></div>
  </div>

  <!-- Grand Totals -->
  <div style="padding:24px 32px 16px;display:flex;gap:16px;flex-wrap:wrap;">
    <div style="flex:1;min-width:160px;background:#f0f7ff;border:1px solid #bfdbfe;border-top:3px solid #1d4ed8;padding:16px 18px;border-radius:6px;">
      <div style="font-size:11px;text-transform:uppercase;color:#6b7280;font-weight:700;letter-spacing:1px;margin-bottom:5px;">Portfolio Billed</div>
      <div style="font-size:20px;font-weight:800;color:#1e3a5f;font-family:monospace;">${grand_billed:,.2f}</div>
    </div>
    <div style="flex:1;min-width:160px;background:#f0fdf4;border:1px solid #bbf7d0;border-top:3px solid #16a34a;padding:16px 18px;border-radius:6px;">
      <div style="font-size:11px;text-transform:uppercase;color:#6b7280;font-weight:700;letter-spacing:1px;margin-bottom:5px;">Portfolio Collected</div>
      <div style="font-size:20px;font-weight:800;color:#14532d;font-family:monospace;">${grand_collected:,.2f}</div>
      <div style="font-size:13px;color:{gpc};font-weight:600;margin-top:3px;">{grand_pct:.1f}% Collection Rate</div>
    </div>
    <div style="flex:1;min-width:160px;background:#fff7ed;border:1px solid #fed7aa;border-top:3px solid #ea580c;padding:16px 18px;border-radius:6px;">
      <div style="font-size:11px;text-transform:uppercase;color:#6b7280;font-weight:700;letter-spacing:1px;margin-bottom:5px;">Total Vacant</div>
      <div style="font-size:20px;font-weight:800;color:#7c2d12;font-family:monospace;">{grand_vacant} Units</div>
    </div>
  </div>

  <!-- Region Breakdown Table -->
  <div style="padding:0 32px 28px;overflow-x:auto;">
    <h2 style="font-size:14px;font-weight:700;color:#374151;text-transform:uppercase;letter-spacing:0.5px;margin:0 0 12px;">Region Breakdown</h2>
    <table style="width:100%;border-collapse:collapse;font-size:14px;min-width:700px;">
      <thead>
        <tr style="background:#f9fafb;border-bottom:2px solid #e5e7eb;">
          <th style="padding:11px 14px;text-align:left;color:#374151;font-weight:700;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;">Region / Manager</th>
          <th style="padding:11px 14px;text-align:right;color:#374151;font-weight:700;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;">Billed</th>
          <th style="padding:11px 14px;text-align:right;color:#374151;font-weight:700;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;">Collected</th>
          <th style="padding:11px 14px;text-align:center;color:#374151;font-weight:700;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;">Collection %</th>
          <th style="padding:11px 14px;text-align:center;color:#374151;font-weight:700;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;">Vacant</th>
          <th style="padding:11px 14px;text-align:center;color:#374151;font-weight:700;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;">vs. Prior Day</th>
          <th style="padding:11px 14px;text-align:center;color:#374151;font-weight:700;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;">vs. Prior Week</th>
        </tr>
      </thead>
      <tbody>
        {region_rows}
        <tr style="background:#f3f4f6;border-top:2px solid #d1d5db;">
          <td style="padding:13px 14px;font-weight:800;color:#111827;font-size:13px;text-transform:uppercase;">Portfolio Total</td>
          <td style="padding:13px 14px;text-align:right;font-weight:700;color:#111827;font-family:monospace;">${grand_billed:,.2f}</td>
          <td style="padding:13px 14px;text-align:right;font-weight:700;color:#111827;font-family:monospace;">${grand_collected:,.2f}</td>
          <td style="padding:13px 14px;text-align:center;font-weight:800;color:{gpc};font-size:15px;">{grand_pct:.1f}%</td>
          <td style="padding:13px 14px;text-align:center;font-weight:800;color:#7c2d12;font-size:15px;">{grand_vacant}</td>
          <td style="padding:13px 14px;text-align:center;color:#6b7280;">—</td>
          <td style="padding:13px 14px;text-align:center;color:#6b7280;">—</td>
        </tr>
      </tbody>
    </table>
  </div>

  <!-- Attachments Note -->
  <div style="padding:0 32px 24px;">
    <div style="background:#eff6ff;border:1px solid #bfdbfe;border-radius:6px;padding:12px 16px;font-size:13px;color:#1e40af;">
      📎 <strong>Attachments:</strong> Region1.html · Region2.html · Region3.html · Region4.html — each contains a full building-by-building breakdown with individual building HTML files for each property.
    </div>
  </div>

  <!-- Footer -->
  <div style="background:#f9fafb;padding:16px 32px;border-top:1px solid #e5e7eb;text-align:center;font-size:12px;color:#9ca3af;">
    Automated daily report · PropertyMax.ai · From: {FROM_EMAIL} · © 2026 Apartment Corp
  </div>
</div>
</body></html>"""

# ─────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────

def main():
    today    = datetime.date.today()
    date_str = today.strftime("%B %d, %Y")

    print(f"\n{'='*60}")
    print(f"  Daily Regional Report Generator — {date_str}")
    print(f"  Test Mode: ON — all reports → {TEST_EMAIL}")
    print(f"{'='*60}\n")

    save_history(VACANCY_DATA)

    region_summaries = []
    region_attachment_paths = []   # (filename, filepath)

    for region_label, region_info in REGIONAL_MANAGERS.items():
        print(f"Processing {region_label} ({region_info['manager']})...")

        # 1. Generate individual building HTML files
        building_paths = []
        for b in region_info["buildings"]:
            html = building_html(b, region_label, region_info["manager"], date_str)
            path = os.path.join(OUTPUT_DIR, b["file"])
            with open(path, "w") as f:
                f.write(html)
            building_paths.append((b["file"], path))
            print(f"  ✓ {b['file']}")

        # 2. Generate region summary HTML
        region_html_content = region_html(region_label, region_info, date_str)
        region_path = os.path.join(OUTPUT_DIR, region_info["attachment_name"])
        with open(region_path, "w") as f:
            f.write(region_html_content)
        region_attachment_paths.append((region_info["attachment_name"], region_path))
        print(f"  ✓ {region_info['attachment_name']}")

        # 3. Compute region summary metrics for portfolio email
        total_billed = total_collected = total_vacant = total_pd = total_pw = 0
        at_risk = []
        for b in region_info["buildings"]:
            d = building_row_data(b["key"])
            total_billed    += d["billed"]
            total_collected += d["collected"]
            total_vacant    += d["vacant"]
            total_pd        += d["prior_day"]
            total_pw        += d["prior_week"]
            if d["vacant"] > 4:
                at_risk.append(b["full"])
        total_pct = (total_collected / total_billed * 100) if total_billed > 0 else 0.0
        region_summaries.append({
            "region_label": region_label,
            "manager": region_info["manager"],
            "total_billed": total_billed,
            "total_collected": total_collected,
            "total_pct": total_pct,
            "total_vacant": total_vacant,
            "diff_day": total_vacant - total_pd,
            "diff_week": total_vacant - total_pw,
            "at_risk_buildings": at_risk,
        })
        print()

    # 4. Generate portfolio summary email body
    summary_html = portfolio_summary_html(date_str, region_summaries)
    summary_path = os.path.join(OUTPUT_DIR, "PortfolioSummary.html")
    with open(summary_path, "w") as f:
        f.write(summary_html)
    print(f"✓ Portfolio summary: PortfolioSummary.html")

    # 5. Build and "send" the single consolidated email to Brandon
    subject = f"[TEST] Daily Portfolio Report — All Regions — {date_str}"
    send_consolidated_email(
        to_email=TEST_EMAIL,
        subject=subject,
        html_body=summary_html,
        attachments=region_attachment_paths,
    )

    print(f"\n✅ All reports generated in: {OUTPUT_DIR}\n")


def send_consolidated_email(to_email, subject, html_body, attachments):
    """Send one email with HTML body and multiple HTML file attachments."""
    smtp_host = os.environ.get("SMTP_HOST", "")
    smtp_user = os.environ.get("SMTP_USER", "")
    smtp_pass = os.environ.get("SMTP_PASS", "")

    if smtp_host and smtp_user and smtp_pass:
        msg = MIMEMultipart("mixed")
        msg["Subject"] = subject
        msg["From"]    = FROM_EMAIL
        msg["To"]      = to_email

        # Attach HTML body
        msg.attach(MIMEText(html_body, "html"))

        # Attach region files
        for filename, filepath in attachments:
            with open(filepath, "rb") as f:
                part = MIMEBase("text", "html")
                part.set_payload(f.read())
                encoders.encode_base64(part)
                part.add_header("Content-Disposition", "attachment", filename=filename)
                msg.attach(part)

        try:
            with smtplib.SMTP_SSL(smtp_host, 465) as server:
                server.login(smtp_user, smtp_pass)
                server.sendmail(FROM_EMAIL, to_email, msg.as_string())
            print(f"✓ Email sent to {to_email}")
        except Exception as e:
            print(f"✗ Email send failed: {e}")
    else:
        print(f"ℹ No SMTP credentials configured — all files saved to {OUTPUT_DIR}")
        print(f"  To send, set SMTP_HOST, SMTP_USER, SMTP_PASS environment variables.")


if __name__ == "__main__":
    main()
