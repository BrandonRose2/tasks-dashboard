# Boca Ciega Townhomes — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 1482145**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/05/2026 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Manager name | ______________________________ |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Availability PDF | `1482145_Boca Ciega Townhomes_Availability_1954058.pdf` |
| Delinquency spreadsheet(s) | `1482145_Boca Ciega Townhomes_Delinquent and Prepaid - Excel_1954129.xls`<br>`1482145_Boca Ciega Townhomes_Delinquent and Prepaid_1954094.xls` |
| Spreadsheet comparison | Review variance: 104 vs. 0 rows; -$17,989.47 net-balance difference |
| Ledger accounts for review | 84 resident accounts |
| Residents with amount owed | 2 accounts; $1,465.00 |
| Prepaid / credit accounts | 82 accounts; $19,454.47 |
| Availability entries | 1 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit’s reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| 9-41 | 2BFLAT | Vacant Not Leased Not Ready | [ ] Verified | __________________ |


## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 15 - 68 | Baker, Ashley B | Owes balance | $0.00 | $880.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 23 | Reid, Donna | Owes balance | $0.00 | $585.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |


## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - 2 | Moto, Silverina | Prepaid / credit | $1,149.85 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 3 | Rodriguez, Erika | Prepaid / credit | $164.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 4 | Marble, Bernadette | Prepaid / credit | $245.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 5 | Ross, Gladys L | Prepaid / credit | $47.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 10 - 42 | Seay, Daryl J | Prepaid / credit | $118.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 10 - 43 | Plummer, Thelma | Prepaid / credit | $30.00 | $0.00 | -$30.00 | [ ] Confirm paid | — |
| 10 - 44 | St Jean, Fergus | Prepaid / credit | $24.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 10 - 46 | Dukes, Ashley M | Prepaid / credit | $50.50 | $0.00 | -$50.50 | [ ] Confirm paid | — |
| 11 - 50 | Wiggan, Kellyann T | Prepaid / credit | $6.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 11 - 51 | Mota, Grailin P | Prepaid / credit | $197.00 | $0.00 | -$197.00 | [ ] Confirm paid | — |
| 11 - 53 | Candelario, Yolanda | Prepaid / credit | $128.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 11 - 54 | De Los Santos, Virginia E | Prepaid / credit | $400.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 11 - 55 | Whitfield, Dartavia | Prepaid / credit | $1,172.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 12 - 106 | Rivera, Joselyn | Prepaid / credit | $126.29 | $0.00 | -$126.29 | [ ] Confirm paid | — |
| 13 - 100 | Hernandez, Angelina O | Prepaid / credit | $73.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 13 - 101 | Jones, Martha | Prepaid / credit | $213.80 | $0.00 | -$56.80 | [ ] Confirm paid | — |
| 13 - 102 | Tramel, R N | Prepaid / credit | $44.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 13 - 103 | Demota, Antonia | Prepaid / credit | $352.00 | $0.00 | -$325.00 | [ ] Confirm paid | — |
| 13 - 105 | Madison, Tayshaun | Prepaid / credit | $134.00 | $0.00 | -$134.00 | [ ] Confirm paid | — |
| 14 - 73 | Santos Martinez, Magaly | Prepaid / credit | $159.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 14 - 74 | Newton, Sheretta | Prepaid / credit | $25.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 14 - 75 | Smith, Arnetta M | Prepaid / credit | $433.00 | $0.00 | -$433.00 | [ ] Confirm paid | — |
| 14 - 76 | Gordon, Kimberly | Prepaid / credit | $74.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 14 - 77 | Mcintosh, Katrina | Prepaid / credit | $202.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 15 - 67 | Maldonado Nieves, MariangelyM | Prepaid / credit | $324.00 | $0.00 | -$84.00 | [ ] Confirm paid | — |
| 15 - 69 | Craft, Nerline M | Prepaid / credit | $157.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 15 - 70 | Broward, SHANNEL L | Prepaid / credit | $299.00 | $0.00 | -$299.00 | [ ] Confirm paid | — |
| 16 - 62 | Mitchell, Decener L | Prepaid / credit | $8.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 16 - 63 | Caicedo, KEYLA S | Prepaid / credit | $731.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 16 - 65 | Alfonso Hernandez, Yeraldine | Prepaid / credit | $302.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 16 - 66 | James, Shelene | Prepaid / credit | $55.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 17 - 78 | Katina, Shorter | Prepaid / credit | $10.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 17 - 79 | Alexander, Shadae | Prepaid / credit | $10.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 17 - 80 | Faulk, Ashley | Prepaid / credit | $228.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 17 - 82 | Guilbeaux Martinez, Josue | Prepaid / credit | $3.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 18 - 83 | Bonilla, Rene | Prepaid / credit | $434.00 | $0.00 | -$170.00 | [ ] Confirm paid | — |
| 18 - 84 | Placencia, Nayeli | Prepaid / credit | $761.00 | $0.00 | -$761.00 | [ ] Confirm paid | — |
| 18 - 85 | Salas Mendez, Doris J | Prepaid / credit | $221.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 19 - 88 | Delgado Vilchez, Oskalit | Prepaid / credit | $15.00 | $0.00 | -$15.00 | [ ] Confirm paid | — |
| 19 - 89 | Garvey, Rashauna C | Prepaid / credit | $15.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 19 - 91 | Batista, Francisca A | Prepaid / credit | $165.00 | $0.00 | -$105.00 | [ ] Confirm paid | — |
| 19 - 92 | Zorrilla De Medina, Mayran M | Prepaid / credit | $48.00 | $0.00 | -$48.00 | [ ] Confirm paid | — |
| 19 - 93 | Boyd, Deja L | Prepaid / credit | $1,344.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 19 - 94 | Benmoussa, Imane | Prepaid / credit | $2.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 10 | Nuez Fermin, Yuderkis | Prepaid / credit | $75.00 | $0.00 | -$75.00 | [ ] Confirm paid | — |
| 2 - 6 | TALLEY, LIONDA | Prepaid / credit | $5.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 7 | Gordon, Sharee | Prepaid / credit | $508.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 8 | Pearson, Sierra M | Prepaid / credit | $20.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 9 | Shubert, Donna | Prepaid / credit | $80.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 20 - 96 | Reid, Dyani I | Prepaid / credit | $173.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 20 - 97 | Maldonado, Milagros | Prepaid / credit | $49.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 20 - 98 | Bright, Loretta | Prepaid / credit | $176.99 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 20 - 99 | Albert, Mamie | Prepaid / credit | $103.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 21 | Garcia Franco, Jeicha | Prepaid / credit | $1,386.00 | $0.00 | -$1,386.00 | [ ] Confirm paid | — |
| 3 - 22 | Garcia-franco, Awilda | Prepaid / credit | $55.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 24 | Rodriguez De Los Sant, Mayerlin V | Prepaid / credit | $649.00 | $0.00 | -$649.00 | [ ] Confirm paid | — |
| 3 - 25 | Skelton, Renita S | Prepaid / credit | $390.00 | $0.00 | -$292.00 | [ ] Confirm paid | — |
| 3 - 26 | Nikulaidis, ColleenM | Prepaid / credit | $60.00 | $0.00 | -$15.00 | [ ] Confirm paid | — |
| 4 - 56 | Nong, Vicky N | Prepaid / credit | $30.00 | $0.00 | -$30.00 | [ ] Confirm paid | — |
| 4 - 58 | Nelson, Berry | Prepaid / credit | $157.00 | $0.00 | -$157.00 | [ ] Confirm paid | — |
| 4 - 59 | Williams, Shibraille | Prepaid / credit | $23.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 11 | Ford, Shiquita | Prepaid / credit | $348.00 | $0.00 | -$348.00 | [ ] Confirm paid | — |
| 5 - 12 | Frere, Jesula P | Prepaid / credit | $303.00 | $0.00 | -$303.00 | [ ] Confirm paid | — |
| 5 - 14 | Perez, Kairaliz M | Prepaid / credit | $1,140.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 15 | Mota, Lucrecia | Prepaid / credit | $54.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 16 | Walcott, Gabrylle | Prepaid / credit | $7.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 6 - 17 | Perry, Doretha | Prepaid / credit | $56.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 6 - 19 | Ramirez, Wanda | Prepaid / credit | $6.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 6 - 20 | Uyeda, Idalena F | Prepaid / credit | $564.10 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 7 - 27 | Nazario, Hector | Prepaid / credit | $56.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 7 - 28 | Stadom, Patricia | Prepaid / credit | $296.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 7 - 29 | Brown, Arsha S | Prepaid / credit | $14.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 7 - 30 | James, Denise L | Prepaid / credit | $16.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 7 - 31 | GARCIA RIO, YANEIXI | Prepaid / credit | $25.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 8 - 32 | Brown, Andrea R | Prepaid / credit | $577.00 | $0.00 | -$115.00 | [ ] Confirm paid | — |
| 8 - 33 | Boyd, Shaina Z | Prepaid / credit | $41.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 8 - 34 | Wilson, Tamesha | Prepaid / credit | $2.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 8 - 35 | Liepe, Robert | Prepaid / credit | $35.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 9 - 36 | Roquemore, Teresa | Prepaid / credit | $110.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 9 - 37 | St Jean, Raquel | Prepaid / credit | $225.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 9 - 38 | Griffin, Margaret | Prepaid / credit | $913.94 | $0.00 | -$688.94 | [ ] Confirm paid | — |
| 9 - 39 | Johnson, Grace E | Prepaid / credit | $26.00 | $0.00 | $0.00 | [ ] Confirm paid | — |


## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.


## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property’s supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*
