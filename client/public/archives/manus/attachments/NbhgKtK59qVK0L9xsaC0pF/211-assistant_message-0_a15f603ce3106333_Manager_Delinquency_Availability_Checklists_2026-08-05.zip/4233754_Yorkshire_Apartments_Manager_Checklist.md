# Yorkshire Apartments — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 4233754**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/04/2026 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Manager name | ______________________________ |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Availability PDF | `4233754_Yorkshire Apartments_Availability_1954074.pdf` |
| Delinquency spreadsheet(s) | `4233754_Yorkshire Apartments_Delinquent and Prepaid - Excel_1954144.xls`<br>`4233754_Yorkshire Apartments_Delinquent and Prepaid_1954109.xls` |
| Spreadsheet comparison | Review variance: 84 vs. 0 rows; -$1,646.89 net-balance difference |
| Ledger accounts for review | 59 resident accounts |
| Residents with amount owed | 27 accounts; $5,246.70 |
| Prepaid / credit accounts | 32 accounts; $6,893.59 |
| Availability entries | 3 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit’s reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| 5-507 | 1B1B | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 16-1603 | 2B1B | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 19-1901 | 2B1B | Vacant Not Leased Not Ready | [ ] Verified | __________________ |


## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - 101 | Douglas, Valoria E | Owes balance | $0.00 | $170.20 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 104 | Howard, April Berince | Owes balance | $0.00 | $286.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1002 | Patterson, Lillie M | Owes balance | $0.00 | $10.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1004 | Bates, Reshiada R | Owes balance | $0.00 | $98.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1102 | Collins, Jamie R | Owes balance | $0.00 | $369.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1103 | Griffin, Diana Rena | Owes balance | $0.00 | $201.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1202 | Avertte-Jones, Amya | Owes balance | $0.00 | $21.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1203 | McGee, Rhonda | Owes balance | $0.00 | $226.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1401 | McCoy, Charmeda Sharisse | Owes balance | $0.00 | $111.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1402 | Bullock, Tammy T | Owes balance | $0.00 | $97.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1404 | Thomas, Nicole | Owes balance | $0.00 | $56.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15 - 1501 | Hinton, Brittney Nicole | Owes balance | $0.00 | $60.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15 - 1503 | Wood, Holly | Owes balance | $0.00 | $385.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 1601 | Morris, Phyllis Marie | Owes balance | $0.00 | $261.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 1602 | Johnson, Anquinette L | Owes balance | $0.00 | $139.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 1604 | Martinez, Toni Ann | Owes balance | $0.00 | $1,147.50 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 1702 | Williams, Mary Belle | Owes balance | $0.00 | $63.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18 - 1802 | Sanders Jr, Carl Kelvin | Owes balance | $0.00 | $87.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 303 | Boykins, Felix | Owes balance | $0.00 | $12.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 405 | Colbert, Linda Marie | Owes balance | $0.00 | $24.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 504 | Jackson, Queen | Owes balance | $0.00 | $131.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 603 | Jones, Victoria A | Owes balance | $0.00 | $174.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 604 | Thomas, Adriana L | Owes balance | $0.00 | $227.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 703 | Johnson, Rolanda A | Owes balance | $0.00 | $26.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 704 | Little, Marvette R | Owes balance | $0.00 | $12.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 801 | Goines, Krystal | Owes balance | $0.00 | $483.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 802 | Morris, RobinR | Owes balance | $0.00 | $370.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |


## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 10 - 1001 | Washington, Carolyn Dawkins | Prepaid / credit | $21.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 11 - 1101 | White, Samantha M | Prepaid / credit | $1,491.00 | $0.00 | -$1,356.00 | [ ] Confirm paid | — |
| 12 - 1201 | Milton, LeandreLamour | Prepaid / credit | $45.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 13 - 1301 | Stewart, Kadisha R | Prepaid / credit | $75.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 13 - 1303 | Heard, Rhonda D | Prepaid / credit | $699.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 13 - 1304 | Hill, Jerice F | Prepaid / credit | $26.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 15 - 1502 | Barlow, Jennifer L | Prepaid / credit | $860.00 | $0.00 | -$245.00 | [ ] Confirm paid | — |
| 15 - 1504 | Gardner, Shakari LaQuincey | Prepaid / credit | $64.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 18 - 1801 | Clark, Kadija Tauntrese | Prepaid / credit | $64.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 18 - 1803 | Jackson, Latasha L | Prepaid / credit | $7.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 18 - 1804 | Edwards, Roger L | Prepaid / credit | $94.59 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 19 - 1902 | Jefferson, Dainh D | Prepaid / credit | $2.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 19 - 1903 | Edmond, Mary L | Prepaid / credit | $260.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 19 - 1904 | Grant, Gloria Williams | Prepaid / credit | $257.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 201 | Priest, Gloria Jean | Prepaid / credit | $10.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 204 | Walker, Angela Denise | Prepaid / credit | $42.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 20 - 2001 | Moore, Geraldine A | Prepaid / credit | $74.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 20 - 2002 | Buffin, Alexandra A | Prepaid / credit | $42.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 20 - 2003 | Moore, Chakawanna S | Prepaid / credit | $63.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 20 - 2004 | Merritt, Douglas | Prepaid / credit | $816.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 302 | Savannah, Alice Faye | Prepaid / credit | $15.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 304 | McDaniel, Beverly H | Prepaid / credit | $85.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - 401 | Linear, Laura W | Prepaid / credit | $863.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - 406 | Collins, Natalie C | Prepaid / credit | $42.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - 408 | Battle, Shaun J | Prepaid / credit | $56.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 503 | Cathron, Twania Y | Prepaid / credit | $47.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 505 | Lane, Sakeythia Vershay | Prepaid / credit | $45.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 506 | Haynes, Derrick | Prepaid / credit | $4.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 508 | Anderson, Farley | Prepaid / credit | $389.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 6 - 602 | Kincade, Ebony S | Prepaid / credit | $133.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 7 - 702 | Danielson, Amanda Nicole | Prepaid / credit | $5.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 8 - 902 | Dismukes, Shannon I | Prepaid / credit | $197.00 | $0.00 | $0.00 | [ ] Confirm paid | — |


## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.


## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property’s supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*
