# Granite Ridge Apartments — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 3990059**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/04/2026 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Manager name | ______________________________ |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Availability PDF | `3990059_Granite Ridge Apartments_Availability_1954069.pdf` |
| Delinquency spreadsheet(s) | `3990059_Granite Ridge Apartments_Delinquent and Prepaid - Excel_1954139.xls`<br>`3990059_Granite Ridge Apartments_Delinquent and Prepaid_1954104.xls` |
| Spreadsheet comparison | Review variance: 63 vs. 0 rows; -$2,073.80 net-balance difference |
| Ledger accounts for review | 57 resident accounts |
| Residents with amount owed | 15 accounts; $11,777.00 |
| Prepaid / credit accounts | 42 accounts; $13,850.80 |
| Availability entries | 5 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit’s reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| 1-73 | 2B1B | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 4-32 | 1B1B | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 1-78 | 1B1B | NTV Not Leased | [ ] Verified | __________________ |
| 3-60 | 2B1B | NTV Not Leased | [ ] Verified | __________________ |
| 3-64 | 1B1B | NTV Not Leased | [ ] Verified | __________________ |


## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - 74 | Barakat, Ashadieeyah | Owes balance | $0.00 | $980.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 10 | Dominguez, Tonya Rosemarie | Owes balance | $0.00 | $738.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 12 | Monserrat, Rosalie M | Owes balance | $0.00 | $912.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 14 | Thayer, Tina | Owes balance | $0.00 | $50.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 7 | Thayer, Heather | Owes balance | $0.00 | $150.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 49 | Avey, Jacqueline Kelly | Owes balance | $0.00 | $91.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 56 | Gutierrez, Jessica Annalinda | Owes balance | $0.00 | $49.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 60 | Robinson, Celena | Owes balance | $0.00 | $2,246.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 61 | Centeno, David | Owes balance | $0.00 | $28.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 64 | Suggs, Oscar | Owes balance | $0.00 | $4,841.00 | $1,550.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 23 | Lopez, Irene Marie | Owes balance | $0.00 | $1.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 25 | Evans, Ebony Nichole | Owes balance | $0.00 | $344.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 41 | Hour, Savoeuth | Owes balance | $0.00 | $1,257.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 42 | Bongcaron, Shari | Owes balance | $0.00 | $50.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 48 | Sandoval, Steve | Owes balance | $0.00 | $40.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |


## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - 67 | Williams, Brenda | Prepaid / credit | $5.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 70 | Meza, Maria Viridiana | Prepaid / credit | $395.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 72 | McKay, Mikalei Helena | Prepaid / credit | $39.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 75 | Wakefield, Kim | Prepaid / credit | $3,621.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 77 | Mai, Phung | Prepaid / credit | $6.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 79 | Golden, Chistopher | Prepaid / credit | $5.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 80 | Griffin Jr, Richard Lee | Prepaid / credit | $62.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 1 | Brooks, Jerome Reginald | Prepaid / credit | $0.25 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 11 | Varela, Monique Angel | Prepaid / credit | $280.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 13 | Adams, Betty | Prepaid / credit | $81.35 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 15 | Hood, Cora | Prepaid / credit | $11.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 3 | Sauter, Deborah | Prepaid / credit | $24.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 4 | Gooden, Joanne Rochelle | Prepaid / credit | $10.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 5 | Mainopaz, Ermele | Prepaid / credit | $15.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 6 | Lent, Rachael Marie | Prepaid / credit | $3,060.00 | $0.00 | -$2,452.00 | [ ] Confirm paid | — |
| 2 - 8 | Nickerson, Ella | Prepaid / credit | $4.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 9 | Ramsey, Tearesa Luvenia | Prepaid / credit | $2,412.00 | $0.00 | -$1,602.00 | [ ] Confirm paid | — |
| 3 - 50 | Moore, Telisa Lanette | Prepaid / credit | $226.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 52 | Enriquez, Celeste Renee | Prepaid / credit | $985.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 57 | Segura Ochoa, Maribel | Prepaid / credit | $75.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 59 | Roman, Kaori | Prepaid / credit | $440.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 62 | Hunt, Steven Eugene | Prepaid / credit | $16.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 63 | Nguyen, Mai | Prepaid / credit | $186.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - 17 | Mack, Debra Lynn | Prepaid / credit | $120.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - 20 | Gaines, Snorah | Prepaid / credit | $50.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - 21 | Flores, Vanessa Irene | Prepaid / credit | $55.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - 22 | Nguyen, Thien | Prepaid / credit | $61.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - 24 | Williams, Georgneshia | Prepaid / credit | $57.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - 27 | Macaraeg, Rolando Abolencia | Prepaid / credit | $221.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - 29 | Marshall, Jeff | Prepaid / credit | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - 30 | Whitfield, Charles Leo | Prepaid / credit | $32.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - 31 | Hunter, Pernell | Prepaid / credit | $127.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 33 | Rodriguez, Tammy Lynn | Prepaid / credit | $13.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 34 | Blount, Demetria deshawn | Prepaid / credit | $297.30 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 35 | Odom, Deborah | Prepaid / credit | $34.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 36 | Johnson, Jimmie | Prepaid / credit | $261.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 38 | Ingham, Sean | Prepaid / credit | $55.40 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 40 | Durham, Tonya Lee | Prepaid / credit | $95.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 44 | Ojeda, Valentino A | Prepaid / credit | $25.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 45 | Zanini, Dino Frank | Prepaid / credit | $14.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 46 | Lo, Chong | Prepaid / credit | $324.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 47 | Villanueba, Yolanda May | Prepaid / credit | $49.50 | $0.00 | $0.00 | [ ] Confirm paid | — |


## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.


## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property’s supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*
