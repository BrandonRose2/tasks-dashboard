# Crossroads of Lees Summit — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 5661023**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/05/2026 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Manager name | ______________________________ |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Availability PDF | `5661023_Crossroads of Lees Summit_Availability_1954089.pdf` |
| Delinquency spreadsheet(s) | `5661023_Crossroads of Lees Summit_Delinquent and Prepaid - Excel_1954159.xls`<br>`5661023_Crossroads of Lees Summit_Delinquent and Prepaid_1954124.xls` |
| Spreadsheet comparison | Review variance: 95 vs. 0 rows; $9,560.07 net-balance difference |
| Ledger accounts for review | 69 resident accounts |
| Residents with amount owed | 31 accounts; $21,104.76 |
| Prepaid / credit accounts | 38 accounts; $11,544.69 |
| Availability entries | 11 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit’s reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| 10-1002 | L3BC60CL | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 17-1705 | L3BC60CL | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 01-0106 | L3BC60CL | NTV Not Leased | [ ] Verified | __________________ |
| 04-0408 | L3BC60CL | NTV Not Leased | [ ] Verified | __________________ |
| 06-0601 | L3BC60CL | NTV Not Leased | [ ] Verified | __________________ |
| 09-0903 | L2BC60CL | NTV Not Leased | [ ] Verified | __________________ |
| 09-0905 | L2BC60CL | NTV Not Leased | [ ] Verified | __________________ |
| 12-1204 | L3BC60CL | NTV Not Leased | [ ] Verified | __________________ |
| 13-1306 | L2BC60CL | NTV Not Leased | [ ] Verified | __________________ |
| 14-1402 | L3BC60CL | NTV Not Leased | [ ] Verified | __________________ |
| As | of | NTV Not Leased | [ ] Verified | __________________ |


## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 02 - 0201 | Harrison, Ebony D | Owes balance | $0.00 | $180.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | 04/14/2026 |
| 02 - 0207 | Schwark, Ashley L | Owes balance | $0.00 | $435.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | 04/14/2026 |
| 03 - 0308 | Jones 1, Partice | Owes balance | $0.00 | $307.54 | $307.54 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | 04/14/2026 |
| 04 - 0401 | Russell, Kyera | Owes balance | $0.00 | $167.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | 04/14/2026 |
| 04 - 0403 | Scott, Precious Shaneece | Owes balance | $0.00 | $710.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | 04/14/2026 |
| 04 - 0406 | Cooper, LaTanya Sharifa Aina | Owes balance | $0.00 | $400.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | 04/14/2026 |
| 05 - 0506 | Love, Briana | Owes balance | $0.00 | $2.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05 - 0508 | Gardner, NaishiaO | Owes balance | $0.00 | $2,129.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | 04/15/2026 |
| 06 - 0601 | Black, Alisha | Owes balance | $0.00 | $84.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 07 - 0706 | *Luster, Corletta | Owes balance | $0.00 | $774.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | 04/15/2026 |
| 08 - 0806 | Nooner, Janay E | Owes balance | $0.00 | $683.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | 04/14/2026 |
| 08 - 0808 | Roberts, Iakita S | Owes balance | $0.00 | $75.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | 04/14/2026 |
| 09 - 0908 | Monroe, India | Owes balance | $0.00 | $875.74 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | 04/15/2026 |
| 11 - 1108 | Trabon, Morgan | Owes balance | $0.00 | $1,319.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | 04/14/2026 |
| 12 - 1207 | Adkins, Brianna Elaine | Owes balance | $0.00 | $35.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1303 | Turner, AliciaDenise | Owes balance | $0.00 | $61.50 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1306 | Jackson-Powell, AnitaGale | Owes balance | $0.00 | $5.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1401 | Randle, Maya Ann | Owes balance | $0.00 | $792.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | 04/14/2026 |
| 14 - 1404 | Khiev, Christina | Owes balance | $0.00 | $1,315.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | 04/14/2026 |
| 14 - 1405 | *Cline, Timothy | Owes balance | $0.00 | $2,170.39 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | 03/09/2026 |
| 14 - 1406 | Brock, LarishaMichelle | Owes balance | $0.00 | $410.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | 04/14/2026 |
| 14 - 1408 | Taylor, MishonAbri | Owes balance | $0.00 | $362.47 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | 04/14/2026 |
| 15 - 1507 | Bolanos, RosalbaMireya | Owes balance | $0.00 | $22.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 1605 | Day, Kelly E | Owes balance | $0.00 | $407.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | 04/14/2026 |
| 17 - 1704 | Smith, Shashawn Latrice | Owes balance | $0.00 | $730.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | 04/14/2026 |
| 18 - 1801 | Clark, Amber | Owes balance | $0.00 | $1,345.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | 04/14/2026 |
| 18 - 1802 | Warrior, Keesha | Owes balance | $0.00 | $594.02 | $594.02 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | 04/14/2026 |
| 18 - 1806 | Jackson, Brittany Kiara | Owes balance | $0.00 | $1,225.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | 04/14/2026 |
| 19 - 1901 | Dawson, Katelyn Sharell | Owes balance | $0.00 | $5.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19 - 1903 | Killingsworth Jackson, Brittany Tenea | Owes balance | $0.00 | $269.10 | $92.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | 04/14/2026 |
| 20 - 2004 | *Champions, Keianna | Owes balance | $0.00 | $3,215.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | 02/13/2026 |


## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 01 - 0105 | Milton, Miranna | Prepaid / credit | $961.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 01 - 0106 | Williams, Tamika L | Prepaid / credit | $7.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 02 - 0205 | Kemp Pickens, Annette Irene | Prepaid / credit | $13.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 02 - 0208 | Boldridge, Joyce | Prepaid / credit | $48.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 03 - 0306 | Dickerson, Monchel m | Prepaid / credit | $100.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 03 - 0307 | Hodge, Barbara J | Prepaid / credit | $9.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 04 - 0408 | Haynes, Melisa D | Prepaid / credit | $0.96 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 05 - 0504 | Rollins, Talisa R | Prepaid / credit | $8.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 06 - 0603 | Deberry, Taytiana | Prepaid / credit | $7.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 08 - 0805 | Sullivan, Karen | Prepaid / credit | $27.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 08 - 0807 | Robinson, Tamisa | Prepaid / credit | $81.00 | $0.00 | -$81.00 | [ ] Confirm paid | — |
| 09 - 0906 | Wilkerson, Latoya Lunett | Prepaid / credit | $4.00 | $0.00 | -$4.00 | [ ] Confirm paid | — |
| 10 - 1001 | Henderson, Xzaviara e | Prepaid / credit | $23.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 10 - 1006 | Gaston, Nikia Bernice | Prepaid / credit | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 11 - 1102 | Swinney, TraMaine | Prepaid / credit | $185.00 | $0.00 | -$185.00 | [ ] Confirm paid | — |
| 11 - 1104 | Merrill, ErinNichole | Prepaid / credit | $475.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 12 - 1201 | Robertson, Elizabeth | Prepaid / credit | $0.04 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 12 - 1203 | Ersery, Dianne L | Prepaid / credit | $88.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 12 - 1204 | Hyman, Charlzetta Denise | Prepaid / credit | $200.00 | $0.00 | -$200.00 | [ ] Confirm paid | — |
| 12 - 1205 | Johnson, Chantae Nicole | Prepaid / credit | $18.98 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 12 - 1206 | Crawford, Kichawn | Prepaid / credit | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 13 - 1308 | Harrington, Stephanie A | Prepaid / credit | $1,079.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 14 - 1407 | Sylvan, D'Nesha M | Prepaid / credit | $461.00 | $0.00 | -$461.00 | [ ] Confirm paid | — |
| 15 - 1501 | Love, Printess A | Prepaid / credit | $1,953.00 | $0.00 | -$1,538.00 | [ ] Confirm paid | — |
| 15 - 1508 | Thomas, Briana Aliya | Prepaid / credit | $6.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 16 - 1602 | Maupin, Angela L | Prepaid / credit | $0.50 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 16 - 1604 | Morris, Diane | Prepaid / credit | $7.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 16 - 1606 | Smith, Tammra S | Prepaid / credit | $77.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 16 - 1607 | Moss, Re'Keya J | Prepaid / credit | $318.00 | $0.00 | -$318.00 | [ ] Confirm paid | — |
| 17 - 1706 | Weaver, Jesse D | Prepaid / credit | $195.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 18 - 1804 | Taylor, Ki'erra | Prepaid / credit | $2,809.42 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 19 - 1902 | Turner, LaVeraM | Prepaid / credit | $45.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 19 - 1904 | Jerman, Genise | Prepaid / credit | $2.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 19 - 1906 | Jones, DaraDornisha | Prepaid / credit | $0.11 | $0.00 | -$0.11 | [ ] Confirm paid | — |
| 19 - 1907 | White, Latoya m | Prepaid / credit | $218.68 | $0.00 | -$218.68 | [ ] Confirm paid | — |
| 20 - 2002 | Jones, Leah L | Prepaid / credit | $709.00 | $0.00 | -$709.00 | [ ] Confirm paid | — |
| 20 - 2005 | Rodriquez, Lakesha | Prepaid / credit | $1,405.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 21 - 2105 | Scott, Alexia Nicole | Prepaid / credit | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |


## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.


## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property’s supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*
