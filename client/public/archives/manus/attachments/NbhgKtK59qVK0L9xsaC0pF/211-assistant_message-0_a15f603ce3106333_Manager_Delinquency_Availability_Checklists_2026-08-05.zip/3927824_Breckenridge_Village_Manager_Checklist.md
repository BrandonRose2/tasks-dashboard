# Breckenridge Village — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 3927824**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/05/2026 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Manager name | ______________________________ |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Availability PDF | `3927824_Breckenridge Village_Availability_1954068.pdf` |
| Delinquency spreadsheet(s) | `3927824_Breckenridge Village_Delinquent and Prepaid - Excel_1954138.xls`<br>`3927824_Breckenridge Village_Delinquent and Prepaid_1954103.xls` |
| Spreadsheet comparison | Review variance: 37 vs. 0 rows; -$2,502.89 net-balance difference |
| Ledger accounts for review | 37 resident accounts |
| Residents with amount owed | 0 accounts; $0.00 |
| Prepaid / credit accounts | 37 accounts; $2,502.89 |
| Availability entries | 3 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit’s reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| 05-2006 | 4B2B | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 54-2102 | 4B2B | Vacant Leased Ready | [ ] Verified | __________________ |
| As | of | NTV Not Leased | [ ] Verified | __________________ |


## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

No resident ledger entries were detected in the selected source export.


## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 01 - 2000 | Villasenor, Luisa Garza | Prepaid / credit | $5.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 03 - 2004 | Gonzalez, Maria | Prepaid / credit | $72.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 09 - 2100 | Torres, Edgar Ociel | Prepaid / credit | $8.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 10 - 2101 | Bates(EHA), Sabrina M | Prepaid / credit | $105.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 11 - 2102 | Potter(EHA), Akida Kecole | Prepaid / credit | $73.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 12 - 2103 | Shuck, Jayson Dale | Prepaid / credit | $0.26 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 16 - 2107 | Jones, Brittney Jacole | Prepaid / credit | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 17 - 2108 | Harris, Rebecca Ann | Prepaid / credit | $34.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 20 - 2201 | Grant, Alexis Abril | Prepaid / credit | $4.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 21 - 2202 | Moran, Raegan Lexi | Prepaid / credit | $0.40 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 23 - 2204 | Edwards, Tiera Lutishia | Prepaid / credit | $130.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 24 - 2000 | Wallace, Zina(EHA) | Prepaid / credit | $3.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 26 - 2002 | Jimenez, Cristina | Prepaid / credit | $75.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 27 - 2003 | Daniels, Doris Ann | Prepaid / credit | $98.03 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 28 - 2004 | Morales, Jose Luis | Prepaid / credit | $25.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 29 - 2005 | Tippen, Raymona Lynnett | Prepaid / credit | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 32 - 2008 | Serrano, Jose | Prepaid / credit | $9.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 34 - 2100 | McBay, Charma | Prepaid / credit | $48.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 36 - 2102 | Gutierrez, Sandra Karina | Prepaid / credit | $75.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 37 - 2103 | Kopaddy(GPHA), Kala Marie | Prepaid / credit | $4.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 38 - 2104 | Puente, Janie | Prepaid / credit | $3.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 40 - 2106 | English, Tonya | Prepaid / credit | $0.50 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 41 - 2107 | *Ford, Shetterrica Laquinn | Prepaid / credit | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 42 - 2108 | Lopez, Alexis Michelle | Prepaid / credit | $25.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 45 - 2111 | Trevino, Chelsea Mariah | Prepaid / credit | $16.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 46 - 2200 | Roberts, Arline Laraye | Prepaid / credit | $21.70 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 48 - 2202 | Brown, Shandell R | Prepaid / credit | $0.33 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 49 - 2203 | Kerrick, Gabriell | Prepaid / credit | $2.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 52 - 2207 | Jenkins, Elisha Ladale | Prepaid / credit | $16.28 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 56 - 2106 | LeBlanc, Donna Mae | Prepaid / credit | $0.39 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 57 - 2200 | Estrada, Sheleene Deanza | Prepaid / credit | $30.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 58 - 2202 | Hawkins, Selisha | Prepaid / credit | $5.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 60 - 2206 | Spencer, Patricia | Prepaid / credit | $64.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 61 - 2300 | Maye, Tiffany Lynette | Prepaid / credit | $1,490.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 62 - 2300 | Kidd(EHA), Shirley | Prepaid / credit | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 63 - 2302 | Brown(EHA), Tamica Rochele | Prepaid / credit | $55.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 64 - 2304 | Lawson (EHA), Latonya | Prepaid / credit | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |


## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.


## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property’s supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*
