# Historical — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 4022593**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 10/28/2025 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Manager name | ______________________________ |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Availability PDF | `4022593_Historical - Riverchase Homes_Availability_1954071.pdf` |
| Delinquency spreadsheet(s) | `4022593_Historical - Riverchase Homes_Delinquent and Prepaid - Excel_1954141.xls`<br>`4022593_Historical - Riverchase Homes_Delinquent and Prepaid_1954106.xls` |
| Spreadsheet comparison | Review variance: 72 vs. 0 rows; $1,040.81 net-balance difference |
| Ledger accounts for review | 60 resident accounts |
| Residents with amount owed | 33 accounts; $15,897.87 |
| Prepaid / credit accounts | 27 accounts; $14,978.06 |
| Availability entries | 0 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit’s reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

No unit-level availability detail could be machine-read from this PDF. Please confirm the Availability source report during the manager call.


## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 01 - 105 | Walker, Trenisha L | Owes balance | $0.00 | $161.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04 - 108 | Davis, Jalessa Nycol | Owes balance | $0.00 | $1,186.68 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 07 - 112 | Sease, Iakeia D | Owes balance | $0.00 | $1,261.90 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 09 - 114 | Smith, Lisa A | Owes balance | $0.00 | $127.17 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 119 | Wilber, Shacoula | Owes balance | $0.00 | $555.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 120 | Turner, Shalonda Reneea | Owes balance | $0.00 | $119.16 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 122 | Coley, Kelbreanna S | Owes balance | $0.00 | $39.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 123 | McKie, Earnestine | Owes balance | $0.00 | $88.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20 - 126 | Hampton, Gwendolyn L | Owes balance | $0.00 | $21.32 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 21 - 127 | Sims, Dora S | Owes balance | $0.00 | $12.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 22 - 128 | Jenkins, Jerri | Owes balance | $0.00 | $104.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 23 - 129 | Tolbert, Kimberly | Owes balance | $0.00 | $257.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 26 - 132 | Jacobs, Shelonda Latrel | Owes balance | $0.00 | $1,355.84 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 30 - 136 | Pernell, Ciera M | Owes balance | $0.00 | $5.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 32 - 202 | Castleberry, Antonette S | Owes balance | $0.00 | $289.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 33 - 203 | Walker, Breyuna S | Owes balance | $0.00 | $22.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 34 - 204 | Baker, LaBlessen Vashae | Owes balance | $0.00 | $83.61 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 38 - 208 | Winston, James L | Owes balance | $0.00 | $84.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 41 - 211 | Farmer, Johnnisha Khadijah | Owes balance | $0.00 | $84.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 42 - 212 | Ballard, Ramona M | Owes balance | $0.00 | $3.67 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 45 - 215 | Harris, De'Angela L | Owes balance | $0.00 | $47.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 47 - 217 | Wilcher, Sharon D | Owes balance | $0.00 | $42.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 48 - 218 | Moody, Shatavia L | Owes balance | $0.00 | $72.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 50 - 220 | Rivers, Bobby | Owes balance | $0.00 | $70.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 52 - 222 | Foreman, Tiffany Laprea | Owes balance | $0.00 | $2,326.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 57 - 227 | Sumpter, Jaleesa Celeste | Owes balance | $0.00 | $1,354.94 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 58 - 228 | Newman, Philisty | Owes balance | $0.00 | $1,205.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 60 - 230 | Smith, Rhonda N | Owes balance | $0.00 | $93.64 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 61 - 231 | Allen, Jessica G | Owes balance | $0.00 | $2,172.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 72 - 244 | Young, Veronica | Owes balance | $0.00 | $22.67 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 75 - 250 | Morris, Tamekia Renea | Owes balance | $0.00 | $1,383.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 76 - 252 | Curtis, Roderick Demon | Owes balance | $0.00 | $78.67 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 80 - 260 | Jones, Roshell Monique | Owes balance | $0.00 | $1,171.60 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |


## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 05 - 110 | Golphin, Angelica C | Prepaid / credit | $0.35 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 10 - 115 | Berrien, Rhonda | Prepaid / credit | $11.68 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 11 - 116 | Blockett, Brittany | Prepaid / credit | $4.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 19 - 125 | Mack, Michael | Prepaid / credit | $2,696.33 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 24 - 130 | Starks, Sandra | Prepaid / credit | $10.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 29 - 135 | Green, Erica M | Prepaid / credit | $3,525.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 31 - 138 | Williams, Felicia Lorraine | Prepaid / credit | $2,210.58 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 35 - 205 | Fallen, LaKeshia A | Prepaid / credit | $563.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 39 - 209 | Bennett, Lastacey N | Prepaid / credit | $4.27 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 40 - 210 | Dixon, Tiffini Charmaine | Prepaid / credit | $7.61 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 43 - 213 | Moore, LaPorcha | Prepaid / credit | $248.80 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 44 - 214 | Rolland, Tandra T | Prepaid / credit | $18.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 46 - 216 | Mormant, Bridgett | Prepaid / credit | $3,616.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 49 - 219 | McKine, Dhasia Tichelle | Prepaid / credit | $154.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 51 - 221 | Andrews, Demetria | Prepaid / credit | $450.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 55 - 225 | Avig, Janett Rachael | Prepaid / credit | $155.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 56 - 226 | Bell, Brenda | Prepaid / credit | $61.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 62 - 232 | Jenkins, Joanne L. | Prepaid / credit | $60.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 63 - 233 | Fredrick, Laura M | Prepaid / credit | $0.81 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 64 - 234 | Thomas, Tasha O | Prepaid / credit | $5.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 65 - 235 | Carter, Montiah | Prepaid / credit | $7.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 66 - 236 | Darrian, Charlene | Prepaid / credit | $3.33 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 71 - 242 | Webb, Frances M | Prepaid / credit | $72.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 73 - 246 | Adams, Amber N | Prepaid / credit | $35.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 74 - 248 | Robinson, Shantel Jerrice | Prepaid / credit | $1,058.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 77 - 254 | McCray, Keona J | Prepaid / credit | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 79 - 258 | Dixon, Latoya M | Prepaid / credit | $0.30 | $0.00 | $0.00 | [ ] Confirm paid | — |


## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.


## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property’s supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*
