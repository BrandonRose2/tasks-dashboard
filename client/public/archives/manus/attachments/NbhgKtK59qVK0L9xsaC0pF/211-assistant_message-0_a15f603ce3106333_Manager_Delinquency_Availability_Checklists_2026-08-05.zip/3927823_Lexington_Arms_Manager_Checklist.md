# Lexington Arms — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 3927823**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/05/2026 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Manager name | ______________________________ |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Availability PDF | `3927823_Lexington Arms_Availability_1954067.pdf` |
| Delinquency spreadsheet(s) | `3927823_Lexington Arms_Delinquent and Prepaid - Excel_1954137.xls`<br>`3927823_Lexington Arms_Delinquent and Prepaid_1954102.xls` |
| Spreadsheet comparison | Review variance: 29 vs. 0 rows; -$2,934.05 net-balance difference |
| Ledger accounts for review | 27 resident accounts |
| Residents with amount owed | 0 accounts; $0.00 |
| Prepaid / credit accounts | 27 accounts; $2,934.05 |
| Availability entries | 2 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit’s reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| 46-1521 | 4B2B | NTV Not Leased | [ ] Verified | __________________ |
| 17-1532 | 4B2B | Vacant Leased Not Ready | [ ] Verified | __________________ |


## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

No resident ledger entries were detected in the selected source export.


## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 01 - 400 | Marquez, Velia | Prepaid / credit | $16.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 02 - 402 | Grier, Shantavia | Prepaid / credit | $25.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 03 - 404 | Moreno, Nikki A | Prepaid / credit | $1.33 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 04 - 406 | Alvarez, Erica Ranee | Prepaid / credit | $2.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 06 - 409 | Nash, Shantel A | Prepaid / credit | $100.50 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 07 - 410 | Stout, Cheeneka Patrice | Prepaid / credit | $2.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 12 - 415 | Carlile, Tina Rae | Prepaid / credit | $2.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 13 - 416 | Solis, Kasey Michelle | Prepaid / credit | $166.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 15 - 100 | Velazquez-Delgado, Mayra Alvin | Prepaid / credit | $75.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 18 - 1534 | Starks, Magayle Andrew | Prepaid / credit | $82.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 21 - 1540 | Taulton, Natasha Lashawn | Prepaid / credit | $40.75 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 23 - 1544 | Rivera, Bobbi Jo | Prepaid / credit | $1,185.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 27 - 1502 | Williams, Velma | Prepaid / credit | $55.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 29 - 1504 | Johnson, David Wayne | Prepaid / credit | $77.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 31 - 1506 | Newton, Rasheeda | Prepaid / credit | $5.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 33 - 1508 | Partida, Jessie Raquel | Prepaid / credit | $33.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 34 - 1509 | Thompson, Dezarai Symone | Prepaid / credit | $55.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 35 - 1510 | Loera, Johanna Gean | Prepaid / credit | $200.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 36 - 1511 | Rodriguez, Stephanie Marie | Prepaid / credit | $225.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 38 - 1513 | Davis, Jennifer | Prepaid / credit | $5.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 39 - 1514 | Davis, Rachel Lenore | Prepaid / credit | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 40 - 1515 | Henley, Holly C | Prepaid / credit | $0.47 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 42 - 1517 | Womack, Lucas James | Prepaid / credit | $193.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 46 - 1521 | Ontiveros III, Antonio | Prepaid / credit | $50.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 53 - 1528 | Maxwell, Sharika Monique | Prepaid / credit | $85.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 56 - 1531 | Person, Katina Necole | Prepaid / credit | $180.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 60 - 1536 | Ransom, Sharita D | Prepaid / credit | $72.00 | $0.00 | $0.00 | [ ] Confirm paid | — |


## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.


## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property’s supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*
