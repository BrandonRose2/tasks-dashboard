# Grove Park Terrace — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 4679872**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/05/2026 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Manager name | ______________________________ |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Availability PDF | `4679872_Grove Park Terrace_Availability_1954079.pdf` |
| Delinquency spreadsheet(s) | `4679872_Grove Park Terrace_Delinquent and Prepaid - Excel_1954149.xls`<br>`4679872_Grove Park Terrace_Delinquent and Prepaid_1954114.xls` |
| Spreadsheet comparison | Review variance: 57 vs. 0 rows; -$4,761.02 net-balance difference |
| Ledger accounts for review | 53 resident accounts |
| Residents with amount owed | 17 accounts; $631.19 |
| Prepaid / credit accounts | 36 accounts; $5,392.21 |
| Availability entries | 0 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit’s reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

No unit-level availability detail could be machine-read from this PDF. Please confirm the Availability source report during the manager call.


## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 01 - 06 | Gonzales, Daniella | Owes balance | $0.00 | $65.97 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 01 - 08 | Whitehead, Shmayia Sentrail | Owes balance | $0.00 | $0.39 | $0.39 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 01 - 12 | Arciba, JoAnn | Owes balance | $0.00 | $1.93 | $1.93 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02 - 13 | Noble, MyKasey Adarria | Owes balance | $0.00 | $181.67 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02 - 15 | Schlottman, Tiffany R | Owes balance | $0.00 | $184.50 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02 - 19 | Taylor, Mary L | Owes balance | $0.00 | $34.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02 - 20 | Turner, Antone | Owes balance | $0.00 | $16.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02 - 24 | Arreola, Zenaida | Owes balance | $0.00 | $5.00 | $5.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | 05/06/2025 |
| 03 - 36 | Hogan, LeSaundra M | Owes balance | $0.00 | $44.75 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04 - 40 | Martinez, Elvia | Owes balance | $0.00 | $3.81 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | 04/06/2026 |
| 04 - 44 | Sanchez, Karina L | Owes balance | $0.00 | $26.40 | $26.40 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04 - 45 | Banda, Brianna Nichole | Owes balance | $0.00 | $10.20 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05 - 49 | Pecina, Veronica | Owes balance | $0.00 | $14.74 | $14.74 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05 - 50 | Artega, Erianna Lynn | Owes balance | $0.00 | $1.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05 - 53 | Alvarez, Vanessa A | Owes balance | $0.00 | $21.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05 - 56 | Deleon, Leslie | Owes balance | $0.00 | $13.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05 - 58 | LILLIE, BRANDIE M | Owes balance | $0.00 | $6.83 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |


## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 01 - 02 | Chambers, Katherine L | Prepaid / credit | $999.25 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 01 - 03 | Guerrero, Ileana M | Prepaid / credit | $27.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 01 - 04 | Southern, Amaya Grace | Prepaid / credit | $18.90 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 01 - 05 | Garcia, Katina | Prepaid / credit | $4.00 | $0.00 | -$4.00 | [ ] Confirm paid | — |
| 01 - 07 | Griggers, Krystal Lenee | Prepaid / credit | $36.73 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 01 - 09 | Daniels, Barbara A | Prepaid / credit | $5.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 01 - 10 | Stone, Emilee Elizabeth | Prepaid / credit | $0.03 | $0.00 | -$0.03 | [ ] Confirm paid | — |
| 01 - 11 | Castillo, Joshua E | Prepaid / credit | $2.12 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 02 - 14 | Anderson, Jalishia La Dawn | Prepaid / credit | $47.00 | $0.00 | -$7.00 | [ ] Confirm paid | — |
| 02 - 16 | Anderson, AlyciaVirginia | Prepaid / credit | $123.34 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 02 - 17 | Watts, Belzoria | Prepaid / credit | $90.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 02 - 18 | Coronado, Braulia | Prepaid / credit | $17.93 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 02 - 21 | Almaguer, Frank | Prepaid / credit | $9.00 | $0.00 | -$9.00 | [ ] Confirm paid | — |
| 02 - 22 | Gonzales, Cynthia Ledesma | Prepaid / credit | $0.32 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 02 - 23 | Cook, Charmaine J | Prepaid / credit | $5.99 | $0.00 | -$5.99 | [ ] Confirm paid | — |
| 03 - 25 | Jones, Keanna J | Prepaid / credit | $11.00 | $0.00 | -$11.00 | [ ] Confirm paid | — |
| 03 - 26 | Torres, Monica | Prepaid / credit | $28.53 | $0.00 | -$28.53 | [ ] Confirm paid | — |
| 03 - 27 | Chandler, Regena | Prepaid / credit | $97.00 | $0.00 | -$97.00 | [ ] Confirm paid | — |
| 03 - 29 | Ortega, Viola E | Prepaid / credit | $88.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 03 - 30 | Morin, Jesusa | Prepaid / credit | $6.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 03 - 31 | Cortez, Destiny Marie | Prepaid / credit | $76.61 | $0.00 | -$76.61 | [ ] Confirm paid | — |
| 03 - 32 | Rivera, Anneliese Marie | Prepaid / credit | $3.87 | $0.00 | -$3.87 | [ ] Confirm paid | — |
| 03 - 33 | Lopez, Karissa R | Prepaid / credit | $73.87 | $0.00 | -$63.87 | [ ] Confirm paid | — |
| 03 - 35 | Gonzales, Audryana Celeste | Prepaid / credit | $152.00 | $0.00 | -$152.00 | [ ] Confirm paid | — |
| 04 - 38 | Sanchez, Gabriella Renae | Prepaid / credit | $73.23 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 04 - 39 | Delgado, Richard L | Prepaid / credit | $6.74 | $0.00 | -$6.74 | [ ] Confirm paid | — |
| 04 - 41 | Villatoro, Sayra Anahi | Prepaid / credit | $0.90 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 04 - 42 | Conner, Carolyn | Prepaid / credit | $77.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 04 - 46 | Ortiz, Carmelin A | Prepaid / credit | $10.00 | $0.00 | -$10.00 | [ ] Confirm paid | — |
| 04 - 47 | Garza, Lazette Marie | Prepaid / credit | $19.52 | $0.00 | -$19.52 | [ ] Confirm paid | — |
| 04 - 48 | Alvarez, Desarie A | Prepaid / credit | $95.13 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 05 - 52 | Hernandez, Jackie | Prepaid / credit | $2,842.00 | $0.00 | -$1,006.00 | [ ] Confirm paid | — |
| 05 - 54 | Holbert, Jalishia Nashae | Prepaid / credit | $157.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 05 - 55 | Johnson, LaQuincia Shardae | Prepaid / credit | $0.43 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 05 - 57 | Garcia, Meily J | Prepaid / credit | $44.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 05 - 60 | Gonzalez, Vida J | Prepaid / credit | $142.77 | $0.00 | $0.00 | [ ] Confirm paid | — |


## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.


## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property’s supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*
