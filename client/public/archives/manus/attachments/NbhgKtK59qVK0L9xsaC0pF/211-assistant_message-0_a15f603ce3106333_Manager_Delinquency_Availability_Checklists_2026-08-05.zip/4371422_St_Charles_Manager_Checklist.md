# St Charles — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 4371422**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/03/2026 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Manager name | ______________________________ |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Availability PDF | `4371422_St Charles_Availability_1954077.pdf` |
| Delinquency spreadsheet(s) | `4371422_St Charles_Delinquent and Prepaid - Excel_1954147.xls`<br>`4371422_St Charles_Delinquent and Prepaid_1954112.xls` |
| Spreadsheet comparison | Review variance: 93 vs. 0 rows; $5,721.01 net-balance difference |
| Ledger accounts for review | 77 resident accounts |
| Residents with amount owed | 29 accounts; $15,733.00 |
| Prepaid / credit accounts | 49 accounts; $10,128.99 |
| Availability entries | 5 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit’s reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| 04-032 | 2A | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 15-113 | 2A | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 06-043 | 2A | Vacant Leased Not Ready | [ ] Verified | __________________ |
| 08-064 | 2A | Vacant Leased Not Ready | [ ] Verified | __________________ |
| 12-089 | 3A | Vacant Leased Not Ready | [ ] Verified | __________________ |


## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 01 - 002 | Peterman, Eldrionna Nicole | Owes balance | $0.00 | $1,501.00 | $934.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 01 - 007 | Preston, Kristopher Erik | Owes balance | $0.00 | $42.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02 - 010 | Ross, Cameron Lee | Owes balance | $0.00 | $12.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02 - 016 | Chambers, Rita Marie | Owes balance | $0.00 | $5.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 03 - 018 | Ross, Mason Alexander | Owes balance | $0.00 | $331.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 03 - 021 | Seymore, Janaysha | Owes balance | $0.00 | $116.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05 - 034 | Jefferson, Alice Faye | Owes balance | $0.00 | $34.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 06 - 041 | Beverly, Curt Van Allen | Owes balance | $0.00 | $825.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 06 - 044 | Anderson, Carolina Lashay | Owes balance | $0.00 | $690.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 06 - 045 | Parker, Brenda Sue | Owes balance | $0.00 | $525.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 07 - 052 | Lewis, Donald Ray | Owes balance | $0.00 | $787.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 08 - 060 | Richard, Reginald Dawayne | Owes balance | $0.00 | $626.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 08 - 062 | Edwards, Charita Semonia | Owes balance | $0.00 | $252.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 08 - 063 | Ramer, TrevianaNakaya Monae | Owes balance | $0.00 | $550.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 069 | Thomas, NakiraDezaniqua renee Thomas | Owes balance | $117.00 | $279.00 | $148.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 075 | Armstrong, TarellLemar | Owes balance | $0.00 | $973.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 076 | Saucier, TiffanyNichole | Owes balance | $0.00 | $1,546.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 077 | Anderson, Joseph Keith | Owes balance | $0.00 | $1,550.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 080 | Louis, VeronicaMarie | Owes balance | $0.00 | $75.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 091 | Simien, Carolyn | Owes balance | $0.00 | $359.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 092 | Landry, Dinika D | Owes balance | $0.00 | $1,961.00 | $1,198.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 093 | Ashley, Diamonds Veronica | Owes balance | $0.00 | $8.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 094 | Rubin, AnJanae Raion | Owes balance | $0.00 | $553.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 096 | Bias, JameshiaSheere | Owes balance | $0.00 | $478.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 097 | Simien, Devanee Rosha | Owes balance | $0.00 | $58.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 099 | Anderson, KiaraJaquelle | Owes balance | $0.00 | $451.00 | $284.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 100 | Harden, Shayla | Owes balance | $0.00 | $290.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 102 | Willis, Tiffany Nicole | Owes balance | $0.00 | $115.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 114 | Landry, TerryMarie | Owes balance | $0.00 | $741.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |


## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 01 - 001 | Bernard, Shannon Marie | Prepaid / credit | $73.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 01 - 003 | Williamson, MalisaRamirez | Prepaid / credit | $70.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 01 - 006 | Guidry, CarnnettaRene | Prepaid / credit | $5.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 01 - 008 | Goudeau, Ricky Wayne | Prepaid / credit | $250.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 02 - 009 | Austin, Dionne Monique | Prepaid / credit | $613.00 | $0.00 | -$149.00 | [ ] Confirm paid | — |
| 02 - 011 | Zackery, Janice Thomas | Prepaid / credit | $16.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 02 - 012 | Thomas, Aleia Janee | Prepaid / credit | $175.00 | $0.00 | -$175.00 | [ ] Confirm paid | — |
| 02 - 013 | Prejaen, Lindsey Dymond | Prepaid / credit | $58.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 02 - 014 | Potts, TrinityDeshay | Prepaid / credit | $101.00 | $0.00 | -$37.00 | [ ] Confirm paid | — |
| 02 - 015 | Oliver, LarryDarnell | Prepaid / credit | $171.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 03 - 017 | Ozane, Tashara Monae | Prepaid / credit | $49.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 03 - 023 | Brown, MarkAnthony | Prepaid / credit | $143.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 04 - 025 | Phills, Regionald Van | Prepaid / credit | $164.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 04 - 027 | Glodd, Ericka None | Prepaid / credit | $37.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 04 - 028 | Bias, Desmond Devontaye | Prepaid / credit | $115.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 04 - 029 | Thomas, Kenadie Ashlynn | Prepaid / credit | $8.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 04 - 031 | Allen, Tammy C | Prepaid / credit | $17.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 05 - 037 | Joseph, CleotaMarie | Prepaid / credit | $25.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 05 - 039 | Ardoin, ScherrazadeMechelle | Prepaid / credit | $609.00 | $0.00 | -$66.00 | [ ] Confirm paid | — |
| 05 - 040 | Richmond, TekesaDanielle | Prepaid / credit | $146.00 | $0.00 | -$146.00 | [ ] Confirm paid | — |
| 07 - 050 | Siverand, Erica Louise | Prepaid / credit | $122.00 | $0.00 | -$122.00 | [ ] Confirm paid | — |
| 07 - 051 | Davis, FlorenceL Sharomone | Prepaid / credit | $308.00 | $0.00 | -$43.00 | [ ] Confirm paid | — |
| 07 - 055 | Mckoy, Donondra Rachelle | Prepaid / credit | $266.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 07 - 056 | Siverand, JacquelineMiranda | Prepaid / credit | $21.00 | $0.00 | -$21.00 | [ ] Confirm paid | — |
| 09 - 065 | Ledet, D'Dara Lashay | Prepaid / credit | $10.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 10 - 067 | Hadnot, Antoinette Jewell Joshanique | Prepaid / credit | $88.00 | $0.00 | -$88.00 | [ ] Confirm paid | — |
| 10 - 069 | Thomas, NakiraDezaniqua renee Thomas | Owes balance | $117.00 | $279.00 | $148.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 070 | Hall, Tiffany Latoya | Prepaid / credit | $4.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 10 - 072 | Jacobs, Nicole Frances | Prepaid / credit | $51.00 | $0.00 | -$51.00 | [ ] Confirm paid | — |
| 12 - 083 | Batiste, Michael Wayne | Prepaid / credit | $649.00 | $0.00 | -$362.00 | [ ] Confirm paid | — |
| 12 - 085 | Leo, FaimataAgnes Palepa | Prepaid / credit | $424.00 | $0.00 | -$322.00 | [ ] Confirm paid | — |
| 12 - 086 | Shell, Patricia Lekee | Prepaid / credit | $52.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 12 - 087 | Smith, Brandy Nicole | Prepaid / credit | $124.00 | $0.00 | -$124.00 | [ ] Confirm paid | — |
| 12 - 088 | Williams, TiffanyLynn | Prepaid / credit | $1,060.00 | $0.00 | -$914.00 | [ ] Confirm paid | — |
| 14 - 101 | Simmons, Emeric Dewayne | Prepaid / credit | $700.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 14 - 104 | Ceasar, Yowanda Chantal | Prepaid / credit | $117.00 | $0.00 | -$66.00 | [ ] Confirm paid | — |
| 14 - 105 | Walker, Asia Dizhane | Prepaid / credit | $36.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 15 - 106 | Sears, Nancy Mae | Prepaid / credit | $134.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 15 - 107 | Watts, MeghanNekole | Prepaid / credit | $189.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 15 - 108 | Dobson, Yazmin Nykole | Prepaid / credit | $340.00 | $0.00 | -$274.00 | [ ] Confirm paid | — |
| 15 - 109 | Guillory, Shamikia Danielle | Prepaid / credit | $290.00 | $0.00 | -$116.00 | [ ] Confirm paid | — |
| 15 - 110 | Jones, April Marie | Prepaid / credit | $94.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 15 - 111 | Richard, ShaniceMarie Renee | Prepaid / credit | $1,064.99 | $0.00 | -$19.00 | [ ] Confirm paid | — |
| 16 - 115 | Atkins, Destiny Sherell | Prepaid / credit | $15.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 16 - 116 | Carrier, TysheannerKevina | Prepaid / credit | $443.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 16 - 117 | Shavers, Vinston D | Prepaid / credit | $18.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 16 - 119 | Hudson, Dillard none | Prepaid / credit | $71.00 | $0.00 | -$62.00 | [ ] Confirm paid | — |
| 16 - 120 | Ruffin, Judy Ann | Prepaid / credit | $175.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 16 - 121 | Tillman, Vanessa Marie | Prepaid / credit | $301.00 | $0.00 | $0.00 | [ ] Confirm paid | — |


## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.


## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property’s supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*
