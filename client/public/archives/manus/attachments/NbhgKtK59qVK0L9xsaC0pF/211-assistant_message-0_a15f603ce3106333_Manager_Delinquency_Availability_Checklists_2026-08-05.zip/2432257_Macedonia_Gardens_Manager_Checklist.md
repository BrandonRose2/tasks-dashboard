# Macedonia Gardens — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 2432257**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/04/2026 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Manager name | ______________________________ |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Availability PDF | `2432257_Macedonia Gardens_Availability_1954060.pdf` |
| Delinquency spreadsheet(s) | `2432257_Macedonia Gardens_Delinquent and Prepaid - Excel_1954131.xls`<br>`2432257_Macedonia Gardens_Delinquent and Prepaid_1954096.xls` |
| Spreadsheet comparison | Review variance: 64 vs. 0 rows; -$6,929.45 net-balance difference |
| Ledger accounts for review | 58 resident accounts |
| Residents with amount owed | 6 accounts; $270.00 |
| Prepaid / credit accounts | 52 accounts; $7,223.45 |
| Availability entries | 0 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit’s reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

No unit-level availability detail could be machine-read from this PDF. Please confirm the Availability source report during the manager call.


## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| C-101 | Katherman, Tania Rena | Owes balance | $0.00 | $2.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E-103 | Oliver, Dawn | Owes balance | $0.00 | $8.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G-102 | Bennett, Tamara Latin | Owes balance | $0.00 | $35.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G-104 | Porter, Caitlin Alisz | Owes balance | $0.00 | $7.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G-204 | Der Hovanesian, Bailey R | Owes balance | $0.00 | $6.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L-204 | Pizarro Garcia, Eddeicha Marie | Owes balance | $0.00 | $212.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |


## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| A-103 | Laracuente-Diaz, Darlene | Prepaid / credit | $2,082.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| A-104 | Morales Murillo, Jesica | Prepaid / credit | $4.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| A-201 | Mercado, Kathia Y | Prepaid / credit | $73.00 | $0.00 | -$73.00 | [ ] Confirm paid | — |
| A-202 | Torres-Perez, Jesus A | Prepaid / credit | $2.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| A-203 | Santos Santiago, Yashira M | Prepaid / credit | $119.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| B-101 | Matos, Shalimar | Prepaid / credit | $265.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| B-102 | Torres, Rose Elizabeth | Prepaid / credit | $13.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| B-202 | Robinson, Lilyann C | Prepaid / credit | $26.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| B-203 | Ming, Juwuan Fatrey | Prepaid / credit | $157.41 | $0.00 | $0.00 | [ ] Confirm paid | — |
| C-102 | Greene, Phyllis t | Prepaid / credit | $2.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| C-103 | Hull, Dionna Nisonya | Prepaid / credit | $8.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| C-203 | Holmes, TamikoRoslana | Prepaid / credit | $75.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| C-204 | Hazelrig, Nichole M | Prepaid / credit | $295.00 | $0.00 | -$295.00 | [ ] Confirm paid | — |
| D-103 | MATTHEW, Natacha M | Prepaid / credit | $115.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| D-104 | De La Rosa Paulino, Maria | Prepaid / credit | $163.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| D-202 | Mercado, Kelly Gloria | Prepaid / credit | $6.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| D-204 | De Jesus, Mileyn Carillo | Prepaid / credit | $21.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| E-201 | Corley, Megan Nicole | Prepaid / credit | $163.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| E-203 | Sisk, Melissa L | Prepaid / credit | $74.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| F-101 | Anderson, Letrice N'Dara | Prepaid / credit | $13.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| F-102 | Colon Martinex, Feliz | Prepaid / credit | $4.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| F-103 | Smiley, Tramika S | Prepaid / credit | $9.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| F-104 | Greene, Stacey R | Prepaid / credit | $14.59 | $0.00 | $0.00 | [ ] Confirm paid | — |
| F-201 | Bloxson, Tysheba L | Prepaid / credit | $8.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| G-103 | Katherman, Brittany N | Prepaid / credit | $240.00 | $0.00 | -$114.00 | [ ] Confirm paid | — |
| G-202 | Carrasquillo-Garcia, Luzviannezaday Marie | Prepaid / credit | $72.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| H-101 | Williams, Andretta M | Prepaid / credit | $37.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| H-104 | Campbell, Alera L | Prepaid / credit | $114.00 | $0.00 | -$114.00 | [ ] Confirm paid | — |
| H-202 | Cobb, Hannah E | Prepaid / credit | $219.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| H-203 | Caraballo, Lizmarie F | Prepaid / credit | $185.00 | $0.00 | -$185.00 | [ ] Confirm paid | — |
| H-204 | Smith, Teresa A | Prepaid / credit | $105.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| I-101 | Olan-Marin, Mercedes Maria | Prepaid / credit | $231.00 | $0.00 | -$231.00 | [ ] Confirm paid | — |
| I-103 | Sauls, Anna Marie | Prepaid / credit | $60.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| I-104 | Matos, Adriana M | Prepaid / credit | $1.00 | $0.00 | -$1.00 | [ ] Confirm paid | — |
| I-202 | Taylor, Maxine D | Prepaid / credit | $9.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| J-102 | Ortega Rodriguez, Nancy O | Prepaid / credit | $77.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| J-104 | Cooper, SandraE | Prepaid / credit | $18.00 | $0.00 | -$18.00 | [ ] Confirm paid | — |
| J-201 | Ruiz Gonzalez, Petra N | Prepaid / credit | $195.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| J-204 | Funes, Jabier Gonzalez | Prepaid / credit | $189.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| K-101 | Graham, Voncile | Prepaid / credit | $17.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| K-102 | Wynn, Alphonso D | Prepaid / credit | $6.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| K-103 | Gaines, Geneath L | Prepaid / credit | $68.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| K-104 | Wright, Sallie L | Prepaid / credit | $128.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| K-202 | Shanin, Mykhailo | Prepaid / credit | $30.00 | $0.00 | -$30.00 | [ ] Confirm paid | — |
| K-203 | Puerto, Carlos Manuel | Prepaid / credit | $330.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| K-204 | McMiller, Neshia | Prepaid / credit | $296.00 | $0.00 | -$296.00 | [ ] Confirm paid | — |
| L-101 | Harrison, Robert G | Prepaid / credit | $1.45 | $0.00 | $0.00 | [ ] Confirm paid | — |
| L-102 | Flowers, Archie L | Prepaid / credit | $110.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| L-202 | Hinnant, Dominique T | Prepaid / credit | $544.00 | $0.00 | -$208.00 | [ ] Confirm paid | — |
| M-101 | Weeks, Wendy L | Prepaid / credit | $25.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| M-103 | Parker, Charlene | Prepaid / credit | $129.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| M-104 | Spears, Patricia A | Prepaid / credit | $75.00 | $0.00 | $0.00 | [ ] Confirm paid | — |


## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.


## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property’s supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*
