# Holiday Apartments — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 3073874**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/05/2026 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Manager name | ______________________________ |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Availability PDF | `3073874_Holiday Apartments_Availability_1954064.pdf` |
| Delinquency spreadsheet(s) | `3073874_Holiday Apartments_Delinquent and Prepaid - Excel_1954134.xls`<br>`3073874_Holiday Apartments_Delinquent and Prepaid_1954099.xls` |
| Spreadsheet comparison | Review variance: 48 vs. 0 rows; $1,781.01 net-balance difference |
| Ledger accounts for review | 43 resident accounts |
| Residents with amount owed | 10 accounts; $4,242.00 |
| Prepaid / credit accounts | 33 accounts; $2,460.99 |
| Availability entries | 1 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit’s reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| 02A | 3BR | Vacant Not Leased Not Ready | [ ] Verified | __________________ |


## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 07A | CHEST, KAWANDA LEE | Owes balance | $0.00 | $512.00 | $128.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 08C | Williams, Oliver Junior | Owes balance | $0.00 | $10.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11A | Johnson, Cadisia Alexandrea | Owes balance | $0.00 | $93.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11C | SMITH, RONNIE L | Owes balance | $0.00 | $487.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12E | FITZGERALD, LAMONICA | Owes balance | $0.00 | $963.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15E | HUNT, YANA | Owes balance | $0.00 | $1.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16D | Allen, Patricia k | Owes balance | $0.00 | $31.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18D | Hence, Debra L | Owes balance | $0.00 | $1,294.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 21A | WILLIAMS, VICKIE | Owes balance | $0.00 | $791.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 27A | WILLIAMS, NICHELLE R | Owes balance | $0.00 | $60.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |


## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 01A | TOWNSEND, SHARON D | Prepaid / credit | $18.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 01B | KING, AUDREY | Prepaid / credit | $5.00 | $0.00 | -$5.00 | [ ] Confirm paid | — |
| 01C | FARMER, BRIANNA NICOLE | Prepaid / credit | $2.00 | $0.00 | -$2.00 | [ ] Confirm paid | — |
| 04B | BELTON, SABRINA RENEE | Prepaid / credit | $5.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 04C | SMITH, TYLON | Prepaid / credit | $20.00 | $0.00 | -$10.00 | [ ] Confirm paid | — |
| 04F | WASHINGTON, STEVE ELLIS | Prepaid / credit | $3.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 05A | HENRY, DIANE | Prepaid / credit | $2.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 05C | COATES, ALAIJA RENAE | Prepaid / credit | $5.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 05D | BOSTIC, THELMA | Prepaid / credit | $50.00 | $0.00 | -$50.00 | [ ] Confirm paid | — |
| 05E | GLENN, AUDREYANA NICOLE | Prepaid / credit | $19.00 | $0.00 | -$19.00 | [ ] Confirm paid | — |
| 05F | Rice, Lakrystal | Prepaid / credit | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 06F | WHITE, TRAVIS | Prepaid / credit | $448.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 07F | SMITH, MARQUITA LASHAY | Prepaid / credit | $7.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 08A | WHITE, JESSECCA FLORIA ALUCCIANA MORALES | Prepaid / credit | $5.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 10B | BROWN, JERICKA DEATRICE | Prepaid / credit | $85.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 11E | MCGOWAN, FANTAISA ENSHAUNTE | Prepaid / credit | $108.00 | $0.00 | -$108.00 | [ ] Confirm paid | — |
| 11F | Williams, Delores Louise | Prepaid / credit | $78.00 | $0.00 | -$78.00 | [ ] Confirm paid | — |
| 14A | Knight, SHEMEKA | Prepaid / credit | $847.99 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 14B | MCKNIGHT, SHAWN | Prepaid / credit | $8.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 14C | KNIGHT, CAROLYN | Prepaid / credit | $16.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 14D | GREEN, CHRISTINA NICOLE | Prepaid / credit | $6.00 | $0.00 | -$6.00 | [ ] Confirm paid | — |
| 14E | Jones, Mary D | Prepaid / credit | $2.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 17A | MINOR, MAMIE K | Prepaid / credit | $26.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 17C | MINOR, TARA | Prepaid / credit | $47.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 18C | McGuire, Laverne | Prepaid / credit | $292.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 19C | Williams, Stella Y | Prepaid / credit | $3.00 | $0.00 | -$3.00 | [ ] Confirm paid | — |
| 19D | TOLLIVER, GLADYS MARIE | Prepaid / credit | $40.00 | $0.00 | -$40.00 | [ ] Confirm paid | — |
| 20A | JEFFERSON, D'SIR LASHAWN | Prepaid / credit | $265.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 20C | Knight, Daisy Bell | Prepaid / credit | $7.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 21B | CAMPBELL, EBONI | Prepaid / credit | $16.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 22B | JONES, BRENELL | Prepaid / credit | $10.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 23A | Fleming, Wilneisha Jevonda | Prepaid / credit | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 25A | MILES, KYMNBERLY LASHUN | Prepaid / credit | $13.00 | $0.00 | $0.00 | [ ] Confirm paid | — |


## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.


## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property’s supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*
