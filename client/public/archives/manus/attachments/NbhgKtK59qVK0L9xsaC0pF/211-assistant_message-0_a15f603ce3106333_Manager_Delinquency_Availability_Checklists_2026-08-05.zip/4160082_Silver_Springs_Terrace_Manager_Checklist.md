# Silver Springs Terrace — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 4160082**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/05/2026 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Manager name | ______________________________ |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Availability PDF | `4160082_Silver Springs Terrace_Availability_1954072.pdf` |
| Delinquency spreadsheet(s) | `4160082_Silver Springs Terrace_Delinquent and Prepaid - Excel_1954142.xls`<br>`4160082_Silver Springs Terrace_Delinquent and Prepaid_1954107.xls` |
| Spreadsheet comparison | Review variance: 79 vs. 0 rows; $33,876.20 net-balance difference |
| Ledger accounts for review | 55 resident accounts |
| Residents with amount owed | 23 accounts; $39,285.20 |
| Prepaid / credit accounts | 32 accounts; $5,983.00 |
| Availability entries | 11 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit’s reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| 1-1A | 2A | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 6-6H | 3A | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 7-7B | 3A | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 8-8B | 4A | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 10-10A | 3A | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 10-10G | 3A | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 10-10H | 3A | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 11-11A | 2A | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 11-11C | 2A | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 14-14B | 3A | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| As | of | Vacant Not Leased Not Ready | [ ] Verified | __________________ |


## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - 1E | Carson, Amalia S | Owes balance | $0.00 | $24.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1F | Prunty, Daquaydra | Owes balance | $0.00 | $258.00 | $258.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 10C | Rogers, Ashley F | Owes balance | $0.00 | $0.20 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 10D | Sanders, Jessica Danielle | Owes balance | $0.00 | $448.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 10E | Griggs, Jakeyia | Owes balance | $0.00 | $886.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 12B | Abernathy, Winter | Owes balance | $0.00 | $3,107.00 | $1,544.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 13B | Mauney, Tiffany | Owes balance | $0.00 | $655.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 14E | Glass, Mattie L | Owes balance | $0.00 | $4,817.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 14F | SMYRE, JOHN | Owes balance | $0.00 | $387.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 16A | Beatty, Antwaine D | Owes balance | $0.00 | $32.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 17G | Aikens, Kasey Justina | Owes balance | $0.00 | $475.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2B | Martin, Jammie l | Owes balance | $0.00 | $7,161.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2H | Owens, Megan D | Owes balance | $0.00 | $438.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3C | Cornwell, Destane S | Owes balance | $0.00 | $197.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3F | Hall, Angel N | Owes balance | $0.00 | $2,863.00 | $886.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 5F | Brown, Shalaya T | Owes balance | $0.00 | $7,242.00 | $4,134.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 6B | Linebarger, Chapele T | Owes balance | $0.00 | $166.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 6C | Abernathy, Shannan L | Owes balance | $0.00 | $3.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 6E | White, Marthisa E | Owes balance | $0.00 | $4,084.00 | $2,389.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 7F | Robinson, Phylicia A | Owes balance | $0.00 | $711.00 | $666.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 7H | Freeman, Latasha | Owes balance | $0.00 | $3,743.00 | $450.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 8A | Blount, Raven T | Owes balance | $0.00 | $133.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 9E | Gibbs, Amber S | Owes balance | $0.00 | $1,455.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |


## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - 1B | Owens, April | Prepaid / credit | $14.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 11 - 11E | Wilson, Jahacea | Prepaid / credit | $636.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 11 - 11G | Sigmon, Amanda D | Prepaid / credit | $131.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 12 - 12E | Walker, Stepahnie J | Prepaid / credit | $899.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 12 - 12F | Little, Maquada L | Prepaid / credit | $745.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 13 - 13A | Moore, MelonieEva | Prepaid / credit | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 15 - 15B | Ortiz Rivera, Doris | Prepaid / credit | $30.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 15 - 15F | Krebs, Wanda | Prepaid / credit | $125.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 16 - 16B | Solera, Carlos L | Prepaid / credit | $6.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 17 - 17A | Blackburn, Rossella C | Prepaid / credit | $36.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 17 - 17B | Humphries, Candace | Prepaid / credit | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 17 - 17D | Ussery, Khala Brianne | Prepaid / credit | $109.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 17 - 17F | Handy, Dennis | Prepaid / credit | $24.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 2A | Russell, Brandy P | Prepaid / credit | $6.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 2C | Dockery, Tommy | Prepaid / credit | $242.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 2D | Kaylor, Mary | Prepaid / credit | $12.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 2E | Gaither, Wanda | Prepaid / credit | $330.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 2F | Harris, Alivih | Prepaid / credit | $30.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 3A | Harris, Emoni A | Prepaid / credit | $30.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 3D | ADAMSON, SHANIEL | Prepaid / credit | $108.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 3G | Nguyen, Luc | Prepaid / credit | $10.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 5A | Redmon, Stephanie p | Prepaid / credit | $3.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 5E | Jones, Kenyettea | Prepaid / credit | $2.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 6 - 6D | Freeman, Elizabeth C | Prepaid / credit | $35.00 | $0.00 | -$30.00 | [ ] Confirm paid | — |
| 6 - 6F | Cardenas-Lemus, Gladis | Prepaid / credit | $74.00 | $0.00 | -$5.00 | [ ] Confirm paid | — |
| 6 - 6G | Weaver, Jessica M | Prepaid / credit | $11.00 | $0.00 | -$11.00 | [ ] Confirm paid | — |
| 7 - 7A | Wright, Alan M | Prepaid / credit | $1,454.00 | $0.00 | -$1,454.00 | [ ] Confirm paid | — |
| 7 - 7C | Scott, Keyana D | Prepaid / credit | $139.00 | $0.00 | -$139.00 | [ ] Confirm paid | — |
| 7 - 7D | Mclean, Jasmine | Prepaid / credit | $671.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 7 - 7G | Edwards, Felicia V | Prepaid / credit | $13.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 9 - 9D | Montgomery, Kahjia T | Prepaid / credit | $42.00 | $0.00 | -$42.00 | [ ] Confirm paid | — |
| 9 - 9F | Susee, Samantha | Prepaid / credit | $14.00 | $0.00 | $0.00 | [ ] Confirm paid | — |


## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.


## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property’s supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*
