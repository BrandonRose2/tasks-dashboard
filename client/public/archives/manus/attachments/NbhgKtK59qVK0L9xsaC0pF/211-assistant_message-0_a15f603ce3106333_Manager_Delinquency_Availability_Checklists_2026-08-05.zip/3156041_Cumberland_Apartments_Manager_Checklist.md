# Cumberland Apartments — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 3156041**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/04/2026 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Manager name | ______________________________ |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Availability PDF | `3156041_Cumberland Apartments_Availability_1954065.pdf` |
| Delinquency spreadsheet(s) | `3156041_Cumberland Apartments_Delinquent and Prepaid - Excel_1954135.xls`<br>`3156041_Cumberland Apartments_Delinquent and Prepaid_1954100.xls` |
| Spreadsheet comparison | Review variance: 45 vs. 0 rows; -$6,679.00 net-balance difference |
| Ledger accounts for review | 40 resident accounts |
| Residents with amount owed | 11 accounts; $1,042.00 |
| Prepaid / credit accounts | 30 accounts; $7,845.91 |
| Availability entries | 0 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit’s reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

No unit-level availability detail could be machine-read from this PDF. Please confirm the Availability source report during the manager call.


## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| A02 | BRENT, ETONYA MICHELLE | Owes balance | $0.00 | $164.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A04 | WILLIAMS, JACQUELINE | Owes balance | $0.00 | $114.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C13 | SUTTON, PRISCILLA | Owes balance | $0.00 | $46.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C14 | MOORE, LESLIE L | Owes balance | $0.00 | $253.45 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E34 | ALEXANDER, LINDA F | Owes balance | $0.00 | $96.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F40 | Christmas, Gwendolyn | Owes balance | $0.00 | $88.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F44 | KENDRICK, KIMALISHA S | Owes balance | $124.00 | $1.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G45 | CRISLER, CLAUDETTE | Owes balance | $0.00 | $155.55 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G46 | ROBINSON, RUTH ANN | Owes balance | $0.00 | $15.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G47 | WEST, CATERENA L | Owes balance | $0.00 | $69.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H60 | Williams, Lashontenique Tatyanna | Owes balance | $0.00 | $40.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |


## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| A03 | Williams, Jacqueline | Prepaid / credit | $47.00 | $0.00 | -$47.00 | [ ] Confirm paid | — |
| A05 | Johnson, Marcus | Prepaid / credit | $284.00 | $0.00 | -$71.00 | [ ] Confirm paid | — |
| A06 | Willis, Jennifer | Prepaid / credit | $258.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| A07 | Tobias, Floyd | Prepaid / credit | $1,091.00 | $0.00 | -$1,016.00 | [ ] Confirm paid | — |
| A08 | Willis, NekiaDuann | Prepaid / credit | $86.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| B10 | WILLIAMS, STACEY M | Prepaid / credit | $624.00 | $0.00 | -$312.00 | [ ] Confirm paid | — |
| C15 | Bailey, A'Kira Shonte | Prepaid / credit | $468.00 | $0.00 | -$117.00 | [ ] Confirm paid | — |
| C17 | Bailey, Akellya | Prepaid / credit | $117.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| C18 | ADAMS, MONICA L | Prepaid / credit | $469.00 | $0.00 | -$118.00 | [ ] Confirm paid | — |
| C19 | ALLEN, AIESHIA M | Prepaid / credit | $468.00 | $0.00 | -$117.00 | [ ] Confirm paid | — |
| C20 | Bailey, Frederick | Prepaid / credit | $101.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| D22 | JOHNSON, BEVERLY | Prepaid / credit | $432.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| D24 | POWELL, SHERRY A | Prepaid / credit | $1.00 | $0.00 | -$1.00 | [ ] Confirm paid | — |
| D25 | Bailey, Jasmine Lavett | Prepaid / credit | $692.00 | $0.00 | -$173.00 | [ ] Confirm paid | — |
| D26 | Rhymes, Ahliyah | Prepaid / credit | $173.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| D27 | Eisenbrandt, Kimberly Ann | Prepaid / credit | $134.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| E29 | Johnson, Jeremy | Prepaid / credit | $672.00 | $0.00 | -$168.00 | [ ] Confirm paid | — |
| E31 | Neal, Laronda Michelle | Prepaid / credit | $87.00 | $0.00 | -$87.00 | [ ] Confirm paid | — |
| E33 | CLAIBORNE, NATASHA | Prepaid / credit | $152.00 | $0.00 | -$2.00 | [ ] Confirm paid | — |
| E35 | BROWN, JENNIFER | Prepaid / credit | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| E36 | Catchings, Trimika | Prepaid / credit | $366.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| F37 | MORRIS, KEYLA Y | Prepaid / credit | $117.91 | $0.00 | $0.00 | [ ] Confirm paid | — |
| F39 | Mcgowan, Veronica Shanut | Prepaid / credit | $117.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| F41 | CLARK, KENYA | Prepaid / credit | $56.00 | $0.00 | -$56.00 | [ ] Confirm paid | — |
| F42 | ALLEN, SHIRLEY | Prepaid / credit | $67.00 | $0.00 | -$67.00 | [ ] Confirm paid | — |
| F43 | Taylor, Tambria Lashea | Prepaid / credit | $106.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| F44 | KENDRICK, KIMALISHA S | Owes balance | $124.00 | $1.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G50 | Carter, William J | Prepaid / credit | $325.00 | $0.00 | -$130.00 | [ ] Confirm paid | — |
| H54 | Barnes, Johnny Harold | Prepaid / credit | $8.00 | $0.00 | -$8.00 | [ ] Confirm paid | — |
| H57 | JENKINS, SURESH | Prepaid / credit | $202.00 | $0.00 | $0.00 | [ ] Confirm paid | — |


## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.


## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property’s supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*
