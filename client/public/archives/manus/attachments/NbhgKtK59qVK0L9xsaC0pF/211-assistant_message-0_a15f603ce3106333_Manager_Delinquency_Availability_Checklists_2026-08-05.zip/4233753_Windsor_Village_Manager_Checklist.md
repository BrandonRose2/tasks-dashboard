# Windsor Village — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 4233753**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/05/2026 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Manager name | ______________________________ |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Availability PDF | `4233753_Windsor Village_Availability_1954073.pdf` |
| Delinquency spreadsheet(s) | `4233753_Windsor Village_Delinquent and Prepaid - Excel_1954143.xls`<br>`4233753_Windsor Village_Delinquent and Prepaid_1954108.xls` |
| Spreadsheet comparison | Review variance: 52 vs. 0 rows; $761.88 net-balance difference |
| Ledger accounts for review | 33 resident accounts |
| Residents with amount owed | 18 accounts; $3,239.69 |
| Prepaid / credit accounts | 15 accounts; $2,477.81 |
| Availability entries | 0 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit’s reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

No unit-level availability detail could be machine-read from this PDF. Please confirm the Availability source report during the manager call.


## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 10 - 1004 | Logan, Tro'Nacey Anbrie | Owes balance | $0.00 | $2.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1101 | Collins, Carl D | Owes balance | $0.00 | $47.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1102 | Mitchell, Javelle Jashaun | Owes balance | $0.00 | $631.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1202 | Smith, Gregory Wayne | Owes balance | $0.00 | $2.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1301 | Lattin, Jashaylan S | Owes balance | $0.00 | $143.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1304 | Fisher, Mary C | Owes balance | $0.00 | $4.10 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1401 | Barfield, Lakysa S | Owes balance | $0.00 | $262.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1402 | Smith, Ke'Leahi | Owes balance | $0.00 | $79.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1404 | Hottenstein, Rhonda S | Owes balance | $0.00 | $118.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 202 | Evans, Shundreka Marquita | Owes balance | $0.00 | $95.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 203 | Ellison, Antionette T | Owes balance | $0.00 | $12.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 204 | Black, Allisha L | Owes balance | $0.00 | $112.91 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 401 | Henderson, Wanda L | Owes balance | $0.00 | $119.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 502 | Johnson, Raquel Shaniana | Owes balance | $0.00 | $26.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 702 | Jones, Erica L | Owes balance | $0.00 | $332.43 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 804 | Feaster, Precious R | Owes balance | $0.00 | $78.25 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 903 | Barrett, Zackery | Owes balance | $0.00 | $1,023.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 904 | Baker, Takiya T | Owes balance | $0.00 | $153.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |


## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - 101 | Mosley, Barbara N | Prepaid / credit | $27.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 102 | Minniefield, Preston Malaki | Prepaid / credit | $60.02 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 103 | Hill, Joyce Juanita | Prepaid / credit | $6.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 10 - 1001 | Moore, Lashanno Lakey | Prepaid / credit | $29.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 10 - 1003 | Stanford-Reed, Brittany Loleta | Prepaid / credit | $64.00 | $0.00 | -$64.00 | [ ] Confirm paid | — |
| 11 - 1103 | Smith, Walter none | Prepaid / credit | $9.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 11 - 1104 | Davis, Theodore | Prepaid / credit | $345.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 12 - 1201 | Ryed, Dangelo | Prepaid / credit | $6.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 13 - 1303 | Fuller, SanijahS | Prepaid / credit | $694.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 301 | Cockerham Jr, John H | Prepaid / credit | $919.00 | $0.00 | -$919.00 | [ ] Confirm paid | — |
| 3 - 302 | Green, Xavier D | Prepaid / credit | $5.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 304 | Edwards, Janice | Prepaid / credit | $16.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 6 - 602 | Reed, David Adair | Prepaid / credit | $291.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 8 - 802 | Howard, Ertis Lee | Prepaid / credit | $4.79 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 8 - 803 | Haynes, LaTia Deshay | Prepaid / credit | $2.00 | $0.00 | $0.00 | [ ] Confirm paid | — |


## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.


## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property’s supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*
