# Walnut Hill — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 5414947**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/05/2026 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Manager name | ______________________________ |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Availability PDF | `5414947_Walnut Hill_Availability_1954088.pdf` |
| Delinquency spreadsheet(s) | `5414947_Walnut Hill_Delinquent and Prepaid - Excel_1954158.xls`<br>`5414947_Walnut Hill_Delinquent and Prepaid_1954123.xls` |
| Spreadsheet comparison | Review variance: 183 vs. 0 rows; -$7,351.59 net-balance difference |
| Ledger accounts for review | 88 resident accounts |
| Residents with amount owed | 42 accounts; $33,737.00 |
| Prepaid / credit accounts | 46 accounts; $41,088.59 |
| Availability entries | 1 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit’s reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| As | of | NTV Leased | [ ] Verified | __________________ |


## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 101 - B | Bradshaw, Darrius Terrell | Owes balance | $0.00 | $1,080.04 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 103 - D | Washington, Patrick Anthony | Owes balance | $0.00 | $0.09 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 104 - C | Hines, Andrea | Owes balance | $0.00 | $151.61 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 104 - H | Thompson, Whitney | Owes balance | $0.00 | $577.87 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 104 - L | Bonner, Tequitsha | Owes balance | $0.00 | $1,306.87 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 105 - D | Drake, Jennifer | Owes balance | $0.00 | $246.44 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 105 - F | Wyche, Khalilha Mi'yuana Rolinda | Owes balance | $0.00 | $1,401.28 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 105 - K | White, Nejla M | Owes balance | $0.00 | $3,080.13 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 105 - L | Geter, Marche | Owes balance | $0.00 | $830.27 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 201 - D | White, Khi'Zhane Arvey | Owes balance | $0.00 | $1,559.80 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 201 - F | Adkins, Sitaracarmelita | Owes balance | $0.00 | $170.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 201 - G | Foster, Amari | Owes balance | $0.00 | $1,539.64 | $1,180.83 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | 01/14/2026 |
| 202 - B | King, Delavonte | Owes balance | $0.00 | $573.52 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 202 - E | Luten-Yates, Kim Denise | Owes balance | $0.00 | $845.79 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 202 - L | Fells, Denisha Shantel | Owes balance | $0.00 | $323.21 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 203 - B | sMITH, AUYANA | Owes balance | $0.00 | $1,630.18 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 203 - E | Johnson III, William | Owes balance | $0.00 | $575.14 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 203 - G | Watson, Brandon | Owes balance | $0.00 | $52.29 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 203 - I | Braxton, Brittany Marie | Owes balance | $0.00 | $116.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 203 - J | Hollman, Shakinah Renasha | Owes balance | $0.00 | $118.67 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 204 - F | Childs, Tonya | Owes balance | $0.00 | $22.50 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 204 - G | Stevenson, Desiree | Owes balance | $0.00 | $1,388.25 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 301 - B | Etterson, Rickey | Owes balance | $0.00 | $1,517.78 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 301 - H | Clanton, Sasha Mone | Owes balance | $0.00 | $35.07 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 301 - J | Richardson, DuJuan | Owes balance | $0.00 | $1,610.41 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 301 - K | Thomas, Shenequel | Owes balance | $0.00 | $1,200.00 | $1,068.27 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | 01/14/2026 |
| 302 - F | Starling, Omar R | Owes balance | $0.00 | $3,579.85 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 302 - I | Green, Shernrika | Owes balance | $0.00 | $286.94 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 303 - A | Redwine, Shelly Y | Owes balance | $0.00 | $98.54 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 303 - B | Brent, Ashunta | Owes balance | $0.00 | $30.11 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 303 - H | Johnson, Gloria | Owes balance | $0.00 | $63.90 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 304 - H | Dobson, Sabrina | Owes balance | $0.00 | $1,020.65 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 304 - L | Medina, Gabriele Stacy | Owes balance | $0.00 | $81.40 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 402 - D | Jones, Jr, Calvin Edward | Owes balance | $0.00 | $799.78 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 402 - G | Smith III, Wilbert Lee | Owes balance | $0.00 | $237.07 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 402 - H | Davis, Michelle Denise | Owes balance | $0.00 | $1,410.02 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 402 - I | Couch, Ty'Neshia Marqushia | Owes balance | $0.00 | $1,809.21 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 402 - J | Day, Ebony A | Owes balance | $0.00 | $446.86 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 402 - L | Taylor, Makiyah Kailei | Owes balance | $0.00 | $1,545.85 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 501 - B | Brown, Gerald Alex | Owes balance | $0.00 | $282.25 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 501 - C | Willis, Lois | Owes balance | $0.00 | $57.43 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 501 - E | Harris, Lavondee V | Owes balance | $0.00 | $34.29 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |


## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 101 - D | Fisher, Bryant | Prepaid / credit | $0.94 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 101 - E | Mason, Earl | Prepaid / credit | $232.01 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 101 - G | Hayes, Tamara | Prepaid / credit | $84.63 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 101 - I | Shell, Jamice Cierra | Prepaid / credit | $1,396.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 101 - J | Thomas, Roshawn L | Prepaid / credit | $4.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 101 - K | Smith, Tauryn M | Prepaid / credit | $93.80 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 101 - L | Smith, KyJaun | Prepaid / credit | $1,195.22 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 103 - A | Williams, Shamyria | Prepaid / credit | $16.43 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 103 - B | Lopez Gonzalez, Evelyn Wanda | Prepaid / credit | $1,429.18 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 103 - F | Fitzgerald, Brenda | Prepaid / credit | $29.89 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 105 - B | Johnson, Maurissa | Prepaid / credit | $971.87 | $0.00 | -$971.87 | [ ] Confirm paid | — |
| 105 - G | Davis, Cynthia | Prepaid / credit | $27.99 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 105 - H | Vaughan, Cynthia | Prepaid / credit | $250.09 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 201 - A | Smith, Barbara | Prepaid / credit | $934.40 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 201 - E | Byrd-Smith, Royshawnda Leeshae | Prepaid / credit | $1,649.72 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 201 - J | Reese, Bonita | Prepaid / credit | $75.01 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 201 - K | Boyd, Eltoro | Prepaid / credit | $159.50 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 201 - L | Starr, Camille N | Prepaid / credit | $1,535.40 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 202 - C | Jackson, Shaunderia | Prepaid / credit | $0.43 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 202 - K | Dishmond, Anjanette Marie | Prepaid / credit | $0.90 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 203 - C | Easter, Aaron Dion | Prepaid / credit | $1,551.70 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 204 - A | Carroll, April Nancy | Prepaid / credit | $278.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 204 - B | Harris, Tashane Ambra | Prepaid / credit | $18,443.40 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 204 - C | Hall, Shareeta M | Prepaid / credit | $3.48 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 204 - I | Parker, Melissa | Prepaid / credit | $0.45 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 204 - L | Smith, Ayanah | Prepaid / credit | $1,568.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 301 - A | Jackson, Jenetta | Prepaid / credit | $15.01 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 301 - E | Ludlow, Tunisha | Prepaid / credit | $1,482.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 301 - F | McLaughlin, TaQuona | Prepaid / credit | $252.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 301 - L | Leonard, Nija | Prepaid / credit | $26.10 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 302 - A | Taylor, Josephine Rene | Prepaid / credit | $18.40 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 302 - B | Wilkins, Cleo Monique | Prepaid / credit | $1,568.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 302 - G | Massenburg, Tenisha | Prepaid / credit | $1.75 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 302 - L | Pettiford, Gloria | Prepaid / credit | $135.08 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 303 - I | Barrett, Kaiyla | Prepaid / credit | $39.33 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 304 - A | Jones, Jerica | Prepaid / credit | $550.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 304 - I | Brown, MarquishaP | Prepaid / credit | $201.43 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 402 - A | Desmore, Na'Chelle | Prepaid / credit | $92.27 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 402 - B | Tolson, Vonda | Prepaid / credit | $1,480.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 402 - C | Golden, Willie Lee | Prepaid / credit | $1,346.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 402 - K | Stover, Talisha Elizabeth | Prepaid / credit | $57.80 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 501 - D | Wyatt, Marketta | Prepaid / credit | $69.56 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 501 - F | Blizzard-Parham, Latoya Ashley | Prepaid / credit | $101.53 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 501 - G | Serrano Vizcaino, Richerson A | Prepaid / credit | $1,628.18 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 501 - H | Jordan, Brenda Michelle | Prepaid / credit | $4.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 501 - K | Whitaker, Crystal | Prepaid / credit | $87.71 | $0.00 | $0.00 | [ ] Confirm paid | — |


## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.


## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property’s supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*
