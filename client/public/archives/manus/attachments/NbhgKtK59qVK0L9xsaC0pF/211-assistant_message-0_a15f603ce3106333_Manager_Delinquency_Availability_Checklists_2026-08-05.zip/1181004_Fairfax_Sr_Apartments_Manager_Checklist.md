# Fairfax Sr Apartments — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 1181004**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/05/2026 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Manager name | ______________________________ |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Availability PDF | `1181004_Fairfax Sr Apartments_Availability_1954055.pdf` |
| Delinquency spreadsheet(s) | `1181004_Fairfax Sr Apartments_Delinquent and Prepaid - Excel_1954126.xls`<br>`1181004_Fairfax Sr Apartments_Delinquent and Prepaid_1954091.xls` |
| Spreadsheet comparison | Review variance: 104 vs. 0 rows; $4,513.53 net-balance difference |
| Ledger accounts for review | 46 resident accounts |
| Residents with amount owed | 31 accounts; $6,544.04 |
| Prepaid / credit accounts | 15 accounts; $2,030.51 |
| Availability entries | 0 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit’s reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

No unit-level availability detail could be machine-read from this PDF. Please confirm the Availability source report during the manager call.


## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 101 | AZER, IREN | Owes balance | $0.00 | $7.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 104 | AVETIKOV, MIKHAIL G | Owes balance | $0.00 | $14.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 106 | NIMAN, ANATOLY | Owes balance | $0.00 | $8.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 108 | NEMIROVSKAYA, ALLA | Owes balance | $0.00 | $276.70 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 109 | KOSTENITSKAYA, NINA | Owes balance | $0.00 | $8.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 110 | DENISOFF, IRINA | Owes balance | $0.00 | $9.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 111 | IGNATY, ALEXANDER | Owes balance | $0.00 | $17.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 113 | YANKOVSKIY, NICK | Owes balance | $0.00 | $2.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 115 | RAIBURG, EUGENIA | Owes balance | $0.00 | $8.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 201 | KOFT, ALEXANDRA | Owes balance | $0.00 | $9.92 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 203 | JOVAN, SLAVITZA J | Owes balance | $0.00 | $8.05 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 204 | ISAEVA, KLARA E | Owes balance | $0.00 | $8.01 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 206 | RUBINOV, BORIS | Owes balance | $0.00 | $8.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 210 | KAGAN, MAYA | Owes balance | $0.00 | $8.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 211 | YOFFE, BENJAMIN | Owes balance | $0.00 | $12.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 212 | CHERNYAVSKYA, LIDIYA | Owes balance | $0.00 | $8.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 213 | CHERNYAVSKAYA, MARIYA | Owes balance | $0.00 | $3.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 214 | SHUMIN, LIOUDMILA | Owes balance | $0.00 | $8.01 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 216 | GERASYMOVA, NADIYA | Owes balance | $0.00 | $22.09 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 301 | LURYE, IOSIF | Owes balance | $0.00 | $8.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 302 | NAGIBINA, MARGARITA | Owes balance | $0.00 | $4.02 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 303 | Kharchenko, Natalya | Owes balance | $0.00 | $378.98 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 304 | LISITSA, TATYANA | Owes balance | $0.00 | $8.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 305 | BRAND, ANNA | Owes balance | $0.00 | $323.25 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 307 | KURS, SHRAGA | Owes balance | $0.00 | $901.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 308 | KANTER, BELA | Owes balance | $0.00 | $14.95 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 310 | HAKHAM, MARGRID | Owes balance | $0.00 | $8.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 312 | PEKAR, MIKHAIL | Owes balance | $0.00 | $20.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 314 | GIVENTER, TAMARA | Owes balance | $0.00 | $8.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 316 | NARODITSKAYA, FLORIDA | Owes balance | $0.00 | $181.06 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3A | Palmer, Greg | Owes balance | $0.00 | $4,244.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |


## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 103 | AKODES, OLGA | Prepaid / credit | $64.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 112 | RIMER, KLARISA | Prepaid / credit | $49.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 114 | ROSOVSKY, INNA | Prepaid / credit | $332.90 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 116 | ROMANOVA, NATALYA | Prepaid / credit | $11.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 202 | PINHASSI, INA | Prepaid / credit | $1.01 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 205 | FUKS, ALEKSEY | Prepaid / credit | $36.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 207 | FLORES, MARIA | Prepaid / credit | $608.56 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 208 | SHERSHER, ZINOVY | Prepaid / credit | $8.92 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 209 | FUKS, IRINA | Prepaid / credit | $226.08 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 215 | Agrachov, Margarita | Prepaid / credit | $5.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 306 | GARBER, BELLA | Prepaid / credit | $319.96 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 309 | KHLEVINSKY, LEONID | Prepaid / credit | $185.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 311 | Rovinsky, Svetlana | Prepaid / credit | $173.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 313 | OVSEPIAN, RAISA | Prepaid / credit | $3.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 315 | GEZEL, REGINA | Prepaid / credit | $7.08 | $0.00 | $0.00 | [ ] Confirm paid | — |


## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.


## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property’s supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*
