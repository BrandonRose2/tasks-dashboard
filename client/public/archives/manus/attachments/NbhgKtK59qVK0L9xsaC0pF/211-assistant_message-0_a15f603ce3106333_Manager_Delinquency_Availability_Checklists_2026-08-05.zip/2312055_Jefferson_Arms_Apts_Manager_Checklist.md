# Jefferson Arms Apts — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 2312055**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/05/2026 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Manager name | ______________________________ |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Availability PDF | `2312055_Jefferson Arms Apts_Availability_1954059.pdf` |
| Delinquency spreadsheet(s) | `2312055_Jefferson Arms Apts_Delinquent and Prepaid - Excel_1954130.xls`<br>`2312055_Jefferson Arms Apts_Delinquent and Prepaid_1954095.xls` |
| Spreadsheet comparison | Review variance: 84 vs. 0 rows; -$30,750.41 net-balance difference |
| Ledger accounts for review | 61 resident accounts |
| Residents with amount owed | 11 accounts; $2,232.00 |
| Prepaid / credit accounts | 53 accounts; $36,839.41 |
| Availability entries | 0 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit’s reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

No unit-level availability detail could be machine-read from this PDF. Please confirm the Availability source report during the manager call.


## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| A8 | Campbell, Debra | Owes balance | $0.00 | $44.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B3 | JOHNSON, JAUA CARUCHIA | Owes balance | $312.00 | $1.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C1 | JOHNSON, VERONICA L | Owes balance | $0.00 | $292.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C9 | Patrick, Javion D | Owes balance | $0.00 | $27.00 | $27.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E3 | Jones, Shekote T | Owes balance | $0.00 | $638.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E8 | Lewis, JhaQuorsha Kaeisa | Owes balance | $459.00 | $39.00 | $315.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G2 | Sims, Maranda K | Owes balance | $864.00 | $202.00 | $850.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G5 | VANN, KAMESHA LASHAY | Owes balance | $0.00 | $492.00 | $290.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H4 | Campbell, Jeraldine | Owes balance | $0.00 | $46.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I6 | Dansey, Tometha R | Owes balance | $0.00 | $355.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J7 | Campbell, Dedra | Owes balance | $0.00 | $96.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |


## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| A2 | KILLAM, STEVEN CHESTER | Prepaid / credit | $329.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| A3 | PARRISH, NINETTA MONICA | Prepaid / credit | $125.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| A4 | LEWIS, PRISCILLA | Prepaid / credit | $30.00 | $0.00 | -$30.00 | [ ] Confirm paid | — |
| A5 | COE, SHARAHONDRA L | Prepaid / credit | $66.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| A6 | Oliver, Jabriya L | Prepaid / credit | $762.46 | $0.00 | $0.00 | [ ] Confirm paid | — |
| A7 | SUMPTER, SANDRA DENISE | Prepaid / credit | $99.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| B3 | JOHNSON, JAUA CARUCHIA | Owes balance | $312.00 | $1.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B4 | STARLING, ETHA | Prepaid / credit | $102.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| C10 | BROWN, DESIRAY RAGINE | Prepaid / credit | $2,805.00 | $0.00 | -$1,821.00 | [ ] Confirm paid | — |
| C11 | Hill, Phylicia | Prepaid / credit | $60.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| C12 | Bellamy, Iyania | Prepaid / credit | $201.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| C2 | Kirksey, Kimyrian | Prepaid / credit | $18.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| C3 | Thomas, Kendra R | Prepaid / credit | $1,420.00 | $0.00 | -$1,054.00 | [ ] Confirm paid | — |
| C4 | Lamar, Tekisha N | Prepaid / credit | $1,646.00 | $0.00 | $1,066.00 | [ ] Confirm paid | — |
| C5 | KING, KENYATTA | Prepaid / credit | $24.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| C7 | HILLS, SHONTERIA LATRICE | Prepaid / credit | $269.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| C8 | Fishburn, Shatay R | Prepaid / credit | $226.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| D2 | Booker, Michael J | Prepaid / credit | $522.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| D3 | Coffey, Nicole Lynn | Prepaid / credit | $2,028.00 | $0.00 | -$1,434.00 | [ ] Confirm paid | — |
| E1 | BARRINGTON, JA'KERIA Q | Prepaid / credit | $2,399.00 | $0.00 | -$1,718.00 | [ ] Confirm paid | — |
| E2 | JONES, MIARA JANEICIA | Prepaid / credit | $239.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| E4 | Walker, Kimberly Y | Prepaid / credit | $306.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| E5 | Allen, Ashley | Prepaid / credit | $12.00 | $0.00 | -$12.00 | [ ] Confirm paid | — |
| E6 | Ardley, Antwhon | Prepaid / credit | $433.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| E8 | Lewis, JhaQuorsha Kaeisa | Owes balance | $459.00 | $39.00 | $315.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F2 | Livingston, Ky Mani | Prepaid / credit | $40.00 | $0.00 | -$10.00 | [ ] Confirm paid | — |
| F3 | Williams, Sheena | Prepaid / credit | $348.00 | $0.00 | -$174.00 | [ ] Confirm paid | — |
| F4 | Taylor, Vonshalya | Prepaid / credit | $101.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| F5 | Thompson, Aniyaiah | Prepaid / credit | $876.00 | $0.00 | -$219.00 | [ ] Confirm paid | — |
| F6 | Lofton, BriannaA | Prepaid / credit | $83.00 | $0.00 | -$83.00 | [ ] Confirm paid | — |
| F7 | CRIM, KATINA | Prepaid / credit | $314.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| F8 | Marlowe, Susan C | Prepaid / credit | $923.95 | $0.00 | $0.00 | [ ] Confirm paid | — |
| G1 | AKINS, LATISHA EVETTE | Prepaid / credit | $66.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| G2 | Sims, Maranda K | Owes balance | $864.00 | $202.00 | $850.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G3 | LAMAR, RUBY M | Prepaid / credit | $271.00 | $0.00 | -$187.00 | [ ] Confirm paid | — |
| G7 | SAUNDERS, TESSIE MARIE | Prepaid / credit | $1,816.00 | $0.00 | -$1,135.00 | [ ] Confirm paid | — |
| G8 | NEELY, BRIANNA | Prepaid / credit | $196.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| H1 | HOWARD, ROSE M | Prepaid / credit | $2,835.00 | $0.00 | -$1,440.00 | [ ] Confirm paid | — |
| H3 | CAMPBELL, SHATAVIA DEORSHAY | Prepaid / credit | $1,940.00 | $0.00 | -$1,346.00 | [ ] Confirm paid | — |
| H5 | FRANKLIN, KENDRA KATRICE | Prepaid / credit | $3.00 | $0.00 | -$3.00 | [ ] Confirm paid | — |
| H6 | Ghee, Jiyah | Prepaid / credit | $1,924.00 | $0.00 | -$1,276.00 | [ ] Confirm paid | — |
| H7 | Bellamy, Dikerria | Prepaid / credit | $5.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| H8 | Harrison, Tykeshiyonna Q | Prepaid / credit | $1,266.00 | $0.00 | -$948.00 | [ ] Confirm paid | — |
| I2 | Jones, Consuela | Prepaid / credit | $169.00 | $0.00 | -$95.00 | [ ] Confirm paid | — |
| I3 | Bellamy, Equilla ann | Prepaid / credit | $100.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| I4 | Beverly, Beatrice M | Prepaid / credit | $1,580.00 | $0.00 | -$1,289.00 | [ ] Confirm paid | — |
| I5 | PLEAS, JANICE | Prepaid / credit | $1,880.00 | $0.00 | -$1,304.00 | [ ] Confirm paid | — |
| I8 | Adams, Eric B | Prepaid / credit | $423.00 | $0.00 | -$36.00 | [ ] Confirm paid | — |
| J1 | Oliver, Janice | Prepaid / credit | $22.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| J2 | PARKER, CALVONTA DESHON | Prepaid / credit | $1,580.00 | $0.00 | -$1,094.00 | [ ] Confirm paid | — |
| J3 | Fishburn, Charmese J | Prepaid / credit | $348.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| J6 | Thompkins, Jaquisha | Prepaid / credit | $438.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| J8 | GRAHAM, LASHONDRA R | Prepaid / credit | $1,535.00 | $0.00 | -$1,376.00 | [ ] Confirm paid | — |


## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.


## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property’s supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*
