# New Wilmington Arms — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 2934332**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/05/2026 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Manager name | ______________________________ |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Availability PDF | `2934332_New Wilmington Arms_Availability_1954063.pdf` |
| Delinquency spreadsheet(s) | `2934332_New Wilmington Arms_Delinquent and Prepaid - Excel_1954133.xls`<br>`2934332_New Wilmington Arms_Delinquent and Prepaid_1954098.xls` |
| Spreadsheet comparison | Review variance: 153 vs. 0 rows; $78,396.51 net-balance difference |
| Ledger accounts for review | 129 resident accounts |
| Residents with amount owed | 40 accounts; $97,239.82 |
| Prepaid / credit accounts | 89 accounts; $18,915.81 |
| Availability entries | 0 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit’s reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

No unit-level availability detail could be machine-read from this PDF. Please confirm the Availability source report during the manager call.


## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| A104 | TELLEZ, AURORA Y | Owes balance | $0.00 | $653.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A107 | SLAUGHTER, CHRISTINA F | Owes balance | $0.00 | $2,196.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A216 | OLIVAS, ALONDRA | Owes balance | $0.00 | $317.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A218 | MADISON, FALLON G | Owes balance | $0.00 | $25.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B101 | NAVA-ONTIVEROS, MAYRA L | Owes balance | $0.00 | $20.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B102 | HARREL, CELESTINE | Owes balance | $0.00 | $20.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B207 | ANGELES MULATO, ESMERALDA | Owes balance | $0.00 | $89.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C105 | CASTELAN, JENNIFER | Owes balance | $0.00 | $3,855.00 | $780.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D110 | HAYNES, JACQUELINE D | Owes balance | $0.00 | $780.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D111 | LAW, SHAKEIA L | Owes balance | $0.00 | $302.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D216 | BRISBY, KIARA | Owes balance | $0.00 | $54.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D218 | JONES, LILLIE | Owes balance | $0.00 | $95.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D221 | MACIAS, ELISABETH | Owes balance | $0.00 | $555.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E108 | SERRANO, RUBIA | Owes balance | $0.00 | $3,611.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E212 | FLORES, ANGELICA | Owes balance | $0.00 | $3,612.00 | $489.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E214 | MALDONADO, JUAN L | Owes balance | $0.00 | $10,151.00 | $4,850.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F104 | ROMERO ESTRADA, JOANA | Owes balance | $0.00 | $48.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F207 | DAVENPORT, ANDRE A | Owes balance | $0.00 | $1,913.00 | $1,325.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G215 | BRYAN, JAMES R | Owes balance | $0.00 | $3,504.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G219 | RODRIGUEZ, MARIA S | Owes balance | $0.00 | $809.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G220 | VARGAS-COLIN, MARIA E | Owes balance | $0.00 | $8,085.00 | $1,959.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H102 | MANZO, JOSEFINA | Owes balance | $0.00 | $215.00 | $134.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H104 | CALVO-FAUSTINOS, MA GUADALUPE | Owes balance | $0.00 | $270.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H105 | BEJARANO, MARY | Owes balance | $0.00 | $27,672.00 | $22,431.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H106 | CAMACHO, JASMIN | Owes balance | $0.00 | $5.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H108 | MEJIA, MONIQUE M | Owes balance | $0.00 | $13.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H216 | DAVIS, KESHIA R | Owes balance | $0.00 | $4,454.00 | $1,022.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H219 | SANCHEZ, JOANA MARLEN | Owes balance | $0.00 | $3,890.00 | $401.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H222 | WILLIAMS, SUSIE | Owes balance | $0.00 | $876.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H223 | LUVIANO MALDONADO, MARGARITA | Owes balance | $0.00 | $10,201.00 | $7,174.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J102 | HAYES, CRYSTAL W | Owes balance | $0.00 | $230.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J207 | STONE, MICHELLE A | Owes balance | $0.00 | $51.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J208 | BLACK, LASONYA Y | Owes balance | $0.00 | $350.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J309 | WOODS, BRITTANIA | Owes balance | $0.00 | $5,996.82 | $1,496.82 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K207 | BROWN, REMY R | Owes balance | $0.00 | $1,072.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K309 | GIBSON, ROMEL | Owes balance | $0.00 | $9.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K310 | WILEY, BRANDY RENEE | Owes balance | $0.00 | $380.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K312 | HOLDEN, CORA D | Owes balance | $0.00 | $376.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L102 | YVANEZ, ANGELICA Y | Owes balance | $0.00 | $329.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L208 | MURPHY, DESHAY L | Owes balance | $0.00 | $156.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |


## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| A102 | ANDRUS, THERESE L | Prepaid / credit | $18.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| A103 | RAND, STEVE | Prepaid / credit | $78.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| A105 | MENDOZA, ELIZABETH | Prepaid / credit | $132.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| A106 | RIOS, VERONICA | Prepaid / credit | $17.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| A108 | CASTRO GUTIEREZ, ORLANDO A | Prepaid / credit | $77.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| A109 | GUEVARA, ZULEMA | Prepaid / credit | $9.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| A212 | WILLIAMS, COLETTE D | Prepaid / credit | $688.00 | $0.00 | -$490.00 | [ ] Confirm paid | — |
| A215 | RODRIGUEZ, YESENIA | Prepaid / credit | $20.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| A217 | PICKERING, JONATHAN N | Prepaid / credit | $3,331.00 | $0.00 | -$1,707.00 | [ ] Confirm paid | — |
| B103 | MEDRANO, JULISA | Prepaid / credit | $183.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| B208 | WILSON, ALANNA R | Prepaid / credit | $127.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| C101 | JIMENEZ LUVIANO, NATALY | Prepaid / credit | $208.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| C102 | GRIFFIN, MARCH D | Prepaid / credit | $2.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| C103 | ANGLON, SHARISE R | Prepaid / credit | $422.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| C106 | HERNANDEZ RODRIGUEZ, MARINA | Prepaid / credit | $739.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| C208 | BROMELL, ERVIN | Prepaid / credit | $2.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| C209 | CALVILLO, ELIZABETH | Prepaid / credit | $205.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| C210 | WILLIAMS, MARNETTE | Prepaid / credit | $259.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| C211 | GANDY, MACHELLE | Prepaid / credit | $333.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| C212 | SIGALA, BRIAN A | Prepaid / credit | $913.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| D101 | GUTIERREZ, MARGARITA | Prepaid / credit | $36.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| D104 | JONES, VERNETTA H | Prepaid / credit | $70.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| D107 | MENDOZA, CLAUDIA JHANNET | Prepaid / credit | $178.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| D109 | MCKINNEY, QUAEMIA S | Prepaid / credit | $0.33 | $0.00 | $0.00 | [ ] Confirm paid | — |
| D215 | ENGLISH, ALICE F | Prepaid / credit | $287.73 | $0.00 | $0.00 | [ ] Confirm paid | — |
| D217 | HERNANDEZ, JOSEPHINA | Prepaid / credit | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| D219 | REYES, ALEJANDRO | Prepaid / credit | $219.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| D220 | MACIAS LOPEZ, YOLANDA | Prepaid / credit | $1.64 | $0.00 | $0.00 | [ ] Confirm paid | — |
| D222 | FIGUEROA, JUANA M | Prepaid / credit | $85.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| E102 | GOMEZ, MARISELA | Prepaid / credit | $27.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| E103 | CALDERON, MARIA LUISA | Prepaid / credit | $785.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| E104 | LOPEZ CORONA, LIZBETH | Prepaid / credit | $25.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| E106 | WHITAKER, SHEKIA SHREE | Prepaid / credit | $4.03 | $0.00 | $0.00 | [ ] Confirm paid | — |
| E107 | ROMERO ESTRADA, FLORINDA ISABEL | Prepaid / credit | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| E209 | WALKER, ROCHELLE M | Prepaid / credit | $20.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| E211 | SPEARS, SHENNA M | Prepaid / credit | $3.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| E213 | ESTRADA TORRES, DALIA MIRAMA | Prepaid / credit | $30.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| E216 | WHITE, KATHERINE L | Prepaid / credit | $760.00 | $0.00 | -$532.00 | [ ] Confirm paid | — |
| F101 | FAIRLEY, TASHON | Prepaid / credit | $45.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| F103 | DE LEON, OLGA C | Prepaid / credit | $304.00 | $0.00 | -$127.00 | [ ] Confirm paid | — |
| F205 | BROWN, KIM R | Prepaid / credit | $20.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| F206 | LAWRENCE, LOSHALL R | Prepaid / credit | $333.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| F208 | GRANT, ROSIEMARIA A | Prepaid / credit | $80.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| G102 | MARTINEZ SOLORIO, JULIO C | Prepaid / credit | $216.00 | $0.00 | $72.50 | [ ] Confirm paid | — |
| G103 | MARTINEZ, BELEN | Prepaid / credit | $677.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| G105 | RODRIGUEZ OCEGUERA, FERNANDO | Prepaid / credit | $5.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| G106 | MORENO, CECILIA | Prepaid / credit | $8.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| G107 | GANT, SHANIKA L | Prepaid / credit | $19.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| G108 | GUTIERREZ, JOANNA MARITHZA | Prepaid / credit | $11.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| G110 | LOPEZ DURAN, ADRIANA | Prepaid / credit | $244.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| G211 | CASTILLO, ALMA V | Prepaid / credit | $11.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| G213 | MEDINA DE LA PAZ, MIRNA L | Prepaid / credit | $262.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| G214 | LUVIANO MALDONADO, ESMERALDA E | Prepaid / credit | $132.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| G216 | WILDER, KIM | Prepaid / credit | $54.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| G217 | MENDEZ, GABRIELA | Prepaid / credit | $15.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| G218 | LOVE, EDITH | Prepaid / credit | $22.75 | $0.00 | $0.00 | [ ] Confirm paid | — |
| H101 | JIMENEZ, RAYMUNDO | Prepaid / credit | $85.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| H107 | RANGEL, JUANA | Prepaid / credit | $17.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| H110 | CARRANZA, RUFINA | Prepaid / credit | $14.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| H111 | VALENCIA, BEATRICE TERESA | Prepaid / credit | $157.00 | $0.00 | -$115.00 | [ ] Confirm paid | — |
| H213 | CHAVEZ, JENIFER | Prepaid / credit | $6.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| H214 | PAREDES NAVARRO, MARTHA A | Prepaid / credit | $60.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| H215 | ANCIRA, AIDEE | Prepaid / credit | $20.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| H217 | ARIAS, GLORIA M | Prepaid / credit | $73.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| H218 | HOWLETT, KEENAN L | Prepaid / credit | $230.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| H220 | SERRANO, SANDRA JASMIN | Prepaid / credit | $126.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| H224 | AVILA, CELIA | Prepaid / credit | $300.00 | $0.00 | -$175.00 | [ ] Confirm paid | — |
| J103 | LAZARO, ROSA O | Prepaid / credit | $739.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| J104 | ALVARADO MOLINA, MARIANELA | Prepaid / credit | $36.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| J205 | STAPLES, FELICIA | Prepaid / credit | $183.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| J206 | VALDEZ, JENNIFER | Prepaid / credit | $66.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| J310 | MINTZ, DEBORAH a | Prepaid / credit | $80.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| J311 | VALLE, JUANITA | Prepaid / credit | $76.03 | $0.00 | $0.00 | [ ] Confirm paid | — |
| J312 | IVORY, SHANICE M | Prepaid / credit | $28.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| K101 | KERR, KEYANNA | Prepaid / credit | $104.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| K103 | JUAREZ, SOLEDADA | Prepaid / credit | $1,945.00 | $0.00 | -$1,939.00 | [ ] Confirm paid | 09/19/2024 |
| K104 | RISON, DARLENA | Prepaid / credit | $2.80 | $0.00 | $0.00 | [ ] Confirm paid | — |
| K205 | JACOBS, DANTE J | Prepaid / credit | $3.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| K206 | PERDERGROW, LADONNA | Prepaid / credit | $43.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| K311 | Williams, ANDREA DANIELA | Prepaid / credit | $5.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| L101 | MILLER, JOHNNIE L | Prepaid / credit | $319.50 | $0.00 | $0.00 | [ ] Confirm paid | — |
| L103 | CHAVEZ, MARINA A | Prepaid / credit | $17.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| L104 | MC CUNE, MARIAN | Prepaid / credit | $6.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| L205 | DIGGINS II, MICHAEL N | Prepaid / credit | $424.00 | $0.00 | -$151.00 | [ ] Confirm paid | — |
| L206 | TIPPIN, JUSTICE L | Prepaid / credit | $426.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| L309 | ALFARO-BELTRAN, EVELYN N | Prepaid / credit | $84.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| L310 | BUTLER, TERRY D | Prepaid / credit | $72.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| L311 | HUGHES, CHARLES R | Prepaid / credit | $352.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| L312 | DREAR, JAMIE | Prepaid / credit | $61.00 | $0.00 | $0.00 | [ ] Confirm paid | — |


## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.


## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property’s supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*
