# Howell Place — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 5313974**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/03/2026 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Manager name | ______________________________ |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Availability PDF | `5313974_Howell Place_Availability_1954085.pdf` |
| Delinquency spreadsheet(s) | `5313974_Howell Place_Delinquent and Prepaid - Excel_1954155.xls`<br>`5313974_Howell Place_Delinquent and Prepaid_1954120.xls` |
| Spreadsheet comparison | Review variance: 31 vs. 0 rows; -$2,031.12 net-balance difference |
| Ledger accounts for review | 24 resident accounts |
| Residents with amount owed | 15 accounts; $1,284.68 |
| Prepaid / credit accounts | 9 accounts; $3,315.80 |
| Availability entries | 8 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit’s reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| 3-324 | 4B2B | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 4-414 | 2B2B | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 5-521 | 2B2B | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 5-512 | 1B1B | NTV Not Leased | [ ] Verified | __________________ |
| 5-522 | 1B1B | NTV Not Leased | [ ] Verified | __________________ |
| 3-311 | 4B2B | Vacant Leased Not Ready | [ ] Verified | __________________ |
| 3-314 | 4B2B | Vacant Leased Not Ready | [ ] Verified | __________________ |
| As | of | Vacant Leased Not Ready | [ ] Verified | __________________ |


## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - 124 | Oliver, Saran | Owes balance | $0.00 | $136.77 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 211 | Thomas, Deborah | Owes balance | $0.00 | $53.05 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 213 | Broden, Vivian | Owes balance | $0.00 | $96.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 222 | Warren, Nacole Renay | Owes balance | $0.00 | $17.43 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 312 | Landry, Rachelle | Owes balance | $0.00 | $11.50 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 321 | Jones, Lashica | Owes balance | $0.00 | $9.50 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 323 | Armstrong, Tammie Madonna | Owes balance | $0.00 | $82.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 416 | Lewis, Oakley | Owes balance | $0.00 | $98.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 422 | Hurry, Kayla | Owes balance | $0.00 | $11.60 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 423 | Bailey, Deaundre T | Owes balance | $0.00 | $85.81 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 426 | Tickles, Jacquan | Owes balance | $0.00 | $301.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 522 | Constant, Shirley | Owes balance | $0.00 | $164.73 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 523 | Edmond, Doris | Owes balance | $0.00 | $10.86 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 524 | Winfrey, Destiny | Owes balance | $0.00 | $182.43 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 525 | Cafey, Wendy Jane | Owes balance | $0.00 | $24.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |


## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - 122 | Williams, Shayla | Prepaid / credit | $374.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 214 | Wilson, Roderica | Prepaid / credit | $510.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - 424 | Broden, Charlotte Nicole | Prepaid / credit | $0.70 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 511 | Holts, Trini L | Prepaid / credit | $24.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 512 | Edwards, Sharon | Prepaid / credit | $4.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 513 | Belt, Linda | Prepaid / credit | $175.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 514 | Jones, Jessica | Prepaid / credit | $150.10 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 516 | Wilson, Ida | Prepaid / credit | $1,051.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 526 | Franklin, Joeronta | Prepaid / credit | $1,027.00 | $0.00 | $0.00 | [ ] Confirm paid | — |


## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.


## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property’s supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*
