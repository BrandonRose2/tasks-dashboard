# Marrero 3 LP — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 4276597**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/05/2026 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Manager name | ______________________________ |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Availability PDF | `4276597_Marrero 3 LP_Availability_1954075.pdf` |
| Delinquency spreadsheet(s) | `4276597_Marrero 3 LP_Delinquent and Prepaid - Excel_1954145.xls`<br>`4276597_Marrero 3 LP_Delinquent and Prepaid_1954110.xls` |
| Spreadsheet comparison | Review variance: 147 vs. 0 rows; -$15,210.19 net-balance difference |
| Ledger accounts for review | 99 resident accounts |
| Residents with amount owed | 41 accounts; $12,681.14 |
| Prepaid / credit accounts | 60 accounts; $28,472.33 |
| Availability entries | 1 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit’s reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| As | of | Vacant Leased Not Ready | [ ] Verified | __________________ |


## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 05 - 546A | Walkey, Leonise | Owes balance | $0.00 | $200.12 | $164.12 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 568A | Taylor, Verna J | Owes balance | $0.00 | $96.00 | $60.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 103 - 7137H | Williams, Anisha Vanita | Owes balance | $0.00 | $1,112.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 572A | Johnson, Sandra | Owes balance | $0.00 | $36.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 114 - 7100K | Burns, Valerie C | Owes balance | $0.00 | $120.00 | $84.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 121 - 7113K | Williams, Tearrani'Cheress | Owes balance | $0.00 | $24.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 122 - 7116K | Hunter, Terri | Owes balance | $0.00 | $271.02 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 138 - 1916S | Houston, Shabrina | Owes balance | $0.00 | $76.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 139 - 1920S | Anderson, Kenisha | Owes balance | $0.00 | $75.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 142 - 6804SA | Batiste, Vernida | Owes balance | $14.00 | $418.00 | -$14.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 151 - 6900SA | Shirley, CarmesiaRekay | Owes balance | $0.00 | $180.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 152 - 6901SA | Brooks, Tersina | Owes balance | $0.00 | $292.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 154 - 6912SA | Robinson, Michaelena | Owes balance | $0.00 | $563.00 | $377.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 156 - 6917SA | Williams, Ashley R | Owes balance | $0.00 | $1,390.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 161 - 6936SA | Carter, Latoryer | Owes balance | $0.00 | $474.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 163 - 6936G | Brooks, Anita L | Owes balance | $0.00 | $152.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 164 - 6813SA | Ford, Tiriaun N | Owes balance | $0.00 | $15.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 168 - 6821SA | Williams, Trena L | Owes balance | $0.00 | $44.00 | $8.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 169 - 6909SA | Berry, Acharmbi | Owes balance | $0.00 | $36.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 547F | Jasmine, Alice | Owes balance | $0.00 | $496.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 27 - 609F | Ford, Gregory | Owes balance | $0.00 | $43.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 33 - 539S | Wiggins, Tammara M | Owes balance | $0.00 | $433.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 34 - 543S | Hudson, Sha'Ron | Owes balance | $0.00 | $224.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 44 - 625S | Blunt, TerrioneDanielle | Owes balance | $0.00 | $75.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 47 - 628F | White, FayeAnn | Owes balance | $0.00 | $285.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 50 - 1116 | Badon, Davineka Deloris Ladae | Owes balance | $0.00 | $775.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 56 - 1204 | Wilson, Valeria | Owes balance | $0.00 | $56.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 58 - 1206 | Collins, Latasha | Owes balance | $0.00 | $377.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 60 - 1209 | Hunter, Ashante | Owes balance | $0.00 | $737.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 61 - 1211 | Jackson, Margaret Nacole | Owes balance | $0.00 | $171.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 63 - 1217 | Simmons, Pricilla | Owes balance | $0.00 | $1,113.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 64 - 1219 | Polezcek, Theresa | Owes balance | $0.00 | $12.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 65 - 1301 | Cornish, DesireeShudae | Owes balance | $0.00 | $108.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 67 - 1305 | Mack, Kimber Michelle | Owes balance | $0.00 | $167.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 72 - 1114 | Davis, MiracleBernice | Owes balance | $0.00 | $99.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 78 - 3136 | Leagea, Shanta | Owes balance | $0.00 | $52.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 79 - 3132 | Turner, Reginik | Owes balance | $0.00 | $800.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 81 - 3124 | Varnado, Tiffany | Owes balance | $0.00 | $179.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 85 - 3112 | Turner Red, Elise | Owes balance | $0.00 | $724.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 89 - 3127 | Peck, Jessie | Owes balance | $87.00 | $107.00 | -$87.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 97 - 3124 | Baudoin, Chanel | Owes balance | $0.00 | $74.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |


## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 02 - 534A | Harris, Shemeka Lynn | Prepaid / credit | $748.00 | $0.00 | -$626.00 | [ ] Confirm paid | — |
| 03 - 538A | Thompson, Mary | Prepaid / credit | $22.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 04 - 542A | Batiste, Cynthia | Prepaid / credit | $2.77 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 06 - 550A | Lambert, CarlaHodges | Prepaid / credit | $348.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 08 - 560A | Jasmine, BrittanyNikida | Prepaid / credit | $11.00 | $0.00 | -$11.00 | [ ] Confirm paid | — |
| 101 - 7133H | Mouton, Cheryl | Prepaid / credit | $260.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 102 - 7134H | Scott, Keshanne | Prepaid / credit | $1,974.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 105 - 7141H | Bernard, Lisa | Prepaid / credit | $321.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 113 - 7162H | Carey, Alicia R | Prepaid / credit | $4,972.00 | $0.00 | -$4,972.00 | [ ] Confirm paid | — |
| 115 - 7101K | Singleton, Eloise | Prepaid / credit | $1,144.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 116 - 7104K | Spencer, Patrice | Prepaid / credit | $300.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 120 - 7112K | Dunbar, Jennie A | Prepaid / credit | $190.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 125 - 7121K | Roberts, Iyanna Marie | Prepaid / credit | $168.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 129 - 7137K | Moore- Farrow, Carolyn | Prepaid / credit | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 13 - 539F | Reese, Tamara | Prepaid / credit | $41.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 130 - 7141K | Sheppard, StephanieMarie | Prepaid / credit | $254.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 136 - 6908G | Sanders, Donisha M | Prepaid / credit | $749.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 140 - 2000S | Walker, Tracy Nicole | Prepaid / credit | $254.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 141 - 6802SA | Peters, Ireyaun | Prepaid / credit | $23.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 142 - 6804SA | Batiste, Vernida | Owes balance | $14.00 | $418.00 | -$14.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 143 - 6808SA | Ross, ShantaRayon | Prepaid / credit | $240.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 147 - 6820SA | Haywood, Tiffiney | Prepaid / credit | $74.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 15 - 543F | Jackson, Alice | Prepaid / credit | $1,112.00 | $0.00 | -$24.00 | [ ] Confirm paid | — |
| 150 - 6829SA | Pinion, Mary | Prepaid / credit | $14.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 155 - 6916SA | Caston, RuthMae | Prepaid / credit | $75.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 159 - 6924SA | Bernard, CharlotteFelicia | Prepaid / credit | $16.00 | $0.00 | -$16.00 | [ ] Confirm paid | — |
| 160 - 6932SA | Dabney, Tanjal | Prepaid / credit | $108.00 | $0.00 | -$12.00 | [ ] Confirm paid | — |
| 167 - 6805SA | Lewis, Wendy M | Prepaid / credit | $12.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 171 - 6825SA | LAMBERT, LAKEISHA | Prepaid / credit | $76.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 172 - 6905SA | Hillard, Lois | Prepaid / credit | $12.00 | $0.00 | -$12.00 | [ ] Confirm paid | — |
| 19 - 551F | Banks, Loretta | Prepaid / credit | $39.02 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 22 - 560F | Simmons, Neknitta Marie | Prepaid / credit | $646.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 23 - 601F | Bailey, Chianti Teleka | Prepaid / credit | $1,723.00 | $0.00 | -$1,723.00 | [ ] Confirm paid | — |
| 28 - 612F | Butler, Deborah | Prepaid / credit | $1,112.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 30 - 620F | Quinn, Keyanna M | Prepaid / credit | $75.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 36 - 551S | Jones, Kavis | Prepaid / credit | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 38 - 601S | Simon, Vannika Mione | Prepaid / credit | $247.00 | $0.00 | -$247.00 | [ ] Confirm paid | — |
| 40 - 609S | Hankerson, Felecia | Prepaid / credit | $146.98 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 43 - 621S | Dillon, Joyce | Prepaid / credit | $245.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 45 - 629S | Hill, Andrea | Prepaid / credit | $1,339.00 | $0.00 | -$364.00 | [ ] Confirm paid | — |
| 46 - 624F | Blunt, Trenisha | Prepaid / credit | $20.05 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 49 - 1112 | Anderson, BaidgetJannai | Prepaid / credit | $8.72 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 52 - 1119 | Spencer, Mickal Chreshal | Prepaid / credit | $1,044.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 53 - 1121 | Johnson, Rochelle | Prepaid / credit | $265.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 68 - 1309 | Harris, Chan'Tavia | Prepaid / credit | $50.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 69 - 1313 | Moore, Cabrina | Prepaid / credit | $71.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 70 - 1317 | Henderson, Paris | Prepaid / credit | $90.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 73 - 1208 | Little, Marcus | Prepaid / credit | $1,898.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 80 - 3128 | Wallace, Harriet | Prepaid / credit | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 83 - 3116 | Poole, Shameka | Prepaid / credit | $69.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 84 - 3108 | Johnson, Jacqueline | Prepaid / credit | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 86 - 3101 | Braxton, TiffianyMonquie | Prepaid / credit | $384.00 | $0.00 | -$384.00 | [ ] Confirm paid | — |
| 89 - 3127 | Peck, Jessie | Owes balance | $87.00 | $107.00 | -$87.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 90 - 3148 | Hawkins, DemetricAnn | Prepaid / credit | $604.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 91 - 3137 | Major, Derionisha | Prepaid / credit | $2,549.00 | $0.00 | -$1,699.00 | [ ] Confirm paid | — |
| 93 - 3117 | Spotville, NadineNicole | Prepaid / credit | $75.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 94 - 3121 | Kendeu, Andre | Prepaid / credit | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 95 - 3125 | McKnight, Brittany Dichelle | Prepaid / credit | $4.00 | $0.00 | -$4.00 | [ ] Confirm paid | — |
| 96 - 3129 | Young, Shana | Prepaid / credit | $1,124.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 99 - 7129H | Gipson, Doris | Prepaid / credit | $1,016.79 | $0.00 | -$171.00 | [ ] Confirm paid | — |


## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.


## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property’s supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*
