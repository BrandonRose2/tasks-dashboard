# Midtown Manor — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 1181005**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/05/2026 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Manager name | ______________________________ |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Availability PDF | `1181005_Midtown Manor_Availability_1954056.pdf` |
| Delinquency spreadsheet(s) | `1181005_Midtown Manor_Delinquent and Prepaid - Excel_1954127.xls`<br>`1181005_Midtown Manor_Delinquent and Prepaid_1954092.xls` |
| Spreadsheet comparison | Review variance: 35 vs. 0 rows; $3,969.42 net-balance difference |
| Ledger accounts for review | 25 resident accounts |
| Residents with amount owed | 12 accounts; $5,110.19 |
| Prepaid / credit accounts | 13 accounts; $1,140.77 |
| Availability entries | 0 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit’s reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

No unit-level availability detail could be machine-read from this PDF. Please confirm the Availability source report during the manager call.


## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 102B | MCCOY, SHERRY | Owes balance | $0.00 | $0.37 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 103B | MATTHEWS, SANDRA | Owes balance | $0.00 | $1,430.60 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 105A | LOVE, ERIC R | Owes balance | $0.00 | $1,307.28 | $428.40 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 106A | AJAYI, LATEEF | Owes balance | $0.00 | $339.51 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 201A | ROSADO LOPEZ, LUIS R | Owes balance | $0.00 | $962.28 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 201B | BENTON, JASON | Owes balance | $0.00 | $256.06 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 202B | Jone, Donna Marie Dockory | Owes balance | $0.00 | $39.55 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 203A | WHALEY, KIMON | Owes balance | $0.00 | $165.58 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 203B | SHANNON, TRAVIS | Owes balance | $0.00 | $395.08 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 205A | WEBB, PHILLIP | Owes balance | $0.00 | $5.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 206B | DIXON, ANTHONY | Owes balance | $0.00 | $11.88 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 207A | DORANTES, AURORA | Owes balance | $0.00 | $197.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |


## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 101A | MILLER JACKSON, KINITA | Prepaid / credit | $48.66 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 102A | JONES, HAROLD | Prepaid / credit | $53.13 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 103A | BALL III, ROY DELL | Prepaid / credit | $1.96 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 104A | STRONG, SHEILA R | Prepaid / credit | $74.78 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 105B | STANLEY, DAVID K | Prepaid / credit | $149.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 106B | BRADFORD, KENNETH | Prepaid / credit | $186.03 | $0.00 | -$66.03 | [ ] Confirm paid | — |
| 107B | TRAVIS, FELIX D | Prepaid / credit | $40.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 108B | SALINAS, VICTORIANA | Prepaid / credit | $229.08 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 202A | COLORADO, ROSARIO MARGOTH | Prepaid / credit | $15.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 204B | LYLES, WALTER | Prepaid / credit | $27.80 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 205B | WEST, LATASHA L | Prepaid / credit | $100.28 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 207B | DONNELL, TRINA E | Prepaid / credit | $175.44 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 208A | MALOY, FRANK | Prepaid / credit | $39.61 | $0.00 | $0.00 | [ ] Confirm paid | — |


## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.


## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property’s supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*
