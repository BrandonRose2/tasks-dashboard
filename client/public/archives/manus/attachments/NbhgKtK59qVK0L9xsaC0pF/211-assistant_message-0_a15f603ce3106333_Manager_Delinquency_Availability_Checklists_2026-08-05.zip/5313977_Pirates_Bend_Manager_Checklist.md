# Pirates Bend — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 5313977**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/03/2026 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Manager name | ______________________________ |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Availability PDF | `5313977_Pirates Bend_Availability_1954087.pdf` |
| Delinquency spreadsheet(s) | `5313977_Pirates Bend_Delinquent and Prepaid - Excel_1954157.xls`<br>`5313977_Pirates Bend_Delinquent and Prepaid_1954122.xls` |
| Spreadsheet comparison | Review variance: 27 vs. 0 rows; -$2,245.13 net-balance difference |
| Ledger accounts for review | 19 resident accounts |
| Residents with amount owed | 10 accounts; $3,064.27 |
| Prepaid / credit accounts | 9 accounts; $5,327.40 |
| Availability entries | 9 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit’s reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| 2-212 | 4B2Ba | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 2-224 | 4B2Ba | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 4-414 | 1B1Ba | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 4-423 | 1B1Ba | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 4-426 | 2B2Ba | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 5-513 | 3B2Ba | NTV Not Leased | [ ] Verified | __________________ |
| leak | from | NTV Not Leased | [ ] Verified | __________________ |
| 1-113 | 3B2Ba | Vacant Leased Ready | [ ] Verified | __________________ |
| As | of | Vacant Leased Ready | [ ] Verified | __________________ |


## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 2 - 214 | Knight, Ryneshia | Owes balance | $0.00 | $2.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 315 | White, Tequan | Owes balance | $0.00 | $1,151.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 322 | Brumfield, Kyle | Owes balance | $0.00 | $923.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 416 | Aucoin, Mary | Owes balance | $0.00 | $112.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 421 | Ealy, Shenka Dente | Owes balance | $0.00 | $0.54 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 424 | Chatman, Thaddus | Owes balance | $0.00 | $28.27 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 512 | Spears, Trevonna | Owes balance | $0.00 | $410.86 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 521 | Collins, Brian Dewayne | Owes balance | $0.00 | $35.60 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 522 | Harris, Shayla | Owes balance | $0.00 | $322.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 524 | Lee, Yolanda | Owes balance | $0.00 | $79.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |


## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - 111 | Harris, Alexis | Prepaid / credit | $50.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 121 | Cross, Romal | Prepaid / credit | $1,206.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 124 | Pinkney, Adrianna | Prepaid / credit | $1,206.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 223 | Bougere, Nicole | Prepaid / credit | $311.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 313 | Chandler, Christopher | Prepaid / credit | $2.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 324 | Palmer, Doreen | Prepaid / credit | $212.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - 411 | Smith, Tarongela | Prepaid / credit | $169.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - 422 | Matthews, Shandrika D | Prepaid / credit | $1,051.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 514 | Washington, Tonya Nicole | Prepaid / credit | $1,120.40 | $0.00 | $0.00 | [ ] Confirm paid | — |


## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.


## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property’s supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*
