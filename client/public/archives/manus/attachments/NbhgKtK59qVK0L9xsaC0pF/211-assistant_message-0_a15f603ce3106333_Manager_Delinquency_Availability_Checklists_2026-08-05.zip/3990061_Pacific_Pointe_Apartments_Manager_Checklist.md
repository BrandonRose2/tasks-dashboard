# Pacific Pointe Apartments — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 3990061**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/04/2026 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Manager name | ______________________________ |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Availability PDF | `3990061_Pacific Pointe Apartments_Availability_1954070.pdf` |
| Delinquency spreadsheet(s) | `3990061_Pacific Pointe Apartments_Delinquent and Prepaid - Excel_1954140.xls`<br>`3990061_Pacific Pointe Apartments_Delinquent and Prepaid_1954105.xls` |
| Spreadsheet comparison | Review variance: 69 vs. 0 rows; $5,480.60 net-balance difference |
| Ledger accounts for review | 66 resident accounts |
| Residents with amount owed | 39 accounts; $17,194.19 |
| Prepaid / credit accounts | 27 accounts; $11,713.59 |
| Availability entries | 3 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit’s reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| 4-H6 | 2B1B | Vacant Not Leased Ready | [ ] Verified | __________________ |
| 1-A4 | 1B1B | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 1-B1 | 1B1B | Vacant Not Leased Not Ready | [ ] Verified | __________________ |


## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - A2 | Lopez, Linda rose | Owes balance | $0.00 | $194.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - A3 | Teel, Roslynn | Owes balance | $0.00 | $237.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - A5 | Gonzales, Geraldine | Owes balance | $0.00 | $377.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - A7 | Williams, Cheryl | Owes balance | $0.00 | $116.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - B6 | Gist, Melissa | Owes balance | $0.00 | $629.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - B8 | Jordan, Oscar | Owes balance | $0.00 | $871.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - C1 | Thurmond, Kathy ann | Owes balance | $0.00 | $330.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - C3 | Arquines, Felipe J | Owes balance | $0.00 | $648.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - C5 | Scippio, Novis | Owes balance | $0.00 | $98.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - C6 | Pope, Embry | Owes balance | $0.00 | $3,349.00 | $355.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - C8 | King, Bianca Jewel | Owes balance | $0.00 | $76.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - D2 | Timberlake, Lorraine | Owes balance | $0.00 | $76.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - D3 | Matlard, Blondell K | Owes balance | $0.00 | $215.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - D6 | Lawson, Vera | Owes balance | $0.00 | $1,024.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - D7 | Ryan, Dejanay | Owes balance | $0.00 | $1,503.00 | $306.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - D8 | Jackson, Natashya | Owes balance | $0.00 | $143.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - E4 | Turner, Hope | Owes balance | $0.00 | $468.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - E7 | TALTON, ROSE | Owes balance | $0.00 | $603.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - F1 | Plaster, Brandy N | Owes balance | $0.00 | $204.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - F2 | Taylor, Betty Ann | Owes balance | $0.00 | $372.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - F5 | West Taylor, Inesha | Owes balance | $0.00 | $124.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - F7 | Ward, Ruby | Owes balance | $0.00 | $94.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - G3 | Edmond, Mathew | Owes balance | $0.00 | $244.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - G4 | Booth, Barbara | Owes balance | $0.00 | $21.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - G5 | Van, Thoeun | Owes balance | $0.00 | $233.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - G6 | Alvarado, Debbie Marie | Owes balance | $0.00 | $1,246.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - G8 | Russell, Jevon | Owes balance | $0.00 | $275.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - H1 | Tenette, Anthony J | Owes balance | $0.00 | $157.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - H3 | Ontiveros, Anthony Louis | Owes balance | $0.00 | $270.65 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - H8 | Leon, Silvia I | Owes balance | $0.00 | $183.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - I1 | King, Janice | Owes balance | $0.00 | $567.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - I7 | Lott, Donald Ray | Owes balance | $0.00 | $728.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - I8 | Ramirez, Susie Ann | Owes balance | $0.00 | $36.99 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - J1 | Conley, Jimmy | Owes balance | $0.00 | $111.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - J2 | Batton, Jeffrey | Owes balance | $0.00 | $795.24 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - J4 | Morales, Jeanine Casey | Owes balance | $0.00 | $12.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - J5 | Harris, Kimba | Owes balance | $0.00 | $248.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - J6 | Grigsby, Kim c | Owes balance | $0.00 | $153.31 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - J8 | Loud, Brittany | Owes balance | $0.00 | $162.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |


## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - A6 | Hernandez, Agustin | Prepaid / credit | $930.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - A8 | Russell, Lakin | Prepaid / credit | $850.00 | $0.00 | -$850.00 | [ ] Confirm paid | — |
| 1 - B3 | BLAKE, REGINA | Prepaid / credit | $172.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - B5 | Fosterf, Antonio | Prepaid / credit | $1,163.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - B7 | Huber, Hailey Anne | Prepaid / credit | $2,125.00 | $0.00 | -$400.00 | [ ] Confirm paid | — |
| 2 - C2 | Camarillo, Rogelio | Prepaid / credit | $45.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - C4 | Sorce, Joseph | Prepaid / credit | $3.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - C7 | Blackburn, Niesha S | Prepaid / credit | $250.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - D1 | McGill, Pennie | Prepaid / credit | $30.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - D4 | Herrmann, Bradley R | Prepaid / credit | $455.00 | $0.00 | -$291.00 | [ ] Confirm paid | — |
| 2 - D5 | Taylor, Josephine | Prepaid / credit | $219.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - E2 | Brown, Russell | Prepaid / credit | $37.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - E5 | Johnson, barbara j | Prepaid / credit | $77.59 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - F3 | Raleigh, Kevin | Prepaid / credit | $95.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - F6 | Hall, Adriano | Prepaid / credit | $1,595.00 | $0.00 | -$245.00 | [ ] Confirm paid | — |
| 3 - F8 | Anderson, Latisha | Prepaid / credit | $22.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - G2 | Roberts, William | Prepaid / credit | $253.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - G7 | Arnold, Santrocilyn | Prepaid / credit | $738.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - H2 | Whitten, Vanessa Rose | Prepaid / credit | $100.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - H4 | Vasquez, Renee Louise | Prepaid / credit | $75.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - H5 | McCullom, Sandra | Prepaid / credit | $800.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - H7 | Martinez, Jalina | Prepaid / credit | $355.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - I2 | Williams, Lori J | Prepaid / credit | $89.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - I3 | Hornsby, Mark | Prepaid / credit | $965.00 | $0.00 | -$613.00 | [ ] Confirm paid | — |
| 5 - I4 | REED, BREOVIJANAY | Prepaid / credit | $210.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - I5 | Wiebe, Terry | Prepaid / credit | $19.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - J7 | Leon, Julia A | Prepaid / credit | $41.00 | $0.00 | $0.00 | [ ] Confirm paid | — |


## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.


## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property’s supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*
