# Coral Village — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 4859069**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/05/2026 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Manager name | ______________________________ |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Availability PDF | `4859069_Coral Village_Availability_1954080.pdf` |
| Delinquency spreadsheet(s) | `4859069_Coral Village_Delinquent and Prepaid - Excel_1954150.xls`<br>`4859069_Coral Village_Delinquent and Prepaid_1954115.xls` |
| Spreadsheet comparison | Review variance: 23 vs. 0 rows; -$350.00 net-balance difference |
| Ledger accounts for review | 21 resident accounts |
| Residents with amount owed | 6 accounts; $320.00 |
| Prepaid / credit accounts | 15 accounts; $745.00 |
| Availability entries | 1 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit’s reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| As | of | Vacant Not Leased Not Ready | [ ] Verified | __________________ |


## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - 107 | Borrero, Elizabeth | Owes balance | $0.00 | $4.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 302 | Green, Ruth Ann | Owes balance | $0.00 | $9.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 303 | Owen, Elfy | Owes balance | $0.00 | $246.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 402 | Passanisi, Ottavio | Owes balance | $0.00 | $2.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 407 | Fentross, Maureen L | Owes balance | $0.00 | $58.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 707 | Aviles, Olga | Owes balance | $0.00 | $1.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |


## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - 104 | Serrano, Juan | Prepaid / credit | $9.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 104A | Martinez, Elsa | Prepaid / credit | $109.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 105 | Fernandez Sabatel, Luz G | Prepaid / credit | $6.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 204 | Carusone, Josephine F | Prepaid / credit | $10.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 205 | Forte, Robert M | Prepaid / credit | $18.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 208 | Fischer, Gloria N | Prepaid / credit | $7.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 301 | Hernandez, Pedro | Prepaid / credit | $5.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 306 | Garcia Gonzalez, Myra | Prepaid / credit | $14.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 307 | Flores, Raul | Prepaid / credit | $6.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - 404 | Whetsell, Ronald A | Prepaid / credit | $75.00 | $0.00 | -$75.00 | [ ] Confirm paid | — |
| 4 - 408 | Kornet, Kenneth A | Prepaid / credit | $6.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 504 | Pampinella, Barbara | Prepaid / credit | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 507 | Gomez, Isolina Ines | Prepaid / credit | $40.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 7 - 703 | Lopez Morales, Buenaventura | Prepaid / credit | $433.00 | $0.00 | -$54.00 | [ ] Confirm paid | — |
| 8 - 807 | Suarez, Ana C | Prepaid / credit | $6.00 | $0.00 | $0.00 | [ ] Confirm paid | — |


## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.


## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property’s supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*
