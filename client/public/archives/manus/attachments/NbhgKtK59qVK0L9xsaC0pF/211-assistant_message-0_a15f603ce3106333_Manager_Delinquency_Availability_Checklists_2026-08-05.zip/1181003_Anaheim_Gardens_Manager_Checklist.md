# Anaheim Gardens — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 1181003**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/05/2026 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Manager name | ______________________________ |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Availability PDF | `1181003_Anaheim Gardens_Availability_1954054.pdf` |
| Delinquency spreadsheet(s) | `1181003_Anaheim Gardens_Delinquent and Prepaid - Excel_1954125.xls`<br>`1181003_Anaheim Gardens_Delinquent and Prepaid_1954090.xls` |
| Spreadsheet comparison | Review variance: 102 vs. 0 rows; $5,523.30 net-balance difference |
| Ledger accounts for review | 73 resident accounts |
| Residents with amount owed | 32 accounts; $16,667.29 |
| Prepaid / credit accounts | 41 accounts; $11,143.99 |
| Availability entries | 1 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit’s reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| 108 | 1X1STD | Admin | [ ] Verified | __________________ |


## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| AA | PALMER, SONJA JOLAINE | Owes balance | $0.00 | $620.04 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| AC | Ragland, Angela V | Owes balance | $0.00 | $65.12 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| AH | DURU, LAURETTA | Owes balance | $0.00 | $587.80 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| BF | Morales, Roberto | Owes balance | $0.00 | $275.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| BG | GALLARDO, JONATHAN C | Owes balance | $0.00 | $201.24 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| CA | AGUIRRE, SALIN DOMINIQUE | Owes balance | $0.00 | $1,922.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| CC | WILLIAMS, AUJON B | Owes balance | $0.00 | $35.68 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| CD | ORTA, ARIEL | Owes balance | $0.00 | $229.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| DA | JONES, TIAUNA P | Owes balance | $0.00 | $4,262.92 | $1,038.04 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| DB | SIMPSON, NICOLE | Owes balance | $0.00 | $28.64 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| DC | ZENDEJAS, JOAQUIN | Owes balance | $0.00 | $17.88 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| DG | DELONEY, QUINISHA | Owes balance | $0.00 | $8.88 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| ED | Tinoco, Maria | Owes balance | $0.00 | $449.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| EF | LOPEZ, JOSEFINA | Owes balance | $0.00 | $112.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| EH | AVILA, IVY BEATRIZ | Owes balance | $0.00 | $770.04 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| FA | CANNON, ERIN RAE | Owes balance | $0.00 | $495.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| FE | CAMPOS, MARIA I | Owes balance | $0.00 | $2,377.60 | $607.72 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| FH | BELT, PATRICE LATICIA | Owes balance | $0.00 | $403.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| GA | GLOVER, DONYELLE RAESHAUN | Owes balance | $0.00 | $1,236.40 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| GD | ROBINSON, TROIESHA P | Owes balance | $0.00 | $49.94 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| GF | ANDERSON, ECOLA C | Owes balance | $0.00 | $320.32 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| HA | JOSHUA, NECOLE D | Owes balance | $0.00 | $114.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| HB | OLAOSE, OLU DAMON O | Owes balance | $0.00 | $63.96 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| HH | VALDEZ, KATHERINE | Owes balance | $0.00 | $16.88 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| HI | Hernandez, Felipe | Owes balance | $0.00 | $146.60 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| JK | MYERS, PAMELA G | Owes balance | $0.00 | $935.92 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| JL | MENDOZA, MARIA DORA | Owes balance | $0.00 | $51.52 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| KA | PEREZ, MAYRA L | Owes balance | $0.00 | $84.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| KB | COLEMAN, JUNIPER D | Owes balance | $0.00 | $27.27 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| KG | WATKINS, DELASHAWN ELISA | Owes balance | $0.00 | $172.96 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| MD | JASPER, LATISHA R | Owes balance | $0.00 | $582.80 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| MJ | SCOTT, ML | Owes balance | $0.00 | $3.88 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |


## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| AB | THORNTON, TAMALA S | Prepaid / credit | $165.37 | $0.00 | $0.00 | [ ] Confirm paid | — |
| AD | VALDEZ, ELIZABETH | Prepaid / credit | $9.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| AE | AVILA, PEDRO M | Prepaid / credit | $431.04 | $0.00 | $0.00 | [ ] Confirm paid | — |
| AG | CARRENA, VERONICA DEYSY | Prepaid / credit | $25.88 | $0.00 | $0.00 | [ ] Confirm paid | — |
| BE | SIMPSON, THEODORE L | Prepaid / credit | $1,631.02 | $0.00 | $0.00 | [ ] Confirm paid | — |
| BH | LINARES, IDALIA M | Prepaid / credit | $43.44 | $0.00 | $0.00 | [ ] Confirm paid | — |
| BM | Antar, Khadijah | Prepaid / credit | $1,500.20 | $0.00 | $0.00 | [ ] Confirm paid | — |
| BN | EDWARDS, APRI TANISH | Prepaid / credit | $57.04 | $0.00 | $0.00 | [ ] Confirm paid | — |
| BO | WRIGHT, LA'NISHA D | Prepaid / credit | $160.72 | $0.00 | $0.00 | [ ] Confirm paid | — |
| BP | DOMINGUEZ, PEDRO L | Prepaid / credit | $170.10 | $0.00 | $0.00 | [ ] Confirm paid | — |
| CB | LUEVANOS, EMILY | Prepaid / credit | $540.98 | $0.00 | $0.00 | [ ] Confirm paid | — |
| CI | MARTINEZ, ADRIANA | Prepaid / credit | $33.84 | $0.00 | $0.00 | [ ] Confirm paid | — |
| CJ | HARPER, DENIKA C | Prepaid / credit | $23.48 | $0.00 | $0.00 | [ ] Confirm paid | — |
| CK | KING, WILLIAM C | Prepaid / credit | $313.03 | $0.00 | $0.00 | [ ] Confirm paid | — |
| DE | WILLIS, SHARRON | Prepaid / credit | $182.51 | $0.00 | $0.00 | [ ] Confirm paid | — |
| DF | SCOTT, DELORES D | Prepaid / credit | $69.40 | $0.00 | $0.00 | [ ] Confirm paid | — |
| DH | HERNANDEZ, CAROLINA ELIZABETH | Prepaid / credit | $982.04 | $0.00 | $0.00 | [ ] Confirm paid | — |
| EA | MOLINA, OFELIA D | Prepaid / credit | $645.35 | $0.00 | $0.00 | [ ] Confirm paid | — |
| EB | MEDINA, JOSE D | Prepaid / credit | $86.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| EC | BURGESS, SOLEDAD | Prepaid / credit | $3.04 | $0.00 | $0.00 | [ ] Confirm paid | — |
| EE | PETTAWAY, JESSIE J | Prepaid / credit | $466.44 | $0.00 | $0.00 | [ ] Confirm paid | — |
| EG | Alas, ANA G | Prepaid / credit | $1,152.80 | $0.00 | $0.00 | [ ] Confirm paid | — |
| FB | CORLEY, LARENCIA A | Prepaid / credit | $32.26 | $0.00 | $0.00 | [ ] Confirm paid | — |
| FD | GONZALEZ MATEO, MARIA DEL CARMEN | Prepaid / credit | $23.15 | $0.00 | $0.00 | [ ] Confirm paid | — |
| FF | VENTURA LARA, MARIA S | Prepaid / credit | $91.02 | $0.00 | $0.00 | [ ] Confirm paid | — |
| FG | FLYNN, CHERRELL A | Prepaid / credit | $415.95 | $0.00 | $0.00 | [ ] Confirm paid | — |
| GB | Jenkins, Stephen J | Prepaid / credit | $597.72 | $0.00 | $0.00 | [ ] Confirm paid | — |
| GC | DURONTE, ROCHELLE L | Prepaid / credit | $83.04 | $0.00 | $0.00 | [ ] Confirm paid | — |
| GE | YOON, SUK | Prepaid / credit | $20.72 | $0.00 | $0.00 | [ ] Confirm paid | — |
| GG | PRUITT, TANASHA S | Prepaid / credit | $150.60 | $0.00 | $0.00 | [ ] Confirm paid | — |
| GH | LOPEZ NAVARRO, JOSE A | Prepaid / credit | $0.40 | $0.00 | $0.00 | [ ] Confirm paid | — |
| HC | REYES, MILENA | Prepaid / credit | $66.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| HG | GARCIA, PATRICIA ELENA | Prepaid / credit | $79.36 | $0.00 | $0.00 | [ ] Confirm paid | — |
| JE | CARR, MICHAEL W | Prepaid / credit | $18.90 | $0.00 | $0.00 | [ ] Confirm paid | — |
| JJ | HINDS, FRANCHESKA H | Prepaid / credit | $0.02 | $0.00 | $0.00 | [ ] Confirm paid | — |
| KC | MATTHIS, MICHELLE D | Prepaid / credit | $36.28 | $0.00 | $0.00 | [ ] Confirm paid | — |
| KH | WHITE, BRENDA | Prepaid / credit | $0.26 | $0.00 | $0.00 | [ ] Confirm paid | — |
| ME | CARDENAS, RUTH | Prepaid / credit | $15.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| MF | BAIRD, VIRGIL WARREN | Prepaid / credit | $14.04 | $0.00 | $0.00 | [ ] Confirm paid | — |
| MK | RAMIREZ, JOHN HENRY | Prepaid / credit | $43.19 | $0.00 | $0.00 | [ ] Confirm paid | — |
| ML | GUERRA, TANIA ELIZABETH | Prepaid / credit | $763.36 | $0.00 | $0.00 | [ ] Confirm paid | — |


## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.


## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property’s supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*
