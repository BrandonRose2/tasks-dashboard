# Grace Townhomes — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 3835626**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/05/2026 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Manager name | ______________________________ |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Availability PDF | `3835626_Grace Townhomes_Availability_1954066.pdf` |
| Delinquency spreadsheet(s) | `3835626_Grace Townhomes_Delinquent and Prepaid - Excel_1954136.xls`<br>`3835626_Grace Townhomes_Delinquent and Prepaid_1954101.xls` |
| Spreadsheet comparison | Review variance: 49 vs. 0 rows; -$2,253.08 net-balance difference |
| Ledger accounts for review | 49 resident accounts |
| Residents with amount owed | 0 accounts; $0.00 |
| Prepaid / credit accounts | 49 accounts; $2,253.08 |
| Availability entries | 8 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit’s reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| 12-1214 | C1 | Vacant Not Leased Ready | [ ] Verified | __________________ |
| 17-1713 | B1H | Vacant Not Leased Ready | [ ] Verified | __________________ |
| 1-122 | C1 | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 4-414 | A1 | NTV Not Leased | [ ] Verified | __________________ |
| 8-814 | B1 | NTV Not Leased | [ ] Verified | __________________ |
| 13-1311 | C1 | NTV Not Leased | [ ] Verified | __________________ |
| 16-1611 | B1 | NTV Not Leased | [ ] Verified | __________________ |
| As | of | NTV Not Leased | [ ] Verified | __________________ |


## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

No resident ledger entries were detected in the selected source export.


## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - 112 | Sparr, Kassie(GPHA) Sue | Prepaid / credit | $32.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 113 | Stephens, Tamieka Rochelle | Prepaid / credit | $7.06 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 114 | Cox, Tenesha Itavia | Prepaid / credit | $69.74 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 10 - 1013 | Showers, Mary Lockridge | Prepaid / credit | $0.84 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 10 - 1014 | Kirk, Deshoun Charles | Prepaid / credit | $0.74 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 11 - 1111 | Schmucker, Amber Michelle | Prepaid / credit | $0.61 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 11 - 1112 | McBride (DHA), Ernest George | Prepaid / credit | $71.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 11 - 1114 | Johnson, Veronica Denise | Prepaid / credit | $124.00 | $0.00 | -$124.00 | [ ] Confirm paid | — |
| 12 - 1212 | Baker, Charlotta Ann | Prepaid / credit | $5.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 12 - 1213 | Hernandez, Edgar Isidro | Prepaid / credit | $0.33 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 13 - 1311 | Webb, Brian Erik | Prepaid / credit | $0.19 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 13 - 1312 | Calhoun, Seth Leric | Prepaid / credit | $84.17 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 13 - 1314 | English-Lane, Cindy | Prepaid / credit | $400.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 13 - 1322 | Lewis, Tamara Alisha | Prepaid / credit | $0.67 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 13 - 1323 | Hall, Sharmaine Nicolette | Prepaid / credit | $40.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 14 - 1413 | *Wilder, Valerie Liane | Prepaid / credit | $15.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 14 - 1414 | Modisett, Jerome Lorell | Prepaid / credit | $15.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 14 - 1422 | Tutson (DHA), Timika Disha | Prepaid / credit | $2.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 15 - 1511 | Jackson, Arietta Jean | Prepaid / credit | $0.54 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 15 - 1512 | Burley(EHA), Mary Hall | Prepaid / credit | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 15 - 1513 | Ball, Jill Anner | Prepaid / credit | $123.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 16 - 1611 | Hellacio, Megan | Prepaid / credit | $35.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 17 - 1714 | Linville, Dameon Wayne | Prepaid / credit | $15.59 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 19 - 1912 | Cunningham, Laura J | Prepaid / credit | $143.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 19 - 1913 | Robinson, Shanitra(EHA) Bronta | Prepaid / credit | $100.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 211 | Green, Maia (GPHA) Lacole | Prepaid / credit | $289.00 | $0.00 | -$289.00 | [ ] Confirm paid | — |
| 2 - 212 | Henderson, Verlean Evella Marie | Prepaid / credit | $0.13 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 20 - 2012 | Douglas, Tamara (EHA)Ladale | Prepaid / credit | $30.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 20 - 2013 | *Waters, Natasha Marsha | Prepaid / credit | $0.29 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 20 - 2014 | Spencer, Jkolby D | Prepaid / credit | $2.61 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 21 - 2113 | Williams, Brittanie Lanette | Prepaid / credit | $12.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 21 - 2114 | Gant, Patricia Ann | Prepaid / credit | $0.79 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 22 - 2212 | Hamilton, Shalita Lashea | Prepaid / credit | $0.61 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 23 - 2311 | Hullett, Donald James | Prepaid / credit | $45.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 23 - 2313 | Ballard, Qandreka Monique | Prepaid / credit | $1.87 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 23 - 2314 | Cox, Tonia J | Prepaid / credit | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 25 - 2513 | Henson, Samantha Jean | Prepaid / credit | $20.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 313 | Anderson, Byron Level | Prepaid / credit | $95.75 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - 411 | Benson, Cameron Michael | Prepaid / credit | $5.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - 413 | Johnson(DHA), Bridgett Shanise | Prepaid / credit | $26.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 513 | Crenshaw, Jennifer Leighanne | Prepaid / credit | $100.48 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 7 - 711 | Manning, Jacobie(EHA) Jeneil | Prepaid / credit | $150.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 7 - 712 | Rodriguez, Ivan | Prepaid / credit | $5.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 7 - 714 | Hardy, Kenneth Dewayne | Prepaid / credit | $12.65 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 8 - 811 | Zavala, Jose Alexis | Prepaid / credit | $11.29 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 8 - 812 | Fulford, Mercedez(DHA) Lynette | Prepaid / credit | $5.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 8 - 814 | Williams (DHA), Tiffany Devone | Prepaid / credit | $151.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 9 - 913 | Crise, Perry Duane | Prepaid / credit | $0.13 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 9 - 914 | Ellis(DHA), Shelinda | Prepaid / credit | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |


## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.


## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property’s supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*
