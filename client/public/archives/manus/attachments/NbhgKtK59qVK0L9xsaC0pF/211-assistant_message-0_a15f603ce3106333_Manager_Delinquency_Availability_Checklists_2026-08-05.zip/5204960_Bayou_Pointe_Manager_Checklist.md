# Bayou Pointe — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 5204960**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/04/2026 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Manager name | ______________________________ |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Availability PDF | `5204960_Bayou Pointe_Availability_1954084.pdf` |
| Delinquency spreadsheet(s) | `5204960_Bayou Pointe_Delinquent and Prepaid - Excel_1954154.xls`<br>`5204960_Bayou Pointe_Delinquent and Prepaid_1954119.xls` |
| Spreadsheet comparison | Review variance: 93 vs. 0 rows; $2,984.90 net-balance difference |
| Ledger accounts for review | 56 resident accounts |
| Residents with amount owed | 40 accounts; $6,008.58 |
| Prepaid / credit accounts | 16 accounts; $3,023.68 |
| Availability entries | 7 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit’s reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| 8139-8139 | office | Vacant Not Leased Ready | [ ] Verified | __________________ |
| 722-722 | 3 | NTV Not Leased | [ ] Verified | __________________ |
| 754-754 | 3 | NTV Leased | [ ] Verified | __________________ |
| 758-758 | 3 | Vacant Leased Not Ready | [ ] Verified | __________________ |
| 8038-8038 | 3 | Vacant Leased Not Ready | [ ] Verified | __________________ |
| 8042-8042 | 4 | Vacant Leased Not Ready | [ ] Verified | __________________ |
| As | of | Vacant Leased Not Ready | [ ] Verified | __________________ |


## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 702 - 702 | Armstrong, Chesaray | Owes balance | $0.00 | $259.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 715 - 715 | O'Neal, Crystal | Owes balance | $0.00 | $44.30 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 718 - 718 | Simpson, Latekika | Owes balance | $0.00 | $8.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 719 - 719 | Hayes, Kimberly | Owes balance | $0.00 | $1,285.29 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 722 - 722 | Blagley, Moesha | Owes balance | $0.00 | $159.74 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 723 - 723 | McKinney, Megan Octavious | Owes balance | $0.00 | $143.52 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 726 - 726 | Wilson, BarbaraL | Owes balance | $0.00 | $96.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 730 - 730 | Mingo, Monte D | Owes balance | $0.00 | $59.03 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 734 - 734 | Cooksey, Tomika | Owes balance | $0.00 | $39.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 738 - 738 | Mester, Gwendolyn Yvette | Owes balance | $0.00 | $397.68 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 746 - 746 | Abney, Shawanda | Owes balance | $0.00 | $87.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 750 - 750 | Jackson, Cassandra P | Owes balance | $0.00 | $317.31 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 754 - 754 | Carey, Shelonda | Owes balance | $0.00 | $24.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 766 - 766 | Lockett, Kari | Owes balance | $0.00 | $96.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 767 - 767 | Haywood, Brandyse s | Owes balance | $0.00 | $12.93 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 770 - 770 | Covington, Zatoria | Owes balance | $0.00 | $24.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 777 - 777 | Anderson, Demarcus R | Owes balance | $0.00 | $11.42 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8001 - 8001 | Johnson, Andrea | Owes balance | $0.00 | $12.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8002 - 8002 | Henderson-Mcdonald, Laquila | Owes balance | $0.00 | $53.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8006 - 8006 | James, Lashunda | Owes balance | $0.00 | $321.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8010 - 8010 | Myles, Angela | Owes balance | $0.00 | $85.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8013 - 8013 | Clark, JabronicaJ | Owes balance | $0.00 | $55.73 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8014 - 8014 | Matthews, Sheena | Owes balance | $0.00 | $43.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8021 - 8021 | Miller, Shaejaunekyue D | Owes balance | $0.00 | $32.40 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8022 - 8022 | Baker, Quennsha | Owes balance | $0.00 | $142.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8029 - 8029 | Moore, Patience | Owes balance | $0.00 | $6.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8030 - 8030 | Washington, Shaterrica | Owes balance | $0.00 | $1,031.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8034 - 8034 | Coleman, Sha'Dyamond K | Owes balance | $0.00 | $28.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8041 - 8041 | Hunter, Rose | Owes balance | $0.00 | $111.00 | $75.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8103 - 8103 | Price, Jacqueline | Owes balance | $0.00 | $195.53 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8104 - 8104 | Terrell, Kissy M | Owes balance | $0.00 | $120.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8107 - 8107 | James, Robbin | Owes balance | $0.00 | $61.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8108 - 8108 | Sneed, Abouya M | Owes balance | $0.00 | $78.70 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8111 - 8111 | Goff, Tanja | Owes balance | $0.00 | $96.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8112 - 8112 | Finch, Carrie | Owes balance | $0.00 | $95.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8115 - 8115 | Bryant, Cordie | Owes balance | $0.00 | $86.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8116 - 8116 | Taylor, Meschelle | Owes balance | $0.00 | $25.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8119 - 8119 | Washington, DevinLamario | Owes balance | $0.00 | $14.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8127 - 8127 | Marshall, Kristina M | Owes balance | $0.00 | $200.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8135 - 8135 | Daniels, Brittany | Owes balance | $0.00 | $53.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |


## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 706 - 706 | Washington, Shetrara | Prepaid / credit | $25.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 710 - 710 | Harris, Victoria | Prepaid / credit | $11.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 727 - 727 | Stepens, Zournesha | Prepaid / credit | $1,152.52 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 742 - 742 | Price, Dyniqua | Prepaid / credit | $96.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 762 - 762 | Giff Jr, Willie | Prepaid / credit | $29.64 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 8005 - 8005 | Atkins, Veronica | Prepaid / credit | $90.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 8009 - 8009 | Thomas, XavierD | Prepaid / credit | $1,070.04 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 8017 - 8017 | McBride, Kaitlin N | Prepaid / credit | $166.57 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 8018 - 8018 | Davis, DorothyJ | Prepaid / credit | $5.57 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 8025 - 8025 | Caldwell, Timberly T | Prepaid / credit | $55.53 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 8026 - 8026 | Simpson, Breanca N | Prepaid / credit | $0.40 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 8033 - 8033 | Taylor, Toshiba | Prepaid / credit | $3.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 8037 - 8037 | Nicholson, Sania | Prepaid / credit | $265.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 8045 - 8045 | Hopkins, KamariaK | Prepaid / credit | $15.97 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 8123 - 8123 | Butler, Alma | Prepaid / credit | $33.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 8131 - 8131 | Thomas, Latia S | Prepaid / credit | $4.44 | $0.00 | $0.00 | [ ] Confirm paid | — |


## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.


## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property’s supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*
