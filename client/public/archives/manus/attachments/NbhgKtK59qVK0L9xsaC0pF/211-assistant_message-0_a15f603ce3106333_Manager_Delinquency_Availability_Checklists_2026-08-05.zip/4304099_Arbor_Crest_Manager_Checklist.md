# Arbor Crest — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 4304099**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/05/2026 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Manager name | ______________________________ |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Availability PDF | `4304099_Arbor Crest_Availability_1954076.pdf` |
| Delinquency spreadsheet(s) | `4304099_Arbor Crest_Delinquent and Prepaid - Excel_1954146.xls`<br>`4304099_Arbor Crest_Delinquent and Prepaid_1954111.xls` |
| Spreadsheet comparison | Review variance: 53 vs. 0 rows; -$3,246.21 net-balance difference |
| Ledger accounts for review | 50 resident accounts |
| Residents with amount owed | 2 accounts; $306.00 |
| Prepaid / credit accounts | 48 accounts; $3,948.51 |
| Availability entries | 1 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit’s reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| As | of | Vacant Leased Not Ready | [ ] Verified | __________________ |


## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - 1206 | Green, Davontraiz | Owes balance | $0.00 | $294.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2113 | Mitchell*, Fredricka | Owes balance | $0.00 | $12.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |


## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - 1106 | Shaw**, Keshondra S | Prepaid / credit | $195.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1107 | Ford, Demetrice Renea | Prepaid / credit | $32.40 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1109 | Stanly, Curtis Lewis | Prepaid / credit | $788.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1110 | Lifherd*, Kimberly M | Prepaid / credit | $4.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1112 | Neverson**, Christine Delores | Prepaid / credit | $6.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1113 | Donaldson*, Sarah | Prepaid / credit | $4.05 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1114 | Bullock*, Florence P | Prepaid / credit | $161.00 | $0.00 | $161.00 | [ ] Confirm paid | — |
| 1 - 1115 | Donald*, Shameca Shontell | Prepaid / credit | $152.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1118 | Baker, Tamekio | Prepaid / credit | $2.93 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1120 | *Smith, Tracy | Prepaid / credit | $226.46 | $0.00 | $226.46 | [ ] Confirm paid | — |
| 1 - 1204 | Kirkland*, Tekeysha L | Prepaid / credit | $0.33 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1208 | Black*, Audora Regina | Prepaid / credit | $151.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1210 | Mitchell, Cynthia H | Prepaid / credit | $90.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1211 | Walker, Kim | Prepaid / credit | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1213 | Clark, Devonte | Prepaid / credit | $61.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1216 | Allen, Tawanea | Prepaid / credit | $2.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1220 | Poole, Shatina Lanay | Prepaid / credit | $5.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1304 | Thomas, Caprice Danielle | Prepaid / credit | $54.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1306 | Johnson, Harriet Lee | Prepaid / credit | $18.32 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1307 | Shaw, Tierra Alexus | Prepaid / credit | $40.71 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1312 | Copeland, Aniyah Julannia | Prepaid / credit | $5.69 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1314 | Berry, Tim'mia Quinshay | Prepaid / credit | $413.57 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1315 | Wells, Cathy | Prepaid / credit | $8.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1317 | Wilson*, Bobby | Prepaid / credit | $175.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1319 | Lane, Aziah | Prepaid / credit | $16.63 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1320 | Hicks, Dorothy | Prepaid / credit | $42.55 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 2101 | Mobley, Verna | Prepaid / credit | $4.71 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 2102 | Budd, Serinity | Prepaid / credit | $21.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 2111 | Williams, Pamela | Prepaid / credit | $16.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 2112 | Williams, Inez | Prepaid / credit | $45.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 2114 | Jackson, Tenisha Lafaye | Prepaid / credit | $48.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 2115 | Minor, Delores | Prepaid / credit | $9.33 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 2201 | Belford, Alandria Makayla | Prepaid / credit | $341.16 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 2207 | Grimes*, Resherricka L | Prepaid / credit | $15.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 2209 | Sam*, Ciera | Prepaid / credit | $2.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 2301 | Johnson, Sabrina | Prepaid / credit | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 2303 | Watson, Shamya Deija Naye | Prepaid / credit | $32.86 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 2304 | Bryant, James Edward | Prepaid / credit | $8.84 | $0.00 | $8.84 | [ ] Confirm paid | — |
| 2 - 2305 | Youmans, Stacy Rechelle | Prepaid / credit | $16.64 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 2307 | Harris, Crystal | Prepaid / credit | $53.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 2309 | Hall**, Audrey | Prepaid / credit | $12.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 2310 | Williams, Crystal | Prepaid / credit | $328.13 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 2312 | Davis**, Brittany S | Prepaid / credit | $235.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 2314 | Jones, Dana L | Prepaid / credit | $3.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 3103 | Zackery**, Verdine Saulters | Prepaid / credit | $25.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 3203 | Ash, Janarvis | Prepaid / credit | $29.63 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 3301 | Lodman, Yolanda | Prepaid / credit | $30.57 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 3302 | Starke, Brittany Preanna | Prepaid / credit | $14.00 | $0.00 | $0.00 | [ ] Confirm paid | — |


## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.


## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property’s supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*
