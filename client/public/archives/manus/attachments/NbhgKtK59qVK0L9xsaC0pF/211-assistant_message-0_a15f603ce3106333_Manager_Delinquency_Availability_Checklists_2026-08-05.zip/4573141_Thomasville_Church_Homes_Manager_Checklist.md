# Thomasville Church Homes — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 4573141**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/03/2026 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Manager name | ______________________________ |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Availability PDF | `4573141_Thomasville Church Homes_Availability_1954078.pdf` |
| Delinquency spreadsheet(s) | `4573141_Thomasville Church Homes_Delinquent and Prepaid - Excel_1954148.xls`<br>`4573141_Thomasville Church Homes_Delinquent and Prepaid_1954113.xls` |
| Spreadsheet comparison | Review variance: 83 vs. 0 rows; $12,969.46 net-balance difference |
| Ledger accounts for review | 64 resident accounts |
| Residents with amount owed | 22 accounts; $19,267.65 |
| Prepaid / credit accounts | 42 accounts; $6,298.19 |
| Availability entries | 1 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit’s reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| As | of | Vacant Not Leased Not Ready | [ ] Verified | __________________ |


## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1000-C | Grays, Kimberly A | Owes balance | $0.00 | $47.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1000-E | Foddrell, Naquida | Owes balance | $0.00 | $1,155.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1000-F | Valentino, Diezal | Owes balance | $0.00 | $45.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1002-F | Thomas, Elshukee | Owes balance | $0.00 | $45.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1003-F | Adams, Glennda Diane | Owes balance | $0.00 | $32.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1004-E | Macias, Janie | Owes balance | $0.00 | $236.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1004-F | *Bradley, Calleasha | Owes balance | $0.00 | $2,989.00 | $502.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1006-B | Taylor, Tiffany R | Owes balance | $0.00 | $256.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1006-D | Williams-Pratt, Alexus | Owes balance | $0.00 | $1,020.00 | $1,020.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1006-E | Gibbons, Alexis | Owes balance | $0.00 | $219.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1007-E | Kearns, Cheryl | Owes balance | $0.00 | $798.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1009-A | Ramirez, Evelyn | Owes balance | $0.00 | $1,964.00 | $1,964.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1011-B | Medley, Shtimeko | Owes balance | $0.00 | $324.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1011-D | Rivera, Montana Breeza | Owes balance | $0.00 | $290.65 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1015-A | Washington, Crystal | Owes balance | $0.00 | $2,238.00 | $219.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1015-C | *Knight, Shaquaya O | Owes balance | $0.00 | $1,473.00 | $1,473.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1015-D | Whitener, Hannah Paige | Owes balance | $0.00 | $2,780.00 | $1,112.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1015-E | Black, Nicole R | Owes balance | $0.00 | $3,214.00 | $1,723.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1015-F | Motes, Darlene Faye | Owes balance | $0.00 | $31.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 809-A | Davis, Tomeka E | Owes balance | $0.00 | $10.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 809-B | Wright, Cheresa | Owes balance | $0.00 | $56.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 811-D | Johnson, Kelly Jo | Owes balance | $0.00 | $45.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |


## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1000-A | Lopez, Fatima L | Prepaid / credit | $1,670.00 | $0.00 | -$1,570.00 | [ ] Confirm paid | — |
| 1001-B | Monk, Tiffany L | Prepaid / credit | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1001-C | Monge-Lopez, Nachaly | Prepaid / credit | $7.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1001-E | Squires, Victoria | Prepaid / credit | $169.00 | $0.00 | -$16.00 | [ ] Confirm paid | — |
| 1001-F | GIBER, JAKHEM | Prepaid / credit | $107.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1002-A | Hunt, Elizabeth | Prepaid / credit | $15.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1003-B | Wiggins, Alea Zhane | Prepaid / credit | $11.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1003-C | Collins, Jaelyah T | Prepaid / credit | $514.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1003-D | Ledbetter, Darryl | Prepaid / credit | $228.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1003-E | Ledbetter, Annie T | Prepaid / credit | $95.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1004-A | Bumgardner, Christina M | Prepaid / credit | $40.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1005-C | Davis, QuSawna | Prepaid / credit | $41.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1005-D | Green, Sarah | Prepaid / credit | $176.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1005-E | Slone, Rita L | Prepaid / credit | $112.00 | $0.00 | -$112.00 | [ ] Confirm paid | — |
| 1006-A | Davidson, Krystal Beth | Prepaid / credit | $872.00 | $0.00 | -$672.00 | [ ] Confirm paid | — |
| 1006-F | White, Myron D | Prepaid / credit | $4.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1007-A | Williams, Candice N | Prepaid / credit | $33.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1007-B | Gilbert, Felicia J | Prepaid / credit | $80.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1007-C | Pearson, Gladys Williams | Prepaid / credit | $59.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1007-D | Porter, Larry R | Prepaid / credit | $43.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1009-B | Legrand, Kelly | Prepaid / credit | $25.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1009-C | Pohlman, Kaitlyn M | Prepaid / credit | $46.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1009-E | Colbert, Dandra Conyetta | Prepaid / credit | $130.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1009-G | Gregorio, Bonnie | Prepaid / credit | $7.80 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1011-C | Smith, Willie | Prepaid / credit | $56.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1011-E | Jones, Carmen A | Prepaid / credit | $5.50 | $0.00 | -$5.50 | [ ] Confirm paid | — |
| 1011-F | Martell, Adreunna | Prepaid / credit | $28.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1013-C | Schaffer, Cheryl | Prepaid / credit | $19.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 807-A | Galloway, Noshaba S | Prepaid / credit | $16.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 807-D | Lee, Demarcus Rasheed | Prepaid / credit | $32.00 | $0.00 | -$32.00 | [ ] Confirm paid | — |
| 809-C | Burgess, Essince | Prepaid / credit | $5.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 809-E | Bryant, Pamela L | Prepaid / credit | $24.00 | $0.00 | -$24.00 | [ ] Confirm paid | — |
| 809-F | Hemrick, Regina R | Prepaid / credit | $34.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 811-A | Johnson, Kiana Evone | Prepaid / credit | $18.89 | $0.00 | -$18.89 | [ ] Confirm paid | — |
| 811-B | Sloane, Debbie J | Prepaid / credit | $36.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 811-C | Worley, Jayden Raye | Prepaid / credit | $1,124.00 | $0.00 | -$398.00 | [ ] Confirm paid | — |
| 811-F | Norris, Willis James | Prepaid / credit | $44.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 813-B | Smith, Danasia Shannail | Prepaid / credit | $22.00 | $0.00 | -$22.00 | [ ] Confirm paid | — |
| 813-C | Guillen Gutierrez, Isabella | Prepaid / credit | $10.00 | $0.00 | -$10.00 | [ ] Confirm paid | — |
| 813-D | Worthington, Brodrick | Prepaid / credit | $48.00 | $0.00 | -$48.00 | [ ] Confirm paid | — |
| 815-A | Thomas, Tylia | Prepaid / credit | $104.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 815-B | ROBERTS, AMANDA | Prepaid / credit | $186.00 | $0.00 | $0.00 | [ ] Confirm paid | — |


## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.


## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property’s supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*
