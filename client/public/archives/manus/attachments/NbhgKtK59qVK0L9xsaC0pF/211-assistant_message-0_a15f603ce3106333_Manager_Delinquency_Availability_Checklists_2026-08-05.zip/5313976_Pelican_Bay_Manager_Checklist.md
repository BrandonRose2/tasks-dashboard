# Pelican Bay — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 5313976**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/04/2026 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Manager name | ______________________________ |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Availability PDF | `5313976_Pelican Bay_Availability_1954086.pdf` |
| Delinquency spreadsheet(s) | `5313976_Pelican Bay_Delinquent and Prepaid - Excel_1954156.xls`<br>`5313976_Pelican Bay_Delinquent and Prepaid_1954121.xls` |
| Spreadsheet comparison | Review variance: 117 vs. 0 rows; -$8,130.81 net-balance difference |
| Ledger accounts for review | 85 resident accounts |
| Residents with amount owed | 46 accounts; $8,179.28 |
| Prepaid / credit accounts | 39 accounts; $16,310.09 |
| Availability entries | 10 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit’s reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| 1-106 | 2A | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 7-703 | 3A | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 11-1104 | 3A | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 11-1106 | 3A | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 12-1205 | 3A | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 12-1208 | 3A | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 3-316 | 4B | NTV Not Leased | [ ] Verified | __________________ |
| 7-709 | 3A | NTV Not Leased | [ ] Verified | __________________ |
| 6-602 | 4A | Vacant Leased Not Ready | [ ] Verified | __________________ |
| As | of | Vacant Leased Not Ready | [ ] Verified | __________________ |


## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - 104 | Knight, Willard | Owes balance | $0.00 | $12.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 105 | Woods, Demetrice | Owes balance | $0.00 | $294.86 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 110 | Pointer, Rhesa | Owes balance | $0.00 | $12.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1004 | Stewart, Sabrina | Owes balance | $0.00 | $48.00 | $7.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1006 | Leger, Jessie E | Owes balance | $0.00 | $20.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1007 | Wilson, Rebecca | Owes balance | $0.00 | $12.56 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1009 | Kirby, Taylor | Owes balance | $0.00 | $1,000.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1101 | Stewart, KeltonD | Owes balance | $0.00 | $1,560.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1201 | Cushingberry, Amandac | Owes balance | $0.00 | $110.86 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1204 | Bell, Dana | Owes balance | $0.00 | $6.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1207 | Davis, Michael | Owes balance | $0.00 | $33.86 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1301 | Coleman, Carl C | Owes balance | $0.00 | $48.00 | $12.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1305 | Braud, Michael | Owes balance | $0.00 | $5.86 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1409 | Carey, Antoinette | Owes balance | $0.00 | $41.68 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1412 | Bryant, Gloria. | Owes balance | $0.00 | $94.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 201 | Allen, Arthur | Owes balance | $0.00 | $23.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 202 | Crockett, Kim Evette | Owes balance | $0.00 | $1.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 203 | Dore, Katherine | Owes balance | $0.00 | $12.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 204 | Senegal, Donna Mouton | Owes balance | $0.00 | $12.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 205 | Preston, Teresa L | Owes balance | $0.00 | $1.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 208 | Nicholas, Jada | Owes balance | $0.00 | $11.60 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 302 | Curtis, Shanetria | Owes balance | $0.00 | $5.36 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 303 | GLASPER, ASHLYN | Owes balance | $0.00 | $1,405.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 305 | Douglas, Wynona | Owes balance | $0.00 | $0.18 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 311 | Gibson, Linda D | Owes balance | $0.00 | $9.86 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 316 | Isaac, Francesca | Owes balance | $0.00 | $543.90 | $507.90 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 406 | Eastwood, Jennifer | Owes balance | $0.00 | $12.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 411 | Stewart, Rosalie | Owes balance | $0.00 | $9.86 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 501 | Veal, Nora | Owes balance | $0.00 | $33.86 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 503 | Givens, Shanette N | Owes balance | $0.00 | $12.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 504 | Moore, Joycelyn | Owes balance | $0.00 | $12.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 508 | Goss, Lakida | Owes balance | $0.00 | $48.00 | $12.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 509 | Manuel, Lionel | Owes balance | $0.00 | $33.86 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 511 | Mack, Bobby | Owes balance | $0.00 | $871.73 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 512 | Mumphrey, Margaret | Owes balance | $0.00 | $12.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 607 | Stewart, Brittany | Owes balance | $0.00 | $1.86 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 702 | Jackson, Keith L | Owes balance | $0.00 | $1,330.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 704 | Stewart, Tyshun | Owes balance | $0.00 | $0.36 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 705 | Conrad, Angelica | Owes balance | $0.00 | $36.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 708 | Harris, Lisa | Owes balance | $0.00 | $12.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 709 | Williams, Cynthia | Owes balance | $0.00 | $12.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 710 | Williams, Charlene | Owes balance | $0.00 | $6.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 712 | Givens, Joanie | Owes balance | $0.00 | $58.86 | $25.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 803 | Gray, Nealester | Owes balance | $0.00 | $48.00 | $12.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 808 | Jones, Dessalynn | Owes balance | $0.00 | $98.18 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 909 | Jackson, NormaD | Owes balance | $0.00 | $206.13 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |


## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - 103 | Hill, Patricia | Prepaid / credit | $400.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 108 | Frazier, Shirley | Prepaid / credit | $232.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 111 | Harbor, Julia | Prepaid / credit | $3.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 10 - 1003 | Caulfield, Dionne | Prepaid / credit | $15.14 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 10 - 1005 | Armstrong, William. | Prepaid / credit | $95.14 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 10 - 1012 | Guillard, Lakiesha | Prepaid / credit | $16.96 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 11 - 1102 | Fields, Theresa | Prepaid / credit | $149.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 12 - 1203 | Glasper, Tara | Prepaid / credit | $1,206.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 13 - 1303 | Rowe, AprilLynn | Prepaid / credit | $40.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 13 - 1304 | Ndiaye, SokhnaFatou | Prepaid / credit | $885.07 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 13 - 1307 | Cisse, Mamadou | Prepaid / credit | $1,040.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 14 - 1401 | Scott, ErnestW. | Prepaid / credit | $88.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 14 - 1402 | Wall, Ian | Prepaid / credit | $234.55 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 14 - 1403 | Spurlock, Marcus | Prepaid / credit | $1,040.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 14 - 1410 | Cardona, BritneyL | Prepaid / credit | $27.14 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 14 - 1411 | Howard, Kevin | Prepaid / credit | $36.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 304 | Byrd, Tyre'yona | Prepaid / credit | $295.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 307 | Everson, Seleaka | Prepaid / credit | $0.14 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 309 | Handy, Raquan | Prepaid / credit | $1,921.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 310 | Farmer, Dawn | Prepaid / credit | $1,333.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 312 | Douglas, Brandon | Prepaid / credit | $1,039.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 314 | Smith, Debra | Prepaid / credit | $70.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 315 | Richardson, Flora M | Prepaid / credit | $659.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - 402 | Weatherspoon, Lisa | Prepaid / credit | $17.53 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - 407 | Williams, Ruby | Prepaid / credit | $244.14 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - 412 | Wide, Zerandrian | Prepaid / credit | $2.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 502 | Derson, Clarence | Prepaid / credit | $455.00 | $0.00 | -$18.00 | [ ] Confirm paid | — |
| 5 - 505 | Green, Tarianne | Prepaid / credit | $1,051.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 510 | King, VictoriaLynn | Prepaid / credit | $93.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 6 - 601 | Jones, Kizzy | Prepaid / credit | $639.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 6 - 603 | Washington, Tonya | Prepaid / credit | $16.14 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 7 - 706 | Senegal, Jasmine | Prepaid / credit | $0.14 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 7 - 707 | Scott, Shinta K | Prepaid / credit | $206.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 8 - 801 | Pennywell, Ryan | Prepaid / credit | $600.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 8 - 807 | Sparrow, Debra | Prepaid / credit | $27.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 9 - 905 | Rowe, Lartika K | Prepaid / credit | $2.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 9 - 906 | Tookes, Samantha L | Prepaid / credit | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 9 - 907 | Lloyd, Imari | Prepaid / credit | $1,206.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 9 - 910 | Harvey, Tayshara L | Prepaid / credit | $925.00 | $0.00 | $0.00 | [ ] Confirm paid | — |


## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.


## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property’s supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*
