# Urban Rehab — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 1181006**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/05/2026 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Manager name | ______________________________ |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Availability PDF | `1181006_Urban Rehab_Availability_1954057.pdf` |
| Delinquency spreadsheet(s) | `1181006_Urban Rehab_Delinquent and Prepaid - Excel_1954128.xls`<br>`1181006_Urban Rehab_Delinquent and Prepaid_1954093.xls` |
| Spreadsheet comparison | Review variance: 54 vs. 0 rows; $6,966.78 net-balance difference |
| Ledger accounts for review | 34 resident accounts |
| Residents with amount owed | 21 accounts; $9,312.46 |
| Prepaid / credit accounts | 13 accounts; $2,345.68 |
| Availability entries | 0 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit’s reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

No unit-level availability detail could be machine-read from this PDF. Please confirm the Availability source report during the manager call.


## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 103 | FREW, DORITA E | Owes balance | $0.00 | $11.98 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9310A | FELIX OJEDA, BEATRIZ | Owes balance | $0.00 | $426.84 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9310C | MCFADDEN, BRITTANY DENISE | Owes balance | $0.00 | $471.08 | $162.20 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9310D | LOPEZ RIGGS, MELISSA | Owes balance | $0.00 | $178.24 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9310E | MITCHELL, SHAUNTRICE D | Owes balance | $0.00 | $1,381.64 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9312A | SANDOVAL, SELENE | Owes balance | $0.00 | $11.36 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9312F | ARNOLD, LACHELLE A | Owes balance | $0.00 | $1,873.92 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9316A | WILLIAMS, DIMINIQUE D | Owes balance | $0.00 | $215.35 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9316B | GATES, JASMINE CARESSA | Owes balance | $0.00 | $101.20 | $62.32 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9316C | WOODS, BRITTNEY E | Owes balance | $0.00 | $302.90 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9316F | LICEA, RAMONA VALENCIA | Owes balance | $0.00 | $162.97 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9318A | LOPEZ, VERONICA | Owes balance | $0.00 | $726.28 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9318B | SANDERS, BRIDGET | Owes balance | $0.00 | $123.62 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9318D | MONTES DE OCA, NATALY | Owes balance | $0.00 | $119.40 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9318E | MONTES DELGADO, LIDIA STEPHANIE | Owes balance | $0.00 | $181.92 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9318F | FARRELL, OTIS | Owes balance | $0.00 | $40.60 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9404E | LUVIANO MALDONADO, VICENTA | Owes balance | $0.00 | $1,034.10 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9408A | PITTS, WINESHA R | Owes balance | $0.00 | $762.55 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9408B | MCGHEE, TAMISHA NASHAUN | Owes balance | $0.00 | $379.93 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9408D | MAY, KA LONNIE L | Owes balance | $0.00 | $696.61 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9408E | CANNON, AMUNIQUE E | Owes balance | $0.00 | $109.97 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |


## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 205 | SMITH III, WILLIE J | Prepaid / credit | $123.04 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 9310B | TORRES RUIZ, SAYRA E | Prepaid / credit | $140.92 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 9310F | MCCORD, JERREAL D | Prepaid / credit | $84.04 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 9312C | GODDEN, TERRELL WARREN | Prepaid / credit | $92.01 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 9312E | LOPEZ DE LUGO, MARIA | Prepaid / credit | $10.37 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 9316D | JIMENEZ LUVIANO, NANCY | Prepaid / credit | $0.19 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 9316E | MATTHEWS, ANDREA D | Prepaid / credit | $789.25 | $0.00 | -$675.25 | [ ] Confirm paid | — |
| 9318C | HORTA, STEFANY | Prepaid / credit | $81.36 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 9404A | HARRELL, BARBARA | Prepaid / credit | $233.20 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 9404B | EASLY ALI, FATIMA MS | Prepaid / credit | $664.57 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 9404D | HEARNS, SHANIYA C | Prepaid / credit | $47.89 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 9404F | DREAR, KEISHANE | Prepaid / credit | $10.76 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 9408F | DOMINGUES DE JESUS, ROSIO | Prepaid / credit | $68.08 | $0.00 | $0.00 | [ ] Confirm paid | — |


## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.


## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property’s supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*
