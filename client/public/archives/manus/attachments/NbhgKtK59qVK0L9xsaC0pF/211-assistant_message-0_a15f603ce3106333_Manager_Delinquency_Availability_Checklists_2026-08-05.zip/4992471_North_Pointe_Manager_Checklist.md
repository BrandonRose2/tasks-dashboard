# North Pointe — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 4992471**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/05/2026 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Manager name | ______________________________ |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Availability PDF | `4992471_North Pointe_Availability_1954081.pdf` |
| Delinquency spreadsheet(s) | `4992471_North Pointe_Delinquent and Prepaid - Excel_1954151.xls`<br>`4992471_North Pointe_Delinquent and Prepaid_1954116.xls` |
| Spreadsheet comparison | Review variance: 42 vs. 0 rows; $3,315.00 net-balance difference |
| Ledger accounts for review | 26 resident accounts |
| Residents with amount owed | 20 accounts; $4,049.00 |
| Prepaid / credit accounts | 8 accounts; $1,817.00 |
| Availability entries | 2 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit’s reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| 2-2608K | 2x2 | Vacant Leased Not Ready | [ ] Verified | __________________ |
| As | of | NTV Leased | [ ] Verified | __________________ |


## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - 1609A | Taylor, Johnnie M | Owes balance | $0.00 | $80.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 2604K | Ashley, Teresa | Owes balance | $0.00 | $2.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 2616K | JUne, Kaitlyn K | Owes balance | $0.00 | $89.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15 - 2620K | Davis, Andrea N | Owes balance | $0.00 | $96.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 1610C | Washington, Lamar | Owes balance | $556.00 | $44.00 | $600.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18 - 1607C | Jernigan, Jamila | Owes balance | $0.00 | $239.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19 - 1617C | Sims, Kimberly | Owes balance | $0.00 | $178.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20 - 1614A | Pero, Nadia D | Owes balance | $0.00 | $43.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 21 - 1604A | Lewis, Rachard | Owes balance | $0.00 | $12.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 22 - 1619A | McDaniel, Alexus | Owes balance | $0.00 | $6.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 23 - 2624K | Patterson, Kowanna | Owes balance | $0.00 | $200.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 24 - 2628K | Harrison, Rosana | Owes balance | $0.00 | $28.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 25 - 2640K | Lewis, Starletta | Owes balance | $0.00 | $98.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 26 - 2644K | Holland, Assaundria | Owes balance | $0.00 | $78.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 27 - 1602C | Sylvie, Kennibya M | Owes balance | $0.00 | $42.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 1603C | Montgomery, Takeveyatta | Owes balance | $0.00 | $71.00 | $35.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 1611C | Marshall, Shadiamond S | Owes balance | $527.00 | $73.00 | $600.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 1618A | Simmons, Alexis | Owes balance | $0.00 | $1,489.00 | $600.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 1608A | Williams, Christy M | Owes balance | $0.00 | $16.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 1605A | Henderson, Erika M | Owes balance | $0.00 | $1,165.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |


## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 10 - 1615A | Thomas, Rosetta | Prepaid / credit | $39.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 11 - 2605K | Davenport, Monique | Prepaid / credit | $33.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 13 - 2612K | Ford, Brittany | Prepaid / credit | $36.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 16 - 2636K | Lee, Raven | Prepaid / credit | $77.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 17 - 1610C | Washington, Lamar | Owes balance | $556.00 | $44.00 | $600.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 2632K | Richardson, Sharon L | Prepaid / credit | $23.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - 1606C | MCKEEVER, JAMIE M | Prepaid / credit | $526.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 6 - 1611C | Marshall, Shadiamond S | Owes balance | $527.00 | $73.00 | $600.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |


## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.


## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property’s supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*
