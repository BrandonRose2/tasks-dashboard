#!/usr/bin/env python3
"""Apply explicit conservative exclusions; keep original findings in a separate audit."""
import argparse
import copy
import json
from pathlib import Path


def apply_review(observations, decisions):
    output = copy.deepcopy(observations)
    lookup = {(p['buildingId'], c['row']): c for p in output['properties'] for c in p['comps']}
    log = []
    seen = set()
    for decision in decisions:
        key = (decision['buildingId'], decision['row'])
        bed = decision.get('bedType')
        review_key = key + (bed,)
        if review_key in seen or key not in lookup:
            raise ValueError(f'Duplicate or unknown review row {review_key}')
        seen.add(review_key)
        reason = decision.get('reason', '').strip()
        if not reason:
            raise ValueError('An explicit exclusion reason is required')
        comp = lookup[key]
        if bed is None:
            if decision.get('eligibility') not in ('unverified', 'ineligible'):
                raise ValueError('Comp-level reviews may only downgrade eligibility')
            rents = comp['rents']
        else:
            if decision.get('status') != 'phone_verify' or 'eligibility' in decision:
                raise ValueError('Cell-level reviews may only downgrade pricing to Phone Verify')
            rents = [r for r in comp['rents'] if r.get('bedType') == bed]
            if len(rents) != 1:
                raise ValueError(f'Unknown/duplicate bedroom {bed}')
        log.append({'buildingId': key[0], 'row': key[1], 'bedType': bed, 'reason': reason, 'originalObservation': copy.deepcopy(comp)})
        if bed is None:
            comp['eligibility'] = decision['eligibility']
        comp['notes'] += ' | REVIEW EXCLUSION: ' + reason
        for rent in rents:
            rent['status'] = 'phone_verify'
            rent['amount'] = None
            rent['evidence'] += ' | REVIEW EXCLUSION: ' + reason + ' Original source finding preserved in review_decisions.json; excluded from numeric market averages.'
    return output, log

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--observations', type=Path, required=True)
    parser.add_argument('--decisions', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    output, log = apply_review(json.loads(args.observations.read_text()), json.loads(args.decisions.read_text()))
    args.output.write_text(json.dumps(output, indent=2, ensure_ascii=False) + '\n')
    args.output.with_suffix('.review_decisions.json').write_text(json.dumps(log, indent=2, ensure_ascii=False) + '\n')
    print(f'Applied {len(log)} conservative exclusions; no prices introduced')
