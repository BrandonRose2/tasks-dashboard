#!/usr/bin/env python3
"""Verify assembled real workbook against allowlisted audited changes; no network or sending."""
import argparse
import json
from pathlib import Path
import zipfile
import openpyxl
import pipeline


def verify(baseline, manifest_path, build_dir):
    manifest=pipeline.load_json(manifest_path)
    audit=pipeline.load_json(build_dir/'audit.json')
    if not audit['successful'] or audit['testMode'] or not audit['distributable']:
        raise ValueError('A real successful source-research build is required')
    output=build_dir/'RentComps_refreshed.xlsx'
    if pipeline.sha256(baseline)!=manifest['baselineSha256']:
        raise ValueError('Baseline changed')
    if pipeline.sha256(output)!=audit['outputWorkbookSha256']:
        raise ValueError('Output changed after assembly')
    changes=pipeline.load_json(build_dir/'changes.json')['changes']
    allowed={(c['sheetName'],c['cell']) for c in changes}
    original=openpyxl.load_workbook(baseline,data_only=False)
    updated=openpyxl.load_workbook(output,data_only=False)
    checked_styles=0
    unchanged_values=0
    tieouts=0
    rent_cells=0
    try:
        assert original.sheetnames==updated.sheetnames
        for ws in original:
            new=updated[ws.title]
            assert str(ws.merged_cells)==str(new.merged_cells)
            assert (ws.max_row,ws.max_column)==(new.max_row,new.max_column)
            assert ws.freeze_panes==new.freeze_panes
            for k,d in ws.column_dimensions.items():assert dict(d)==dict(new.column_dimensions[k])
            for k,d in ws.row_dimensions.items():assert dict(d)==dict(new.row_dimensions[k])
            for row in ws:
                for cell in row:
                    if isinstance(cell,openpyxl.cell.cell.MergedCell):continue
                    replacement=new[cell.coordinate]
                    assert cell._style==replacement._style,(ws.title,cell.coordinate,'style')
                    checked_styles+=1
                    if (ws.title,cell.coordinate) not in allowed:
                        assert cell.value==replacement.value,(ws.title,cell.coordinate,'unapproved change')
                        unchanged_values+=1
        for prop in manifest['properties']:
            ws=updated[prop['sheetName']]
            for bed,col in prop['headerMapping']['actualColumns'].items():
                vals=[ws.cell(c['row'],col).value for c in prop['comps']]
                assert all(type(v) in (int,float) or v in ('Phone Verify','Not Offered') for v in vals)
                rent_cells+=len(vals)
                expected=pipeline.average([v for v in vals if type(v) in (int,float)])
                for row in prop['benchmarkRows']:
                    assert ws.cell(row,col).value==expected,(prop['sheetName'],bed,'benchmark')
                    tieouts+=1
                for coord in prop['summaryCells'][bed]:
                    assert ws[coord].value==expected,(prop['sheetName'],bed,'summary')
                    tieouts+=1
    finally:
        original.close();updated.close()
    identical=0
    with zipfile.ZipFile(baseline) as old,zipfile.ZipFile(output) as new:
        assert old.namelist()==new.namelist()
        paths=pipeline.worksheet_paths(old)
        modified={paths[c['sheetName']] for c in changes}
        for name in old.namelist():
            if name not in modified:
                assert old.read(name)==new.read(name),name
                identical+=1
    assert rent_cells==manifest['expectedRentCellCount']
    result={'status':'REAL REPORT READBACK PASS','runId':audit['runId'],'runDate':audit['runDate'],'propertyCount':manifest['propertyCount'],'comparableRows':manifest['expectedObservationCount'],'rentCellsVerifiedStructurally':rent_cells,'sourceSupportedRentCounts':audit['counts'],'stylesChecked':checked_styles,'untouchedCellValuesChecked':unchanged_values,'benchmarkSummaryTieouts':tieouts,'byteIdenticalUnmodifiedArchiveMembers':identical,'sourceUnchanged':True,'outputWorkbookSha256':pipeline.sha256(output),'limitation':'Source truth rests on the recorded researcher evidence; original formula caches are preserved and must be recalculated in Excel.'}
    (build_dir/'readback_verification.json').write_text(json.dumps(result,indent=2)+'\n')
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--baseline',type=Path,required=True)
    p.add_argument('--manifest',type=Path,required=True)
    p.add_argument('--build-dir',type=Path,required=True)
    a=p.parse_args()
    print(json.dumps(verify(a.baseline,a.manifest,a.build_dir),indent=2))
