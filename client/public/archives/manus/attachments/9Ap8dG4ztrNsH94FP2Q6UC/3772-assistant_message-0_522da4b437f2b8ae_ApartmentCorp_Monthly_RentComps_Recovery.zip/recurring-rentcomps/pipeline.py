#!/usr/bin/env python3
"""Deterministic rent-comps processing. No research, network access or email sending.

All inputs are untrusted data. Existing XLSX members are copied byte-for-byte,
except the explicitly allowlisted worksheet cell contents. No Excel calculation
engine is used; original formulas and their cached values are preserved.
"""
from __future__ import annotations

import argparse
import copy
from collections import Counter, defaultdict
from datetime import date
from decimal import Decimal, ROUND_HALF_EVEN
import hashlib
import json
import math
import os
from pathlib import Path
import re
import shutil
import sys
import tempfile
from urllib.parse import urlsplit
import zipfile
import xml.etree.ElementTree as ET

import openpyxl
from openpyxl.cell.cell import MergedCell

VERSION = "1.0"
PROPERTY_RE = re.compile(r"^(\d+)\s*[-–]")
BED_RE = re.compile(r"\b(STUDIO|[1-5]BD)\b", re.I)
PROHIBITED_PRICING_RE = re.compile(
    r"\b(per[- ]bed|per person|by the bed|student pricing|net[- ]effective|after concessions|"
    r"estimat(?:e[sd]?|ion|ing)|prox(?:y|ies))\b", re.I)
# Only complete, literal exclusion lists are recognized. Do not let a nearby
# 'not' negate a different claim, a price, a contrast, or the rest of a sentence.
_EXCLUDED_PRICING_ITEM = (
    r"(?:(?:the\s+)?deposit|per[- ]bed(?:\s+(?:pricing|rent))?|per person|by the bed|"
    r"student pricing|net[- ]effective(?:\s+rent)?|after concessions|"
    r"(?:an?\s+)?(?:estimate(?:d\s+rent)?|proxy))")
_EXCLUDED_TOTAL_PRICE = r"['\"]?\$\d[\d,]*(?:\.\d{1,2})?(?:/mo)?['\"]?"
_PRICING_EXCLUSION_RE = re.compile(
    r"\bnot\s+" + _EXCLUDED_PRICING_ITEM +
    r"(?:(?:\s*,\s*(?:(?:or|and)\s+)?|\s+(?:or|and)\s+)" + _EXCLUDED_PRICING_ITEM + r")*"
    r"(?=\s*(?:[.;!?]|$))|"
    r"\bwas not used as a lower[- ]priced proxy(?=\s*(?:[.;!?]|$))|"
    r"\bestimated total(?: monthly price)?\s+" + _EXCLUDED_TOTAL_PRICE +
    r"(?:\s+and\s+(?:(?:the\s+)?" + _EXCLUDED_TOTAL_PRICE + r"\s+deposit|deposits))?"
    r"\s+(?:is|are)\s+(?:separately displayed and )?excluded(?=\s*(?:[.;!?]|$))|"
    r"\bestimated total monthly price\s+" + _EXCLUDED_TOTAL_PRICE +
    r",\s*which is not the base rent(?=\s*(?:[.;!?]|$))|"
    r"\blower floorplan[- ]level estimated range endpoint was not used as an actual unit quote"
    r"(?=\s*(?:[.;!?]|$))", re.I)
_BASE_PRICING_RE = re.compile(
    r"\b(?:base\s+(?:monthly\s+)?(?:entire[- ]unit\s+)?rent|"
    r"(?:whole[- ]unit|entire[- ]unit|entire unit)\s+(?:monthly\s+)?rent|"
    r"full\s+(?:[-\w]+\s+){0,3}apartment price)\b", re.I)
MAIN_NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
REL_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
PKG_NS = "http://schemas.openxmlformats.org/package/2006/relationships"
NS = {"m": MAIN_NS}
ET.register_namespace("", MAIN_NS)
ET.register_namespace("r", REL_NS)
TEST_LABEL = "TEST — NOT LIVE RESEARCH"
CAVEATS = [
    "Only supplied source-supported current numeric observations enter market averages; no estimates, proxies, concessions or per-bed/student pricing.",
    "Source evidence and eligibility are researcher attestations: this offline processor does not visit URLs, establish identity, or independently prove the lowest advertised BASE rent.",
    "Subject and affordable rents, HUD/AMI data, source identities, styling and original formulas remain unchanged; baseline dates are not new verification.",
    "No Excel calculation engine was run. Original formulas/cached results (including Difference and recommendations) may be stale or produce errors when market averages are Phone Verify. Recalculate and review in Excel before use.",
    "Bedroom types are requested from Actual headers, not inferred from titles or legends; header-only bedrooms without Actual columns have no fresh observations.",
    "Duplicate comparable addresses/URLs are flagged, not silently removed or replaced. Averages are row-weighted; reviewer approval is required.",
    "Unlabeled legacy summary cells and unchanged hyperlinks outside refreshed cells remain baseline artifacts, not newly verified rent data. Obsolete hyperlinks on refreshed cells are removed; current URLs are retained as source text and audit evidence.",
]


class PipelineError(ValueError):
    """Input validation or unsafe workbook update; no refreshed workbook published."""


def require(condition, message):
    if not condition:
        raise PipelineError(message)


def clean(value):
    return "" if value is None else str(value).strip()


def norm(value):
    return re.sub(r"\s+", " ", clean(value)).casefold()


def sha256(path):
    with open(path, "rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def iso_date(value, context):
    require(isinstance(value, str) and re.fullmatch(r"\d{4}-\d{2}-\d{2}", value), f"{context}: expected YYYY-MM-DD")
    try:
        return date.fromisoformat(value)
    except ValueError as exc:
        raise PipelineError(f"{context}: invalid date") from exc


def valid_url(value):
    if not isinstance(value, str) or not value or re.search(r"[\s\x00-\x1f]", value):
        return False
    try:
        url = urlsplit(value)
        return url.scheme in {"https", "http"} and bool(url.hostname) and not url.username and not url.password
    except ValueError:
        return False


def urls_from(value, hyperlink=None):
    """Keep baseline provenance, including old scheme-less listing URLs."""
    result = []
    for text in (clean(value), clean(hyperlink)):
        for match in re.findall(r"(?:https?://[^\s<>]+|(?:www\.)?[a-zA-Z0-9.-]+\.(?:com|org|gov|net)/[^\s<>]*)", text):
            url = match.rstrip(".,;)|]")
            if not url.startswith(("https://", "http://")):
                url = "https://" + url
            if url not in result:
                result.append(url)
    return result


def cell_value(value):
    if isinstance(value, (date,)):
        return value.isoformat()
    return value


def direct_reference_value(wb, cached, value, seen=None):
    """Resolve only direct references, never evaluate arbitrary formulas."""
    if not isinstance(value, str) or not value.startswith("="):
        return cell_value(value)
    match = re.fullmatch(r"=(?:'((?:[^']|'')+)'|([^'!]+))!\$?([A-Z]+)\$?(\d+)", value)
    if not match:
        return None
    sheet = (match.group(1) or match.group(2)).replace("''", "'")
    address = match.group(3) + match.group(4)
    seen = set() if seen is None else seen
    if sheet not in wb or (sheet, address) in seen:
        return None
    seen.add((sheet, address))
    target = wb[sheet][address].value
    if isinstance(target, str) and target.startswith("="):
        resolved = direct_reference_value(wb, cached, target, seen)
        return resolved if resolved is not None else cell_value(cached[sheet][address].value)
    return cell_value(target)


def find_header(ws):
    matches = []
    for row in range(1, min(25, ws.max_row) + 1):
        labels = {norm(c.value) for c in ws[row] if c.value is not None}
        if {"rank", "type", "property name"} <= labels:
            matches.append(row)
    require(len(matches) == 1, f"{ws.title}: expected one Rank/Type/Property Name header in first 25 rows, found {matches}")
    return matches[0]


def safe_cell(ws, coordinate, allow_merged_anchor=False):
    cell = ws[coordinate]
    require(not isinstance(cell, MergedCell), f"{ws.title}!{coordinate}: merged interior write forbidden")
    for merged in ws.merged_cells.ranges:
        if coordinate in merged:
            require(allow_merged_anchor and coordinate == merged.start_cell.coordinate,
                    f"{ws.title}!{coordinate}: merged write requires explicit anchor authorization ({merged})")
    return cell


def inspect_workbook(workbook, run_id, run_date):
    require(isinstance(run_id, str) and bool(re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,99}", run_id)), "runId must be 1–100 safe filename characters")
    day = iso_date(run_date, "runDate")
    require(day <= date.today(), "runDate cannot be in the future")
    wb = openpyxl.load_workbook(workbook, data_only=False)
    cached = openpyxl.load_workbook(workbook, data_only=True)
    properties = []
    ids = set()
    for ws in wb:
        match = PROPERTY_RE.match(ws.title)
        if not match:
            continue
        building_id = match.group(1)
        require(building_id not in ids, f"Duplicate buildingId {building_id}")
        ids.add(building_id)
        header = find_header(ws)
        labels = {}
        actuals = {}
        bed_columns = defaultdict(list)
        for cell in ws[header]:
            label = norm(cell.value)
            if not label:
                continue
            require(label not in labels, f"{ws.title}: duplicate header {label}")
            labels[label] = cell.column
            bed = BED_RE.search(clean(cell.value))
            if bed:
                bed_type = bed.group(1).upper()
                bed_columns[bed_type].append(cell.column)
                if "ACTUAL" in clean(cell.value).upper():
                    require(bed_type not in actuals, f"{ws.title}: multiple Actual columns for {bed_type}")
                    actuals[bed_type] = cell.column
        require(actuals, f"{ws.title}: no bedroom Actual columns detected")
        source_col = labels.get("data source", labels.get("source"))
        notes_col = next((col for label, col in labels.items() if label.startswith("notes")), None)
        require(source_col and notes_col, f"{ws.title}: source and notes headers required")
        type_col, name_col = labels["type"], labels["property name"]
        subjects, rows, benchmarks = [], [], []
        for row in range(header + 1, ws.max_row + 1):
            kind = clean(ws.cell(row, type_col).value).upper()
            name = clean(ws.cell(row, name_col).value)
            if kind == "SUBJECT":
                subjects.append(row)
            elif kind == "MARKET RATE":
                require(name, f"{ws.title} row {row}: missing comparable name")
                rows.append(row)
            elif kind == "BENCHMARK" and "MARKET AVG" in name.upper():
                benchmarks.append(row)
        require(len(subjects) == 1 and rows and benchmarks, f"{ws.title}: expected one subject, market rows and Market Avg benchmark(s)")

        def identity(row):
            result = {"row": row, "propertyName": clean(ws.cell(row, name_col).value)}
            for key, names in {"address": ("address",), "city": ("city",), "state": ("st", "state"), "zip": ("zip", "zip code")}.items():
                col = next((labels[n] for n in names if n in labels), None)
                result[key] = clean(ws.cell(row, col).value) if col else ""
            return result

        subject = identity(subjects[0])
        subject["previousRents"] = {bed: cell_value(ws.cell(subjects[0], col).value) for bed, col in actuals.items()}
        subject["resolvedPreviousRents"] = {bed: direct_reference_value(wb, cached, ws.cell(subjects[0], col).value) for bed, col in actuals.items()}
        comps = []
        for row in rows:
            comp = identity(row)
            source = ws.cell(row, source_col)
            comp.update(sourceText=clean(source.value), sourceUrls=urls_from(source.value, source.hyperlink.target if source.hyperlink else None),
                        notes=clean(ws.cell(row, notes_col).value),
                        previousRents={bed: cell_value(ws.cell(row, col).value) for bed, col in actuals.items()})
            comps.append(comp)
        summaries = {bed: [] for bed in actuals}
        summary_context = []
        for row in range(header + 1, ws.max_row + 1):
            bed = clean(ws.cell(row, 1).value).upper()
            if bed in actuals:
                coord = ws.cell(row, 3).coordinate
                safe_cell(ws, coord, allow_merged_anchor=True)
                summaries[bed].append(coord)
                current = ws.cell(row, 2).value
                summary_context.append({"bedType": bed, "row": row, "marketCell": coord,
                                        "previousMarket": cell_value(ws.cell(row, 3).value),
                                        "currentRentFormulaOrValue": cell_value(current),
                                        "resolvedCurrentRent": direct_reference_value(wb, cached, current)})
        disclosures = []
        for row in ws:
            for cell in row:
                text = clean(cell.value)
                if isinstance(cell, MergedCell) or cell.column != 1:
                    continue
                if text.lower().startswith("data as of") or text.lower().startswith("market actual refresh as of"):
                    disclosures.append({"cell": cell.coordinate, "kind": "date_source", "previous": text})
                elif text.lower().startswith("market average ="):
                    disclosures.append({"cell": cell.coordinate, "kind": "average_caption", "previous": text})
                elif text.upper().startswith("COLUMN GUIDE"):
                    disclosures.append({"cell": cell.coordinate, "kind": "column_guide", "previous": text})
        properties.append({"buildingId": building_id, "sheetName": ws.title, "subject": subject,
                           "bedTypes": list(actuals), "comps": comps,
                           "headerMapping": {"row": header, "labels": labels, "actualColumns": actuals,
                                             "bedroomColumns": dict(bed_columns), "typeColumn": type_col,
                                             "propertyNameColumn": name_col, "sourceColumn": source_col, "notesColumn": notes_col},
                           "benchmarkRows": benchmarks, "benchmarkRow": benchmarks[-1],
                           "summaryCells": summaries, "summaryContext": summary_context,
                           "baselineDisclosures": disclosures,
                           "baselineBenchmarkMetadata": [{"row": row, "name": clean(ws.cell(row, name_col).value),
                               "sourceText": clean(ws.cell(row, source_col).value), "notes": clean(ws.cell(row, notes_col).value),
                               "bedValues": {bed: [cell_value(ws.cell(row, col).value) for col in cols] for bed, cols in bed_columns.items()}}
                               for row in benchmarks]})
    require(properties, "No property tabs matching ^\\d+\\s*[-–]")
    manifest = {"schemaVersion": VERSION, "baselineSha256": sha256(workbook), "runId": run_id, "runDate": run_date,
                "propertyCount": len(properties), "expectedObservationCount": sum(len(p["comps"]) for p in properties),
                "expectedRentCellCount": sum(len(p["comps"]) * len(p["bedTypes"]) for p in properties),
                "properties": properties, "caveats": CAVEATS}
    wb.close()
    cached.close()
    return manifest


def unique_map(items, key, context):
    require(isinstance(items, list), f"{context}: expected array")
    result = {}
    for item in items:
        require(isinstance(item, dict) and key in item, f"{context}: each item needs {key}")
        value = item[key]
        require(type(value) in {str, int}, f"{context}: invalid {key}")
        require(value not in result, f"{context}: duplicate {key} {value}")
        result[value] = item
    return result


def prohibited_pricing_evidence(evidence):
    """Fail closed unless every forbidden mention is explicitly excluded.

    This is a small exclusion grammar, not general natural-language negation.
    Exemptions also need affirmative base/whole-unit context elsewhere. A mixed
    actual forbidden claim always fails, even if another occurrence is excluded.
    Evidence is inspected only; it is never rewritten for validation or output.
    """
    mentions = list(PROHIBITED_PRICING_RE.finditer(evidence))
    if not mentions:
        return False
    exclusions = []
    for match in _PRICING_EXCLUSION_RE.finditer(evidence):
        clause_prefix = re.split(r"[.;!?]", evidence[:match.start()])[-1]
        if re.search(r"\b(?:not|may|might|could|whether|if|unless|unclear|unknown|possibly|perhaps)\b",
                     clause_prefix, re.I):
            continue
        # A question is not an attested exclusion.
        if evidence[match.end():].lstrip().startswith("?"):
            continue
        exclusions.append(match.span())
    if any(not any(start <= mention.start() and mention.end() <= end for start, end in exclusions)
           for mention in mentions):
        return True
    for base in _BASE_PRICING_RE.finditer(evidence):
        # An explicitly negated base-rent phrase is not affirmative support.
        prefix = evidence[:base.start()]
        if not re.search(r"\b(?:not|no|without)\s+(?:the\s+)?$", prefix, re.I):
            return False
    return True


def validate_observations(manifest, observations, max_age_days=0):
    require(isinstance(observations, dict), "Observation envelope must be an object")
    require(type(max_age_days) is int and 0 <= max_age_days <= 7, "max-age-days must be 0–7; default 0")
    for key in ("runId", "runDate", "baselineSha256"):
        require(observations.get(key) == manifest[key], f"Observation envelope {key} mismatch")
    run_day = iso_date(manifest["runDate"], "runDate")
    observed = unique_map(observations.get("properties"), "buildingId", "properties")
    expected = {p["buildingId"]: p for p in manifest["properties"]}
    require(observed.keys() == expected.keys(), f"Property IDs mismatch: missing {sorted(expected.keys()-observed.keys())}, extra {sorted(observed.keys()-expected.keys())}")

    def checked(value, context):
        day = iso_date(value, context)
        require(day <= date.today() and day <= run_day, f"{context}: future checkedAt prohibited")
        require((run_day - day).days <= max_age_days, f"{context}: stale checkedAt (allowed {max_age_days} days)")

    for building_id, p in expected.items():
        comps = unique_map(observed[building_id].get("comps"), "row", f"{building_id} comps")
        base = {c["row"]: c for c in p["comps"]}
        require(comps.keys() == base.keys(), f"{building_id}: comparable row IDs mismatch")
        for row, comp in comps.items():
            context = f"{building_id} row {row}"
            require(type(row) is int, f"{context}: row must be integer")
            require(comp.get("propertyName") == base[row]["propertyName"], f"{context}: propertyName identity mismatch")
            require(comp.get("eligibility") in {"market_rate", "unverified", "ineligible"}, f"{context}: invalid eligibility")
            require(isinstance(comp.get("identityEvidence"), str) and bool(comp["identityEvidence"].strip()), f"{context}: identityEvidence required (including unresolved identity context)")
            require(isinstance(comp.get("notes"), str), f"{context}: notes must be text")
            checked(comp.get("checkedAt"), context)
            rents = unique_map(comp.get("rents"), "bedType", context + " rents")
            require(rents.keys() == set(p["bedTypes"]), f"{context}: missing/extra bedTypes")
            for bed, rent in rents.items():
                ctx = context + " " + bed
                status = rent.get("status")
                require(status in {"verified", "phone_verify", "not_offered"}, f"{ctx}: invalid/blank status")
                require("amount" in rent and "sourceUrl" in rent and "evidence" in rent, f"{ctx}: amount/sourceUrl/evidence fields required")
                require(isinstance(rent["sourceUrl"], str) and isinstance(rent["evidence"], str), f"{ctx}: sourceUrl/evidence must be text")
                checked(rent.get("checkedAt"), ctx)
                require(not rent["sourceUrl"] or valid_url(rent["sourceUrl"]), f"{ctx}: sourceUrl must be an HTTP(S) URL without embedded credentials")
                require(comp["eligibility"] == "market_rate" or status == "phone_verify", f"{ctx}: unverified/ineligible comps may only become Phone Verify; replacement needs reviewer")
                if status == "verified":
                    amount = rent["amount"]
                    require(type(amount) in {int, float} and math.isfinite(amount) and amount > 0, f"{ctx}: positive finite numeric amount required")
                    require(valid_url(rent["sourceUrl"]) and bool(rent["evidence"].strip()), f"{ctx}: verified rent requires URL and evidence; prior numeric values are not proof")
                    require(not prohibited_pricing_evidence(rent["evidence"]), f"{ctx}: evidence indicates prohibited pricing/estimate")
                else:
                    require(rent["amount"] is None, f"{ctx}: nonnumeric status must have null amount; stale numeric values cannot carry forward")
                    if status == "not_offered":
                        require(valid_url(rent["sourceUrl"]) and bool(rent["evidence"].strip()), f"{ctx}: Not Offered requires source URL and explicit evidence")
    return observed


def average(values):
    return int((sum(Decimal(str(v)) for v in values) / Decimal(len(values))).quantize(Decimal("1"), rounding=ROUND_HALF_EVEN)) if values else "Phone Verify"


def duplicate_flags(prop, obs_comps=None):
    groups = defaultdict(set)
    subject_address = norm(prop["subject"]["address"])
    flags = []
    for comp in prop["comps"]:
        address = norm(comp["address"])
        if address:
            groups[("address", address, norm(comp["city"]), norm(comp["state"]))].add(comp["row"])
            if address == subject_address and norm(comp["city"]) == norm(prop["subject"]["city"]) and norm(comp["state"]) == norm(prop["subject"]["state"]):
                flags.append({"kind": "subject_address_match", "rows": [comp["row"]], "value": comp["address"]})
        if obs_comps is None:
            urls = comp["sourceUrls"]
        else:
            urls = {r["sourceUrl"] for r in obs_comps[comp["row"]]["rents"] if r["sourceUrl"]}
        for url in urls:
            parsed = urlsplit(url)
            key = (parsed.netloc.casefold().removeprefix("www."), parsed.path.rstrip("/"))
            groups[("url", *key)].add(comp["row"])
    flags.extend({"kind": key[0], "rows": sorted(rows), "value": " | ".join(key[1:])} for key, rows in groups.items() if len(rows) > 1)
    return flags


def plan_updates(wb, manifest, observations, test_mode):
    writes = defaultdict(dict)
    changes, reports, flags = [], [], []
    prefix = TEST_LABEL + " | " if test_mode else ""

    def put(ws, coordinate, value, reason, merged=False):
        cell = safe_cell(ws, coordinate, allow_merged_anchor=merged)
        require(not isinstance(value, str) or len(value) <= 32767, f"{ws.title}!{coordinate}: text exceeds Excel cell limit")
        previous = cell_value(cell.value)
        if coordinate in writes[ws.title]:
            require(writes[ws.title][coordinate] == value, f"Conflicting writes at {ws.title}!{coordinate}")
        writes[ws.title][coordinate] = value
        changes.append({"sheetName": ws.title, "cell": coordinate, "previous": previous, "new": value, "reason": reason,
                        "mergedAnchorExplicitlyAuthorized": merged,
                        "previousHyperlink": cell.hyperlink.target if cell.hyperlink else None,
                        "newHyperlink": None})

    totals = Counter()
    source_dates = Counter()
    for p in manifest["properties"]:
        ws = wb[p["sheetName"]]
        h = p["headerMapping"]
        comps = {c["row"]: c for c in observations[p["buildingId"]]["comps"]}
        coverage = {bed: [] for bed in p["bedTypes"]}
        comp_reports = []
        for baseline in p["comps"]:
            comp = comps[baseline["row"]]
            status_counts = Counter()
            for rent in comp["rents"]:
                bed = rent["bedType"]
                value = rent["amount"] if rent["status"] == "verified" else {"phone_verify": "Phone Verify", "not_offered": "Not Offered"}[rent["status"]]
                put(ws, ws.cell(comp["row"], h["actualColumns"][bed]).coordinate, value, f"observed {bed} {rent['status']}")
                totals[rent["status"]] += 1
                status_counts[rent["status"]] += 1
                source_dates[rent["checkedAt"]] += 1
                if rent["status"] == "verified":
                    coverage[bed].append(rent["amount"])
            urls = sorted({r["sourceUrl"] for r in comp["rents"] if r["sourceUrl"]})
            source_text = prefix + f"Checked {comp['checkedAt']}; eligibility {comp['eligibility']}; " + (" | ".join(urls) if urls else "No published source obtained; Phone Verify")
            note = prefix + f"Run {manifest['runId']} {manifest['runDate']}. Identity: {comp['identityEvidence']}. {comp['notes']}"
            if comp["eligibility"] != "market_rate":
                note += " NEED REPLACEMENT REVIEW: not confirmed eligible; no substitute inserted."
            note += " | " + " | ".join(f"{r['bedType']}: {r['status']} checked {r['checkedAt']}; {r['evidence'] or 'No numeric verification evidence obtained'}" for r in comp["rents"])
            put(ws, ws.cell(comp["row"], h["sourceColumn"]).coordinate, source_text, "current source record (baseline retained in audit)")
            put(ws, ws.cell(comp["row"], h["notesColumn"]).coordinate, note, "evidence and attempted verification record")
            comp_reports.append({**copy.deepcopy(comp), "previousRents": baseline["previousRents"], "previousSourceText": baseline["sourceText"],
                                 "previousSourceUrls": baseline["sourceUrls"], "previousNotes": baseline["notes"], "needsReplacement": comp["eligibility"] != "market_rate", "counts": dict(status_counts)})
        averages = {bed: average(values) for bed, values in coverage.items()}
        count_text = "; ".join(f"{bed}: {len(values)}/{len(comps)} verified numeric" for bed, values in coverage.items())
        for row in p["benchmarkRows"]:
            for bed, cols in h["bedroomColumns"].items():
                for col in cols:
                    put(ws, ws.cell(row, col).coordinate, averages.get(bed, "Phone Verify"), "market benchmark, verified numeric observations only")
            name_cell = ws.cell(row, h["propertyNameColumn"])
            name = re.sub(r"\s*\([^)]*\)\s*$", "", clean(name_cell.value))
            put(ws, name_cell.coordinate, name + f" ({prefix}Refresh {manifest['runDate']})", "benchmark run-date disclosure", merged=True)
            put(ws, ws.cell(row, h["sourceColumn"]).coordinate, prefix + f"Source-supported observations checked for run {manifest['runDate']}; original nonmarket sources unchanged", "benchmark current source disclosure")
            put(ws, ws.cell(row, h["notesColumn"]).coordinate, prefix + "Row-weighted average of verified lowest advertised BASE numeric rents only; " + count_text + ". Phone Verify/Not Offered excluded. Duplicate flags require reviewer approval.", "benchmark coverage disclosure")
        for bed, coords in p["summaryCells"].items():
            for coord in coords:
                put(ws, coord, averages[bed], "visible summary equals matching benchmark", merged=True)
        for disclosure in p["baselineDisclosures"]:
            if disclosure["kind"] == "date_source":
                text = f"Market Actual refresh as of {manifest['runDate']} | {prefix}Numeric rents source-supported only where evidence supplied; Phone Verify / Not Offered explicit. Subject, affordable and HUD/AMI data remain baseline, not reverified."
            elif disclosure["kind"] == "average_caption":
                text = prefix + f"Market Average = verified numeric BASE rents only, checked for {manifest['runDate']}. Coverage: {count_text}. No estimates; recalculate/review original formulas in Excel."
            else:
                text = re.sub(r"ACTUAL\s*=.*?(?=\s*\|\s*|\. |$)", "ACTUAL = source-supported numeric BASE rent, Phone Verify, or evidenced Not Offered", disclosure["previous"], flags=re.I)
                text = prefix + text + f" | Market Actual standard {manifest['runDate']}: only fresh source-supported numeric values; no concessions/per-bed estimates. Other columns remain baseline."
            put(ws, disclosure["cell"], text, "current date/source/coverage disclosure", merged=True)
        baseline_duplicates = duplicate_flags(p)
        current_duplicates = duplicate_flags(p, comps)
        missing_coverage = [bed for bed, values in coverage.items() if not values]
        unmapped_beds = sorted(set(h["bedroomColumns"]) - set(p["bedTypes"]))
        warnings = []
        if missing_coverage:
            warnings.append("No numeric eligible comparable coverage: " + ", ".join(missing_coverage))
        if unmapped_beds:
            warnings.append("Bedrooms in non-Actual headers have no requested Actual observation column: " + ", ".join(unmapped_beds))
        if any(not coords for coords in p["summaryCells"].values()):
            warnings.append("At least one Actual bedroom has no visible A-labeled summary row")
        if len(p["benchmarkRows"]) > 1:
            warnings.append("Multiple explicit Market Avg benchmarks refreshed consistently: " + str(p["benchmarkRows"]))
        if baseline_duplicates or current_duplicates:
            warnings.append("Duplicate comparable address/URL or subject-address match requires review; row-weighted average may overrepresent duplicate listings")
        if any(c["needsReplacement"] for c in comp_reports):
            warnings.append("Unverified/ineligible comparable needs replacement review; no property identity substituted")
        reports.append({"buildingId": p["buildingId"], "sheetName": p["sheetName"], "subject": p["subject"],
                        "marketAvg": averages, "benchmarkCoverageCounts": {bed: len(values) for bed, values in coverage.items()},
                        "requestedBedTypes": p["bedTypes"], "comps": comp_reports, "warnings": warnings,
                        "baselineDuplicateFlags": baseline_duplicates, "currentDuplicateFlags": current_duplicates,
                        "baselineDisclosures": p["baselineDisclosures"], "baselineBenchmarkMetadata": p["baselineBenchmarkMetadata"]})
        flags.extend({"buildingId": p["buildingId"], "warning": warning} for warning in warnings)
    return dict(writes), changes, reports, {key: totals[key] for key in ("verified", "phone_verify", "not_offered")}, dict(source_dates), flags


def worksheet_paths(archive):
    workbook = ET.fromstring(archive.read("xl/workbook.xml"))
    rels = ET.fromstring(archive.read("xl/_rels/workbook.xml.rels"))
    targets = {r.attrib["Id"]: r.attrib["Target"] for r in rels}
    result = {}
    import posixpath
    for sheet in workbook.find("m:sheets", NS):
        target = targets[sheet.attrib[f"{{{REL_NS}}}id"]]
        result[sheet.attrib["name"]] = target.lstrip("/") if target.startswith("/") else posixpath.normpath("xl/" + target)
    return result


def patch_xlsx(source, destination, writes):
    """Surgically replace allowlisted cell contents. Preserve all ZIP members.

    Even inside modified worksheets, cells outside the allowlist are unchanged;
    dimensions, merged ranges, styles, formula caches and relationships untouched.
    """
    with zipfile.ZipFile(source) as old, zipfile.ZipFile(destination, "w") as new:
        paths = worksheet_paths(old)
        updates = {paths[name]: cells for name, cells in writes.items()}
        for info in old.infolist():
            data = old.read(info.filename)
            if info.filename in updates:
                root = ET.fromstring(data)
                cells = {c.attrib["r"]: c for c in root.findall("m:sheetData/m:row/m:c", NS)}
                row_nodes = {int(r.attrib["r"]): r for r in root.findall("m:sheetData/m:row", NS)}
                for coordinate, value in updates[info.filename].items():
                    node = cells.get(coordinate)
                    if node is None:
                        row_number = int(re.search(r"\d+$", coordinate).group())
                        require(row_number in row_nodes, f"Missing existing row for {coordinate}")
                        node = ET.SubElement(row_nodes[row_number], f"{{{MAIN_NS}}}c", {"r": coordinate})
                        # SpreadsheetML requires increasing column order within a row.
                        row_nodes[row_number][:] = sorted(row_nodes[row_number], key=lambda c: openpyxl.utils.cell.column_index_from_string(re.match(r"[A-Z]+", c.attrib["r"]).group()))
                    for child in list(node):
                        if child.tag in {f"{{{MAIN_NS}}}{tag}" for tag in ("v", "f", "is")}:
                            node.remove(child)
                    node.attrib.pop("t", None)
                    if isinstance(value, str):
                        node.set("t", "inlineStr")
                        inline = ET.SubElement(node, f"{{{MAIN_NS}}}is")
                        text = ET.SubElement(inline, f"{{{MAIN_NS}}}t")
                        text.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
                        text.text = value
                    elif value is not None:
                        ET.SubElement(node, f"{{{MAIN_NS}}}v").text = str(value)
                links = root.find("m:hyperlinks", NS)
                if links is not None:
                    for link in list(links):
                        if link.attrib.get("ref") in updates[info.filename]:
                            links.remove(link)
                    if not len(links):
                        root.remove(links)
                data = ET.tostring(root, encoding="utf-8", xml_declaration=True)
            new.writestr(info, data)
        new.comment = old.comment


def json_text(value):
    return json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + "\n"


def load_json(path):
    def no_duplicate_keys(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, f"JSON duplicate key: {key}")
            result[key] = value
        return result
    try:
        with open(path, encoding="utf-8") as stream:
            return json.load(stream, object_pairs_hook=no_duplicate_keys, parse_constant=lambda value: (_ for _ in ()).throw(PipelineError(f"Nonfinite JSON number: {value}")))
    except (OSError, json.JSONDecodeError) as exc:
        raise PipelineError(f"Cannot read JSON {path}: {exc}") from exc


def atomic_publish(output_dir, producer):
    """All-or-nothing directory publication; reject preexisting nonempty targets."""
    target = Path(output_dir).resolve()
    require(not target.exists() or (target.is_dir() and not any(target.iterdir())), f"Output directory must be new or empty: {target}")
    target.parent.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix=".rentcomps-stage-", dir=target.parent))
    try:
        result = producer(staging)
        if target.exists():
            target.rmdir()
        os.replace(staging, target)
        return result
    finally:
        if staging.exists():
            shutil.rmtree(staging)


def extract(workbook, output_dir, run_id, run_date):
    manifest = inspect_workbook(workbook, run_id, run_date)
    def produce(staging):
        (staging / "manifest.json").write_text(json_text(manifest), encoding="utf-8")
        return manifest
    return atomic_publish(output_dir, produce)


def md(value):
    return clean(value).replace("|", "\\|").replace("\n", " ")


def checklist(audit):
    label = audit["label"]
    lines = [f"# ApartmentCorp rent-comps checklist — {label}", "", f"Run `{audit['runId']}` | {audit['runDate']} | {audit['propertyCount']} property tabs | {audit['expectedObservationCount']} observed comparable rows",
             "", f"**Outcome:** {audit['outcome']}. Verified numeric cells: {audit['counts']['verified']}; Phone Verify: {audit['counts']['phone_verify']}; Not Offered: {audit['counts']['not_offered']}.", "",
             "Numeric coverage is not a guarantee that every rent is verified. Prior numeric values are baseline only. Not Offered requires explicit source evidence; absence of listings is Phone Verify.", ""]
    lines += ["- [ ] " + caveat for caveat in CAVEATS]
    for p in audit["properties"]:
        lines += ["", f"## {p['sheetName']} — {md(p['subject']['propertyName'])}",
                  f"{md(p['subject']['address'])}, {md(p['subject']['city'])}, {md(p['subject']['state'])} {md(p['subject']['zip'])}", "",
                  "**Market average / eligible numeric coverage:** " + "; ".join(f"{bed}: {p['marketAvg'][bed]} ({count}/{len(p['comps'])})" for bed, count in p["benchmarkCoverageCounts"].items()), ""]
        for warning in p["warnings"]:
            lines.append("- [ ] **Review:** " + warning)
        lines += ["", "| Row | Comparable | Bed | Previous | New / status | Checked | Source / evidence |", "|---|---|---|---|---|---|---|"]
        for comp in p["comps"]:
            for r in comp["rents"]:
                new = r["amount"] if r["status"] == "verified" else {"phone_verify": "Phone Verify", "not_offered": "Not Offered"}[r["status"]]
                lines.append("| " + " | ".join(md(v) for v in [comp["row"], comp["propertyName"], r["bedType"], comp["previousRents"][r["bedType"]], new, r["checkedAt"], (r["sourceUrl"] or "No URL obtained") + " — " + (r["evidence"] or "Phone Verify; no numeric evidence")]) + " |")
            lines += ["", f"**Row {comp['row']} identity / eligibility:** {md(comp['identityEvidence'])}; `{comp['eligibility']}`. **Notes / phone attempts:** {md(comp['notes'])}"]
        lines += ["", "- [ ] Review eligibility, source identity, lowest BASE rent, exclusions and duplicate flags.", "- [ ] Resolve Phone Verify and replacement warnings; review summary/benchmark equality."]
    return "\n".join(lines) + "\n"


def build(workbook, manifest_path, observations_path, output_dir, test_mode=False, max_age_days=0):
    manifest = load_json(manifest_path)
    require(isinstance(manifest, dict), "Manifest must be an object")
    require(manifest.get("baselineSha256") == sha256(workbook), "Source baseline hash mismatch")
    canonical = inspect_workbook(workbook, manifest.get("runId"), manifest.get("runDate"))
    require(manifest == canonical, "Manifest differs from fresh baseline extraction; subsets/tampered identities/mappings prohibited")
    observations_raw = load_json(observations_path)
    observations = validate_observations(manifest, observations_raw, max_age_days)
    if not test_mode:
        require(not observations_raw.get("testMode") and not re.search(r"TEST|NOT LIVE|SYNTHETIC", clean(observations_raw.get("label")), re.I), "Synthetic/test observations require --test-mode; not live research")
        for prop in observations_raw.get("properties", []):
            for comp in prop.get("comps", []):
                require(not re.search(r"TEST NOT LIVE|TEST[ —-]+NOT LIVE|SYNTHETIC", comp.get("identityEvidence", "") + " " + comp.get("notes", ""), re.I), "Synthetic/test identity evidence requires --test-mode")
                for rent in comp.get("rents", []):
                    hostname = urlsplit(rent.get("sourceUrl", "")).hostname or ""
                    require(not hostname.endswith((".invalid", ".test", ".example")) and hostname not in {"example.com", "example.org", "example.net"}, "Reserved fixture source URL requires --test-mode")
                    require(not re.search(r"TEST NOT LIVE|TEST[ —-]+NOT LIVE|SYNTHETIC", rent.get("evidence", ""), re.I), "Synthetic/test rent evidence requires --test-mode")
    wb = openpyxl.load_workbook(workbook, data_only=False)
    try:
        writes, changes, reports, counts, source_dates, flags = plan_updates(wb, manifest, observations, test_mode)
    finally:
        wb.close()
    successful = counts["verified"] > 0
    distributable = successful and not test_mode
    label = TEST_LABEL if test_mode else ("SOURCE-SUPPORTED REFRESH — REVIEW REQUIRED" if successful else "UNSUCCESSFUL — ZERO VERIFIED NUMERIC CELLS — NOT DISTRIBUTABLE")
    prefix = "TEST_NOT_LIVE_" if test_mode else ""
    workbook_name = prefix + ("RentComps_refreshed.xlsx" if successful or test_mode else "UNSUCCESSFUL_NOT_DISTRIBUTABLE_RentComps.xlsx")
    audit = {"schemaVersion": VERSION, "label": label, "testMode": test_mode, "runId": manifest["runId"], "runDate": manifest["runDate"],
             "baselineSha256": manifest["baselineSha256"], "observationsSha256": sha256(observations_path),
             "propertyCount": manifest["propertyCount"], "expectedObservationCount": manifest["expectedObservationCount"],
             "observedComparableCount": sum(len(p["comps"]) for p in reports), "expectedRentCellCount": manifest["expectedRentCellCount"],
             "counts": counts, "checkedDateCounts": source_dates, "maxAgeDays": max_age_days,
             "sourceCheckedDateCountsByStatus": {status: dict(Counter(r["checkedAt"] for p in reports for c in p["comps"] for r in c["rents"] if r["status"] == status and r["sourceUrl"])) for status in ("verified", "phone_verify", "not_offered")},
             "successful": successful and not test_mode, "structuralValidationPassed": True,
             "distributable": distributable, "requiresReviewerApproval": True,
             "outcome": "TEST STRUCTURAL PASS; NOT LIVE RESEARCH" if test_mode else ("SUCCESSFUL WITH COVERAGE LIMITS; REVIEW REQUIRED" if successful else "UNSUCCESSFUL: no verified numeric observations"),
             "properties": reports, "reviewFlags": flags, "caveats": CAVEATS}
    payload = {"label": label, "from": "apartmentcorp44@gmail.com",
               "to": ["ethan@apartmentcorp.com"] if test_mode else ["Ethan@apartmentcorp.com", "mam@22.bz"],
               "subject": f"{label} | ApartmentCorp rent comps | {manifest['runDate']}",
               "bodyText": f"{label}\n\nThe deterministic workbook review covers {manifest['propertyCount']} properties and {manifest['expectedObservationCount']} comparable rows. Supplied observations contain {counts['verified']} source-supported numeric rent cells, {counts['phone_verify']} Phone Verify cells and {counts['not_offered']} evidenced Not Offered cells. Not all rents are verified. Market averages exclude nonnumeric statuses. Source identity, BASE-rent semantics, duplicates and unchanged formulas require reviewer approval. Subject/affordable data remain baseline, not freshly researched.\n\n" + ("This is a synthetic structural TEST, NOT LIVE RESEARCH. Do not use for pricing or distribute as live rent research.\n" if test_mode else "") + "\n".join(CAVEATS),
               "send": False, "sendAllowed": False, "distributionEligibleAfterReview": distributable,
               "attachments": [workbook_name, prefix + "checklist.md"], "caveats": CAVEATS}

    def produce(staging):
        require(sha256(workbook) == manifest["baselineSha256"], "Source changed during validation; assembly aborted")
        patch_xlsx(workbook, staging / workbook_name, writes)
        require(sha256(workbook) == manifest["baselineSha256"], "Source changed during assembly; publication aborted")
        audit["outputWorkbookSha256"] = sha256(staging / workbook_name)
        checked = openpyxl.load_workbook(staging / workbook_name, data_only=False)
        try:
            for sheet, cells in writes.items():
                for coordinate, value in cells.items():
                    require(checked[sheet][coordinate].value == value, f"Output read-back failed {sheet}!{coordinate}")
        finally:
            checked.close()
        files = {prefix + "audit.json": audit,
                 prefix + "changes.json": {"label": label, "runId": manifest["runId"], "runDate": manifest["runDate"], "baselineSha256": manifest["baselineSha256"], "changes": changes},
                 prefix + "email_payload.json": payload}
        if distributable:
            files["distributable_manifest.json"] = {"label": label, "runId": manifest["runId"], "runDate": manifest["runDate"], "baselineSha256": manifest["baselineSha256"],
                "workbook": workbook_name, "outputWorkbookSha256": audit["outputWorkbookSha256"], "counts": counts, "requiresReviewerApproval": True, "sendAuthorized": False}
        for filename, content in files.items():
            (staging / filename).write_text(json_text(content), encoding="utf-8")
        (staging / (prefix + "checklist.md")).write_text(checklist(audit), encoding="utf-8")
        # A completion marker is not a distributable manifest. Test/zero runs never create the latter.
        (staging / (prefix + "completion.json")).write_text(json_text({"label": label, "runId": manifest["runId"], "successful": audit["successful"], "distributable": distributable, "files": sorted(p.name for p in staging.iterdir())}), encoding="utf-8")
        return audit
    return atomic_publish(output_dir, produce)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    extraction = commands.add_parser("extract", help="Create full header-driven baseline research manifest")
    extraction.add_argument("--workbook", required=True)
    extraction.add_argument("--output-dir", required=True)
    extraction.add_argument("--run-id", required=True)
    extraction.add_argument("--run-date", required=True)
    assembly = commands.add_parser("build", help="Validate full observations and create atomic reviewed outputs")
    assembly.add_argument("--workbook", required=True)
    assembly.add_argument("--manifest", required=True)
    assembly.add_argument("--observations", required=True)
    assembly.add_argument("--output-dir", required=True)
    assembly.add_argument("--test-mode", action="store_true")
    assembly.add_argument("--max-age-days", type=int, default=0, help="Conservative source age tolerance, 0–7 days; default same-day")
    args = parser.parse_args(argv)
    try:
        if args.command == "extract":
            result = extract(args.workbook, args.output_dir, args.run_id, args.run_date)
            print(json_text({k: result[k] for k in ("baselineSha256", "runId", "runDate", "propertyCount", "expectedObservationCount", "expectedRentCellCount")}))
        else:
            result = build(args.workbook, args.manifest, args.observations, args.output_dir, args.test_mode, args.max_age_days)
            print(json_text({k: result[k] for k in ("label", "outcome", "propertyCount", "observedComparableCount", "counts", "distributable")}))
            if not result["testMode"] and not result["successful"]:
                return 2
        return 0
    except (PipelineError, OSError, zipfile.BadZipFile) as exc:
        print(f"REJECTED — no refreshed workbook published: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
