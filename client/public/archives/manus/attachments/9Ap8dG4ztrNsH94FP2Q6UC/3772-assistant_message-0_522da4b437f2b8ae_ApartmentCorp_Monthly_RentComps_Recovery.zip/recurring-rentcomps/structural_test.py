#!/usr/bin/env python3
"""Explicitly synthetic full-baseline proof. TEST — NOT LIVE RESEARCH.

Does not overwrite input. Writes only to the requested new/empty output dir.
"""
import argparse
from datetime import date
import json
from pathlib import Path
import sys
import zipfile

import openpyxl

import pipeline

sys.path.insert(0,str(Path(__file__).resolve().parent/'tests'))
from test_pipeline import observations_for


def run(workbook, output_dir, run_date):
    baseline_hash = pipeline.sha256(workbook)
    manifest = pipeline.inspect_workbook(workbook,'TEST-structural-'+run_date,run_date)

    def produce(staging):
        extraction_dir = staging/'TEST_NOT_LIVE_extract'
        extraction_dir.mkdir()
        manifest_path=extraction_dir/'manifest.json'
        manifest_path.write_text(pipeline.json_text(manifest),encoding='utf-8')
        observations_path=staging/'TEST_NOT_LIVE_observations.json'
        observations_path.write_text(pipeline.json_text(observations_for(manifest)),encoding='utf-8')
        output=staging/'TEST_NOT_LIVE_build'
        audit=pipeline.build(workbook,manifest_path,observations_path,output,test_mode=True)
        updated=output/'TEST_NOT_LIVE_RentComps_refreshed.xlsx'
        changes=pipeline.load_json(output/'TEST_NOT_LIVE_changes.json')['changes']
        allowed={(c['sheetName'],c['cell']) for c in changes}
        original=openpyxl.load_workbook(workbook,data_only=False)
        refreshed=openpyxl.load_workbook(updated,data_only=False)
        untouched_cells=0
        styles_checked=0
        try:
            original_sheet_count=len(original.sheetnames)
            assert original.sheetnames==refreshed.sheetnames
            for ws in original:
                new=refreshed[ws.title]
                assert str(ws.merged_cells)==str(new.merged_cells),(ws.title,'merged ranges')
                assert (ws.max_row,ws.max_column)==(new.max_row,new.max_column),(ws.title,'dimensions')
                assert ws.freeze_panes==new.freeze_panes,(ws.title,'freeze panes')
                for key,dim in ws.column_dimensions.items():assert dict(dim)==dict(new.column_dimensions[key]),(ws.title,key,'column dimension')
                for key,dim in ws.row_dimensions.items():assert dict(dim)==dict(new.row_dimensions[key]),(ws.title,key,'row dimension')
                for row in ws:
                    for cell in row:
                        if isinstance(cell,openpyxl.cell.cell.MergedCell):continue
                        newcell=new[cell.coordinate]
                        assert cell._style==newcell._style,(ws.title,cell.coordinate,'style')
                        styles_checked+=1
                        if (ws.title,cell.coordinate) not in allowed:
                            assert cell.value==newcell.value,(ws.title,cell.coordinate,'unexpected mutation')
                            untouched_cells+=1
            for p in manifest['properties']:
                ws=refreshed[p['sheetName']]
                comp_rows=[c['row'] for c in p['comps']]
                for bed,col in p['headerMapping']['actualColumns'].items():
                    values=[ws.cell(row,col).value for row in comp_rows]
                    assert all(type(v) in (int,float) or v in ('Phone Verify','Not Offered') for v in values)
                    numeric=[v for v in values if type(v) in (int,float)]
                    expected=pipeline.average(numeric)
                    for row in p['benchmarkRows']:assert ws.cell(row,col).value==expected,(p['sheetName'],bed,'benchmark')
                    for coordinate in p['summaryCells'][bed]:assert ws[coordinate].value==expected,(p['sheetName'],bed,'summary')
        finally:
            original.close();refreshed.close()
        byte_identical_members=0
        with zipfile.ZipFile(workbook) as old,zipfile.ZipFile(updated) as new:
            assert old.namelist()==new.namelist()
            paths=pipeline.worksheet_paths(old)
            modified={paths[c['sheetName']] for c in changes}
            for name in old.namelist():
                if name not in modified:
                    assert old.read(name)==new.read(name),name
                    byte_identical_members+=1
        assert pipeline.sha256(workbook)==baseline_hash,'Source changed'
        assert not (output/'distributable_manifest.json').exists()
        result={'label':pipeline.TEST_LABEL,'runDate':run_date,'baselineSha256':baseline_hash,
                'sourceUnchanged':True,'propertyCount':manifest['propertyCount'],'totalOriginalSheetCount':original_sheet_count,
                'observedComparableCount':manifest['expectedObservationCount'],'rentCellCount':manifest['expectedRentCellCount'],
                'counts':audit['counts'],'stylesChecked':styles_checked,'untouchedCellsChecked':untouched_cells,
                'unmodifiedArchiveMembersByteIdentical':byte_identical_members,
                'benchmarkSummaryEqualityPassed':True,'distributableManifestBlocked':True,
                'warningCount':len(audit['reviewFlags']),'status':'STRUCTURAL PASS ONLY; NOT LIVE RESEARCH'}
        (staging/'TEST_NOT_LIVE_verification.json').write_text(pipeline.json_text(result),encoding='utf-8')
        return result
    return pipeline.atomic_publish(output_dir,produce)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workbook',required=True)
    parser.add_argument('--output-dir',required=True)
    parser.add_argument('--run-date',default=date.today().isoformat())
    args=parser.parse_args()
    print(pipeline.json_text(run(args.workbook,args.output_dir,args.run_date)))
