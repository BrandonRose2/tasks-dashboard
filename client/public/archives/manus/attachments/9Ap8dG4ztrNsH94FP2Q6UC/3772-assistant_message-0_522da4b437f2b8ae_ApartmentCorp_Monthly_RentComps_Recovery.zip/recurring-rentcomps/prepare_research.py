#!/usr/bin/env python3
"""Prepare declared research inputs; this script never researches or invents rents."""
from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

import openpyxl

import pipeline


def prepare(workbook: Path, output: Path, run_id: str, run_date: str):
    # One authoritative parser owns IDs, row identities, Actual bedrooms and URLs.
    # Inspect before creating files so invalid workbooks/runs fail without output.
    manifest = pipeline.inspect_workbook(workbook, run_id, run_date)
    properties = []
    inputs = []
    wb = openpyxl.load_workbook(workbook, data_only=False)
    try:
        for canonical in manifest["properties"]:
            subject = copy.deepcopy(canonical["subject"])
            subject["sheetName"] = canonical["sheetName"]
            comps = copy.deepcopy(canonical["comps"])
            # Distance is research context, not an identity or source field. Use
            # the canonical header mapping to preserve this legacy input field.
            distance_col = canonical["headerMapping"]["labels"].get("distance")
            ws = wb[canonical["sheetName"]]
            for comp in comps:
                comp["distance"] = pipeline.clean(ws.cell(comp["row"], distance_col).value) if distance_col else ""
            properties.append({"buildingId": canonical["buildingId"], "sheetName": canonical["sheetName"],
                               "subject": subject, "bedTypes": list(canonical["bedTypes"]), "comps": comps})
    finally:
        wb.close()

    output.mkdir(parents=True, exist_ok=True)
    for index, prop in enumerate(properties, start=1):
        path = output / f"property-{index:02d}.json"
        payload = {key: manifest[key] for key in ("runId", "runDate", "baselineSha256")}
        payload["property"] = prop
        path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        inputs.append({"index": index, "buildingId": prop["buildingId"], "path": str(path.resolve())})
    result = {
        "runId": manifest["runId"],
        "runDate": manifest["runDate"],
        "baselineSha256": manifest["baselineSha256"],
        "propertyCount": manifest["propertyCount"],
        "expectedObservationCount": manifest["expectedObservationCount"],
        "properties": properties,
        "inputs": inputs,
    }
    (output / "research-inputs.json").write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--workbook", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--run-date", required=True)
    args = parser.parse_args()
    result = prepare(args.workbook, args.output_dir, args.run_id, args.run_date)
    print(json.dumps({k: result[k] for k in ["runId", "runDate", "propertyCount", "expectedObservationCount", "baselineSha256"]}, indent=2))
