"""Offline deterministic tests. All pricing fixtures are TEST, NOT LIVE RESEARCH."""
import copy
from datetime import date, timedelta
import json
from pathlib import Path
import tempfile
import unittest
import zipfile
import xml.etree.ElementTree as ET

import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

import pipeline

BASELINE = Path('/home/ubuntu/RentComps_UPDATED_Aug2026.xlsx')
RUN_DATE = date.today().isoformat()


def create_fixture(path, count=1, merged_actual=False):
    wb = openpyxl.Workbook()
    wb.active.title = 'INDEX'
    wb['INDEX']['A1'] = 'Do not touch index'
    current = wb.create_sheet('Current Rents')
    current['E20'] = 1456
    for index in range(1, count + 1):
        ws = wb.create_sheet(f'{index} – Irregular Property')
        # Header labels at row 10, not fixed row 7. Actual column 16, not 13.
        for col, value in {1:'Rank', 2:'Type', 3:'Property Name', 5:'Address', 6:'City', 7:'St', 8:'ZIP',
                           13:'2BD\n50% AMI', 14:'2BD\n60% AMI', 15:'2BD\nFMR', 16:'2BD -\nActual',
                           18:'STUDIO ACTUAL', 20:'5BD - Actual', 22:'Notes / Why Competitive', 23:'Data Source'}.items():
            ws.cell(10, col, value)
        ws.merge_cells('C10:D10')
        for row, kind, name, address in [(11,'SUBJECT','Irregular Property (SUBJECT)','111 Subject Ave'),
                                       (12,'AFFORDABLE','Affordable Untouched','222 Affordable Ave'),
                                       (16,'MARKET RATE','Comp One','100 Alpha Dr'),
                                       (17,'MARKET RATE','Comp Two','200 Beta Dr'),
                                       (19,'BENCHMARK','Metro Market Avg — Somewhere (Refresh Aug 2026)','N/A'),
                                       (21,'BENCHMARK','Metro Market Avg — Somewhere (Apartments.com/Zillow, Aug 2026)','N/A'),
                                       (22,'BENCHMARK','HUD FY2026 FMR','N/A')]:
            for col, value in {1:str(row),2:kind,3:name,5:address,6:'Somewhere',7:'OH',8:'12345',13:600,14:700,15:800,16:1100,18:'Phone Verify',20:'Not Offered',22:'Old notes baseline',23:'https://old.invalid/property'}.items():
                ws.cell(row,col,value)
        ws['P11'] = "='Current Rents'!E20"
        ws['P12'] = 900
        ws.merge_cells('C19:D19')
        ws.merge_cells('C21:D21')
        ws.merge_cells('A8:W8')
        ws['A8'] = 'Data as of April 30, 2026 | Sources: Old baseline sources'
        ws.merge_cells('A9:W9')
        ws['A9'] = 'COLUMN GUIDE — Actual = Current advertised rent. Other columns remain baseline.'
        ws.merge_cells('A24:H24')
        ws['A24'] = 'Market Average = Avg of 6 comps (old claim)'
        for row, bed in [(26,'2BD'),(27,'STUDIO'),(28,'5BD')]:
            ws.cell(row,1,bed)
            ws.cell(row,2,"='Current Rents'!E20")
            ws.cell(row,3,1100)
            ws.cell(row,5,f'=B{row}-C{row}')
        ws['Z30'] = 'Unrelated baseline remains'
        ws['W16'].hyperlink = 'https://old.invalid/click-target'
        for row in ws:
            for cell in row:
                if not isinstance(cell,openpyxl.cell.cell.MergedCell):
                    cell.font = Font(name='Arial',size=11,bold=cell.row==10,color='123456')
                    cell.fill = PatternFill('solid',fgColor='FFEEDD')
                    cell.alignment = Alignment(wrap_text=True)
                    cell.border = Border(bottom=Side(style='thin',color='222222'))
                    cell.number_format = '$#,##0' if cell.column==16 else 'General'
        ws.column_dimensions['P'].width = 18.5
        ws.row_dimensions[16].height = 40.5
        ws.freeze_panes = 'J11'
        if merged_actual:
            ws.merge_cells('O16:P16')
    wb.save(path)
    wb.close()


def observations_for(manifest, statuses=('verified','phone_verify','not_offered'), synthetic=True):
    """Generate clearly synthetic prices, not a research observation artifact."""
    result = {key:manifest[key] for key in ('runId','runDate','baselineSha256')}
    if synthetic:
        result.update(label=pipeline.TEST_LABEL, testMode=True)
    result['properties'] = []
    for prop in manifest['properties']:
        comps = []
        for comp in prop['comps']:
            rents = []
            for index,bed in enumerate(prop['bedTypes']):
                status = statuses[index % len(statuses)]
                value = 2000 + comp['row'] * 10 + index if status=='verified' else None
                rents.append({'bedType':bed,'status':status,'amount':value,
                    'sourceUrl':f'https://example.invalid/TEST-NOT-LIVE/{prop["buildingId"]}/{comp["row"]}/{bed}' if status!='phone_verify' else '',
                    'evidence': f'TEST NOT LIVE RESEARCH: {bed} lowest advertised BASE monthly rent {value}, entire unit.' if status=='verified' else ('TEST NOT LIVE RESEARCH: property floor-plan list explicitly excludes this bedroom.' if status=='not_offered' else 'TEST NOT LIVE RESEARCH: attempted phone call, no answer; rent unconfirmed.'),
                    'checkedAt':manifest['runDate']})
            comps.append({'row':comp['row'],'propertyName':comp['propertyName'],'eligibility':'market_rate',
                'checkedAt':manifest['runDate'],'identityEvidence':f'TEST NOT LIVE RESEARCH: name and address fixture {comp["propertyName"]}, {comp["address"]}',
                'rents':rents,'notes':'TEST NOT LIVE RESEARCH: attempted phone verification preserved here.'})
        result['properties'].append({'buildingId':prop['buildingId'],'comps':comps})
    return result


class PipelineTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parents[1] / 'tests')
        self.root = Path(self.temp.name)
        self.workbook = self.root/'fixture.xlsx'
        create_fixture(self.workbook)
        self.manifest = pipeline.extract(self.workbook,self.root/'extract','fixture-test',RUN_DATE)
        self.manifest_path = self.root/'extract'/'manifest.json'
        self.observations = observations_for(self.manifest)
        self.observations_path = self.root/'TEST_NOT_LIVE_observations.json'
        self.original_hash = pipeline.sha256(self.workbook)

    def tearDown(self):
        self.temp.cleanup()

    def build(self, observations=None, test_mode=True, max_age_days=0):
        self.observations_path.write_text(pipeline.json_text(observations or self.observations))
        return pipeline.build(self.workbook,self.manifest_path,self.observations_path,self.root/'out',test_mode,max_age_days)

    def reject(self, observations):
        with self.assertRaises(pipeline.PipelineError):
            self.build(observations)
        self.assertEqual(pipeline.sha256(self.workbook),self.original_hash)
        self.assertFalse((self.root/'out').exists())

    def first_rent(self, observations):
        return observations['properties'][0]['comps'][0]['rents'][0]

    def test_irregular_header_and_direct_current_rents(self):
        p=self.manifest['properties'][0]
        self.assertEqual(p['headerMapping']['row'],10)
        self.assertEqual(p['headerMapping']['actualColumns']['2BD'],16)
        self.assertEqual(p['bedTypes'],['2BD','STUDIO','5BD'])
        self.assertEqual([c['row'] for c in p['comps']],[16,17])
        self.assertEqual(p['benchmarkRows'],[19,21])
        self.assertEqual(p['subject']['resolvedPreviousRents']['2BD'],1456)
        self.assertEqual(p['summaryContext'][0]['resolvedCurrentRent'],1456)
        self.assertEqual(p['comps'][0]['sourceUrls'],['https://old.invalid/property','https://old.invalid/click-target'])

    def test_merged_safe_write_explicit_anchor_only(self):
        wb=openpyxl.load_workbook(self.workbook)
        ws=wb.worksheets[2]
        with self.assertRaises(pipeline.PipelineError): pipeline.safe_cell(ws,'B8',True)
        with self.assertRaises(pipeline.PipelineError): pipeline.safe_cell(ws,'A8')
        self.assertEqual(pipeline.safe_cell(ws,'A8',True).coordinate,'A8')
        wb.close()

    def test_merged_actual_aborts_before_output(self):
        create_fixture(self.workbook,merged_actual=True)
        self.original_hash=pipeline.sha256(self.workbook)
        self.manifest=pipeline.inspect_workbook(self.workbook,'fixture-test',RUN_DATE)
        self.manifest_path.write_text(pipeline.json_text(self.manifest))
        self.reject(observations_for(self.manifest))

    def test_blank_invalid_nonpositive_and_nonfinite_verified_amounts(self):
        for value in (None,'',0,-3,True,'2200',float('inf'),float('nan')):
            with self.subTest(value=value):
                o=copy.deepcopy(self.observations); self.first_rent(o)['amount']=value
                with self.assertRaises((pipeline.PipelineError,ValueError)):
                    pipeline.validate_observations(self.manifest,o)
        self.assertEqual(pipeline.sha256(self.workbook),self.original_hash)

    def test_no_source_or_no_evidence_rejected_without_mutation(self):
        for field,value in [('sourceUrl',''),('sourceUrl','ftp://site.test'),('sourceUrl','https://user:secret@site.test'),('evidence',''),('status','')]:
            with self.subTest(field=field):
                o=copy.deepcopy(self.observations); self.first_rent(o)[field]=value; self.reject(o)

    def test_stale_and_future_checked_dates_fail_closed(self):
        for checked in ((date.fromisoformat(RUN_DATE)-timedelta(days=1)).isoformat(), (date.fromisoformat(RUN_DATE)+timedelta(days=1)).isoformat()):
            o=copy.deepcopy(self.observations); self.first_rent(o)['checkedAt']=checked; self.reject(o)

    def test_configurable_source_age_at_most_seven_days(self):
        o=copy.deepcopy(self.observations); self.first_rent(o)['checkedAt']=(date.fromisoformat(RUN_DATE)-timedelta(days=7)).isoformat()
        pipeline.validate_observations(self.manifest,o,7)
        with self.assertRaises(pipeline.PipelineError): pipeline.validate_observations(self.manifest,o,6)
        with self.assertRaises(pipeline.PipelineError): pipeline.validate_observations(self.manifest,o,8)

    def test_reject_missing_extra_duplicate_comp_and_property_ids(self):
        for mode in ('empty_properties','duplicate_property','extra_property','empty_comps','duplicate_comp','extra_comp'):
            o=copy.deepcopy(self.observations)
            if mode=='empty_properties':o['properties']=[]
            elif mode=='duplicate_property':o['properties'].append(copy.deepcopy(o['properties'][0]))
            elif mode=='extra_property':p=copy.deepcopy(o['properties'][0]);p['buildingId']='999';o['properties'].append(p)
            elif mode=='empty_comps':o['properties'][0]['comps']=[]
            elif mode=='duplicate_comp':o['properties'][0]['comps'].append(copy.deepcopy(o['properties'][0]['comps'][0]))
            elif mode=='extra_comp':c=copy.deepcopy(o['properties'][0]['comps'][0]);c['row']=100;o['properties'][0]['comps'].append(c)
            with self.subTest(mode=mode): self.reject(o)

    def test_reject_identity_bed_omissions_extras_duplicates(self):
        for mode in ('name','missing_bed','extra_bed','duplicate_bed'):
            o=copy.deepcopy(self.observations); comp=o['properties'][0]['comps'][0]
            if mode=='name':comp['propertyName']='Different property'
            elif mode=='missing_bed':comp['rents'].pop()
            elif mode=='extra_bed':r=copy.deepcopy(comp['rents'][0]);r['bedType']='3BD';comp['rents'].append(r)
            elif mode=='duplicate_bed':comp['rents'].append(copy.deepcopy(comp['rents'][0]))
            with self.subTest(mode=mode): self.reject(o)

    def test_reject_stale_numeric_carryforward_in_phone_verify(self):
        o=copy.deepcopy(self.observations); r=self.first_rent(o);r['status']='phone_verify';r['amount']=1100;r['sourceUrl']='';r['evidence']=''
        self.reject(o)

    def test_not_offered_requires_url_and_evidence(self):
        for field in ('sourceUrl','evidence'):
            o=copy.deepcopy(self.observations);o['properties'][0]['comps'][0]['rents'][2][field]='';self.reject(o)

    def test_unverified_ineligible_only_phone_verify_and_flag_replacement(self):
        for eligibility in ('unverified','ineligible'):
            o=copy.deepcopy(self.observations);o['properties'][0]['comps'][0]['eligibility']=eligibility;self.reject(o)
        o=observations_for(self.manifest,('phone_verify',));o['properties'][0]['comps'][0]['eligibility']='ineligible'
        result=self.build(o)
        self.assertTrue(result['properties'][0]['comps'][0]['needsReplacement'])
        self.assertEqual(result['counts']['phone_verify'],6)
        self.assertTrue(result['properties'][0]['warnings'])

    def test_no_estimates_concessions_or_per_bed_numeric_pricing(self):
        for evidence in ('Rent per-bed $999','Student pricing $999','Net effective monthly rent $999','Market estimate $999','Proxy rent $999','Price after concessions $999'):
            o=copy.deepcopy(self.observations);self.first_rent(o)['evidence']=evidence;self.reject(o)

    def test_explicit_pricing_exclusions_with_base_context_are_allowed(self):
        for exclusion in (
            'not per-bed or an estimated rent.',
            'not the deposit, per-bed pricing or an estimate.',
            'not per person, by the bed, student pricing or a proxy.',
            'not net effective rent or after concessions.',
            'not net-effective rent or after concessions.',
            'The Studio Loft was not used as a lower-priced proxy.',
            'Official estimated total $940/mo is excluded.',
            'Official estimated total $1,390/mo and the $500 deposit are excluded.',
            'Official estimated total $915/mo and deposits are excluded.',
            "Estimated total monthly price '$1,280/mo' is separately displayed and excluded.",
            "It separately lists estimated total monthly price '$1,250/mo', which is not the base rent.",
            'The lower floorplan-level estimated range endpoint was not used as an actual unit quote.',
        ):
            with self.subTest(exclusion=exclusion):
                o=copy.deepcopy(self.observations)
                self.first_rent(o)['evidence']='Lowest advertised BASE monthly rent $2160 for the entire unit; ' + exclusion
                before=copy.deepcopy(o)
                pipeline.validate_observations(self.manifest,o)
                self.assertEqual(o,before,'validation must not rewrite evidence or observations')

    def test_actual_forbidden_pricing_and_mixed_claims_still_rejected(self):
        actual_claims=(
            'Rent per-bed $999', 'Rent per bed $999', 'Rent per person $999',
            'Lease by the bed $999', 'Student pricing $999',
            'Net effective monthly rent $999', 'Net-effective rent $999',
            'Price after concessions $999', 'Estimated rent $999',
            'Rent estimates $999', 'Proxy rent $999', 'Bedroom proxies $999',
            'Estimated price does not include non-optional fees.',
            'Estimated total $999/mo is displayed.',
        )
        safe='Lowest advertised BASE monthly rent $2160 for the entire unit; not per-bed or an estimate.'
        for claim in actual_claims:
            for evidence in (claim, safe + ' ' + claim, claim + '. ' + safe):
                with self.subTest(evidence=evidence):
                    o=copy.deepcopy(self.observations);self.first_rent(o)['evidence']=evidence
                    self.reject(o)

    def test_ambiguous_or_unrelated_negation_fails_closed(self):
        for evidence in (
            'Not per-bed or an estimate.',  # No affirmative base/whole-unit context.
            'This is not base rent; not per-bed or an estimate.',
            'Base rent $2160; not only per-bed pricing.',
            'Base rent $2160; not necessarily per-bed pricing.',
            'Base rent $2160; may be not per-bed.',
            'Base rent $2160; unclear whether it is not per-bed.',
            'Base rent $2160; not not per-bed.',
            'Base rent $2160; not per-bed?',
            'Base rent $2160; not per-bed for this particular unit.',
            'Base rent $2160; not per-bed but an estimate.',
            'Base rent $2160; not a deposit, per-bed pricing $999.',
            'Base rent $2160; not per-bed or an estimate of other units.',
            'Base rent $2160; the proxy was not used as the price.',
            'Base rent $2160; the Studio Loft may have been omitted and was not used as a lower-priced proxy.',
            'Base rent $2160; estimated total $940/mo is excluded only from fees.',
            'Base rent $2160; estimated total $940/mo may be excluded.',
            'Base rent $2160; estimated total $940/mo is not excluded.',
            'Base rent $2160; estimated total $940/mo is excluded?',
            'Base rent $2160; estimated total $940/mo is excluded but a proxy is used.',
        ):
            with self.subTest(evidence=evidence):
                o=copy.deepcopy(self.observations);self.first_rent(o)['evidence']=evidence
                self.reject(o)

    @unittest.skipUnless((Path(__file__).resolve().parents[1]/'reports/2026-11-04/observations.canonical.json').exists(),
                         'canonical research artifact is not available')
    def test_exact_canonical_evidence_exclusion_regressions(self):
        path=Path(__file__).resolve().parents[1]/'reports/2026-11-04/observations.canonical.json'
        original_hash=pipeline.sha256(path)
        data=pipeline.load_json(path)
        cases={
            ('48',24,'2BD'): 'This is a full two-bedroom apartment price, not per-bed or an estimated rent.',
            ('55',16,'1BD'): 'The Studio Loft has no advertised price on the live catalog and was not used as a lower-priced proxy.',
            ('24',16,'3BD'): '$2,195 is the advertised whole-unit monthly rent, not the deposit, per-bed pricing or an estimate.',
        }
        rents={(p['buildingId'],c['row'],r['bedType']):r for p in data['properties'] for c in p['comps'] for r in c['rents']}
        for key,exclusion in cases.items():
            with self.subTest(identity=key):
                evidence=rents[key]['evidence']
                self.assertIn(exclusion,evidence)
                # Exercise the exact text through validation on a synthetic
                # envelope, without changing any real observation or evidence.
                o=copy.deepcopy(self.observations);self.first_rent(o)['evidence']=evidence
                before=copy.deepcopy(o)
                pipeline.validate_observations(self.manifest,o)
                self.assertEqual(o,before)
        for prop in data['properties']:
            for comp in prop['comps']:
                for rent in comp['rents']:
                    key=(prop['buildingId'],comp['row'],rent['bedType'])
                    if rent['status']=='verified' and (key[:2] in {('37',14),('37',15),('33',15),('6',12)}):
                        with self.subTest(excluded_estimate=key):
                            self.assertFalse(pipeline.prohibited_pricing_evidence(rent['evidence']))
        for key in (('63',11,'2BD'),('63',11,'3BD')):
            with self.subTest(actual_estimated_price=key):
                self.assertTrue(pipeline.prohibited_pricing_evidence(rents[key]['evidence']))
        self.assertEqual(pipeline.sha256(path),original_hash)

    def test_envelope_hash_and_manifest_tampering(self):
        for field in ('runId','runDate','baselineSha256'):
            o=copy.deepcopy(self.observations);o[field]='wrong';self.reject(o)
        changed=copy.deepcopy(self.manifest);changed['properties'][0]['comps'][0]['address']='Wrong address'
        self.manifest_path.write_text(pipeline.json_text(changed));self.reject(self.observations)

    def test_changed_source_hash_rejected(self):
        with open(self.workbook,'ab') as f:f.write(b'changed')
        self.original_hash=pipeline.sha256(self.workbook)
        self.reject(self.observations)

    def test_zero_numeric_observations_not_distributable(self):
        o=observations_for(self.manifest,('phone_verify',),synthetic=False)
        for p in o['properties']:
            for c in p['comps']:
                c['identityEvidence']='Could not establish identity; no source obtained'
                c['notes']='Attempted phone verification: no answer'
                for r in c['rents']:r['evidence']='Attempted phone verification: no answer'
        result=self.build(o,test_mode=False)
        self.assertFalse(result['successful']);self.assertFalse(result['distributable'])
        self.assertEqual(result['counts'],{'verified':0,'phone_verify':6,'not_offered':0})
        self.assertFalse((self.root/'out'/'distributable_manifest.json').exists())
        self.assertIn('UNSUCCESSFUL',result['label'])
        self.assertTrue((self.root/'out'/'UNSUCCESSFUL_NOT_DISTRIBUTABLE_RentComps.xlsx').exists())
        payload=pipeline.load_json(self.root/'out'/'email_payload.json')
        self.assertFalse(payload['sendAllowed']);self.assertFalse(payload['distributionEligibleAfterReview'])

    def test_styles_subject_affordable_formulas_sizes_merged_ranges_preserved(self):
        self.build()
        old=openpyxl.load_workbook(self.workbook,data_only=False)
        new=openpyxl.load_workbook(self.root/'out'/'TEST_NOT_LIVE_RentComps_refreshed.xlsx',data_only=False)
        changes=pipeline.load_json(self.root/'out'/'TEST_NOT_LIVE_changes.json')['changes']
        allowed={(c['sheetName'],c['cell']) for c in changes}
        self.assertEqual(old.sheetnames,new.sheetnames)
        for original in old:
            revised=new[original.title]
            self.assertEqual(str(original.merged_cells),str(revised.merged_cells))
            self.assertEqual(original.max_row,revised.max_row)
            self.assertEqual(original.max_column,revised.max_column)
            self.assertEqual(original.freeze_panes,revised.freeze_panes)
            for key,dim in original.column_dimensions.items(): self.assertEqual(dict(dim),dict(revised.column_dimensions[key]))
            for key,dim in original.row_dimensions.items(): self.assertEqual(dict(dim),dict(revised.row_dimensions[key]))
            for row in original:
                for cell in row:
                    if isinstance(cell,openpyxl.cell.cell.MergedCell):continue
                    updated=revised[cell.coordinate]
                    self.assertEqual(cell._style,updated._style,(original.title,cell.coordinate))
                    if (original.title,cell.coordinate) not in allowed:
                        self.assertEqual(cell.value,updated.value,(original.title,cell.coordinate))
        self.assertEqual(new.worksheets[2]['P11'].value,"='Current Rents'!E20")
        self.assertEqual(new.worksheets[2]['P12'].value,900)
        old.close();new.close()
        self.assertEqual(pipeline.sha256(self.workbook),self.original_hash)
        with zipfile.ZipFile(self.workbook) as before,zipfile.ZipFile(self.root/'out'/'TEST_NOT_LIVE_RentComps_refreshed.xlsx') as after:
            self.assertEqual(before.namelist(),after.namelist())
            paths=pipeline.worksheet_paths(before)
            for entry in before.namelist():
                if entry != paths[self.manifest['properties'][0]['sheetName']]: self.assertEqual(before.read(entry),after.read(entry),entry)

    def test_benchmarks_summary_equal_explicit_statuses_and_phone_attempts(self):
        result=self.build()
        ws=openpyxl.load_workbook(self.root/'out'/'TEST_NOT_LIVE_RentComps_refreshed.xlsx').worksheets[2]
        self.assertEqual(result['properties'][0]['marketAvg'],{'2BD':2165,'STUDIO':'Phone Verify','5BD':'Phone Verify'})
        for row in (19,21):
            for col in (13,14,15,16):self.assertEqual(ws.cell(row,col).value,2165)
            self.assertEqual(ws.cell(row,18).value,'Phone Verify')
        self.assertEqual(ws['C26'].value,2165);self.assertEqual(ws['C27'].value,'Phone Verify');self.assertEqual(ws['C28'].value,'Phone Verify')
        self.assertEqual(ws['R16'].value,'Phone Verify');self.assertEqual(ws['T16'].value,'Not Offered')
        self.assertIn('attempted phone',ws['V16'].value)
        self.assertIn(RUN_DATE,ws['A8'].value)
        self.assertIsNone(ws['W16'].hyperlink)
        self.assertIn('TEST',ws['A8'].value)
        self.assertIn('April 30, 2026',result['properties'][0]['baselineDisclosures'][0]['previous'])
        self.assertFalse(result['distributable']);self.assertFalse(result['successful'])
        for f in (self.root/'out').iterdir():self.assertIn('TEST_NOT_LIVE',f.name)
        payload=pipeline.load_json(self.root/'out'/'TEST_NOT_LIVE_email_payload.json')
        self.assertEqual(payload['to'],['ethan@apartmentcorp.com'])
        self.assertEqual(payload['from'],'apartmentcorp44@gmail.com')
        self.assertFalse(payload['send'])

    def test_synthetic_observations_cannot_enter_production(self):
        with self.assertRaises(pipeline.PipelineError): self.build(test_mode=False)
        self.assertFalse((self.root/'out').exists())
        self.assertEqual(pipeline.sha256(self.workbook),self.original_hash)

    def test_success_gate_and_fixed_production_email_payload(self):
        # A unit fixture simulates the production path, never live research.
        o=observations_for(self.manifest,synthetic=False)
        for p in o['properties']:
            for c in p['comps']:
                c['identityEvidence']='Fixture matched property name and address'
                c['notes']='Phone attempt recorded where unavailable'
                for r in c['rents']:
                    if r['sourceUrl']:r['sourceUrl']='https://leasing-fixture.localhost/floorplans'
                    r['evidence']={'verified':'Lowest advertised BASE monthly entire-unit rent $2160', 'phone_verify':'Called leasing office; no answer', 'not_offered':'Complete product mix explicitly excludes this bedroom'}[r['status']]
        result=self.build(o,test_mode=False)
        self.assertTrue(result['successful']);self.assertTrue(result['distributable'])
        self.assertTrue((self.root/'out'/'distributable_manifest.json').exists())
        payload=pipeline.load_json(self.root/'out'/'email_payload.json')
        self.assertEqual(payload['to'],['Ethan@apartmentcorp.com','mam@22.bz'])
        self.assertFalse(payload['send']);self.assertFalse(payload['sendAllowed'])
        self.assertIn('Not all rents are verified',payload['bodyText'])

    def test_duplicate_address_and_urls_flagged_for_review(self):
        p=copy.deepcopy(self.manifest['properties'][0]);p['comps'][1]['address']=p['comps'][0]['address']
        self.assertTrue(any(f['kind']=='address' for f in pipeline.duplicate_flags(p)))
        p['comps'][0]['address']=p['subject']['address']
        self.assertTrue(any(f['kind']=='subject_address_match' for f in pipeline.duplicate_flags(p)))
        o=copy.deepcopy(self.observations)
        for r in o['properties'][0]['comps'][1]['rents']:
            if r['sourceUrl']:r['sourceUrl']=o['properties'][0]['comps'][0]['rents'][0]['sourceUrl']
        result=self.build(o)
        self.assertTrue(result['properties'][0]['currentDuplicateFlags'])

    def test_atomic_output_rejects_nonempty_directory(self):
        (self.root/'out').mkdir();(self.root/'out'/'sentinel').write_text('do not overwrite')
        with self.assertRaises(pipeline.PipelineError):self.build()
        self.assertEqual((self.root/'out'/'sentinel').read_text(),'do not overwrite')
        self.assertEqual(len(list((self.root/'out').iterdir())),1)

    def test_atomic_mid_write_failure_publishes_nothing(self):
        def bad_producer(staging):
            (staging/'partial').write_text('not published')
            raise pipeline.PipelineError('simulated failure')
        with self.assertRaises(pipeline.PipelineError):pipeline.atomic_publish(self.root/'out',bad_producer)
        self.assertFalse((self.root/'out').exists())
        self.assertFalse(list(self.root.glob('.rentcomps-stage-*')))

    def test_duplicate_json_keys_are_rejected(self):
        p=self.root/'duplicate.json';p.write_text('{"runId":"a","runId":"b"}')
        with self.assertRaises(pipeline.PipelineError):pipeline.load_json(p)

    def test_full_41_synthetic_extraction_and_build(self):
        path=self.root/'fortyone.xlsx';create_fixture(path,count=41)
        manifest=pipeline.extract(path,self.root/'extract41','TEST-41',RUN_DATE)
        self.assertEqual(manifest['propertyCount'],41)
        self.assertEqual(manifest['expectedObservationCount'],82)
        self.assertEqual(manifest['expectedRentCellCount'],246)
        o=self.root/'TEST41_observations.json';o.write_text(pipeline.json_text(observations_for(manifest)))
        result=pipeline.build(path,self.root/'extract41'/'manifest.json',o,self.root/'out41',True)
        self.assertEqual(result['propertyCount'],41)
        self.assertEqual(result['observedComparableCount'],82)
        self.assertEqual(sum(result['counts'].values()),246)

    @unittest.skipUnless(BASELINE.exists(),'Actual baseline not available')
    def test_actual_baseline_all41_dynamic_inventory(self):
        result=pipeline.inspect_workbook(BASELINE,'actual-extraction-test',RUN_DATE)
        self.assertEqual(result['propertyCount'],41)
        self.assertEqual(result['expectedObservationCount'],190)
        self.assertEqual(result['expectedRentCellCount'],499)
        river=next(p for p in result['properties'] if p['buildingId']=='29')
        self.assertEqual(river['bedTypes'],['2BD'])
        self.assertEqual(river['headerMapping']['actualColumns']['2BD'],16)
        urban=next(p for p in result['properties'] if p['buildingId']=='31')
        self.assertEqual(urban['bedTypes'],['2BD'])
        boca=next(p for p in result['properties'] if p['buildingId']=='21')
        self.assertEqual(boca['benchmarkRows'],[19])
        self.assertEqual(boca['summaryCells'],{'2BD':['C26'],'3BD':['C27']})
        for p in result['properties']:
            self.assertTrue(p['comps'])
            for c in p['comps']:self.assertIn('previousRents',c)


if __name__=='__main__':
    unittest.main()
