#!/usr/bin/env python3
"""Normalize exact sheet-name aliases only; never supply or alter rent evidence."""
import argparse
import copy
import json
from pathlib import Path


def integrate(manifest, result):
    if result.get('failures'):
        raise ValueError('Research workflow has failures; recover them before building')
    for key in ('runId', 'runDate', 'baselineSha256'):
        if result.get(key) != manifest.get(key):
            raise ValueError(f'Envelope mismatch: {key}')
    output = copy.deepcopy(result)
    aliases = {}
    for prop in manifest['properties']:
        for alias in (prop['buildingId'], prop['sheetName']):
            if alias in aliases and aliases[alias] != prop['buildingId']:
                raise ValueError(f'Ambiguous alias {alias}')
            aliases[alias] = prop['buildingId']
    for prop in output['properties']:
        original = prop['buildingId']
        if original not in aliases:
            raise ValueError(f'Unknown property identity: {original}')
        prop['buildingId'] = aliases[original]
    expected = {p['buildingId']: p for p in manifest['properties']}
    ids = [p['buildingId'] for p in output['properties']]
    if len(ids) != len(set(ids)) or set(ids) != set(expected):
        raise ValueError('Missing, extra or duplicate property IDs')
    gaps = []
    for prop in output['properties']:
        ref = expected[prop['buildingId']]
        rows = {c['row']: c for c in ref['comps']}
        seen = []
        for comp in prop['comps']:
            seen.append(comp['row'])
            if comp['row'] not in rows:
                gaps.append({'buildingId': prop['buildingId'], 'row': comp['row'], 'error': 'extra row'})
                continue
            if comp['propertyName'] != rows[comp['row']]['propertyName']:
                gaps.append({'buildingId': prop['buildingId'], 'row': comp['row'], 'error': 'name mismatch'})
            beds = [r['bedType'] for r in comp['rents']]
            if len(beds) != len(set(beds)) or set(beds) != set(ref['bedTypes']):
                gaps.append({'buildingId': prop['buildingId'], 'row': comp['row'], 'error': 'bedroom coverage mismatch', 'expected': ref['bedTypes'], 'actual': beds})
        for row in sorted(set(rows) - set(seen)):
            gaps.append({'buildingId': prop['buildingId'], 'row': row, 'propertyName': rows[row]['propertyName'], 'error': 'missing row'})
        if len(seen) != len(set(seen)):
            gaps.append({'buildingId': prop['buildingId'], 'error': 'duplicate row'})
    return output, gaps

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--manifest', type=Path, required=True)
    p.add_argument('--results', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    normalized, gaps = integrate(json.loads(args.manifest.read_text()), json.loads(args.results.read_text()))
    args.output.write_text(json.dumps(normalized, indent=2, ensure_ascii=False) + '\n')
    gap_path = args.output.with_suffix('.gaps.json')
    gap_path.write_text(json.dumps(gaps, indent=2, ensure_ascii=False) + '\n')
    print(json.dumps({'properties': len(normalized['properties']), 'gaps': gaps}, indent=2))
    raise SystemExit(1 if gaps else 0)
