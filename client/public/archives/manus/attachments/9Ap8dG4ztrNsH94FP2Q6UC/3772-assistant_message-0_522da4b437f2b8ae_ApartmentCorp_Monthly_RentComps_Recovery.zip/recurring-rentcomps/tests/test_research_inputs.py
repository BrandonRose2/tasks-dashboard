import copy
from datetime import date
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

import openpyxl

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import pipeline
from prepare_research import prepare
from make_workflow import generate
from test_pipeline import create_fixture

BASELINE = Path('/home/ubuntu/RentComps_UPDATED_Aug2026.xlsx')
RUN_DATE = date.today().isoformat()


class ResearchInputTests(unittest.TestCase):
    def assert_manifest_alignment(self, data, canonical, output):
        self.assertEqual(set(data), {'runId', 'runDate', 'baselineSha256', 'propertyCount',
                                     'expectedObservationCount', 'properties', 'inputs'})
        for key in ('runId', 'runDate', 'baselineSha256', 'propertyCount', 'expectedObservationCount'):
            self.assertEqual(data[key], canonical[key])
        self.assertEqual(len(data['properties']), len(canonical['properties']))
        self.assertEqual(len(data['inputs']), len(canonical['properties']))
        for index, (prop, expected, item) in enumerate(zip(data['properties'], canonical['properties'], data['inputs']), 1):
            self.assertEqual(prop['buildingId'], expected['buildingId'])
            self.assertEqual(prop['sheetName'], expected['sheetName'])
            self.assertEqual(prop['subject']['sheetName'], expected['sheetName'])
            subject = {k: v for k, v in prop['subject'].items() if k != 'sheetName'}
            self.assertEqual(subject, expected['subject'])
            self.assertEqual(prop['bedTypes'], expected['bedTypes'])
            comps = [{k: v for k, v in comp.items() if k != 'distance'} for comp in prop['comps']]
            # Exact equality includes ordered rows, identities, source text/URLs,
            # notes and previous rents, not just counts or selected fields.
            self.assertEqual(comps, expected['comps'])
            self.assertTrue(all('distance' in comp for comp in prop['comps']))
            path = output / f'property-{index:02d}.json'
            self.assertEqual(item, {'index': index, 'buildingId': expected['buildingId'], 'path': str(path.resolve())})
            payload = {key: canonical[key] for key in ('runId', 'runDate', 'baselineSha256')}
            payload['property'] = prop
            self.assertEqual(json.loads(path.read_text()), payload)
        self.assertEqual(json.loads((output / 'research-inputs.json').read_text()), data)

    @unittest.skipUnless(BASELINE.exists(), 'approved baseline is not available in this environment')
    def test_complete_header_driven_property_manifest(self):
        with tempfile.TemporaryDirectory(dir=ROOT / 'tests') as tmp:
            output = Path(tmp)
            data = prepare(BASELINE, output, 'test-manifest', RUN_DATE)
            self.assertEqual(data['propertyCount'], 41)
            self.assertEqual(data['expectedObservationCount'], 190)
            self.assertEqual(data['baselineSha256'], hashlib.sha256(BASELINE.read_bytes()).hexdigest())
            self.assertEqual(len(data['inputs']), 41)
            for prop in data['properties']:
                self.assertTrue(prop['bedTypes'])
                self.assertTrue(prop['comps'])
                for comp in prop['comps']:
                    self.assertTrue(comp['propertyName'])
                    self.assertEqual(set(comp['previousRents']), set(prop['bedTypes']))
            river = next(p for p in data['properties'] if p['buildingId'] == '29')
            self.assertEqual(river['sheetName'], '29 - River Pointe')
            self.assertEqual(river['bedTypes'], ['2BD'])
            self.assertNotIn('COLOR KEY', json.dumps(data))
            for item in data['inputs']:
                declared = json.loads(Path(item['path']).read_text())
                self.assertEqual(declared['property']['buildingId'], item['buildingId'])
                self.assertEqual(declared['baselineSha256'], data['baselineSha256'])

    @unittest.skipUnless(BASELINE.exists(), 'approved baseline is not available in this environment')
    def test_exact_actual_canonical_manifest_alignment(self):
        with tempfile.TemporaryDirectory(dir=ROOT / 'tests') as tmp:
            output = Path(tmp)
            canonical = pipeline.inspect_workbook(BASELINE, 'exact-canonical', RUN_DATE)
            data = prepare(BASELINE, output, 'exact-canonical', RUN_DATE)
            self.assert_manifest_alignment(data, canonical, output)

    def test_exact_irregular_canonical_alignment_and_metadata(self):
        with tempfile.TemporaryDirectory(dir=ROOT / 'tests') as tmp:
            root = Path(tmp)
            workbook = root / 'irregular.xlsx'
            create_fixture(workbook, count=2)
            wb = openpyxl.load_workbook(workbook)
            ws = wb.worksheets[2]
            ws.title = '001 – Irregular Property'
            for coordinate, value in {'G10': 'State', 'H10': 'ZIP Code', 'I10': 'Distance',
                                      'V10': 'Notes and research context', 'W10': 'Source',
                                      'I16': '0.75 miles',
                                      'V16': 'Original provenance https://notes.invalid/keep-in-notes',
                                      'W16': 'listing.com/property; https://other.invalid/plan'}.items():
                ws[coordinate] = value
            wb.save(workbook)
            wb.close()
            canonical = pipeline.inspect_workbook(workbook, 'irregular', RUN_DATE)
            protected = copy.deepcopy(canonical)
            output = root / 'inputs'
            with patch('prepare_research.pipeline.inspect_workbook', return_value=canonical) as inspect:
                data = prepare(workbook, output, 'irregular', RUN_DATE)
            inspect.assert_called_once_with(workbook, 'irregular', RUN_DATE)
            self.assertEqual(canonical, protected, 'prepare must not mutate the canonical manifest')
            self.assert_manifest_alignment(data, canonical, output)
            prop = data['properties'][0]
            self.assertEqual(prop['buildingId'], '001')
            self.assertEqual(prop['bedTypes'], ['2BD', 'STUDIO', '5BD'])
            self.assertEqual(prop['subject']['row'], 11)
            self.assertEqual(prop['subject']['resolvedPreviousRents']['2BD'], 1456)
            self.assertEqual(prop['comps'][0]['distance'], '0.75 miles')
            self.assertEqual(prop['comps'][0]['sourceUrls'], [
                'https://listing.com/property', 'https://other.invalid/plan', 'https://old.invalid/click-target'])
            self.assertIn('https://notes.invalid/keep-in-notes', prop['comps'][0]['notes'])

    def test_canonical_duplicate_id_guard_fails_before_writing(self):
        with tempfile.TemporaryDirectory(dir=ROOT / 'tests') as tmp:
            root = Path(tmp)
            workbook = root / 'duplicate.xlsx'
            create_fixture(workbook, count=2)
            wb = openpyxl.load_workbook(workbook)
            wb.worksheets[3].title = '1 - Duplicate ID'
            wb.save(workbook)
            wb.close()
            output = root / 'inputs'
            with self.assertRaisesRegex(pipeline.PipelineError, 'Duplicate buildingId 1'):
                prepare(workbook, output, 'duplicate-id', RUN_DATE)
            self.assertFalse(output.exists())

    @unittest.skipUnless(BASELINE.exists(), 'approved baseline is not available in this environment')
    def test_deterministic_workflow_declares_each_input(self):
        with tempfile.TemporaryDirectory(dir=ROOT / 'tests') as tmp:
            output = Path(tmp)
            data = prepare(BASELINE, output, 'test-workflow', RUN_DATE)
            target = output / 'workflow.js'
            count = generate(output / 'research-inputs.json', ROOT / 'research_prompt.txt', target)
            self.assertEqual(count, 41)
            text = target.read_text()
            self.assertIn("parallel('Fresh comparable rents by property'", text)
            self.assertIn("sandbox: 'isolated'", text)
            self.assertIn('input_files:', text)
            self.assertNotIn('Date.now', text)
            self.assertNotIn('Math.random', text)
            params = json.loads(target.with_suffix('.params.json').read_text())
            self.assertEqual(params['estimated_agent_calls'], 41)
            self.assertEqual(params['failure_policy'], 'collect')
            self.assertIn(json.dumps(data['inputs'], ensure_ascii=False), text)

    def test_invalid_run_date_is_rejected(self):
        with tempfile.TemporaryDirectory(dir=ROOT / 'tests') as tmp:
            with self.assertRaises(ValueError):
                prepare(BASELINE, Path(tmp), 'bad-date', 'not-a-date')


if __name__ == '__main__':
    unittest.main()
