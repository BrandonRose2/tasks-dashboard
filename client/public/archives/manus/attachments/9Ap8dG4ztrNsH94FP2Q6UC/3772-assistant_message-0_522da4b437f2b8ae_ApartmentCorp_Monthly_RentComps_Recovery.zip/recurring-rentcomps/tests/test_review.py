import copy
import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from apply_review import apply_review

class ReviewTests(unittest.TestCase):
    def setUp(self):
        self.obs={'properties':[{'buildingId':'24','comps':[{'row':16,'eligibility':'market_rate','notes':'Individual duplex','rents':[{'status':'verified','amount':2195,'evidence':'Quoted price','sourceUrl':'https://site.org/unit'}]}]}]}
        self.dec=[{'buildingId':'24','row':16,'eligibility':'unverified','reason':'Non-community supplement'}]
    def test_exclusion_preserves_original_and_input(self):
        original=copy.deepcopy(self.obs)
        out,log=apply_review(self.obs,self.dec)
        self.assertEqual(self.obs,original)
        self.assertEqual(log[0]['originalObservation'],original['properties'][0]['comps'][0])
        rent=out['properties'][0]['comps'][0]['rents'][0]
        self.assertEqual((rent['status'],rent['amount']),('phone_verify',None))
        self.assertEqual(rent['sourceUrl'],'https://site.org/unit')
    def test_cannot_promote_eligibility(self):
        self.dec[0]['eligibility']='market_rate'
        with self.assertRaises(ValueError):apply_review(self.obs,self.dec)
    def test_reason_required(self):
        self.dec[0]['reason']=''
        with self.assertRaises(ValueError):apply_review(self.obs,self.dec)
    def test_unknown_or_duplicate_rejected(self):
        with self.assertRaises(ValueError):apply_review(self.obs,self.dec*2)
        self.dec[0]['row']=99
        with self.assertRaises(ValueError):apply_review(self.obs,self.dec)

    def test_cell_exclusion_preserves_eligibility_and_other_prices(self):
        comp=self.obs['properties'][0]['comps'][0]
        comp['rents'][0]['bedType']='2BD'
        comp['rents'].append({'bedType':'3BD','status':'verified','amount':2025,'evidence':'Base rent','sourceUrl':'https://site.org/other'})
        decision={'buildingId':'24','row':16,'bedType':'2BD','status':'phone_verify','reason':'Estimated price'}
        out,log=apply_review(self.obs,[decision])
        new=out['properties'][0]['comps'][0]
        self.assertEqual(new['eligibility'],'market_rate')
        self.assertEqual(new['rents'][0]['amount'],None)
        self.assertEqual(new['rents'][1],comp['rents'][1])
        self.assertEqual(log[0]['originalObservation'],comp)

    def test_cell_price_promotion_is_rejected(self):
        self.obs['properties'][0]['comps'][0]['rents'][0]['bedType']='2BD'
        with self.assertRaises(ValueError):apply_review(self.obs,[{'buildingId':'24','row':16,'bedType':'2BD','status':'verified','reason':'Unsupported promotion'}])

    def test_unknown_cell_is_rejected(self):
        with self.assertRaises(ValueError):apply_review(self.obs,[{'buildingId':'24','row':16,'bedType':'5BD','status':'phone_verify','reason':'Missing bedroom'}])

if __name__=='__main__':unittest.main()
