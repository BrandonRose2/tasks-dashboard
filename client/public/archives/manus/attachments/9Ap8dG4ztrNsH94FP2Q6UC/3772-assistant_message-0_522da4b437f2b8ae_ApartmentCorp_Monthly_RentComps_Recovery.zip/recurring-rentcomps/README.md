# ApartmentCorp monthly fresh rent-comps pipeline

This package replaces the obsolete local `find_comps_v2.py` / `build_excel.py` / `clickup_sync.py` chain. The previous chain referenced a different 42-property HUD/ClickUp report. This repair uses the approved formatted 41-property comparable-rent workbook and a source-verifiable monthly soft refresh.

The package separates public-source research from deterministic workbook updates. Research is performed by a task with search/browser access; the Python scripts never fabricate rents or treat baseline prices as live source evidence. Header-driven extraction accommodates the irregular workbook layouts, including River Pointe. Successful report generation requires observations for every expected comparable row and bedroom type, with valid evidence for numeric prices.

## Sender, recipients and schedule

The required sender is `apartmentcorp44@gmail.com`. The normal report recipients are `ethan@apartmentcorp.com` and `mam@22.bz`. The user's completed-report test goes only to `ethan@apartmentcorp.com`.

The existing schedule is active for the 10th of each month at 8:00 AM in `America/Los_Angeles`. This session was blocked from saving the schedule's account binding with the error `Collaboration sessions are not allowed to modify schedule via manus-config schedule`. Repairing these files does not override that restriction. The owner must replace the schedule's obsolete instructions with `MONTHLY_RUN_PLAYBOOK.md` and save the correct Gmail account using an authorized schedule-editing interface. If the platform continues to reject that edit, the scheduling-permission issue must be resolved before recurring activation can be claimed.

The existing schedule reports `runMode: ask_user`, and the Gmail send connector can require a Send confirmation. Workflow-budget approval may also be required for a 41-property source-research pass. Those approval gates are separate from this package's tests; do not describe the report as fully unattended until the account owner has confirmed the permitted execution and delivery settings.

## Files and commands

`pipeline.py` owns header-driven workbook extraction, evidence/coverage validation, workbook updates, benchmark/summary reconciliation, and report artifacts. `prepare_research.py` creates one declared JSON research input per subject property. `make_workflow.py` creates a deterministic research orchestration payload using `research_prompt.txt`. The input workbook must be the latest approved source, not a generated API-format export or unapproved draft.

Install `requirements.txt`, then run:

```bash
python3 -m pip install -r requirements.txt
python3 -m unittest discover -s tests -v
```

For a real run, derive the current run date in `America/Los_Angeles`. The November date in the repair's demonstration outputs is not a future scheduled-run setting.

```bash
RUN_DATE=$(python3 -c 'from datetime import datetime; from zoneinfo import ZoneInfo; print(datetime.now(ZoneInfo("America/Los_Angeles")).date())')
RUN_ID="monthly-$RUN_DATE"
BASELINE="/path/to/latest-approved-workbook.xlsx"
RUN_DIR="reports/$RUN_DATE"

python3 pipeline.py extract --workbook "$BASELINE" --output-dir "$RUN_DIR" --run-id "$RUN_ID" --run-date "$RUN_DATE"
python3 prepare_research.py --workbook "$BASELINE" --output-dir "$RUN_DIR/inputs" --run-id "$RUN_ID" --run-date "$RUN_DATE"
python3 make_workflow.py --inputs "$RUN_DIR/inputs/research-inputs.json" --output "$RUN_DIR/workflow.js"
```

The parent task must run the generated workflow with the declared property inputs and any required approval, then save the structured result as `observations.json`. A workflow is not executed simply by generating its JavaScript file. The Python pipeline is not a stand-alone web scraper and does not invoke task tools from a shell script.

```bash
python3 integrate_results.py --manifest "$RUN_DIR/manifest.json" --results "$RUN_DIR/observations.json" --output "$RUN_DIR/observations-canonical.json"
python3 apply_review.py --observations "$RUN_DIR/observations-canonical.json" --decisions "$RUN_DIR/reviewer-decisions.json" --output "$RUN_DIR/observations-reviewed.json"
python3 pipeline.py build --workbook "$BASELINE" --manifest "$RUN_DIR/manifest.json" --observations "$RUN_DIR/observations-reviewed.json" --output-dir "$RUN_DIR/output"
python3 verify_report.py --baseline "$BASELINE" --manifest "$RUN_DIR/manifest.json" --build-dir "$RUN_DIR/output"
python3 render_review_checklist.py --audit "$RUN_DIR/output/audit.json" --output "$RUN_DIR/review-checklist.md"
```

After the build, convert its complete checklist Markdown to PDF with `manus-md-to-pdf`, verify the workbook and PDF, and send the two attachments from the correct Gmail account. `email_payload.json` prepares email content but does not send mail. Follow the playbook's Sent verification and duplicate-send safeguards.

## Data integrity and recovery

The baseline remains unchanged. Numeric rents need fresh source URLs and price/bedroom evidence. Unresolved pricing becomes `Phone Verify`; `Not Offered` needs evidence of the property's unit mix, not merely temporary unavailability. Ineligible or identity-unresolved listings are disclosed and excluded from numeric averages. No bedroom proxies, concessions, per-person rates or historical price carry-forwards are permitted.

Market-average benchmark and visible summary cells are recalculated from current eligible numeric observations only. Existing subject rents, affordable-comparison data, colors, fonts, column widths and merged ranges are preserved. Data-age and partial-verification disclosures travel with the report. The old baseline's subject/FMR information is not re-verified merely by refreshing market comps.

Structural fixtures created with `--test-mode` are visibly synthetic and must never be sent as a live rent report. The user-requested full report test instead requires real source research and should identify itself as a TEST email while containing a genuine dated research report.

The full report build fails closed on missing properties/rows/bedrooms, duplicate observations, checksum mismatches, stale or unsupported numeric observations, and completely unsuccessful fresh research. Preserve successful observations after failures and resolve only the affected items. Do not silently publish changes to SharePoint, the API, ClickUp or GitHub.
