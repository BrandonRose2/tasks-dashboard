import copy
import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from integrate_results import integrate

class IntegrationTests(unittest.TestCase):
    def setUp(self):
        self.manifest={'runId':'monthly-test','runDate':'2026-11-04','baselineSha256':'abc','properties':[{'buildingId':'36','sheetName':'36 - Silver Springs','bedTypes':['2BD'],'comps':[{'row':13,'propertyName':'Comp'}]}]}
        self.result={'runId':'monthly-test','runDate':'2026-11-04','baselineSha256':'abc','failures':[],'properties':[{'buildingId':'36 - Silver Springs','comps':[{'row':13,'propertyName':'Comp','rents':[{'bedType':'2BD','status':'phone_verify','amount':None,'evidence':'Blocked','sourceUrl':'','checkedAt':'2026-11-04'}]}]}]}
    def test_exact_alias_preserves_evidence(self):
        original=copy.deepcopy(self.result)
        out,gaps=integrate(self.manifest,self.result)
        self.assertEqual(gaps,[])
        self.assertEqual(out['properties'][0]['buildingId'],'36')
        self.assertEqual(out['properties'][0]['comps'],original['properties'][0]['comps'])
        self.assertEqual(self.result,original)
    def test_canonical_id_is_accepted(self):
        self.result['properties'][0]['buildingId']='36'
        self.assertEqual(integrate(self.manifest,self.result)[1],[])
    def test_missing_row_is_reported_not_fabricated(self):
        self.result['properties'][0]['comps']=[]
        out,gaps=integrate(self.manifest,self.result)
        self.assertEqual(len(gaps),1)
        self.assertEqual(gaps[0]['error'],'missing row')
        self.assertEqual(out['properties'][0]['comps'],[])
    def test_invalid_identity_is_rejected(self):
        self.result['properties'][0]['buildingId']='36 - Wrong'
        with self.assertRaises(ValueError):integrate(self.manifest,self.result)
    def test_duplicates_rejected(self):
        self.result['properties']*=2
        with self.assertRaises(ValueError):integrate(self.manifest,self.result)
    def test_hash_mismatch_rejected(self):
        self.result['baselineSha256']='wrong'
        with self.assertRaises(ValueError):integrate(self.manifest,self.result)
    def test_failed_workflow_rejected(self):
        self.result['failures']=[{'buildingId':'36'}]
        with self.assertRaises(ValueError):integrate(self.manifest,self.result)
    def test_bed_gap_is_reported(self):
        self.result['properties'][0]['comps'][0]['rents']=[]
        self.assertEqual(integrate(self.manifest,self.result)[1][0]['error'],'bedroom coverage mismatch')

if __name__=='__main__':unittest.main()
