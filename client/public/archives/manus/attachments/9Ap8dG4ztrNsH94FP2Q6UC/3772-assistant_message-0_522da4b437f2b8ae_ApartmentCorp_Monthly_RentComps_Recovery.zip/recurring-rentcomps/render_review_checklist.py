#!/usr/bin/env python3
"""Build a concise complete checklist; detailed source quotations remain in audit.json."""
import argparse
import json
from pathlib import Path
from urllib.parse import quote


def md(value):
    return str(value).replace('|','\\|').replace('\n',' ')


def money(value):
    return f'\\${value:,.0f}' if type(value) in (int,float) else md(value)


def render(audit):
    counts=audit['counts']
    lines=[f"# ApartmentCorp Rent Comps — {audit['runDate']}", '', f"**41-property review checklist**" if audit['propertyCount']==41 else f"**{audit['propertyCount']}-property review checklist**", '',
           f"Fresh-source research covers {audit['propertyCount']} subject-property tabs and {audit['observedComparableCount']} existing market-rate rows. Of {audit['expectedRentCellCount']} requested rent fields: **{counts['verified']} verified numeric rents**, **{counts['phone_verify']} Phone Verify**, and **{counts['not_offered']} evidence-supported Not Offered**.", '',
           'This is a review draft, not an all-rents-verified report. Numeric rents are advertised monthly base rents, not guaranteed vacancy or telephone-confirmed quotes. Phone Verify includes pricing, identity or eligibility gaps. No stale price, estimate or bedroom proxy enters the averages.', '',
           'The input is the approved August 2026 formatted workbook. Subject rents, affordable-comp data and HUD/AMI information remain that baseline and were not re-researched. Colors, fonts, widths and merged ranges are preserved. Updated Market Average benchmarks and labeled visible market-average summaries are synchronized. Open and recalculate in Excel: unchanged Difference/recommendation formula caches may be stale or show errors when an average is Phone Verify.', '',
           'Individual house/duplex supplements without approved apartment-community comparability are retained for review but excluded from numeric averages. No comps were silently replaced. Detailed identity evidence, price quotations, attempted sources and original excluded findings are included in the accompanying audit package.', '',
           '- [ ] Approve coverage limits and unresolved pricing before using this workbook.',
           '- [ ] Resolve ineligible/unverified comps and any duplicate listing identities.',
           '- [ ] Recalculate and review workbook formulas in Excel.', '']
    for prop in audit['properties']:
        lines += [f"## {md(prop['sheetName'])}", '', f"{md(prop['subject']['propertyName'])} — {md(prop['subject']['address'])}, {md(prop['subject']['city'])}, {md(prop['subject']['state'])}", '',
                  '**Eligible numeric market averages:** '+ '; '.join(f"{bed}: {money(prop['marketAvg'][bed])} ({n}/{len(prop['comps'])} comps)" for bed,n in prop['benchmarkCoverageCounts'].items()), '']
        if prop['warnings']:
            lines += ['**Review flags**'] + ['- [ ] '+md(w) for w in prop['warnings']] + ['']
        for comp in prop['comps']:
            lines += [f"### Row {comp['row']} — {md(comp['propertyName'])}", '', f"Eligibility: **{md(comp['eligibility'])}**. All observations checked {audit['runDate']}.", '',
                      '| Bedroom | Previous baseline | Current rent / status |', '|---|---:|---:|']
            sources=[]
            for rent in comp['rents']:
                status=rent['amount'] if rent['status']=='verified' else {'phone_verify':'Phone Verify','not_offered':'Not Offered'}[rent['status']]
                lines.append(f"| {md(rent['bedType'])} | {money(comp['previousRents'][rent['bedType']])} | {money(status)} |")
                if rent['sourceUrl'] and rent['sourceUrl'] not in sources:sources.append(rent['sourceUrl'])
            if sources:
                lines += ['', 'Sources checked: '+ '; '.join(f"[Source {i+1}]({quote(url,safe=':/?&=%#@+.,;_-~')})" for i,url in enumerate(sources))+'.']
            else:lines += ['', 'No usable public source obtained; see detailed research audit for attempted checks.']
            if comp['eligibility']!='market_rate':
                reason=comp['notes'].split('REVIEW EXCLUSION: ')[-1] if 'REVIEW EXCLUSION:' in comp['notes'] else comp['notes']
                lines += ['', '**Eligibility / follow-up:** '+md(reason)]
            lines += ['', '- [ ] Confirm identity, bedroom mix, base price and availability; resolve Phone Verify.', '']
        lines += ['- [ ] Approve this property and confirm benchmark/summary agreement.', '', '---', '']
    return '\n'.join(lines)+'\n'

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--audit',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args()
    args.output.write_text(render(json.loads(args.audit.read_text())),encoding='utf-8')
    print(str(args.output.resolve()))
