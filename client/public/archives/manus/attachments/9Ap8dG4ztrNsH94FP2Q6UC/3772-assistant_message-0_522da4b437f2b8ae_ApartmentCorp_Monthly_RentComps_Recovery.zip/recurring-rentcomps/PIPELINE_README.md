# ApartmentCorp deterministic workbook processor

This stage performs **no research, browsing, network calls, email sending, scheduling, PDF generation, deployment or persistence configuration**. It is an offline contract validator and workbook/report assembler. Research and any authorized sending remain separate.

## Implementation files

- `pipeline.py`: `extract` and `build` CLI, plus importable functions.
- `requirements.txt`: `openpyxl>=3.1.5,<4`.
- `tests/test_pipeline.py`: 26 processor tests with synthetic workbook fixtures and actual-baseline inventory checks.
- `structural_test.py`: reproducible, explicitly synthetic full-baseline structural proof and preservation verification.

All implementation outputs and temporary directories in this task are under `/home/ubuntu/recurring-rentcomps`. The original input `/home/ubuntu/RentComps_UPDATED_Aug2026.xlsx` is read only. Legacy fixed-path scripts were read for patterns, **not imported**.

## Commands

Run from `/home/ubuntu/recurring-rentcomps`:

```bash
python3 -m pip install -r requirements.txt
python3 -m unittest discover -s tests -v

# New/empty output directory required. Do not overwrite an existing run.
python3 pipeline.py extract \
  --workbook /home/ubuntu/RentComps_UPDATED_Aug2026.xlsx \
  --output-dir /home/ubuntu/recurring-rentcomps/fixtures/NEXT-extract \
  --run-id monthly-2026-11-04 \
  --run-date 2026-11-04

# Real, full research observations only. This creates payloads, never sends them.
python3 pipeline.py build \
  --workbook /home/ubuntu/RentComps_UPDATED_Aug2026.xlsx \
  --manifest /home/ubuntu/recurring-rentcomps/fixtures/NEXT-extract/manifest.json \
  --observations /home/ubuntu/recurring-rentcomps/REAL_observations.json \
  --output-dir /home/ubuntu/recurring-rentcomps/reports/NEXT-live-build

# Reproducible synthetic proof; never live research. Use a new directory.
python3 structural_test.py \
  --workbook /home/ubuntu/RentComps_UPDATED_Aug2026.xlsx \
  --output-dir /home/ubuntu/recurring-rentcomps/reports/TEST_NOT_LIVE_next-full41 \
  --run-date 2026-11-04

# Direct structural build of existing clearly synthetic observations, new dir.
python3 pipeline.py build \
  --workbook /home/ubuntu/RentComps_UPDATED_Aug2026.xlsx \
  --manifest /home/ubuntu/recurring-rentcomps/reports/TEST_NOT_LIVE_full41/TEST_NOT_LIVE_extract/manifest.json \
  --observations /home/ubuntu/recurring-rentcomps/reports/TEST_NOT_LIVE_full41/TEST_NOT_LIVE_observations.json \
  --output-dir /home/ubuntu/recurring-rentcomps/reports/TEST_NOT_LIVE_next-build \
  --test-mode
```

`--max-age-days N` may be added to `build`, with integer `N` between 0 and 7. Default **0** requires same-day comparable and cell checks. Future run dates/check dates are always rejected. Run IDs must be 1–100 safe filename characters.

CLI exit codes: **0** accepted extraction/build (including explicitly test-mode structural output); **1** rejected input/unsafe update, no new output directory; **2** structurally valid full production run with zero verified numeric cells, explicitly unsuccessful nondistributable review artifacts only.

## Actual baseline inventory

Header detection: exactly one row in first 25 containing literal normalized `Rank`, `Type`, `Property Name`. Property sheets match `^\d+\s*[-–]`. Only rows explicitly typed `MARKET RATE` become comparable observations. Subject rows are explicit `SUBJECT`. All `BENCHMARK` rows with names containing `MARKET AVG` are refreshed consistently; other benchmark rows are preserved.

The supplied baseline has **43 total sheets, 41 property tabs, 190 comparable rows, 499 requested rent cells**. No fixed six-comps assumption is used. River Pointe is only `2BD` Actual at column 16; Urban is only `2BD` Actual. `STUDIO` and `1BD` through `5BD` with `ACTUAL` in their actual header labels are supported. Titles/legends are not authoritative bedroom maps.

Baseline SHA-256:

```text
9443d57d981ee9c3b73efd1efbe7db81958130ce2f8a41005da9ea588e0e1553
```

The real-baseline extraction currently available for research is:

`/home/ubuntu/recurring-rentcomps/fixtures/baseline-extract/manifest.json`

Its run envelope is `runId: source-refresh-2026-11-04`, `runDate: 2026-11-04`. The manifest has `baselineSha256`, `runId`, `runDate`, `propertyCount`, `expectedObservationCount`, `expectedRentCellCount`, and `properties`. Each property includes string `buildingId`, sheet name, subject identity/location/previous rents and resolved direct-reference values, requested `bedTypes`, exact comparable row identities/address/city/state/source text/URLs/notes/previous rents, actual/header/bedroom mappings, all benchmark rows, labeled summary cells, and baseline disclosure/benchmark metadata. `data_only=False` is authoritative; `data_only=True` is used only as a fallback cache when resolving a direct reference. No legacy code is imported.

`expectedObservationCount` is the comparable-row count (190), not the rent-cell count (499).

## Observation JSON contract

Every property ID, comparable row, property name and requested bedroom must match the manifest **exactly once**. IDs are strings; row IDs are integers. Every rent entry must contain all six fields. This illustrative fragment is **not a complete accepted run and is not live evidence**:

```json
{
  "runId": "source-refresh-2026-11-04",
  "runDate": "2026-11-04",
  "baselineSha256": "9443d57d981ee9c3b73efd1efbe7db81958130ce2f8a41005da9ea588e0e1553",
  "properties": [
    {
      "buildingId": "21",
      "comps": [
        {
          "row": 12,
          "propertyName": "The Addison Skyway Marina",
          "eligibility": "unverified",
          "checkedAt": "2026-11-04",
          "identityEvidence": "Research not supplied; identity and eligibility unresolved",
          "rents": [
            {
              "bedType": "2BD",
              "status": "phone_verify",
              "amount": null,
              "sourceUrl": "",
              "evidence": "No current numeric source evidence supplied",
              "checkedAt": "2026-11-04"
            },
            {
              "bedType": "3BD",
              "status": "phone_verify",
              "amount": null,
              "sourceUrl": "",
              "evidence": "No current numeric source evidence supplied",
              "checkedAt": "2026-11-04"
            }
          ],
          "notes": "Record actual phone verification attempts here; do not invent a call"
        }
      ]
    }
  ]
}
```

Allowed `eligibility`: `market_rate`, `unverified`, `ineligible`.

Allowed rent `status`:

- `verified`: positive finite JSON number, valid HTTP(S) URL without embedded credentials, nonempty verbatim source/context evidence, fresh date, and `market_rate` eligibility. This must be the **lowest advertised BASE monthly rent for the entire unit**, excluding concessions, net effective rents, per-bed/student prices, estimates and proxies. The researcher must establish these semantics and identity; the offline processor validates required evidence and catches obvious prohibited evidence terms. An amount unchanged from baseline is allowed **only with new source evidence**; it is never inherited as verification.
- `phone_verify`: `amount: null`; empty URL/evidence are permitted when no source was obtained. Keep actual attempted phone calls and unresolved-source context in `evidence` and `notes`. A fresh `checkedAt` means this run checked the item, not that a source was obtained. Unverified or ineligible properties **may only** have this status, and are flagged for replacement review without substitution.
- `not_offered`: `amount: null`, HTTP(S) URL, nonempty explicit source evidence and fresh date. No advertised listing, unavailable inventory, blocked pages or unanswered calls are **not** proof of an absent product type; use Phone Verify instead. Only `market_rate` comps may have this status.

Nonfinite numbers, booleans as amounts, numeric strings, missing fields, missing/extra/duplicate properties/rows/bedrooms, duplicate JSON keys, changed identities, stale/future dates, source-hash mismatches and tampered/subset manifests fail closed before any published workbook. The full manifest is re-extracted and compared before build; a selected-manifest pilot is **not supported** by this full-run build contract. A separate preview design would need explicit authorization/implementation and must not weaken the full-run gate.

Synthetic observations should add `"label": "TEST — NOT LIVE RESEARCH", "testMode": true` at the envelope level and explicit TEST language throughout evidence. Production build rejects these markers and reserved fixture URL hosts. `--test-mode` puts `TEST_NOT_LIVE_` on all build filenames, visible TEST disclosures throughout the workbook and reports, and never creates a distributable manifest.

## Workbook preservation and calculation

The processor plans all changes before output. It patches XLSX worksheet cell contents directly in the ZIP package, rather than resaving the workbook via openpyxl. All unrelated package members are copied **byte-for-byte**. All original sheets, subject/affordable rows, ordinary non-Market-Avg benchmarks, styles, sizes, row/column dimensions, merged ranges, formula strings and formula caches are retained.

Allowed updates: market Actual cells; market source text/notes/evidence; market-average bedroom columns and benchmark metadata; visible column-C market values on rows whose column-A literal matches a requested bed label; existing date/source/average/column-guide disclosures. Merged interiors are rejected. Merged anchors require explicit authorization and are recorded in changes. Obsolete hyperlinks on refreshed cells are removed so they do not silently point to old sources; their baseline targets remain in extracted source URLs/audit. Current URLs are stored in source text and evidence, not generated hyperlinks. Relationships elsewhere remain unchanged.

Every matching Market Avg benchmark is calculated from **only current `verified` numeric observations**, row-weighted and rounded to the nearest dollar with Decimal half-even rounding (matching ordinary Python `round` behavior). All columns matching that bed label on Market Avg rows are updated consistently. Zero eligible numeric observations gives **Phone Verify**, including in corresponding visible column-C summaries. A non-Actual bedroom found in AMI/FMR headers is not researched; its Market Avg row values become Phone Verify and the discrepancy is disclosed. Unlabeled legacy cells, such as orphan column-C values without an A bedroom label, remain baseline and are not newly verified.

Duplicate source URLs/addresses among comps for one subject and comparable addresses matching the subject are flagged. Duplicates are **not** silently dropped; averages remain row-weighted and require reviewer approval. Identical URLs across distinct source pages/bedrooms on the same row do not double-count that row.

**No Excel calculation engine runs.** Original Difference/recommendation formula caches can be stale; numeric-to-Phone-Verify transitions can yield Excel formula errors. These caveats are explicit in audit, checklist and email copy. Open/recalculate/review in Excel before use. The extracted subject/current-rent direct reference resolver supplies context only and never changes subject formulas.

## Output gates, artifacts and email payload

Outputs are staged in a temporary sibling directory and published by one atomic directory rename. New/empty output directories are required; an existing nonempty run is never partially overwritten. An exception during validation, assembly or read-back cleans staging and publishes nothing. Source hash is rechecked before and after assembly. The original source is never saved or overwritten.

A live accepted build produces `RentComps_refreshed.xlsx`, `checklist.md`, `changes.json`, `audit.json`, `email_payload.json`, `completion.json`, and, only when at least one numeric cell is verified, `distributable_manifest.json`. The latter still says reviewer approval is required and sending is not authorized. Zero-numeric production builds instead produce an `UNSUCCESSFUL_NOT_DISTRIBUTABLE_RentComps.xlsx`, clear unsuccessful reports/payload, and **no distributable manifest**.

Audit counts current observed `verified`, `phone_verify`, `not_offered`; observation dates and source dates by status; per-property/bed numeric benchmark coverage; previous/new values; baseline disclosure/source/metadata; replacement and duplicate warnings. No old numeric values are counted as newly observed automatically.

The payload never sends email. Sender is fixed `apartmentcorp44@gmail.com`. Intended production recipients are exactly `Ethan@apartmentcorp.com`, `mam@22.bz`; test recipient is only `ethan@apartmentcorp.com`. Copy honestly states source-supported numeric coverage and that not all rents are verified. `send` and `sendAllowed` are always false. Do not place secrets in observation notes/evidence or generated files; no credential or network integration exists here.

## Executed test results

Latest combined repository discovery: **29 tests passed**, including 26 processor tests and 3 independently supplied research-input tests. Processor tests cover irregular headers, merged writes, full 41 synthetic extraction/build, actual inventory, source/stale/nonfinite/missing/extra/duplicate rejection, empty/zero gates, source immutability on failures, source hash/manifest tampering, styles/subject/affordable/formula/sizing/merged preservation, benchmark/summary equality, explicit statuses, phone-attempt provenance, duplicate warnings, production/test gating, fixed sender/recipient payloads and atomic publication failure cleanup.

Latest log: `/home/ubuntu/recurring-rentcomps/reports/unit-tests.log`.

Executed full actual-baseline structural proof:

- Output root: `/home/ubuntu/recurring-rentcomps/reports/TEST_NOT_LIVE_full41`.
- Verification: `TEST_NOT_LIVE_verification.json`.
- Synthetic observations: `TEST_NOT_LIVE_observations.json`.
- Extraction: `TEST_NOT_LIVE_extract/manifest.json`.
- Workbook: `TEST_NOT_LIVE_build/TEST_NOT_LIVE_RentComps_refreshed.xlsx`.
- Checklist: `TEST_NOT_LIVE_build/TEST_NOT_LIVE_checklist.md`.
- Audit/changes/email/completion: corresponding `TEST_NOT_LIVE_*.json` files in that build directory.

**STRUCTURAL PASS ONLY — NOT LIVE RESEARCH:** 41 property tabs, 190 comparable rows, 499 requested rent cells, with synthetic 235 numeric / 172 Phone Verify / 92 Not Offered. Source unchanged; 35,797 styles checked; 34,042 untouched cell values checked; 10 unmodified ZIP members byte-identical; all updated benchmark and labeled summary values equal; distributable manifest blocked. There were 61 explicit reviewer warnings from baseline duplicates, uncovered bedrooms, multiple benchmarks and layout discrepancies. These synthetic coverage figures are software-test data and must not appear as live rent research.

## Known limits

This processor cannot verify page accessibility, actual identity, market eligibility, exact evidence truth, complete product mix, or whether a claimed amount really is the lowest advertised BASE rent. These are the researcher's and reviewer's responsibilities. Baseline metadata can itself be wrong, including duplicated Market Avg rows, nonmarket fields, bedroom labels in titles, legacy sources and orphan summaries; only explicitly permitted refresh fields are corrected. The full-run gate accepts source-supported partial numeric coverage but clearly counts and warns about all gaps; it does not guarantee all rents verified. Preservation was verified against this specific baseline and synthetic fixtures; arbitrary unsupported XLSX extensions need their own regression testing. There is no PDF/export calculation engine, persistence, live source research, email sending or one-property production-subset mode.

## Completed November 4 real-source repair test

After canonical research-input alignment, narrow false-positive pricing-exclusion handling and auditable conservative review, the final combined suite passed **51 tests**. The genuine full research build covers **41 properties / 190 rows / 499 rent fields**, with **146 accepted source-supported numeric rents / 297 Phone Verify / 56 evidence-supported Not Offered**. A separate real-report readback verified 35,797 styles, 34,042 unchanged cell values, 234 benchmark/summary tie-outs and 10 unchanged ZIP members. Source baseline remained unchanged. Code helpers `integrate_results.py`, `apply_review.py`, `verify_report.py` and `render_review_checklist.py` now own result integration, conservative exclusions, real readback and a readable complete PDF checklist input. Actual source evidence and exclusion originals are in the dated audit package. Original formula-cache caveats and owner-side schedule-activation restrictions still apply; this successful build is not an all-rents-verified or already-activated recurring report.
