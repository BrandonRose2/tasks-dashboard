#!/usr/bin/env python3
"""Generate deterministic workflow source; orchestration is run by the parent task."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

CELL_SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "properties": {
        "bedType": {"type": "string"},
        "status": {"type": "string", "enum": ["verified", "phone_verify", "not_offered"]},
        "amount": {"type": ["number", "null"]},
        "sourceUrl": {"type": "string"},
        "evidence": {"type": "string"},
        "checkedAt": {"type": "string"},
    },
    "required": ["bedType", "status", "amount", "sourceUrl", "evidence", "checkedAt"],
}
COMP_SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "properties": {
        "row": {"type": "integer"},
        "propertyName": {"type": "string"},
        "eligibility": {"type": "string", "enum": ["market_rate", "unverified", "ineligible"]},
        "checkedAt": {"type": "string"},
        "identityEvidence": {"type": "string"},
        "rents": {"type": "array", "items": CELL_SCHEMA},
        "notes": {"type": "string"},
    },
    "required": ["row", "propertyName", "eligibility", "checkedAt", "identityEvidence", "rents", "notes"],
}
PROPERTY_SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "properties": {
        "buildingId": {"type": "string"},
        "comps": {"type": "array", "items": COMP_SCHEMA},
    },
    "required": ["buildingId", "comps"],
}


def generate(inputs_path: Path, prompt_path: Path, output: Path, limit: int | None = None):
    data = json.loads(inputs_path.read_text(encoding="utf-8"))
    entries = data["inputs"][:limit] if limit else data["inputs"]
    prompt = prompt_path.read_text(encoding="utf-8")
    payload = {
        "runId": data["runId"],
        "runDate": data["runDate"],
        "baselineSha256": data["baselineSha256"],
        "entries": entries,
    }
    script = (
        "const input = " + json.dumps(payload, ensure_ascii=False) + ";\n"
        "const prompt = " + json.dumps(prompt, ensure_ascii=False) + ";\n"
        "const schema = " + json.dumps(PROPERTY_SCHEMA) + ";\n"
        "log('Researching ' + input.entries.length + ' workbook-derived properties');\n"
        "const mapped = await parallel('Fresh comparable rents by property', () =>\n"
        "  input.entries.map(item => agent(\n"
        "    prompt + '\\nResearch subject property: ' + item.buildingId + '. Read the declared property-input file; use only its comparable rows.',\n"
        "    {brief: 'Refresh rents: ' + item.buildingId, schema, sandbox: 'isolated', effort_level: 'standard',\n"
        "     input_files: [{path: item.path, name: 'property-input'}]}\n"
        "  ))\n"
        ");\n"
        "const properties = mapped.filter(r => r.ok).map(r => r.value);\n"
        "const failures = mapped.map((r,i) => r.ok ? null : ({buildingId: input.entries[i].buildingId, code: r.error.code, message: r.error.message})).filter(Boolean);\n"
        "return {runId: input.runId, runDate: input.runDate, baselineSha256: input.baselineSha256, properties, failures};\n"
    )
    output.write_text(script, encoding="utf-8")
    params = {
        "brief": "Research current advertised rents for each workbook property using verified public sources.",
        "script": script,
        "estimated_agent_calls": len(entries),
        "max_agent_calls": len(entries),
        "effort_level": "standard",
        "sandbox": "isolated",
        "failure_policy": "collect",
    }
    output.with_suffix(".params.json").write_text(json.dumps(params, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return len(entries)


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--inputs", type=Path, required=True)
    p.add_argument("--prompt", type=Path, default=Path(__file__).with_name("research_prompt.txt"))
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--limit", type=int)
    args = p.parse_args()
    count = generate(args.inputs, args.prompt, args.output, args.limit)
    print(f"Prepared deterministic workflow with {count} property research tasks: {args.output}")
