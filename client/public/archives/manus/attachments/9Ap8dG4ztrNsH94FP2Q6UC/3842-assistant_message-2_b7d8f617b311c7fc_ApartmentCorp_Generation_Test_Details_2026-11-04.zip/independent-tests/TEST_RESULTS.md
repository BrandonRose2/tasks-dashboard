# ApartmentCorp recovery-bundle test results — November 4, 2026

## Scope and integrity

The ZIP was securely extracted into this unique workspace, rejecting unsafe paths, symlinks, duplicate targets, encrypted members, and oversized extraction. No email, schedule changes, browser interaction, publication, fresh research, or real-report assembly was performed. The canonical project and source ZIP were not modified. All 23 extracted original members remain byte-identical to their initial hashes.

- Workspace: `/home/ubuntu/rentcomps-test-suite-20261104-X61GZZRZ`
- Extracted project: `extracted/recurring-rentcomps/`
- Source ZIP SHA-256: `76aab9c1c3b740934cb801991e9cdc901255e70e6bfd75b4bca71cfeb4345985`
- Bundled approved baseline SHA-256: `9443d57d981ee9c3b73efd1efbe7db81958130ce2f8a41005da9ea588e0e1553`

## Actual installation and test outcomes

A fresh Python 3.12.3 venv was created. Bundled `requirements.txt` installed successfully: `openpyxl==3.1.5`, transitive dependency `et_xmlfile==2.0.0`. `pip check` returned exit 0, with no broken requirements. An initial shell wrapper failed to retain the pipeline exit code after pip had already succeeded; installation was subsequently confirmed by a captured subprocess with exit 0. This was log bookkeeping, not a dependency-install failure.

| Run | Discovered | Passed | Failed | Errors | Skipped | Exit |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Unmodified bundled `python -m unittest discover -s tests -v` | 51 | 50 | 0 | 0 | 1 | 0 |
| Same complete discovery with legacy baseline unavailable | 51 | 46 | 0 | 0 | 5 | 0 |

The first run took 34.679 seconds according to unittest. The cold-start run took 19.731 seconds. The cold-start harness made only `/home/ubuntu/RentComps_UPDATED_Aug2026.xlsx` appear absent and denied reads to it; no original file was removed/moved and no tests, assertions, or application code were changed. This is a targeted absence simulation, not a new operating-system container.

The standalone `structural_test.py` also passed with exit 0 using **only `baselines/RentComps_UPDATED_Aug2026.xlsx` from the ZIP** and a new output directory. It checked 41 properties, 190 comparable rows, 499 rent fields, 35,797 styles, and 34,042 untouched cells, with benchmark/summary equality and source immutability passing. Generated structural artifacts are explicitly **TEST — NOT LIVE RESEARCH**, not a real monthly report; their synthetic prices must not be reused in the report. No distributable manifest was produced.

## Concrete cold-start issues and minimal fixes

1. **Four real-baseline tests depend on an old absolute file rather than the bundled baseline.** `tests/test_pipeline.py:16` and `tests/test_research_inputs.py:20` define `BASELINE = Path('/home/ubuntu/RentComps_UPDATED_Aug2026.xlsx')`. The old file happens to exist here and is byte-identical to the bundled baseline, explaining why those tests passed in the ordinary run. Without it, discovery still reports OK but silently skips:
   - `test_actual_baseline_all41_dynamic_inventory`
   - `test_complete_header_driven_property_manifest`
   - `test_exact_actual_canonical_manifest_alignment`
   - `test_deterministic_workflow_declares_each_input`

   Minimal proposed fix: set both constants to `Path(__file__).resolve().parents[1] / 'baselines' / 'RentComps_UPDATED_Aug2026.xlsx'`. This restores cold-start baseline regression coverage without relaxing assertions. No fix was applied.

2. **One evidence-regression fixture is missing from the bundle.** `tests/test_pipeline.py:284–287` expects `reports/2026-11-04/observations.canonical.json`, which is absent from the ZIP. `test_exact_canonical_evidence_exclusion_regressions` skipped in both runs. Minimal proposed fix: package an immutable minimal fixture containing the three exact evidence cases consumed by this test (or bundle the approved canonical artifact) and reference it under `tests/fixtures`; do not drop the assertions. No fix was applied, and no parent evidence was copied into the test project.

3. **Old command examples can reproduce the external-path dependency.** `PIPELINE_README.md` uses the old `/home/ubuntu/RentComps_UPDATED_Aug2026.xlsx` in extract/build/structural examples and fixed `/home/ubuntu/recurring-rentcomps` output paths. The actual Python CLI scripts accept explicit workbook/output paths, and the bundled-baseline structural command succeeded. Minimal documentation fix: use project-relative `baselines/RentComps_UPDATED_Aug2026.xlsx` for recovery tests and a new run-specific output directory; retain explicit user-approved latest-baseline selection for live runs.

These are regression-coverage/command-example portability issues, **not observed failures of the portable deterministic pipeline**. No installation or executed-test failure blocks report assembly when the bundled baseline is passed explicitly. Unittest discovery does not verify live rent accuracy, email delivery, or schedule execution.

## Logs and artifacts

All paths below are relative to this workspace:

- `install.log`, `install-confirmation.log`, `install-status.log`, `pip-check.log`, `installed-packages.txt`
- `unittest-bundled.log`, `unittest-bundled.json`
- `unittest-cold-start.log`, `unittest-cold-start.json`, `cold_start_discovery.py`
- `structural-bundled-baseline.log`, `structural-bundled-baseline.json`
- `structural-proof/TEST_NOT_LIVE_verification.json`
- `extraction_manifest.json`, `integrity-verification.json`, `dependency_scan.log`, `legacy-path-state.log`
- Reproducible local utilities: `secure_extract.py`, `run_command.py`

The Python scripts were inspected only for concrete external-file dependencies and safe offline test execution. No broad speculative code review or workflow execution was performed.
