# ApartmentCorp report-generation test — November 4, 2026

**Result: generation passed.** The uploaded Reports recovery ZIP was restored into a new directory. Its own code regenerated the complete real-source workbook and review-checklist PDF from the genuine source observations already collected earlier on November 4. This is a same-day evidence replay, not a second full research pass, a November 10 report or an emailed report.

## What passed

The generated workbook contains all 41 subject-property tabs, 190 existing market-rate comparable rows and 499 requested bedroom-rent fields. Readback checked 35,797 cell styles, 34,042 unchanged cell values and 234 benchmark/visible-summary tie-outs. The source baseline and original evidence checksums remained unchanged. All 41 properties are present in the exported 75-page checklist PDF.

The same-day reviewed evidence comprises 146 accepted source-supported numeric rents, 297 Phone Verify fields and 56 evidence-supported Not Offered fields. Generation success does not mean every price is verified. The historical August subject/affordable/HUD baseline remains unchanged. Original formula caches are preserved; open and recalculate/review in Excel before making pricing decisions.

A fresh Python 3.12 environment installed the bundle's requirements successfully and passed its dependency check. Full unmodified discovery ran 51 tests: 50 passed, one skipped, no failures or errors. The skipped evidence regression requires a historical observations fixture that the recovery ZIP does not include.

A separate absence simulation found that four additional tests skip if the old absolute-path baseline is unavailable. This is a test-fixture portability limitation, not an observed report-generation runtime failure: the standalone structural processor ran successfully with the baseline inside the ZIP. That independent proof used synthetic data and is NOT the real-source workbook delivered with this test.

Generated 41-property research inputs and the research workflow passed preparation/syntax validation. Two official source pages were successfully fetched for accessibility; dynamic numeric pricing was not available in those extracted pages, and no new price-verification claim was made from them.

## What this did not test

This test did not launch another full source-research workflow, invoke the scheduler's Run now action, execute an actual November 10 firing, verify automatic approval of a new research budget or send email. It did not change the schedule, publish to SharePoint/API/GitHub, overwrite the approved source or run ClickUp synchronization.

The existing separate-task schedule still retains a legacy internal playbook field in backend metadata; its saved replacement prompt explicitly supersedes those obsolete instructions. This generation test does not independently prove how the scheduler resolves that retained field at runtime. Future execution must follow the replacement prompt and ZIP playbook, verify the actual Gmail sender and fail closed on any approval, source, validation or delivery problem.

## Evidence files

`test-summary.json` and `test-provenance.json` record the replay scope and checksums. `readback_verification.json`, `audit.json` and `changes.json` document workbook validation and source coverage. The preserved same-day reviewed observations supply price/identity evidence. Independent test logs and results are included separately. The workbook and PDF are clearly named TEST outputs; no email delivery receipt was created for this generation-only test.
