# ApartmentCorp Rent Comps — November 4, 2026

This package contains a genuine public-source fresh-rent research run, not synthetic test prices. It is a review draft and does not establish that all rents or vacancies are verified.

Coverage: **41 subject-property tabs, 190 existing market-rate rows and 499 requested rent fields**. Accepted observations include **146 source-supported numeric base rents, 297 Phone Verify entries and 56 evidence-supported Not Offered entries**. Thirty-two properties have at least some accepted numeric coverage. Forty-seven property/bedroom groups have no eligible verified numeric rent, so their matching market-average benchmark and labeled summary are explicitly Phone Verify. The checklist and workbook disclose these gaps rather than inherit old prices.

The August 2026 formatted approved workbook supplied the existing comp identities, subject data and styles. Its source checksum remained unchanged. Subject rents, affordable-comparison data and HUD/AMI information were not freshly researched. Original colors, fonts, widths, merged ranges and unapproved cell values were preserved. Validation checked 35,797 cell styles, 34,042 unchanged cell values and 234 benchmark/summary tie-outs. Original Difference/recommendation formula caches are preserved, may be stale or error when an average is Phone Verify, and must be recalculated/reviewed in Excel.

Individual houses/duplexes without explicit approved apartment-community comparability, eligibility-unverified/ineligible comps and estimated prices are excluded from numeric averages. No new comps were substituted and no SharePoint, API, GitHub or ClickUp data was published. Publicly advertised prices do not guarantee currently vacant units. No telephone confirmation was performed.

## Files

The dated Excel workbook and complete PDF/Markdown review checklist are intended for review. `audit.json` and `checklist-full-evidence.md` retain source URLs, quoted price/bedroom evidence, identity notes, eligibility reasons and coverage flags. `changes.json` logs every allowlisted workbook change. `readback_verification.json` records preservation and market-average tie-out checks.

`research-original.json` contains the original portfolio-workflow response, including the initially incomplete Silver Springs result. `research-complete.json` replaces only that missing property with the recovered six-row result. `observations-reviewed.json` contains the conservative observations actually used to build the workbook. `review_decisions.json` preserves the original quoted findings and reasons for 26 conservative review exclusions. Excluded numeric findings are not accepted rents.

The software passed 51 combined tests. Synthetic structural fixture outputs are deliberately excluded from this report package. The separate recovery ZIP contains the executable processor, research-input/workflow builders, tests, run playbook and unchanged historical approved baseline for future recovery.

Regular scheduled recipients are ethan@apartmentcorp.com and mam@22.bz from apartmentcorp44@gmail.com. The user-authorized completed-report TEST is sent only to ethan@apartmentcorp.com. Schedule activation remains an owner-side step because this shared task cannot modify the existing recurring schedule; do not infer activation from this report build or email test.
