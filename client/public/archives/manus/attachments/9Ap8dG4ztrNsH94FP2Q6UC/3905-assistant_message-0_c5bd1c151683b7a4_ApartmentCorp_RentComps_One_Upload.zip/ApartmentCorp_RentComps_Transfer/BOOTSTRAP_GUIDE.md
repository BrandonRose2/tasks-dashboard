# Offline bootstrap contract

Requires Python 3.10 or later. The bootstrap itself uses only the standard library; the copied workbook engine requires `recurring-rentcomps/requirements.txt`. The receiving agent installs those dependencies explicitly. No command installs packages, reads credentials, calls a network service, executes research workflows, creates schedules, or sends messages.

## Commands

```bash
python bootstrap.py verify
python bootstrap.py prepare
python bootstrap.py prepare --workbook /approved/input.xlsx
python bootstrap.py self-test
```

Every command accepts `--package-root PATH` before or after the command. It defaults to the directory containing `bootstrap.py`, independent of the current working directory. There are no date, run-ID, scheduling, sending, or research-execution flags. An explicit `--workbook` is available only for `prepare`; its inventory and hash are regenerated, and the input is never overwritten.

Successful commands emit a JSON receipt on standard output and return exit code 0. Rejected operations emit JSON on standard error and return 1; invalid CLI syntax returns 2. Receipts distinguish `VERIFIED`, `PREPARED_NOT_RESEARCHED`, and `TEST_NOT_LIVE_PASS`. None claims fresh research happened.

## Verification rules

`package_manifest.json` must be an object with integer `schemaVersion: 1`, a nonempty string `packageId`, `files` mapping canonical relative POSIX paths to lowercase 64-character `sha256` and nonnegative integer `size`, and `baselineSha256`. Duplicate JSON keys and nonfinite values are rejected. Every listed file must exist with matching size and SHA-256.

`report_config.json` must be listed. Its `baselinePath` must be a listed canonical relative path. Its `baselineSha256`, the manifest's `baselineSha256`, and the baseline file entry's hash must match. The bootstrap is an inventory verifier, not a signature verifier: the receiving agent must authenticate the manifest's expected checksum separately.

Unexpected regular files are rejected, with exactly these exclusions:

1. Root `package_manifest.json`, excluded because a manifest cannot inventory its own final hash.
2. Files beneath directory components named `__pycache__` or `.venv`, anywhere in the package.
3. The entire root `runs/` tree, including unique preparation and synthetic self-test artifacts.
4. Only root verification-log files matching `verification-logs/verify-YYYYMMDDTHHMMSSZ-<32 lowercase hex>.json`.

Excluded directory trees are not traversed, but a symlink at their root is rejected. All symlinks and nonregular objects in the traversed distribution tree are rejected. No other `.log`, `.json`, dotfile, temporary directory, reference output, or verification artifact is implicitly excluded. Listed entries cannot use exclusions. Paths cannot be absolute or contain empty, `.` or `..` components, backslashes, colons, or control characters; listed files and all their in-package ancestors cannot be symlinks. Empty directories are not inventory entries.

`verify` adds one atomic successful-verification log under the exact excluded pattern. `prepare` and `self-test` verify before creating run directories or importing engine dependencies.

## Preparation receipt and artifacts

`report_config.json` supplies `baselinePath`, `baselineSha256`, `timezone` (IANA name), and optional `researchBatchSize` (default 18; valid integer range 1–1000). The run date is today's date in the configured `ZoneInfo` timezone. The canonical engine still rejects dates later than the host date; the bootstrap does not bypass that guard or provide a future-date override. IANA timezone data must exist in the receiving environment.

Preparation reserves a unique `runs/rentcomps-YYYY-MM-DD-<uuid>/` directory, stages all work, and publishes only after extraction, input generation, workflow generation, and unchanged-input hash checks succeed. On failure, its staging tree and empty reservation are removed. Existing runs and input workbooks are never overwritten.

The receipt `preparation-summary.json` contains hashes, byte sizes, absolute artifact paths, inventory counts, run ID/date, selected workbook hash, and the packaged baseline hash. Primary fields are `canonicalManifest`, `researchInputs`, `fullWorkflowScript`, `fullWorkflowParams`, `batchList`, `batches`, `artifacts`, and `summaryPath`.

| Relative artifact | Purpose |
| --- | --- |
| `extract/manifest.json` | Full canonical workbook inventory |
| `research-inputs/research-inputs.json` | Full research envelope and input declarations |
| `research-inputs/property-NN.json` | One workbook-derived property input |
| `workflows/full-workflow.js` and `.params.json` | Full workflow inventory; **do not execute in addition to batches** |
| `workflows/batch-NNN.research-inputs.json` | Batch input subset, preserving the full envelope/counts/properties |
| `workflows/batch-NNN.js` and `.params.json` | Tool-call payloads for one bounded batch |
| `batch-list.json` | Ordered batches and expected result destinations |
| `preparation-summary.json` | `PREPARED_NOT_RESEARCHED` publication receipt |

All declared property paths are regenerated for the current package location and final run directory. No absolute path from transferred reference outputs is reused. Each `batches` item provides `batchIndex`, `propertyCount`, input index range, building IDs, hashed `researchInputs`, `workflowScript`, `workflowParams`, and `expectedResultPath`. The latter points to `research-results/batch-NNN.result.json`; no result file or results directory is created by bootstrap.

The receiving agent executes **only the bounded batches, sequentially by `batchIndex`**, using each `workflowParams.path` with its authorized research tools, saves result envelopes to the declared destinations, and handles merging/recovery separately. Within each workflow, the unchanged engine may fan out its bounded subset. Preparing scripts is not research, evidence verification, or approval to distribute a workbook.

## Self-test

`self-test` runs engine unittest discovery, setup unittest discovery, then the full packaged-baseline `structural_test.run` with explicitly synthetic observations. Setup tests use only temporary synthetic packages; their self-test cases mock the suite runner, so there is no recursive suite invocation.

Only an all-pass run is published to unique `runs/TEST_NOT_LIVE-YYYY-MM-DD-<uuid>/`. It includes `TEST_NOT_LIVE_unittest.log`, the engine's `TEST_NOT_LIVE_structural/` outputs, and `TEST_NOT_LIVE_summary.json`. The receipt records every skipped test and its reason; a missing optional historical canonical-research fixture is a skip, not proof of fresh research. Synthetic workbook/audit outputs remain nondistributable. The unchanged engine produces a test email **payload file** with sending disabled; bootstrap does not read email credentials, integrate email, or send it.

The engine uses `hashlib.file_digest`, introduced in Python 3.11. On Python 3.10, bootstrap temporarily supplies a chunked equivalent while verified engine modules are loaded, then restores the interpreter state. Engine processing code is not modified. Engine baseline test fixture paths are package-relative.
