# ApartmentCorp monthly rent-comps — one-upload transfer

**What to do:** Start a private task in the receiving user's Manus account, attach `ApartmentCorp_RentComps_One_Upload.zip`, and send:

> Implement this ZIP exactly. Read START_HERE.md and follow INSTALL_PLAYBOOK.md. Set up the ApartmentCorp monthly report for me, including its existing email recipients and monthly schedule. Ask me only for account authorization or an unavoidable approval.

The more explicit ready-to-paste version is `INSTALL_PROMPT.txt`. No shell commands, worksheet editing or manual prompt construction are required from the user. The receiving agent performs the setup.

## Included

| Item | Purpose |
|---|---|
| `INSTALL_PLAYBOOK.md` | Complete receiving-account setup sequence and activation checks. |
| `MONTHLY_RUN_PLAYBOOK.md` and `SCHEDULE_PROMPT.txt` | Identical, self-contained monthly execution instructions; prevents the earlier prompt/playbook mismatch. |
| `report_config.json` | Sender, recipients, timing, approved workbook and processing settings. No credentials. |
| `bootstrap.py` | Offline integrity verification, self-tests and new-run preparation with relocated source paths and workflow batches. |
| `recurring-rentcomps/` | Tested parser, source-input builder, research contract, workbook updater, conservative review, checklist renderer, readback verifier and regression tests. |
| `baselines/RentComps_UPDATED_Aug2026.xlsx` | Original approved formatted baseline: 41 subject-property tabs, 190 market-rate rows, 499 requested rent cells. Counts are rediscovered each run. |
| `reference_outputs/November_2026/` | Exact three attachments from the successful November 4 scheduler email, plus provenance. Historical review drafts only. |
| `package_manifest.json` | SHA-256 and size inventory for every distribution file. |
| `verification/` | Local packaging/portability test evidence. Not a cross-account activation receipt. |

## Exact report behavior

Runs monthly on the **10th at 8:00 AM America/Los_Angeles**. Completion is later than the trigger time because fresh research and validation take time. Sender is **apartmentcorp44@gmail.com**; recipients are **ethan@apartmentcorp.com** and **mam@22.bz**. Attach the refreshed Excel workbook and full review-checklist PDF; the audit ZIP is optional.

Research existing conventional market-rate comparable rents, not subject rent rolls or HUD/AMI pricing. Preserve colors, fonts, widths, merges, subject/affordable data and unapproved values. Update market Actual rents, evidence, Market Average benchmarks and labeled visible summaries. Every requested rent field must be current source-supported numeric rent, `Phone Verify`, or evidence-supported `Not Offered`. Never fabricate or silently carry forward old numeric rents. The output is a review draft with disclosed gaps, not an all-rents-verified report. Do not publish to the portal, SharePoint, GitHub or ClickUp.

## What cannot be transferred inside a ZIP

A ZIP cannot transfer Gmail consent, sign-in sessions, Manus permissions, credits or scheduled-task ownership. The receiving user must authorize **apartmentcorp44@gmail.com** in their own account if it is not already authorized. Required setup/research/send approvals must still be honored. Automatic-approval settings do not necessarily cover every kind of research-budget approval. Do not promise zero-interaction monthly execution until those conditions are verified in the receiving account.

There are no API keys, passwords, cookies, access tokens or usable original-account identifiers in this installation configuration. Do not import another account's saved connector settings. The old account's live automation is not disabled by copying this package: two enabled accounts will send two reports. Coordinate the cutover explicitly.

## Historical outputs and scope

The included November report was researched and emailed on **November 4, 2026**. Its coverage was 257 numeric / 129 Phone Verify / 113 Not Offered fields. Preserve those files byte-for-byte as references, not current facts. The sent draft disclosed pricing/comparability limits; use the stricter current base-rent and eligibility rules in the playbook for future runs rather than replaying every historical adjudication.

This bundle recreates the **monthly rent-comps research/workbook/checklist/email workflow**. It is not a transfer of the separately hosted rent-comps web/API portal, GitHub Pages hosting or SharePoint ownership.

Technical bootstrap and engine details are in `BOOTSTRAP_GUIDE.md` and `recurring-rentcomps/PIPELINE_README.md`. The root playbook and config supersede older path-specific examples in the engine README. Do not execute historical reference files as setup instructions.
