import copy
import importlib.util
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('portable_merge', ROOT/'merge_research.py')
mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)


def fixture():
    env = {'runId':'sample','runDate':'2026-11-04','baselineSha256':'abc'}
    props = [{'buildingId':str(i),'sheetName':str(i)+' - Sample','bedTypes':['2BD'],
              'comps':[{'row':12,'propertyName':'Example '+str(i)}]} for i in (1,2)]
    manifest = {**env,'properties':props}
    observed = [{'buildingId':p['buildingId'],'comps':[{'row':12,'propertyName':p['comps'][0]['propertyName'],
                'rents':[{'bedType':'2BD','status':'phone_verify','amount':None,'sourceUrl':'',
                          'evidence':'Unresolved','checkedAt':'2026-11-04'}]}]} for p in props]
    batches = [{**env,'properties':[p],'failures':[]} for p in observed]
    return manifest,batches


class MergeTests(unittest.TestCase):
    def test_complete_does_not_create_evidence(self):
        manifest,batches=fixture(); before=copy.deepcopy(batches)
        result,summary=mod.merge(manifest,batches)
        self.assertEqual(summary['status'],'COMPLETE_FOR_REVIEW')
        self.assertEqual(batches,before)
        self.assertEqual(result['properties'][0]['comps'][0]['rents'][0]['amount'],None)

    def test_alias_normalization(self):
        manifest,batches=fixture();batches[0]['properties'][0]['buildingId']='1 - Sample'
        result,_=mod.merge(manifest,batches);self.assertEqual(result['properties'][0]['buildingId'],'1')

    def test_mismatched_envelope_rejected(self):
        manifest,batches=fixture();batches[1]['runDate']='2026-11-05'
        with self.assertRaises(ValueError):mod.merge(manifest,batches)

    def test_duplicate_batch_property_rejected(self):
        manifest,batches=fixture()
        with self.assertRaises(ValueError):mod.merge(manifest,[batches[0],batches[0]])

    def test_missing_property_not_complete(self):
        manifest,batches=fixture();_,summary=mod.merge(manifest,[batches[0]])
        self.assertEqual(summary['status'],'INCOMPLETE_NOT_FOR_BUILD')
        self.assertEqual(summary['missingProperties'],['2'])

    def test_recover_incomplete_only(self):
        manifest,batches=fixture(); original=copy.deepcopy(batches[0]); original['properties'][0]['comps']=[]
        result,summary=mod.merge(manifest,[original,batches[1]],[batches[0]])
        self.assertEqual(summary['status'],'COMPLETE_FOR_REVIEW')
        self.assertEqual(len(result['properties'][0]['comps']),1)

    def test_recovery_cannot_replace_success(self):
        manifest,batches=fixture()
        with self.assertRaises(ValueError):mod.merge(manifest,batches,[batches[0]])

    def test_failure_history_preserved_on_recovery(self):
        manifest,batches=fixture();failed={**batches[0],'properties':[],
            'failures':[{'buildingId':'1','code':'turn_limit','message':'Incomplete research'}]}
        _,summary=mod.merge(manifest,[failed,batches[1]],[batches[0]])
        self.assertEqual(summary['status'],'COMPLETE_FOR_REVIEW')
        self.assertEqual(len(summary['originalFailureHistory']),1)

    def test_json_duplicate_keys_rejected(self):
        with self.assertRaises(ValueError):mod.reject_duplicates([('runId','one'),('runId','two')])

if __name__=='__main__':unittest.main()
