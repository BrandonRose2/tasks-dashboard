# Portable bundle validation — November 6, 2026

The installation payload was tested by extracting the generated ZIP into a different temporary location and installing its requirements in a fresh virtual environment. No original sandbox file dependency was used for the recovered code, baseline, input declarations or reference outputs.

- Python 3.12.3; openpyxl 3.1.5.
- Engine: 51 tests discovered, 50 passed, 1 optional historical canonical-evidence fixture skipped.
- Portable setup/batch merger: 37 passed; no failures/errors.
- Total: 87 passed and 1 optional skip.
- Approved baseline inventory: 41 subject-property tabs, 190 market-rate rows, 499 requested rent fields.
- Bounded research preparation: 18 / 18 / 5 property batches; every generated input path points to the recovered location; workflow syntax checked in its actual async-function-body format.
- Full synthetic structural proof: baseline unchanged, 35,797 styles checked, 34,042 unrelated cell values checked, 10 unmodified ZIP members byte-identical, market-average/summary equality passed and synthetic distributable manifest blocked.
- Modified configuration was rejected by the integrity verifier.
- Scheduler Prompt and internal Playbook source files are byte-identical.
- Nested archive integrity and credential-pattern scans passed. Scanning is a supplementary check, not a guarantee against every possible sensitive value.

The cold_start.json records the test of the initial archive. Final packaging adds this verification evidence and a runtime clarification in setup instructions; the report-processing and bootstrap code are unchanged. The final archive and its complete checksum manifest are independently reverified after packaging.

This was an offline portability/generation test. No source research, emails or schedule changes occurred during packaging. It does not activate another user's account, grant Gmail consent or prove an unattended send under that account. The included historical November report is the actual earlier scheduler-test output, not this synthetic proof.
