"""Synthetic bootstrap tests: temporary packages only; no live baseline writes.

No test invokes the real self-test suite recursively, executes research, sends
mail, reads credentials, or uses a network. Engine calls are deterministic fakes;
workflow generation uses the package's genuine stdlib make_workflow.py.
"""
from __future__ import annotations

from contextlib import contextmanager
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import shutil
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("portable_bootstrap_under_test", ROOT / "bootstrap.py")
bootstrap = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(bootstrap)
WORKFLOW_SPEC = importlib.util.spec_from_file_location("bootstrap_workflow_under_test", ROOT / "recurring-rentcomps" / "make_workflow.py")
workflow = importlib.util.module_from_spec(WORKFLOW_SPEC)
WORKFLOW_SPEC.loader.exec_module(workflow)


class BootstrapTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="rentcomps-bootstrap-test-")
        self.root = Path(self.temp.name)
        # This is a new synthetic byte fixture, never the bundled/live XLSX.
        (self.root / "fixture.bin").write_bytes(b"TEST_NOT_LIVE synthetic baseline fixture")
        self.config = {"baselinePath": "fixture.bin", "baselineSha256": bootstrap.sha256(self.root / "fixture.bin"),
                       "timezone": "America/New_York", "researchBatchSize": 18}
        bootstrap.write_json(self.root / "report_config.json", self.config)
        engine = self.root / "recurring-rentcomps"
        engine.mkdir()
        for name in ("pipeline.py", "prepare_research.py", "make_workflow.py"):
            (engine / name).write_text("# TEST_NOT_LIVE placeholder\n", encoding="utf-8")
        (engine / "research_prompt.txt").write_text("TEST_NOT_LIVE prompt; no research executed", encoding="utf-8")
        self.reseal()

    def tearDown(self):
        self.temp.cleanup()

    def reseal(self):
        self.manifest = {"schemaVersion": 1, "packageId": "synthetic-test-package",
                         "baselineSha256": self.config["baselineSha256"],
                         "files": {p.relative_to(self.root).as_posix(): {"sha256": bootstrap.sha256(p), "size": p.stat().st_size}
                                   for p in sorted(self.root.rglob("*"))
                                   if p.is_file() and p.name != "package_manifest.json"
                                   and not bootstrap.excluded(p.relative_to(self.root).as_posix())}}
        self.save_manifest()

    def save_manifest(self):
        bootstrap.write_json(self.root / "package_manifest.json", self.manifest)

    def update_config(self, **changes):
        self.config.update(changes)
        bootstrap.write_json(self.root / "report_config.json", self.config)
        self.reseal()

    @contextmanager
    def fake_engine(self, count=41, fail=None):
        source_hash = self.config["baselineSha256"]
        def extract(source, output, run_id, day):
            if fail == "extract":
                raise ValueError("synthetic extraction failure")
            output.mkdir()
            result = {"runId": run_id, "runDate": day, "baselineSha256": bootstrap.sha256(source),
                      "propertyCount": count, "expectedObservationCount": count * 2,
                      "expectedRentCellCount": count * 6,
                      "properties": [{"buildingId": str(i), "comps": [{"row": 16}, {"row": 17}]} for i in range(1, count + 1)]}
            bootstrap.write_json(output / "manifest.json", result)
            return result
        def prepare(source, output, run_id, day):
            output.mkdir()
            if fail == "prepare":
                (output / "incomplete.json").write_text("TEST_NOT_LIVE")
                raise ValueError("synthetic prepare failure")
            properties = [{"buildingId": str(i), "metadata": "full envelope"} for i in range(1, count + 1)]
            entries = []
            for i, prop in enumerate(properties, 1):
                file = output / f"property-{i:02d}.json"
                bootstrap.write_json(file, {"runId": run_id, "runDate": day,
                                            "baselineSha256": bootstrap.sha256(source), "property": prop})
                entries.append({"index": i, "buildingId": prop["buildingId"], "path": str(file.resolve())})
            result = {"runId": run_id, "runDate": day, "baselineSha256": bootstrap.sha256(source),
                      "propertyCount": count, "expectedObservationCount": count * 2,
                      "properties": properties, "inputs": entries}
            bootstrap.write_json(output / "research-inputs.json", result)
            return result
        def generate(*args, **kwargs):
            if fail == "generate":
                raise ValueError("synthetic workflow failure")
            return workflow.generate(*args, **kwargs)
        def structural(source, output, day):
            output.mkdir()
            result = {"sourceUnchanged": True, "distributableManifestBlocked": True,
                      "status": "STRUCTURAL PASS ONLY; NOT LIVE RESEARCH", "baselineSha256": source_hash}
            bootstrap.write_json(output / "TEST_NOT_LIVE_verification.json", result)
            return result
        with patch.object(bootstrap, "engine_modules") as manager:
            manager.return_value.__enter__.return_value = {
                "pipeline": SimpleNamespace(extract=extract), "prepare_research": SimpleNamespace(prepare=prepare),
                "make_workflow": SimpleNamespace(generate=generate), "structural_test": SimpleNamespace(run=structural)}
            yield manager

    def test_minimal_verify_and_no_import_or_write(self):
        before = set(self.root.rglob("*"))
        with patch.object(bootstrap, "engine_modules", side_effect=AssertionError("No import during verify")):
            result = bootstrap.verify_package(self.root)
        self.assertEqual(result["status"], "VERIFIED")
        self.assertEqual(result["verifiedFileCount"], len(self.manifest["files"]))
        self.assertEqual(before, set(self.root.rglob("*")))

    def test_missing_file_rejected(self):
        (self.root / "fixture.bin").unlink()
        with self.assertRaisesRegex(bootstrap.BootstrapError, "Missing/unreadable"):
            bootstrap.verify_package(self.root)

    def test_tampered_same_size_hash_rejected(self):
        path = self.root / "fixture.bin"
        path.write_bytes(b"X" * path.stat().st_size)
        with self.assertRaisesRegex(bootstrap.BootstrapError, "SHA-256 mismatch"):
            bootstrap.verify_package(self.root)

    def test_tampered_size_rejected(self):
        (self.root / "fixture.bin").write_bytes(b"short")
        with self.assertRaisesRegex(bootstrap.BootstrapError, "Size mismatch"):
            bootstrap.verify_package(self.root)

    def test_unexpected_file_rejected(self):
        (self.root / "extra.txt").write_text("unexpected")
        with self.assertRaisesRegex(bootstrap.BootstrapError, "Unexpected distribution files: extra.txt"):
            bootstrap.verify_package(self.root)

    def test_exclusion_rules_and_arbitrary_logs_rejected(self):
        for relative in ("runs/old/output.txt", ".venv/lib/x.py", "recurring-rentcomps/__pycache__/x.pyc",
                         "verification-logs/verify-20260101T010101Z-" + "a" * 32 + ".json"):
            path = self.root / relative
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text("generated excluded fixture")
        self.assertEqual(bootstrap.verify_package(self.root)["status"], "VERIFIED")
        (self.root / "verification-logs" / "anything.log").write_text("not excluded")
        with self.assertRaisesRegex(bootstrap.BootstrapError, "Unexpected distribution"):
            bootstrap.verify_package(self.root)

    def test_symlink_file_and_ancestor_rejected(self):
        path = self.root / "fixture.bin"
        path.unlink()
        path.symlink_to(Path(self.temp.name).parent / "outside-missing")
        with self.assertRaisesRegex(bootstrap.BootstrapError, "Symlink prohibited"):
            bootstrap.verify_package(self.root)
        path.unlink()
        path.write_bytes(b"TEST_NOT_LIVE synthetic baseline fixture")
        shutil.rmtree(self.root / "recurring-rentcomps")
        (self.root / "recurring-rentcomps").symlink_to(self.root, target_is_directory=True)
        with self.assertRaisesRegex(bootstrap.BootstrapError, "Symlink prohibited"):
            bootstrap.verify_package(self.root)

    def test_excluded_root_symlink_rejected(self):
        (self.root / "runs").symlink_to(self.root, target_is_directory=True)
        with self.assertRaisesRegex(bootstrap.BootstrapError, "Symlink prohibited"):
            bootstrap.verify_package(self.root)

    def test_unsafe_manifest_paths_rejected(self):
        original = dict(self.manifest["files"])
        for name in ("../outside", "/outside", "a/../outside", "a//b", "a/./b", "a\\b", "C:/file", "x\nfile"):
            with self.subTest(name=name):
                self.manifest["files"] = dict(original)
                self.manifest["files"][name] = {"sha256": "a" * 64, "size": 0}
                self.save_manifest()
                with self.assertRaisesRegex(bootstrap.BootstrapError, "Unsafe relative path"):
                    bootstrap.verify_package(self.root)

    def test_self_and_excluded_manifest_entries_rejected(self):
        original = dict(self.manifest["files"])
        for name in ("package_manifest.json", "runs/generated.json", "__pycache__/x.pyc"):
            with self.subTest(name=name):
                self.manifest["files"] = dict(original)
                self.manifest["files"][name] = {"sha256": "a" * 64, "size": 0}
                self.save_manifest()
                with self.assertRaisesRegex(bootstrap.BootstrapError, "Excluded/self-referential"):
                    bootstrap.verify_package(self.root)

    def test_manifest_schema_and_types_rejected(self):
        for field, value in (("schemaVersion", 2), ("schemaVersion", True), ("packageId", ""),
                             ("files", []), ("baselineSha256", "bad")):
            with self.subTest(field=field, value=value):
                self.reseal()
                self.manifest[field] = value
                self.save_manifest()
                with self.assertRaises(bootstrap.BootstrapError):
                    bootstrap.verify_package(self.root)

    def test_config_hash_mismatch_and_unlisted_baseline_rejected(self):
        self.update_config(baselineSha256="f" * 64)
        with self.assertRaisesRegex(bootstrap.BootstrapError, "Baseline SHA-256 mismatch"):
            bootstrap.verify_package(self.root)
        self.config["baselineSha256"] = bootstrap.sha256(self.root / "fixture.bin")
        self.update_config(baselinePath="absent.bin")
        with self.assertRaisesRegex(bootstrap.BootstrapError, "must be manifest-listed"):
            bootstrap.verify_package(self.root)

    def test_duplicate_json_keys_rejected(self):
        (self.root / "package_manifest.json").write_text('{"schemaVersion":1,"schemaVersion":1}')
        with self.assertRaisesRegex(bootstrap.BootstrapError, "Duplicate JSON key"):
            bootstrap.verify_package(self.root)

    def test_invalid_entry_metadata(self):
        for changes in ({"size": True}, {"size": -1}, {"sha256": "x" * 64}):
            with self.subTest(changes=changes):
                self.reseal()
                self.manifest["files"]["fixture.bin"].update(changes)
                self.save_manifest()
                with self.assertRaises(bootstrap.BootstrapError):
                    bootstrap.verify_package(self.root)

    def test_prepare_verifies_before_import_and_creation(self):
        (self.root / "extra.txt").write_text("unexpected")
        with self.fake_engine() as manager:
            with self.assertRaisesRegex(bootstrap.BootstrapError, "Unexpected distribution"):
                bootstrap.prepare_run(self.root)
            manager.assert_not_called()
        self.assertFalse((self.root / "runs").exists())

    def test_prepare_full_envelope_batches_final_absolute_paths_and_unique_ids(self):
        before = bootstrap.sha256(self.root / "fixture.bin")
        with self.fake_engine():
            one = bootstrap.prepare_run(self.root)
            two = bootstrap.prepare_run(self.root)
        self.assertNotEqual(one["runId"], two["runId"])
        self.assertEqual(one["status"], "PREPARED_NOT_RESEARCHED")
        self.assertFalse(one["researchExecuted"])
        self.assertEqual([batch["propertyCount"] for batch in one["batches"]], [18, 18, 5])
        self.assertEqual(one["runDate"], bootstrap.local_day(self.config))
        batch_list = bootstrap.read_json(one["batchList"]["path"])
        self.assertEqual(batch_list["batches"], one["batches"])
        self.assertEqual(batch_list["status"], "PREPARED_NOT_RESEARCHED")
        self.assertEqual(one["batchList"]["sha256"], bootstrap.sha256(one["batchList"]["path"]))
        full = bootstrap.read_json(one["researchInputs"]["path"])
        covered = []
        for batch in one["batches"]:
            subset = bootstrap.read_json(batch["researchInputs"]["path"])
            self.assertEqual(subset["properties"], full["properties"])
            for key in ("runId", "runDate", "baselineSha256", "propertyCount", "expectedObservationCount"):
                self.assertEqual(subset[key], full[key])
            covered.extend(subset["inputs"])
            params = bootstrap.read_json(batch["workflowParams"]["path"])
            self.assertEqual(params["max_agent_calls"], len(subset["inputs"]))
            self.assertFalse(Path(batch["expectedResultPath"]).exists())
            self.assertIn("research-results", batch["expectedResultPath"])
            for item in subset["inputs"]:
                path = Path(item["path"])
                self.assertTrue(path.is_absolute() and path.is_file())
                self.assertTrue(path.is_relative_to(Path(one["runDirectory"])))
                self.assertNotIn(".prepare-stage-", str(path))
                self.assertIn(item["path"], params["script"])
        self.assertEqual(covered, full["inputs"])
        self.assertEqual(before, bootstrap.sha256(self.root / "fixture.bin"))
        for record in one["artifacts"]:
            self.assertEqual(record["sha256"], bootstrap.sha256(record["path"]))
        self.assertEqual(bootstrap.verify_package(self.root)["status"], "VERIFIED")

    def test_default_batch_size(self):
        del self.config["researchBatchSize"]
        bootstrap.write_json(self.root / "report_config.json", self.config)
        self.reseal()
        with self.fake_engine(count=20):
            result = bootstrap.prepare_run(self.root)
        self.assertEqual([batch["propertyCount"] for batch in result["batches"]], [18, 2])

    def test_invalid_batch_or_timezone_has_no_run(self):
        for value in (0, -1, True, "18", 1001):
            with self.subTest(value=value):
                self.update_config(researchBatchSize=value)
                with self.assertRaisesRegex(bootstrap.BootstrapError, "researchBatchSize"):
                    bootstrap.prepare_run(self.root)
        self.update_config(researchBatchSize=18, timezone="Invalid/Zone")
        with self.assertRaisesRegex(bootstrap.BootstrapError, "Timezone"):
            bootstrap.prepare_run(self.root)
        self.assertFalse((self.root / "runs").exists())

    def test_explicit_override_reinventories_and_never_overwrites(self):
        with tempfile.TemporaryDirectory(prefix="rentcomps-approved-override-") as temporary:
            override = Path(temporary) / "TEST_NOT_LIVE_override.bin"
            override.write_bytes(b"different synthetic approved workbook")
            original = override.read_bytes()
            with self.fake_engine(count=2):
                result = bootstrap.prepare_run(self.root, override)
            self.assertTrue(result["workbookOverrideExplicit"])
            self.assertEqual(result["baselineSha256"], bootstrap.sha256(override))
            self.assertNotEqual(result["baselineSha256"], result["packagedBaselineSha256"])
            self.assertEqual(override.read_bytes(), original)
            self.assertEqual(result["workbookPath"], str(override.resolve()))

    def test_atomic_cleanup_on_each_preparation_failure(self):
        for failure in ("extract", "prepare", "generate"):
            with self.subTest(failure=failure), self.fake_engine(fail=failure):
                with self.assertRaisesRegex(ValueError, "synthetic"):
                    bootstrap.prepare_run(self.root)
                self.assertEqual(list((self.root / "runs").iterdir()), [])

    def test_import_origin_and_dependency_errors(self):
        sentinel = SimpleNamespace(__file__="outside/pipeline.py")
        with patch.dict(sys.modules, {"pipeline": sentinel}):
            with bootstrap.engine_modules(self.root) as modules:
                self.assertEqual(Path(modules["pipeline"].__file__).resolve().parent, self.root / "recurring-rentcomps")
                self.assertIsNot(modules["pipeline"], sentinel)
            self.assertIs(sys.modules["pipeline"], sentinel)
        (self.root / "recurring-rentcomps" / "pipeline.py").write_text("import intentionally_missing_bootstrap_dependency_928347\n")
        with self.assertRaisesRegex(bootstrap.BootstrapError, "Receiving agent must install"):
            with bootstrap.engine_modules(self.root):
                pass

    def test_python310_digest_adapter(self):
        expected = hashlib.sha256(b"TEST_NOT_LIVE").hexdigest()
        self.assertEqual(bootstrap._file_digest_310(io.BytesIO(b"TEST_NOT_LIVE"), "sha256").hexdigest(), expected)
        original = getattr(hashlib, "file_digest", None)
        if original is not None:
            del hashlib.file_digest
        try:
            with bootstrap.engine_modules(self.root):
                self.assertEqual(hashlib.file_digest(io.BytesIO(b"TEST_NOT_LIVE"), "sha256").hexdigest(), expected)
            self.assertFalse(hasattr(hashlib, "file_digest"))
        finally:
            if original is not None:
                hashlib.file_digest = original

    def test_unique_run_collision_does_not_overwrite(self):
        existing = self.root / "runs" / ("test-" + "a" * 32)
        existing.mkdir(parents=True)
        (existing / "keep.txt").write_text("retain existing run")
        ids = [SimpleNamespace(hex="a" * 32), SimpleNamespace(hex="b" * 32)]
        with patch.object(bootstrap.uuid, "uuid4", side_effect=ids):
            run_id, target = bootstrap.reserve_run(self.root, "test")
        self.assertEqual(run_id, "test-" + "b" * 32)
        self.assertTrue(target.is_dir())
        self.assertEqual((existing / "keep.txt").read_text(), "retain existing run")

    def test_synthetic_selftest_with_suite_runner_mock_no_recursion(self):
        suites = {"engine": {"passed": True, "testsRun": 1, "skipped": []},
                  "setup": {"passed": True, "testsRun": 1, "skipped": []}}
        before = bootstrap.sha256(self.root / "fixture.bin")
        with self.fake_engine(), patch.object(bootstrap, "run_unit_suites", return_value=suites) as runner:
            result = bootstrap.self_test(self.root)
        runner.assert_called_once()
        self.assertEqual(result["status"], "TEST_NOT_LIVE_PASS")
        self.assertIn("TEST_NOT_LIVE", result["runDirectory"])
        self.assertFalse(result["sendExecuted"])
        self.assertFalse(result["researchExecuted"])
        self.assertEqual(before, bootstrap.sha256(self.root / "fixture.bin"))
        self.assertTrue(Path(result["summaryPath"]).is_file())

    def test_selftest_failure_cleans_completion(self):
        suites = {"engine": {"passed": False}, "setup": {"passed": True}}
        with self.fake_engine(), patch.object(bootstrap, "run_unit_suites", return_value=suites):
            with self.assertRaisesRegex(bootstrap.BootstrapError, "unit suite failed"):
                bootstrap.self_test(self.root)
        self.assertEqual(list((self.root / "runs").iterdir()), [])

    def test_cli_verify_logs_and_package_root_option_positions(self):
        for args in (["--package-root", str(self.root), "verify"], ["verify", "--package-root", str(self.root)]):
            with patch("sys.stdout", new_callable=io.StringIO) as output:
                code = bootstrap.main(args)
            self.assertEqual(code, 0)
            result = json.loads(output.getvalue())
            self.assertTrue(Path(result["verificationLog"]).is_file())
        self.assertEqual(bootstrap.verify_package(self.root)["status"], "VERIFIED")

    def test_cli_rejects_date_override(self):
        with patch("sys.stderr", new_callable=io.StringIO):
            with self.assertRaises(SystemExit) as error:
                bootstrap.main(["prepare", "--run-date", "2099-01-01"])
        self.assertEqual(error.exception.code, 2)

    def test_cli_rejection_is_not_completion(self):
        (self.root / "fixture.bin").unlink()
        with patch("sys.stderr", new_callable=io.StringIO) as output:
            code = bootstrap.main(["verify", "--package-root", str(self.root)])
        self.assertEqual(code, 1)
        result = json.loads(output.getvalue())
        self.assertEqual(result["status"], "REJECTED")
        self.assertFalse(result["completeRunPublished"])
        self.assertFalse((self.root / "verification-logs").exists())


if __name__ == "__main__":
    unittest.main()
