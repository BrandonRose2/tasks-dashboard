#!/usr/bin/env python3
"""Offline ApartmentCorp rent-comps package bootstrap (Python >= 3.10).

Distribution verification rules (also returned by `verify`):
* package_manifest.json is the sole self-excluded distribution file; it is not
  a signature, and its hash must be authenticated separately by the recipient.
* Every other regular file must be listed, except files under directory
  components named __pycache__ or .venv, the root runs/ tree, and root
  verification-logs/verify-YYYYMMDDTHHMMSSZ-<32 lowercase hex>.json files.
* Excluded trees are not traversed. Symlinks at their roots are still rejected.
  All symlinks and nonregular filesystem objects in the traversed tree fail.
* Listed paths use canonical relative POSIX spelling: no empty/dot/dot-dot
  components, backslashes, colons, control characters or absolute paths.
  Excluded paths cannot be listed; listed files and ancestors cannot be symlinks.
* report_config.json and its relative baselinePath must be listed. The baseline
  hash must equal both baselineSha256 fields and its file entry's sha256.

No credentials, network calls, dependency installation, scheduling, research
execution or sending. Generated workflows require explicit receiving-agent tool
execution. Self-test artifacts are synthetic, TEST_NOT_LIVE, never distributable.
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
import copy
from datetime import datetime, timezone
import hashlib
import importlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import sys
import tempfile
import unittest
import uuid
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

MANIFEST_NAME = "package_manifest.json"
CONFIG_NAME = "report_config.json"
LOG_PATTERN = re.compile(r"verify-\d{8}T\d{6}Z-[0-9a-f]{32}\.json")
HASH_PATTERN = re.compile(r"[0-9a-f]{64}")
VERIFICATION_RULES = {
    "manifestSelfExcluded": MANIFEST_NAME,
    "excludedDirectoryComponents": ["__pycache__", ".venv"],
    "excludedRootTrees": ["runs"],
    "excludedVerificationLogs": "verification-logs/verify-YYYYMMDDTHHMMSSZ-<32 lowercase hex>.json",
    "symlinks": "Rejected in traversed tree, including excluded directory roots; excluded contents are not traversed.",
    "paths": "Canonical relative POSIX paths only; no empty, dot, dot-dot, backslash, colon or control characters.",
    "trust": "Manifest is an integrity inventory, not an authenticated signature; authenticate its checksum separately.",
}


class BootstrapError(ValueError):
    """A rejected package or incomplete offline bootstrap operation."""


def require(condition, message):
    if not condition:
        raise BootstrapError(message)


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_json(path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, f"Duplicate JSON key: {key}")
            result[key] = value
        return result
    try:
        with Path(path).open(encoding="utf-8") as stream:
            return json.load(stream, object_pairs_hook=unique,
                             parse_constant=lambda x: (_ for _ in ()).throw(BootstrapError(f"Nonfinite JSON: {x}")))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise BootstrapError(f"Cannot read JSON {path}: {exc}") from exc


def write_json(path, data):
    Path(path).write_text(json.dumps(data, indent=2, ensure_ascii=False, allow_nan=False) + "\n", encoding="utf-8")


def relative_parts(relative):
    require(isinstance(relative, str) and relative, "File path must be a nonempty string")
    require(not relative.startswith("/") and "\\" not in relative and ":" not in relative
            and not any(ord(c) < 32 or ord(c) == 127 for c in relative), f"Unsafe relative path: {relative!r}")
    parts = relative.split("/")
    require(all(p not in ("", ".", "..") for p in parts)
            and str(PurePosixPath(relative)) == relative, f"Unsafe relative path: {relative!r}")
    return parts


def excluded(relative):
    parts = relative.split("/")
    return (any(p in ("__pycache__", ".venv") for p in parts[:-1])
            or parts[0] == "runs"
            or (len(parts) == 2 and parts[0] == "verification-logs" and bool(LOG_PATTERN.fullmatch(parts[1]))))


def package_root(value=None):
    path = Path(value) if value is not None else Path(__file__).parent
    require(not path.is_symlink(), f"Package root cannot be a symlink: {path}")
    path = path.resolve()
    require(path.is_dir(), f"Package root is not a directory: {path}")
    return path


def safe_file(root, relative):
    parts = relative_parts(relative)
    path = root
    for index, part in enumerate(parts):
        path = path / part
        try:
            mode = path.lstat().st_mode
        except OSError as exc:
            raise BootstrapError(f"Missing/unreadable package path {relative}: {exc}") from exc
        require(not stat.S_ISLNK(mode), f"Symlink prohibited: {relative}")
        if index < len(parts) - 1:
            require(stat.S_ISDIR(mode), f"Ancestor is not a directory: {relative}")
        else:
            require(stat.S_ISREG(mode), f"Not a regular file: {relative}")
    require(path.resolve().is_relative_to(root), f"Path escapes package root: {relative}")
    return path


def regular_distribution_files(root):
    found = set()
    def walk(directory):
        for path in sorted(directory.iterdir()):
            relative = path.relative_to(root).as_posix()
            mode = path.lstat().st_mode
            require(not stat.S_ISLNK(mode), f"Symlink prohibited: {relative}")
            if stat.S_ISDIR(mode):
                if path.name in ("__pycache__", ".venv") or relative == "runs":
                    continue
                walk(path)
            else:
                require(stat.S_ISREG(mode), f"Nonregular distribution object: {relative}")
                if relative != MANIFEST_NAME and not excluded(relative):
                    found.add(relative)
    walk(root)
    return found


def verify_package(root):
    """Verify without writing logs or importing third-party modules."""
    root = package_root(root)
    manifest = read_json(safe_file(root, MANIFEST_NAME))
    require(isinstance(manifest, dict), "Package manifest must be an object")
    require(type(manifest.get("schemaVersion")) is int and manifest["schemaVersion"] == 1,
            "Unsupported package manifest schemaVersion; expected 1")
    require(isinstance(manifest.get("packageId"), str) and manifest["packageId"].strip(), "Missing packageId")
    files = manifest.get("files")
    require(isinstance(files, dict) and files, "Manifest files must be a nonempty object")
    baseline_hash = manifest.get("baselineSha256")
    require(isinstance(baseline_hash, str) and bool(HASH_PATTERN.fullmatch(baseline_hash)), "Invalid manifest baselineSha256")
    for relative, entry in files.items():
        relative_parts(relative)
        require(relative != MANIFEST_NAME and not excluded(relative), f"Excluded/self-referential manifest entry: {relative}")
        require(isinstance(entry, dict), f"Invalid manifest entry: {relative}")
        require(type(entry.get("size")) is int and entry["size"] >= 0, f"Invalid size: {relative}")
        require(isinstance(entry.get("sha256"), str) and bool(HASH_PATTERN.fullmatch(entry["sha256"])), f"Invalid sha256: {relative}")
        path = safe_file(root, relative)
        require(path.stat().st_size == entry["size"], f"Size mismatch: {relative}")
        require(sha256(path) == entry["sha256"], f"SHA-256 mismatch: {relative}")
    unexpected = regular_distribution_files(root) - set(files)
    require(not unexpected, "Unexpected distribution files: " + ", ".join(sorted(unexpected)))
    require(CONFIG_NAME in files, "report_config.json must be manifest-listed")
    config = read_json(safe_file(root, CONFIG_NAME))
    require(isinstance(config, dict), "report_config.json must be an object")
    baseline_relative = config.get("baselinePath")
    relative_parts(baseline_relative)
    require(baseline_relative in files, "Config baselinePath must be manifest-listed")
    require(config.get("baselineSha256") == baseline_hash == files[baseline_relative]["sha256"],
            "Baseline SHA-256 mismatch between manifest, config and file entry")
    baseline = safe_file(root, baseline_relative)
    return {"status": "VERIFIED", "packageId": manifest["packageId"], "packageRoot": str(root),
            "manifestSha256": sha256(root / MANIFEST_NAME), "baselineSha256": baseline_hash,
            "baselinePath": str(baseline), "verifiedFileCount": len(files),
            "verificationRules": VERIFICATION_RULES}


def local_day(config):
    name = config.get("timezone")
    require(isinstance(name, str) and name, "Config timezone must be an IANA name, e.g. America/New_York")
    try:
        return datetime.now(ZoneInfo(name)).date().isoformat()
    except (ZoneInfoNotFoundError, ValueError) as exc:
        raise BootstrapError(f"Timezone {name!r} is unavailable. Install system IANA timezone data (or tzdata in the receiving environment); no installation was attempted.") from exc


def batch_size(config):
    value = config.get("researchBatchSize", 18)
    require(type(value) is int and 1 <= value <= 1000, "researchBatchSize must be an integer from 1 to 1000")
    return value


def _file_digest_310(stream, algorithm):
    """Compatibility adapter for the unchanged engine's Python 3.11 helper."""
    digest = hashlib.new(algorithm)
    for chunk in iter(lambda: stream.read(1024 * 1024), b""):
        digest.update(chunk)
    return digest


@contextmanager
def engine_modules(root, structural=False):
    """Import verified modules from this package only; restore caller state."""
    engine = root / "recurring-rentcomps"
    names = {p.stem for p in engine.glob("*.py")} | {p.stem for p in (engine / "tests").glob("*.py")}
    required = ("pipeline.py", "prepare_research.py", "make_workflow.py", "research_prompt.txt")
    if structural:
        required += ("structural_test.py", "tests/test_pipeline.py")
    for relative in required:
        safe_file(root, "recurring-rentcomps/" + relative)
    saved_modules = {name: sys.modules[name] for name in names if name in sys.modules}
    saved_path = sys.path[:]
    had_digest = hasattr(hashlib, "file_digest")
    try:
        for name in names:
            sys.modules.pop(name, None)
        sys.path[:0] = [str(engine), str(engine / "tests")]
        if not had_digest:
            hashlib.file_digest = _file_digest_310
        importlib.invalidate_caches()
        try:
            modules = {name: importlib.import_module(name) for name in ("pipeline", "prepare_research", "make_workflow")}
            if structural:
                modules["structural_test"] = importlib.import_module("structural_test")
        except ModuleNotFoundError as exc:
            raise BootstrapError(f"Missing module {exc.name!r}. Receiving agent must install recurring-rentcomps/requirements.txt with this Python environment (e.g. python -m pip install -r requirements.txt) before retrying. No dependency installation or network was attempted.") from exc
        except ImportError as exc:
            raise BootstrapError(f"Engine dependency import failed: {exc}. Check Python >= 3.10 and recurring-rentcomps/requirements.txt in the receiving environment.") from exc
        for name, module in modules.items():
            require(Path(module.__file__).resolve().parent == engine, f"Engine import escaped package root: {name}")
        yield modules
    finally:
        sys.path[:] = saved_path
        for name in names:
            sys.modules.pop(name, None)
        sys.modules.update(saved_modules)
        if not had_digest and hasattr(hashlib, "file_digest"):
            del hashlib.file_digest


def reserve_run(root, prefix):
    runs = root / "runs"
    require(not runs.is_symlink(), "runs/ cannot be a symlink")
    runs.mkdir(exist_ok=True)
    require(runs.is_dir(), "runs/ must be a directory")
    for _ in range(10):
        run_id = prefix + "-" + uuid.uuid4().hex
        target = runs / run_id
        try:
            target.mkdir()
            return run_id, target
        except FileExistsError:
            continue
    raise BootstrapError("Cannot reserve a unique run directory; no existing run was overwritten")


def artifact_record(path, final_path=None):
    return {"path": str(final_path or path), "sha256": sha256(path), "size": path.stat().st_size}


def publish_stage(stage, target):
    require(target.is_dir() and not target.is_symlink() and not any(target.iterdir()), "Reserved run target changed; publication rejected")
    os.replace(stage, target)


def prepare_run(root, workbook=None):
    verified = verify_package(root)  # Must precede imports and all run creation.
    root = Path(verified["packageRoot"])
    config = read_json(root / CONFIG_NAME)
    day = local_day(config)
    size = batch_size(config)
    source = Path(verified["baselinePath"])
    override = workbook is not None
    if override:
        supplied = Path(workbook).expanduser()
        require(not supplied.is_symlink(), "Workbook override cannot be a symlink")
        source = supplied.resolve()
        require(source.is_file(), f"Approved --workbook override is not a regular file: {source}")
    source_hash = sha256(source)
    with engine_modules(root) as modules:
        pipeline = modules["pipeline"]
        run_id, target = reserve_run(root, "rentcomps-" + day)
        stage = None
        published = False
        try:
            stage = Path(tempfile.mkdtemp(prefix=".prepare-stage-", dir=target.parent))
            manifest = pipeline.extract(source, stage / "extract", run_id, day)
            data = modules["prepare_research"].prepare(source, stage / "research-inputs", run_id, day)
            for key in ("runId", "runDate", "baselineSha256", "propertyCount", "expectedObservationCount"):
                require(data[key] == manifest[key], f"Research inputs/canonical manifest disagree: {key}")
            require(len(data["inputs"]) == manifest["propertyCount"] and manifest["baselineSha256"] == source_hash,
                    "Source inventory/hash changed during preparation")
            # Prepare emits staging absolute paths. Regenerate declarations for the
            # final environment before generating any workflow; never reuse paths
            # embedded in the transferred reference outputs.
            for item in data["inputs"]:
                relative = Path(item["path"]).relative_to(stage)
                require((stage / relative).is_file(), "Declared property input missing")
                item["path"] = str(target / relative)
            inputs_path = stage / "research-inputs" / "research-inputs.json"
            write_json(inputs_path, data)
            workflows = stage / "workflows"
            workflows.mkdir()
            prompt = root / "recurring-rentcomps" / "research_prompt.txt"
            full_path = workflows / "full-workflow.js"
            require(modules["make_workflow"].generate(inputs_path, prompt, full_path) == manifest["propertyCount"],
                    "Full workflow coverage mismatch")
            batches = []
            for offset in range(0, len(data["inputs"]), size):
                index = len(batches) + 1
                subset = copy.deepcopy(data)  # Keep full canonical envelope/counts/properties.
                subset["inputs"] = data["inputs"][offset:offset + size]
                subset_path = workflows / f"batch-{index:03d}.research-inputs.json"
                write_json(subset_path, subset)
                workflow_path = workflows / f"batch-{index:03d}.js"
                count = modules["make_workflow"].generate(subset_path, prompt, workflow_path)
                require(count == len(subset["inputs"]) and count <= size, "Batch workflow size mismatch")
                def record(path):
                    return artifact_record(path, target / path.relative_to(stage))
                batches.append({"batchIndex": index, "propertyCount": count,
                                "firstInputIndex": subset["inputs"][0]["index"], "lastInputIndex": subset["inputs"][-1]["index"],
                                "buildingIds": [item["buildingId"] for item in subset["inputs"]],
                                "researchInputs": record(subset_path), "workflowScript": record(workflow_path),
                                "workflowParams": record(workflow_path.with_suffix(".params.json")),
                                "expectedResultPath": str(target / "research-results" / f"batch-{index:03d}.result.json")})
            require(sha256(source) == source_hash, "Input workbook changed during preparation; no run published")
            def record(path):
                return artifact_record(path, target / path.relative_to(stage))
            batch_list_path = stage / "batch-list.json"
            write_json(batch_list_path, {
                "status": "PREPARED_NOT_RESEARCHED", "researchExecuted": False,
                "runId": run_id, "runDate": day, "baselineSha256": source_hash,
                "propertyCount": manifest["propertyCount"], "expectedObservationCount": manifest["expectedObservationCount"],
                "researchBatchSize": size, "batchCount": len(batches),
                "executionOrder": "Sequential by batchIndex; do not execute the full workflow as well.",
                "batches": batches,
            })
            summary = {"status": "PREPARED_NOT_RESEARCHED", "researchExecuted": False,
                       "sendExecuted": False, "scheduleCreated": False, "packageId": verified["packageId"],
                       "packageManifestSha256": verified["manifestSha256"], "runId": run_id, "runDate": day,
                       "timezone": config["timezone"], "runDirectory": str(target), "workbookPath": str(source),
                       "workbookOverrideExplicit": override, "baselineSha256": source_hash,
                       "packagedBaselineSha256": verified["baselineSha256"], "propertyCount": manifest["propertyCount"],
                       "expectedObservationCount": manifest["expectedObservationCount"],
                       "expectedRentCellCount": manifest["expectedRentCellCount"], "researchBatchSize": size,
                       "batchCount": len(batches), "batchExecutionOrder": "Sequential by batchIndex; receiving agent executes workflowParams via authorized tools. Full workflow is inventory, not the batched execution plan.",
                       "canonicalManifest": record(stage / "extract" / "manifest.json"), "researchInputs": record(inputs_path),
                       "fullWorkflowScript": record(full_path), "fullWorkflowParams": record(full_path.with_suffix(".params.json")),
                       "batchList": record(batch_list_path), "researchResultsDirectory": str(target / "research-results"),
                       "batches": batches, "summaryPath": str(target / "preparation-summary.json")}
            # Hash every prepared payload, including individual property files.
            summary["artifacts"] = [record(path) for path in sorted(stage.rglob("*")) if path.is_file()]
            write_json(stage / "preparation-summary.json", summary)
            publish_stage(stage, target)
            published = True
            return summary
        finally:
            if stage is not None and stage.exists():
                shutil.rmtree(stage)
            if not published and target.exists() and not target.is_symlink() and not any(target.iterdir()):
                target.rmdir()


def run_unit_suites(root, stream):
    """Separate discovery roots; setup tests never invoke real self-test recursively."""
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(
        unittest.TestLoader().discover(str(root / "recurring-rentcomps" / "tests")))
    setup_result = unittest.TextTestRunner(stream=stream, verbosity=2).run(
        unittest.TestLoader().discover(str(root / "setup-tests")))
    def details(item):
        return {"testsRun": item.testsRun, "failures": len(item.failures), "errors": len(item.errors),
                "skipped": [{"test": str(test), "reason": reason} for test, reason in item.skipped],
                "passed": item.wasSuccessful()}
    return {"engine": details(result), "setup": details(setup_result)}


def self_test(root):
    verified = verify_package(root)
    root = Path(verified["packageRoot"])
    config = read_json(root / CONFIG_NAME)
    day = local_day(config)
    source = Path(verified["baselinePath"])
    source_hash = sha256(source)
    with engine_modules(root, structural=True) as modules:
        run_id, target = reserve_run(root, "TEST_NOT_LIVE-" + day)
        stage = None
        published = False
        try:
            stage = Path(tempfile.mkdtemp(prefix=".self-test-stage-", dir=target.parent))
            log = io.StringIO()
            suites = run_unit_suites(root, log)
            (stage / "TEST_NOT_LIVE_unittest.log").write_text(log.getvalue(), encoding="utf-8")
            # Completion is not published unless all mandatory checks pass.
            require(all(value["passed"] for value in suites.values()), "Self-test unit suite failed:\n" + log.getvalue())
            structural = modules["structural_test"].run(source, stage / "TEST_NOT_LIVE_structural", day)
            require(sha256(source) == source_hash, "Self-test modified baseline; rejected")
            require(structural.get("sourceUnchanged") and structural.get("distributableManifestBlocked"),
                    "Synthetic structural safety check failed")
            summary = {"status": "TEST_NOT_LIVE_PASS", "label": "TEST — NOT LIVE RESEARCH",
                       "researchExecuted": False, "sendExecuted": False, "scheduleCreated": False,
                       "runId": run_id, "runDate": day, "timezone": config["timezone"],
                       "baselineSha256": source_hash, "sourceUnchanged": True,
                       "packageManifestSha256": verified["manifestSha256"], "unitSuites": suites,
                       "structuralResult": structural, "runDirectory": str(target),
                       "summaryPath": str(target / "TEST_NOT_LIVE_summary.json"),
                       "artifacts": [artifact_record(p, target / p.relative_to(stage)) for p in sorted(stage.rglob("*")) if p.is_file()]}
            write_json(stage / "TEST_NOT_LIVE_summary.json", summary)
            publish_stage(stage, target)
            published = True
            return summary
        finally:
            if stage is not None and stage.exists():
                shutil.rmtree(stage)
            if not published and target.exists() and not target.is_symlink() and not any(target.iterdir()):
                target.rmdir()


def verification_log(root, result):
    directory = root / "verification-logs"
    require(not directory.is_symlink(), "verification-logs/ cannot be a symlink")
    directory.mkdir(exist_ok=True)
    name = "verify-" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + uuid.uuid4().hex + ".json"
    target = directory / name
    descriptor, temp_name = tempfile.mkstemp(prefix=".verify-stage-", dir=directory)
    os.close(descriptor)
    temporary = Path(temp_name)
    try:
        write_json(temporary, result)
        require(not target.exists(), "Verification log collision")
        os.replace(temporary, target)
    finally:
        temporary.unlink(missing_ok=True)
    return str(target)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--package-root", type=Path, default=None, help="Defaults to bootstrap.py's directory; may also follow the command")
    commands = parser.add_subparsers(dest="command", required=True)
    for name, help_text in (("verify", "Verify the complete distribution integrity inventory"),
                            ("prepare", "Prepare workflows only; never execute research"),
                            ("self-test", "Offline synthetic unit and full-baseline structural tests")):
        command = commands.add_parser(name, help=help_text)
        command.add_argument("--package-root", type=Path, default=argparse.SUPPRESS)
        if name == "prepare":
            command.add_argument("--workbook", type=Path, help="Explicit approved input override; re-inventoried, never overwritten")
    args = parser.parse_args(argv)
    try:
        require(sys.version_info >= (3, 10), "Python >= 3.10 is required")
        root = package_root(args.package_root)
        if args.command == "verify":
            result = verify_package(root)
            result["verificationLog"] = verification_log(root, result)
        elif args.command == "prepare":
            result = prepare_run(root, args.workbook)
        else:
            result = self_test(root)
        print(json.dumps(result, indent=2, ensure_ascii=False, allow_nan=False))
        return 0
    except Exception as exc:
        # Engine validation/dependency failures must not produce a success marker.
        print(json.dumps({"status": "REJECTED", "command": args.command, "error": str(exc),
                          "errorType": type(exc).__name__, "researchExecuted": False, "sendExecuted": False,
                          "scheduleCreated": False, "completeRunPublished": False}, indent=2), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
