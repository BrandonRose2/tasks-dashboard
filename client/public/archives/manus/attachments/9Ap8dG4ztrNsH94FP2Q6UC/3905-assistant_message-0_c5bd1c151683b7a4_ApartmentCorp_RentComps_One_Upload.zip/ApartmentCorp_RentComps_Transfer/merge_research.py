#!/usr/bin/env python3
"""Merge declared research results only; no research, evidence creation or sending."""
from __future__ import annotations
import argparse
import copy
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'recurring-rentcomps'))
from integrate_results import integrate


def reject_duplicates(pairs):
    result = {}
    for k, v in pairs:
        if k in result:
            raise ValueError(f'Duplicate JSON key: {k}')
        result[k] = v
    return result


def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8'), object_pairs_hook=reject_duplicates)


def merge(manifest, batches, recoveries=()):
    envelope = {k: manifest[k] for k in ('runId', 'runDate', 'baselineSha256')}
    refs = {p['buildingId']: p for p in manifest['properties']}
    aliases = {alias: p['buildingId'] for p in manifest['properties']
               for alias in (p['buildingId'], p['sheetName'])}
    found, failures, original_failures = {}, {}, []

    def check_envelope(result):
        for k, v in envelope.items():
            if result.get(k) != v:
                raise ValueError(f'Batch envelope mismatch: {k}')
        if not isinstance(result.get('properties'), list):
            raise ValueError('Batch must contain a properties array')

    def canonical_id(value):
        if value not in aliases:
            raise ValueError(f'Unknown property identity: {value}')
        return aliases[value]

    def gaps_for(prop):
        ref = refs[prop['buildingId']]
        small = {**manifest, 'properties': [ref]}
        try:
            _, gaps = integrate(small, {**envelope, 'properties': [prop], 'failures': []})
            return gaps
        except (ValueError, KeyError, TypeError) as exc:
            return [{'buildingId': prop['buildingId'], 'error': str(exc)}]

    for recovering, results in ((False, batches), (True, recoveries)):
        for result in results:
            check_envelope(result)
            seen = set()
            for prop in result['properties']:
                prop = copy.deepcopy(prop)
                identity = canonical_id(prop['buildingId'])
                prop['buildingId'] = identity
                if identity in seen:
                    raise ValueError(f'Duplicate property in batch: {identity}')
                seen.add(identity)
                if identity in found:
                    if not recovering:
                        raise ValueError(f'Property repeated across original batches: {identity}')
                    if identity not in failures and not gaps_for(found[identity]):
                        raise ValueError(f'Recovery cannot replace successful property: {identity}')
                found[identity] = prop
                if not gaps_for(prop):
                    failures.pop(identity, None)
            for failure in result.get('failures', []):
                failure = copy.deepcopy(failure)
                identity = canonical_id(failure['buildingId'])
                failure['buildingId'] = identity
                failures[identity] = failure
                original_failures.append(failure)

    missing = sorted(set(refs) - set(found))
    gaps = [gap for prop in found.values() for gap in gaps_for(prop)]
    output = {**envelope, 'properties': [found[p['buildingId']] for p in manifest['properties']
                                       if p['buildingId'] in found],
              'failures': [failures[k] for k in sorted(failures)]}
    summary = {'status': 'COMPLETE_FOR_REVIEW' if not missing and not gaps and not failures
               else 'INCOMPLETE_NOT_FOR_BUILD', 'missingProperties': missing,
               'coverageGaps': gaps, 'unresolvedFailures': output['failures'],
               'originalFailureHistory': original_failures,
               'researchPerformedByThisUtility': False, 'evidenceInvented': False}
    return output, summary


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--manifest', type=Path, required=True)
    p.add_argument('--batch', type=Path, action='append', required=True)
    p.add_argument('--recovery', type=Path, action='append', default=[])
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    out, summary = merge(read_json(args.manifest), [read_json(f) for f in args.batch],
                         [read_json(f) for f in args.recovery])
    diag = args.output.with_suffix('.merge-summary.json')
    if args.output.exists() or diag.exists():
        raise ValueError('Use a new output path; original results are never overwritten')
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(out, indent=2, ensure_ascii=False) + '\n')
    diag.write_text(json.dumps(summary, indent=2, ensure_ascii=False) + '\n')
    print(json.dumps(summary, indent=2, ensure_ascii=False))
    return 0 if summary['status'] == 'COMPLETE_FOR_REVIEW' else 1


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (ValueError, KeyError, TypeError, OSError, json.JSONDecodeError) as exc:
        print(f'Research merge rejected: {exc}', file=sys.stderr)
        raise SystemExit(2)
