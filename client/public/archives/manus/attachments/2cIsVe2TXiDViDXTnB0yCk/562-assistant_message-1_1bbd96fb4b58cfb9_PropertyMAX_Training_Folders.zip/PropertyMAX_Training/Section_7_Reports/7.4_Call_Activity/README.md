# 7.4_Call_Activity

Upload your screen recording(s) and training materials for this topic into this folder.

Supported formats: .mp4, .mov, .webm, .pdf, .docx
