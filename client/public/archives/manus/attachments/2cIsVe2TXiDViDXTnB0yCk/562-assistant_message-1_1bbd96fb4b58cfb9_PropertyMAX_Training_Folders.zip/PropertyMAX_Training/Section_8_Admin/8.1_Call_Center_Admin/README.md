# 8.1_Call_Center_Admin

Upload your screen recording(s) and training materials for this topic into this folder.

Supported formats: .mp4, .mov, .webm, .pdf, .docx
