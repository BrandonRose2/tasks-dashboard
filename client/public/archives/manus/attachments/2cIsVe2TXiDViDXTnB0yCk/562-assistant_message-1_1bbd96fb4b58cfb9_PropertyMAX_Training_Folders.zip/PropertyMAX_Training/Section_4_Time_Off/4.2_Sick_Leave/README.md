# 4.2_Sick_Leave

Upload your screen recording(s) and training materials for this topic into this folder.

Supported formats: .mp4, .mov, .webm, .pdf, .docx
