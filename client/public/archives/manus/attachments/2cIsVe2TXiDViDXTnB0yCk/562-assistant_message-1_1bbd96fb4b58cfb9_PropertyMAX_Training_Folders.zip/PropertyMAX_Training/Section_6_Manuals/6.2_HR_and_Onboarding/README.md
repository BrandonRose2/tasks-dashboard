# 6.2_HR_and_Onboarding

Upload your screen recording(s) and training materials for this topic into this folder.

Supported formats: .mp4, .mov, .webm, .pdf, .docx
