# PropertyMAX.ai Training Videos
Place all screen recording training videos here, organized by module/topic.
Naming convention: [Module Name] - [Topic] - [Version or Date]
Example: Hub Overview - Dashboard Navigation - v1.0

