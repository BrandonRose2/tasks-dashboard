# Employee Template Folder
Copy this entire folder when creating a new employee file.
Rename to: [LastName, FirstName] - [Job Title] - [Start Date YYYY-MM-DD]

