# Property Template Folder
Copy this entire folder when adding a new property to the directory.
Rename to: [Property Number] - [Property Name]
Example: 01 - Boca Ciega

