# ApartmentCorp Employee Directory
This is the root of the ApartmentCorp Employee Directory on the company OneDrive/server.
See the folder structure below for navigation guidance.

Created: May 14, 2026

