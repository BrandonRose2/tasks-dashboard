# Technology Onboarding — Credential Records
Managed by: Ethan Fowler
This folder houses all completed Technology Onboarding records.
Each file contains the platform credentials provisioned for a specific new hire.
Access: Ethan Fowler + Admin Staff + New Hire (via PIN)

