# New Hire Onboarding Forms
Place all completed new hire form packets here, organized by employee name and start date.
Naming convention: [YYYY-MM-DD] [LastName, FirstName] - New Hire Packet

