export const DAILY_VACANCY_SCHEDULE_KEY = "daily-vacancy";
export const DAILY_VACANCY_TIMEZONE = "America/Los_Angeles";
export const DAILY_VACANCY_SEND_HOUR = 10;
export const DAILY_COLLECTIONS_SEND_HOUR = 13;
/** Existing dailyVacancyJobs.sendHour remains 13; it is NOT the Vacancy send hour. */
export const DAILY_REPORTS_LEGACY_COLLECTIONS_JOB_ANCHOR_HOUR = DAILY_COLLECTIONS_SEND_HOUR;
export const DAILY_VACANCY_PLATFORM_CRON = "0 0 17,18,20,21 * * *";
export const DAILY_VACANCY_APPROVED_RECIPIENTS = Object.freeze([
  "ethan@apartmentcorp.com", "mam@22.bz",
]);

export type ScheduledDailyReportType = "vacancy" | "collections";

/** One registered callback; off-time UTC candidates never claim or fetch a report. */
export function getDueDailyReport(hour: number): ScheduledDailyReportType | undefined {
  if (hour === DAILY_VACANCY_SEND_HOUR) return "vacancy";
  if (hour === DAILY_COLLECTIONS_SEND_HOUR) return "collections";
  return undefined;
}

export function assertApprovedScheduledRecipients(recipients: unknown): asserts recipients is string[] {
  if (!Array.isArray(recipients) || recipients.length !== 2
    || new Set(recipients).size !== 2
    || !DAILY_VACANCY_APPROVED_RECIPIENTS.every(email => recipients.includes(email))) {
    throw new Error("Scheduled Daily Vacancy recipients must be exactly the two approved addresses");
  }
}

/** Never use the server timezone or a UTC ISO date to select the ledger day. */
export function getLosAngelesCalendar(now: Date) {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: DAILY_VACANCY_TIMEZONE, year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", hourCycle: "h23",
  }).formatToParts(now);
  const value = (type: Intl.DateTimeFormatPartTypes) => parts.find(part => part.type === type)!.value;
  return { localDate: `${value("year")}-${value("month")}-${value("day")}`, hour: Number(value("hour")) };
}

/** Activation at/after this report's scheduled hour starts tomorrow, never backfills. */
export function firstDailyReportSendDate(activatedAt: Date, reportType: ScheduledDailyReportType): string {
  const calendar = getLosAngelesCalendar(activatedAt);
  const sendHour = reportType === "vacancy" ? DAILY_VACANCY_SEND_HOUR : DAILY_COLLECTIONS_SEND_HOUR;
  if (calendar.hour < sendHour) return calendar.localDate;
  const nextDay = new Date(`${calendar.localDate}T00:00:00Z`);
  nextDay.setUTCDate(nextDay.getUTCDate() + 1);
  return `${nextDay.getUTCFullYear()}-${String(nextDay.getUTCMonth() + 1).padStart(2, "0")}-${String(nextDay.getUTCDate()).padStart(2, "0")}`;
}

/** Preserved export: now follows Vacancy's 10 AM policy, not the legacy job anchor. */
export function firstDailyVacancySendDate(activatedAt: Date): string {
  return firstDailyReportSendDate(activatedAt, "vacancy");
}
