import type { AuxiliaryEmailJob } from "../drizzle/schema";

export const AUXILIARY_TIMEZONE = "America/New_York";
export const AUXILIARY_SEND_HOUR = 9;
export const AUXILIARY_POLICIES = {
  weekly_vacancy: { scheduleKey: "weekly-vacancy", endpointPath: "/api/scheduled/weekly-vacancy", cron: "0 0 13,14 * * 6", description: "Weekly Vacancy Summary — Saturdays 9 AM America/New_York; DST-gated, active Daily Vacancy recipients, durable no-backfill ledger." },
  eviction_reminders: { scheduleKey: "eviction-reminders", endpointPath: "/api/scheduled/eviction-reminders", cron: "0 0 13,14 1,15 * *", description: "Eviction missing-amount reminders — 1st/15th 9 AM America/New_York; DST-gated, existing manager/regional contacts, durable per-manager ledger." },
} as const;
export type AuxiliaryReportType = keyof typeof AUXILIARY_POLICIES;

const calendarFormatter = new Intl.DateTimeFormat("en-US", {
  timeZone: AUXILIARY_TIMEZONE, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", hourCycle: "h23",
});
export function getNewYorkCalendar(now: Date) {
  const parts = calendarFormatter.formatToParts(now);
  const part = (name: string) => parts.find(p => p.type === name)!.value;
  const localDate = `${part("year")}-${part("month")}-${part("day")}`;
  return { localDate, day: Number(part("day")), hour: Number(part("hour")), weekday: new Date(`${localDate}T12:00:00Z`).getUTCDay() };
}
export function isAuxiliaryScheduledDay(type: AuxiliaryReportType, localDate: string) {
  const day = new Date(`${localDate}T12:00:00Z`);
  return type === "weekly_vacancy" ? day.getUTCDay() === 6 : [1, 15].includes(day.getUTCDate());
}
export function auxiliarySlotUtc(localDate: string): Date {
  for (const hour of [13, 14]) {
    const candidate = new Date(`${localDate}T${hour}:00:00Z`);
    if (getNewYorkCalendar(candidate).hour === 9) return candidate;
  }
  throw new Error("Invalid auxiliary schedule date");
}
export function firstAuxiliarySendDate(activatedAt: Date, type: AuxiliaryReportType): string {
  let date = getNewYorkCalendar(activatedAt).localDate;
  for (let i = 0; i < 32; i++) {
    if (isAuxiliaryScheduledDay(type, date) && auxiliarySlotUtc(date) >= activatedAt) return date;
    date = new Date(new Date(`${date}T12:00:00Z`).getTime() + 86_400_000).toISOString().slice(0, 10);
  }
  throw new Error("Invalid auxiliary activation date");
}
export function isAuxiliaryJobPolicyValid(job: AuxiliaryEmailJob, uid: string, type: AuxiliaryReportType) {
  const policy = AUXILIARY_POLICIES[type];
  return job.scheduleCronTaskUid === uid && job.reportType === type && job.scheduleKey === policy.scheduleKey
    && job.endpointPath === policy.endpointPath && job.timezone === AUXILIARY_TIMEZONE && job.sendHour === AUXILIARY_SEND_HOUR;
}
export function auxiliaryGate(job: AuxiliaryEmailJob, now: Date): "off-time" | "before-activation" | null {
  const { localDate, hour } = getNewYorkCalendar(now);
  if (hour !== 9 || !isAuxiliaryScheduledDay(job.reportType, localDate)) return "off-time";
  if (!job.activatedAt || !Number.isFinite(job.activatedAt.getTime()) || !job.firstSendDate
    || now < job.activatedAt || localDate < job.firstSendDate || auxiliarySlotUtc(localDate) < job.activatedAt) return "before-activation";
  return null;
}
