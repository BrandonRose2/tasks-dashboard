import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import type { Request, Response } from "express";
import type { DailyVacancyJob } from "../drizzle/schema";
import type { CollectionsSnapshot, DashboardData } from "./scraper";

const mocks = vi.hoisted(() => ({
  authenticateRequest: vi.fn(), getJob: vi.fn(), claim: vi.fn(), transition: vi.fn(),
  fetchDashboardData: vi.fn(), fetchCollections: vi.fn(), prepare: vi.fn(), send: vi.fn(),
  prepareCollections: vi.fn(), sendCollections: vi.fn(),
}));
vi.mock("./_core/sdk", () => ({ sdk: { authenticateRequest: mocks.authenticateRequest } }));
vi.mock("./dailyVacancyScheduleDb", () => ({ getDailyVacancyJobByTaskUid: mocks.getJob, claimDailyVacancySend: mocks.claim, transitionDailyVacancySend: mocks.transition }));
vi.mock("./scraper", async importOriginal => ({ ...await importOriginal<typeof import("./scraper")>(), fetchDashboardData: mocks.fetchDashboardData, fetchAndSaveCollectionsSnapshot: mocks.fetchCollections }));
vi.mock("./emailService", () => ({ DAILY_VACANCY_TEST_RECIPIENT: "ethan@apartmentcorp.com", prepareScheduledDailyVacancy: mocks.prepare, sendPreparedScheduledDailyVacancy: mocks.send, prepareManagedCollections: mocks.prepareCollections, sendPreparedManagedCollections: mocks.sendCollections }));
import { assertScheduledVacancySnapshot, assertScheduledCollectionsSnapshot, dailyVacancyScheduledHandler, sendManagedCollectionsTestToEthan } from "./dailyVacancyScheduled";
import {
  DAILY_VACANCY_SEND_HOUR, DAILY_COLLECTIONS_SEND_HOUR, DAILY_REPORTS_LEGACY_COLLECTIONS_JOB_ANCHOR_HOUR,
  DAILY_VACANCY_PLATFORM_CRON, firstDailyReportSendDate, firstDailyVacancySendDate, getDueDailyReport, getLosAngelesCalendar,
  type ScheduledDailyReportType,
} from "./dailyVacancySchedulePolicy";

const taskUid = "VZyvdDPMbzyNdrdFimtdHj";
const recipients = ["ethan@apartmentcorp.com", "mam@22.bz"];
const reportTypes = ["vacancy", "collections"] as const;
let job: DailyVacancyJob;
let data: DashboardData;
let collections: CollectionsSnapshot;
let ledger: Map<string, { state: string; token: string }>;
const receipt = { messageId: "synthetic-id", accepted: recipients, rejected: [], response: "250 accepted" };
const testReceipt = { ...receipt, accepted: [recipients[0]] };
async function trigger(body: unknown = {}) {
  const req = { headers: {}, body, originalUrl: "/api/scheduled/daily-vacancy" } as Request;
  const res = { statusCode: 200, status: vi.fn(), json: vi.fn() };
  res.status.mockImplementation((code: number) => { res.statusCode = code; return res; });
  await dailyVacancyScheduledHandler(req, res as unknown as Response);
  return { code: res.statusCode, body: res.json.mock.calls[0][0] };
}
const ledgerKey = (type: string, localDate = getLosAngelesCalendar(new Date()).localDate, id = job.id) => `${id}:${type}:${localDate}`;
const state = (type = "vacancy", localDate?: string) => ledger.get(ledgerKey(type, localDate))?.state;
function setSlot(type: ScheduledDailyReportType, date = "2026-11-03") {
  vi.setSystemTime(new Date(`${date}T${type === "vacancy" ? "18" : "21"}:00:00Z`));
  data.lastUpdated = new Date();
}
const reportMocks = (type: ScheduledDailyReportType) => type === "vacancy"
  ? { source: mocks.fetchDashboardData, prepare: mocks.prepare, send: mocks.send, otherSource: mocks.fetchCollections, otherPrepare: mocks.prepareCollections, otherSend: mocks.sendCollections }
  : { source: mocks.fetchCollections, prepare: mocks.prepareCollections, send: mocks.sendCollections, otherSource: mocks.fetchDashboardData, otherPrepare: mocks.prepare, otherSend: mocks.send };
function expectOnlyDue(type: ScheduledDailyReportType) {
  const mock = reportMocks(type);
  expect(mock.otherSource).not.toHaveBeenCalled(); expect(mock.otherPrepare).not.toHaveBeenCalled(); expect(mock.otherSend).not.toHaveBeenCalled();
  expect(mocks.claim.mock.calls.every(call => call[3] === type)).toBe(true);
  expect(mocks.transition.mock.calls.every(call => call[6] === type)).toBe(true);
}

beforeEach(() => {
  vi.resetAllMocks(); vi.useFakeTimers(); vi.setSystemTime(new Date("2026-11-03T18:00:00Z"));
  vi.stubGlobal("fetch", vi.fn(() => { throw new Error("No live network permitted"); }));
  ledger = new Map();
  job = { id: 1, scheduleKey: "daily-vacancy", scheduleCronTaskUid: taskUid, enabled: true, collectionsApproved: true,
    timezone: "America/Los_Angeles", sendHour: 13, recipients: [...recipients],
    activatedAt: new Date("2026-01-01T00:00:00Z"), firstSendDate: "2026-01-01", createdAt: new Date(), updatedAt: new Date() };
  data = { stats: { totalVacant: 3, vacUnleased: 2, vacPreleased: 1, onNotice: 7, eviction: 5 },
    vacantUnleased: [{ building: "Example", unit: "A" }, { building: "Example", unit: "B" }] as never,
    vacantPreleased: [{ building: "Example", unit: "C" }] as never,
    onNotice: [{ building: "Example", unit: "D" }] as never, evictions: [{ building: "Example", unit: "E" }] as never,
    buildingVacancy: [{ name: "Example", totalVacant: 3, vacUnleased: 2, vacPreleased: 1, onNotice: 6, eviction: 4, totalUnits: 100, vacancyPct: 3, atRisk: false }],
    dailyChanges: [], historicalMonths: [], lastUpdated: new Date() };
  collections = { snapshotDate: "2026-11-03", totalRentBilled: 400, totalRentCollected: 360, overallCollectionPct: 90,
    buildings: [1, 2, 3, 4].map(regionId => ({ buildingName: `Example ${regionId}`, regionId, regionName: `Region ${regionId}`, rentBilled: 100, rentCollected: 90, utilityReimbursement: 0, vouchersCount: 0, collectionPct: 90 })) };
  mocks.authenticateRequest.mockResolvedValue({ isCron: true, taskUid });
  mocks.getJob.mockImplementation(async task => task === taskUid ? job : undefined);
  // Model existing durable uniqueness across job + report + LA date, never clearing between callbacks.
  mocks.claim.mockImplementation(async (id, date, token, type = "vacancy") => {
    const key = ledgerKey(type, date, id); const row = ledger.get(key);
    if (!row || (row.state === "failed_before_send" && type !== "collections_test")) {
      ledger.set(key, { state: "preparing", token }); return { claimed: true, state: "preparing" };
    }
    return { claimed: false, state: row.state };
  });
  mocks.transition.mockImplementation(async (id, date, token, expected, next, _patch, type = "vacancy") => {
    const row = ledger.get(ledgerKey(type, date, id));
    if (row?.token !== token || row.state !== expected) return false;
    row.state = next; return true;
  });
  mocks.fetchDashboardData.mockResolvedValue(data); mocks.fetchCollections.mockResolvedValue(collections);
  mocks.prepare.mockResolvedValue({ message: "synthetic" }); mocks.prepareCollections.mockImplementation(async (_snapshot, to, type) => ({ message: "synthetic", to, type }));
  mocks.send.mockImplementation(async () => { expect(state()).toBe("sending"); return receipt; });
  mocks.sendCollections.mockImplementation(async prepared => { expect(state(prepared.type)).toBe("sending"); return prepared.type === "collections_test" ? testReceipt : receipt; });
});
afterEach(() => { expect(fetch).not.toHaveBeenCalled(); vi.unstubAllGlobals(); vi.useRealTimers(); });

const calendarCases = [
  { date: "2026-03-07", vacancyUtc: "18", collectionsUtc: "21" },
  { date: "2026-03-08", vacancyUtc: "17", collectionsUtc: "20" },
  { date: "2026-03-09", vacancyUtc: "17", collectionsUtc: "20" },
  { date: "2026-07-03", vacancyUtc: "17", collectionsUtc: "20" },
  { date: "2026-10-31", vacancyUtc: "17", collectionsUtc: "20" },
  { date: "2026-11-01", vacancyUtc: "18", collectionsUtc: "21" },
  { date: "2026-11-02", vacancyUtc: "18", collectionsUtc: "21" },
  { date: "2026-11-03", vacancyUtc: "18", collectionsUtc: "21" },
];

describe("LA calendar and one-job UTC candidate consistency", () => {
  it("names split report hours separately from the persisted legacy Collections anchor", () => {
    expect(DAILY_VACANCY_SEND_HOUR).toBe(10); expect(DAILY_COLLECTIONS_SEND_HOUR).toBe(13);
    expect(DAILY_REPORTS_LEGACY_COLLECTIONS_JOB_ANCHOR_HOUR).toBe(13);
    expect(Array.from({ length: 24 }, (_, hour) => getDueDailyReport(hour)).filter(Boolean)).toEqual(reportTypes);
  });
  it("cron supplies exactly one due candidate per report and two no-ops every day of 2026, including DST transitions", () => {
    expect(DAILY_VACANCY_PLATFORM_CRON).toBe("0 0 17,18,20,21 * * *");
    const [second, minute, hours, ...rest] = DAILY_VACANCY_PLATFORM_CRON.split(" ");
    expect([second, minute, ...rest]).toEqual(["0", "0", "*", "*", "*"]);
    const candidates = hours.split(",").map(Number);
    for (const day = new Date("2026-01-01T00:00:00Z"); day.getUTCFullYear() === 2026; day.setUTCDate(day.getUTCDate() + 1)) {
      const date = day.toISOString().slice(0, 10);
      const due = candidates.map(hour => {
        const instant = new Date(day); instant.setUTCHours(hour);
        const calendar = getLosAngelesCalendar(instant); expect(calendar.localDate).toBe(date);
        return getDueDailyReport(calendar.hour);
      });
      expect(due.filter(Boolean), date).toEqual(reportTypes);
      expect(due.filter(type => !type), date).toHaveLength(2);
    }
  });
  it("retains LA dates across UTC midnight and per-report no-backfill/year boundaries", () => {
    expect(getLosAngelesCalendar(new Date("2026-11-04T07:30:00Z"))).toEqual({ localDate: "2026-11-03", hour: 23 });
    expect(getLosAngelesCalendar(new Date("2026-11-04T08:00:00Z"))).toEqual({ localDate: "2026-11-04", hour: 0 });
    expect(firstDailyVacancySendDate(new Date("2026-11-03T17:59:59Z"))).toBe("2026-11-03");
    expect(firstDailyVacancySendDate(new Date("2026-11-03T18:00:00Z"))).toBe("2026-11-04");
    expect(firstDailyReportSendDate(new Date("2026-11-03T19:00:00Z"), "collections")).toBe("2026-11-03");
    expect(firstDailyReportSendDate(new Date("2026-11-03T21:00:00Z"), "collections")).toBe("2026-11-04");
    for (const type of reportTypes) expect(firstDailyReportSendDate(new Date("2026-12-31T23:00:00Z"), type)).toBe("2027-01-01");
  });
});

describe("single managed split-time callback (fully mocked; never live sends)", () => {
  it("rejects anonymous requests", async () => { mocks.authenticateRequest.mockRejectedValue(new Error("anonymous")); expect((await trigger()).code).toBe(403); expect(mocks.getJob).not.toHaveBeenCalled(); });
  it.each([{ role: "admin" }, { isCron: false, taskUid }, { isCron: true }])("rejects non-cron identity %j", async user => { mocks.authenticateRequest.mockResolvedValue(user); expect((await trigger()).code).toBe(403); expect(mocks.claim).not.toHaveBeenCalled(); });
  it.each(reportTypes)("ignores attacker body policy and sends ONLY due %s", async type => {
    setSlot(type);
    const result = await trigger({ taskUid: "attacker", recipients: ["extra@invalid.test"], date: "2000-01-01", sendHour: 1, enabled: false, collectionsApproved: false });
    expect(result.body.status).toBe("sent"); expect(Object.keys(result.body.reports)).toEqual([type]);
    expect(mocks.getJob).toHaveBeenCalledWith(taskUid);
    expect(mocks.claim).toHaveBeenCalledWith(1, "2026-11-03", expect.any(String), type);
    const mock = reportMocks(type);
    expect(mocks.claim.mock.invocationCallOrder[0]).toBeLessThan(mock.source.mock.invocationCallOrder[0]);
    if (type === "vacancy") { expect(mock.source).toHaveBeenCalledWith(true); expect(mock.prepare).toHaveBeenCalledWith(data, recipients); }
    else { expect(mock.source).toHaveBeenCalledWith(); expect(mock.prepare).toHaveBeenCalledWith(collections, recipients, "collections"); }
    expectOnlyDue(type);
  });
  it("uses only authenticated task UID", async () => { mocks.authenticateRequest.mockResolvedValue({ isCron: true, taskUid: "other" }); expect((await trigger({ taskUid })).body.skipped).toBe("orphan"); expect(mocks.getJob).toHaveBeenCalledWith("other"); expect(mocks.claim).not.toHaveBeenCalled(); });
  it.each(reportTypes)("blocks due %s under all existing policy/activation gates", async type => {
    setSlot(type);
    const original = { ...job };
    for (const mode of ["disabled", "awaiting-collections-approval", "before-activation", "invalid-config"]) {
      Object.assign(job, original);
      if (mode === "disabled") job.enabled = false; if (mode === "awaiting-collections-approval") job.collectionsApproved = false;
      if (mode === "before-activation") job.firstSendDate = "2026-11-04"; if (mode === "invalid-config") job.sendHour = 14;
      expect((await trigger({ enabled: true, collectionsApproved: true })).body.skipped).toBe(mode);
    }
    expect(mocks.claim).not.toHaveBeenCalled(); expectOnlyDue(type);
  });
  it.each(calendarCases)("selects the correct report for all four UTC candidates on $date (PST/PDT/transition)", async ({ date, vacancyUtc, collectionsUtc }) => {
    for (const utc of ["17", "18", "20", "21"]) {
      vi.setSystemTime(new Date(`${date}T${utc}:00:00Z`)); data.lastUpdated = new Date();
      const expected = utc === vacancyUtc ? "vacancy" : utc === collectionsUtc ? "collections" : undefined;
      const claims = mocks.claim.mock.calls.length; const vacancyPulls = mocks.fetchDashboardData.mock.calls.length; const collectionsPulls = mocks.fetchCollections.mock.calls.length;
      const result = await trigger();
      if (!expected) { expect(result.body.skipped).toBe("off-time"); expect(mocks.claim).toHaveBeenCalledTimes(claims); }
      else { expect(result.body.status).toBe("sent"); expect(Object.keys(result.body.reports)).toEqual([expected]); expect(mocks.claim).toHaveBeenLastCalledWith(1, date, expect.any(String), expected); }
      expect(mocks.fetchDashboardData).toHaveBeenCalledTimes(vacancyPulls + (expected === "vacancy" ? 1 : 0));
      expect(mocks.fetchCollections).toHaveBeenCalledTimes(collectionsPulls + (expected === "collections" ? 1 : 0));
    }
    expect(mocks.send).toHaveBeenCalledOnce(); expect(mocks.sendCollections).toHaveBeenCalledOnce();
  });
  it.each(["2026-11-03T19:00:00Z", "2026-11-03T22:00:00Z", "2026-07-03T18:00:00Z", "2026-07-03T21:00:00Z", "2026-11-04T07:30:00Z"])("no-ops off-time %s before any report claim/source", async time => {
    vi.setSystemTime(new Date(time)); expect((await trigger()).body.skipped).toBe("off-time"); expect(mocks.claim).not.toHaveBeenCalled(); expect(mocks.fetchDashboardData).not.toHaveBeenCalled(); expect(mocks.fetchCollections).not.toHaveBeenCalled();
  });
  it.each(reportTypes)("rejects persisted recipient policy before the %s claim", async type => { setSlot(type); job.recipients.push("extra@invalid.test"); expect((await trigger()).code).toBe(500); expect(mocks.claim).not.toHaveBeenCalled(); });
  it.each(reportTypes)("duplicate and concurrent %s callbacks guard its durable report/day independently", async type => {
    setSlot(type); await Promise.all([trigger(), trigger(), trigger()]); await trigger();
    expect(reportMocks(type).send).toHaveBeenCalledOnce(); expect(state(type)).toBe("sent"); expectOnlyDue(type);
  });
  it("both slots can succeed independently without clearing historical evidence, then send again next LA day", async () => {
    const historical = { state: "sent", token: "historical-message-evidence" }; ledger.set(ledgerKey("vacancy", "2026-11-02"), historical);
    for (const date of ["2026-11-03", "2026-11-04"]) for (const type of reportTypes) { setSlot(type, date); await Promise.all([trigger(), trigger()]); await trigger(); expect(state(type, date)).toBe("sent"); }
    expect(mocks.send).toHaveBeenCalledTimes(2); expect(mocks.sendCollections).toHaveBeenCalledTimes(2);
    expect(ledger.get(ledgerKey("vacancy", "2026-11-02"))).toBe(historical); expect(ledger.size).toBe(5);
  });
  it("never backfills a missed morning Vacancy at 1 PM", async () => {
    setSlot("collections"); const result = await trigger(); expect(result.body.status).toBe("sent");
    expect(ledger.has(ledgerKey("vacancy"))).toBe(false); expectOnlyDue("collections");
  });
  it.each(reportTypes)("%s preparation failure safely retries ONLY in its own slot", async type => {
    setSlot(type); reportMocks(type).source.mockRejectedValueOnce(new Error("source failed"));
    expect(await trigger()).toMatchObject({ code: 503, body: { retrySafe: true, manualReviewNeeded: false } }); expect(state(type)).toBe("failed_before_send");
    expect((await trigger()).body.reports[type].status).toBe("sent"); expect(reportMocks(type).send).toHaveBeenCalledOnce(); expectOnlyDue(type);
  });
  it.each(["failed_before_send", "unknown", "sending", "preparing", "sent"])("existing morning Vacancy %s evidence cannot affect the 1 PM Collections slot", async existingState => {
    const old = { state: existingState, token: "old-vacancy-evidence" }; ledger.set(ledgerKey("vacancy"), old);
    setSlot("collections"); const result = await trigger();
    expect(result).toMatchObject({ code: 200, body: { retrySafe: false, manualReviewNeeded: false, status: "sent" } });
    expect(Object.keys(result.body.reports)).toEqual(["collections"]); expect(ledger.get(ledgerKey("vacancy"))).toBe(old); expect(state()).toBe(existingState); expectOnlyDue("collections");
  });
  it.each(reportTypes)("existing sent/unknown/sending/preparing %s rows never fetch or send again", async type => {
    setSlot(type);
    for (const existingState of ["sent", "unknown", "sending", "preparing"]) {
      const old = { state: existingState, token: "durable-old-evidence" }; ledger.set(ledgerKey(type), old);
      const result = await trigger(); expect(result.body.reports[type]).toMatchObject({ status: "already-claimed", state: existingState, retrySafe: false, manualReviewNeeded: existingState !== "sent" });
      expect(ledger.get(ledgerKey(type))).toBe(old);
    }
    expect(reportMocks(type).source).not.toHaveBeenCalled(); expect(reportMocks(type).send).not.toHaveBeenCalled(); expectOnlyDue(type);
  });
  it("Collections failure cannot affect the next day's morning Vacancy or backfill Collections at 10 AM", async () => {
    setSlot("collections"); mocks.fetchCollections.mockRejectedValueOnce(new Error("afternoon source failed")); expect((await trigger()).code).toBe(503);
    const afternoon = ledger.get(ledgerKey("collections")); setSlot("vacancy", "2026-11-04"); expect((await trigger()).body.status).toBe("sent");
    expect(ledger.get(ledgerKey("collections", "2026-11-03"))).toBe(afternoon); expect(state("collections", "2026-11-03")).toBe("failed_before_send");
    expect(ledger.has(ledgerKey("collections", "2026-11-04"))).toBe(false); expect(mocks.fetchCollections).toHaveBeenCalledOnce(); expect(mocks.sendCollections).not.toHaveBeenCalled();
  });
  it("a failed morning Vacancy is not retried at 1 PM and a Collections failure cannot re-claim Vacancy", async () => {
    mocks.fetchDashboardData.mockRejectedValueOnce(new Error("morning source failed")); expect((await trigger()).code).toBe(503);
    const morning = ledger.get(ledgerKey("vacancy")); setSlot("collections"); mocks.fetchCollections.mockRejectedValueOnce(new Error("FLOW failed"));
    expect((await trigger()).code).toBe(503); expect((await trigger()).body.status).toBe("sent");
    expect(ledger.get(ledgerKey("vacancy"))).toBe(morning); expect(state()).toBe("failed_before_send");
    expect(mocks.fetchDashboardData).toHaveBeenCalledOnce(); expect(mocks.send).not.toHaveBeenCalled(); expect(mocks.sendCollections).toHaveBeenCalledOnce();
  });
  it("an ambiguous morning SMTP delivery cannot block or repeat in the afternoon slot", async () => {
    mocks.send.mockRejectedValueOnce(new Error("ambiguous DATA")); expect((await trigger()).body.manualReviewNeeded).toBe(true);
    setSlot("collections"); expect((await trigger()).body.status).toBe("sent"); expect(state()).toBe("unknown");
    expect(mocks.claim.mock.calls.filter(call => call[3] === "vacancy")).toHaveLength(1); expect(mocks.send).toHaveBeenCalledOnce();
  });
  it.each(reportTypes)("%s SMTP error is ambiguous and never resent", async type => {
    setSlot(type); reportMocks(type).send.mockRejectedValueOnce(new Error("SMTP timeout after DATA"));
    expect((await trigger()).body.manualReviewNeeded).toBe(true); expect(state(type)).toBe("unknown"); await trigger();
    expect(reportMocks(type).send).toHaveBeenCalledOnce(); expectOnlyDue(type);
  });
  it.each(reportTypes)("%s partial acceptance never resends anyone", async type => {
    setSlot(type); reportMocks(type).send.mockResolvedValueOnce({ ...receipt, accepted: [recipients[0]], rejected: [recipients[1]] });
    expect((await trigger()).body.manualReviewNeeded).toBe(true); expect(state(type)).toBe("unknown"); await trigger(); expect(reportMocks(type).send).toHaveBeenCalledOnce(); expectOnlyDue(type);
  });
  it.each(reportTypes)("%s accepted-mail persistence failure retains non-retryable sending", async type => {
    setSlot(type); const normal = mocks.transition.getMockImplementation()!;
    mocks.transition.mockImplementation(async (...args) => { if (args[6] === type && ["sent", "unknown"].includes(args[4])) throw new Error("DB unavailable after SMTP"); return normal(...args); });
    expect((await trigger()).body.manualReviewNeeded).toBe(true); expect(state(type)).toBe("sending"); await trigger(); expect(reportMocks(type).send).toHaveBeenCalledOnce(); expectOnlyDue(type);
  });
  it.each(reportTypes)("%s uncertain sending CAS never invokes SMTP", async type => {
    setSlot(type); const normal = mocks.transition.getMockImplementation()!;
    mocks.transition.mockImplementation(async (...args) => { if (args[6] === type && args[4] === "sending") throw new Error("CAS uncertain"); return normal(...args); });
    expect((await trigger()).body.manualReviewNeeded).toBe(true); await trigger(); expect(reportMocks(type).send).not.toHaveBeenCalled(); expectOnlyDue(type);
  });
  it.each(reportTypes)("%s uncertain ownership claim never fetches or sends", async type => {
    setSlot(type); mocks.claim.mockRejectedValueOnce(new Error("INSERT outcome uncertain"));
    expect((await trigger()).body.manualReviewNeeded).toBe(true); expect(reportMocks(type).source).not.toHaveBeenCalled(); expect(reportMocks(type).send).not.toHaveBeenCalled(); expectOnlyDue(type);
  });
  it.each(reportTypes)("late %s sending CAS completion cannot invoke SMTP", async type => {
    setSlot(type); const normal = mocks.transition.getMockImplementation()!; let resolve!: (value: boolean) => void;
    mocks.transition.mockImplementation(async (...args) => args[6] === type && args[4] === "sending" ? new Promise<boolean>(done => { resolve = done; }) : normal(...args));
    const callback = trigger(); await vi.advanceTimersByTimeAsync(110001); expect((await callback).body.manualReviewNeeded).toBe(true);
    resolve(true); await Promise.resolve(); expect(reportMocks(type).send).not.toHaveBeenCalled(); expectOnlyDue(type);
  });
  it.each(reportTypes)("%s never sends from late preparation completion", async type => {
    setSlot(type); let resolve!: (value: any) => void;
    reportMocks(type).source.mockImplementationOnce(() => new Promise(done => { resolve = done; }));
    const callback = trigger(); await vi.advanceTimersByTimeAsync(45001); expect((await callback).code).toBe(503);
    resolve(type === "vacancy" ? data : collections); await Promise.resolve(); expect(reportMocks(type).send).not.toHaveBeenCalled(); expectOnlyDue(type);
  });
  it.each(reportTypes)("%s total callback deadline stays 110 seconds and never starts the other slot", async type => {
    setSlot(type); reportMocks(type).send.mockImplementationOnce(() => new Promise(() => {})); const callback = trigger();
    await vi.advanceTimersByTimeAsync(110001); const result = await callback;
    expect(result.body.manualReviewNeeded).toBe(true); expect(["sending", "unknown"]).toContain(state(type));
    await trigger(); expect(reportMocks(type).send).toHaveBeenCalledOnce(); expectOnlyDue(type);
  });
  it.each(["stale", "missing-details", "bad-total", "bad-building", "bad-building-sum"])("blocks Vacancy %s before SMTP without touching Collections", async mode => {
    if (mode === "stale") data.lastUpdated = new Date(Date.now() - 120001); if (mode === "missing-details") data.vacantUnleased = [];
    if (mode === "bad-total") data.stats.totalVacant = 4; if (mode === "bad-building") data.buildingVacancy[0].totalVacant = 4;
    if (mode === "bad-building-sum") data.buildingVacancy.push({ ...data.buildingVacancy[0] });
    expect((await trigger()).code).toBe(503); expect(mocks.send).not.toHaveBeenCalled(); expectOnlyDue("vacancy");
  });
  it("allows legitimate on-notice detail/tooltip count differences", () => { expect(() => assertScheduledVacancySnapshot(data, new Date())).not.toThrow(); });
  it.each(["missing-region", "duplicate", "non-finite", "bad-total", "bad-rate", "bad-row-rate", "empty", "bad-date"])("blocks Collections %s without touching Vacancy or changing arithmetic", async mode => {
    setSlot("collections");
    if (mode === "missing-region") collections.buildings.pop(); if (mode === "duplicate") collections.buildings.push({ ...collections.buildings[0], buildingName: "  EXAMPLE 1  " });
    if (mode === "non-finite") collections.buildings[0].rentCollected = NaN; if (mode === "bad-total") collections.totalRentBilled += 2;
    if (mode === "bad-rate") collections.overallCollectionPct = 99; if (mode === "bad-row-rate") collections.buildings[0].collectionPct = 99;
    if (mode === "empty") collections.buildings = []; if (mode === "bad-date") collections.snapshotDate = "not-a-date";
    expect((await trigger()).code).toBe(503); expect(mocks.sendCollections).not.toHaveBeenCalled(); expectOnlyDue("collections");
  });
  it("uses actual forced pull started/completed timestamps, rejecting stale/future intervals", () => {
    const now = new Date(); expect(() => assertScheduledCollectionsSnapshot(collections, now, now, now)).not.toThrow();
    expect(() => assertScheduledCollectionsSnapshot(collections, new Date(Date.now() - 120001), now, now)).toThrow("stale");
    expect(() => assertScheduledCollectionsSnapshot(collections, new Date(Date.now() + 1), now, now)).toThrow("stale");
  });
  it.each(reportTypes)("%s credential preparation failure remains before SMTP", async type => {
    setSlot(type); reportMocks(type).prepare.mockRejectedValueOnce(new Error("Wrong selected mailbox"));
    expect((await trigger()).code).toBe(503); expect(state(type)).toBe("failed_before_send"); expect(reportMocks(type).send).not.toHaveBeenCalled(); expectOnlyDue(type);
  });
  it.each(reportTypes)("%s refuses a future/missing activation timestamp or missing first-send boundary", async type => {
    setSlot(type); job.activatedAt = new Date(Date.now() + 1); expect((await trigger()).body.skipped).toBe("before-activation");
    job.activatedAt = null; expect((await trigger()).body.skipped).toBe("before-activation");
    job.activatedAt = new Date("2026-01-01"); job.firstSendDate = null; expect((await trigger()).body.skipped).toBe("before-activation"); expect(mocks.claim).not.toHaveBeenCalled();
  });
  it("activation before 10 AM permits both slots without mutating the stored activation boundary", async () => {
    job.activatedAt = new Date("2026-11-03T17:59:59Z"); job.firstSendDate = "2026-11-03"; const boundary = { ...job };
    await trigger(); setSlot("collections"); await trigger(); expect(mocks.send).toHaveBeenCalledOnce(); expect(mocks.sendCollections).toHaveBeenCalledOnce(); expect(job).toEqual(boundary);
  });
  it.each(["2026-11-03T18:00:00Z", "2026-11-03T18:01:00Z", "2026-11-03T19:00:00Z"])("activation at/after Vacancy hour %s skips morning but keeps same-day Collections", async activatedAt => {
    job.activatedAt = new Date(activatedAt); job.firstSendDate = "2026-11-03";
    vi.setSystemTime(new Date("2026-11-03T18:30:00Z")); expect((await trigger()).body.skipped).toBe("before-activation");
    setSlot("collections"); expect((await trigger()).body.status).toBe("sent"); expectOnlyDue("collections");
    setSlot("vacancy", "2026-11-04"); expect((await trigger()).body.status).toBe("sent"); expect(mocks.send).toHaveBeenCalledOnce();
  });
  it("activation at Collections hour blocks today's afternoon, and retained stored tomorrow boundary also blocks Vacancy today", async () => {
    job.activatedAt = new Date("2026-11-03T21:00:00Z"); job.firstSendDate = "2026-11-04";
    setSlot("collections"); expect((await trigger()).body.skipped).toBe("before-activation");
    setSlot("vacancy", "2026-11-04"); expect((await trigger()).body.status).toBe("sent"); setSlot("collections", "2026-11-04"); expect((await trigger()).body.status).toBe("sent");
  });
  it("the Collections activation-hour cutoff also blocks late same-hour invocation with an older stored date", async () => {
    job.activatedAt = new Date("2026-11-03T21:00:00Z"); job.firstSendDate = "2026-11-03";
    vi.setSystemTime(new Date("2026-11-03T21:30:00Z")); expect((await trigger()).body.skipped).toBe("before-activation"); expect(mocks.claim).not.toHaveBeenCalled();
  });
});

describe("one durable Ethan Collections Test3 while paused", () => {
  beforeEach(() => { job.enabled = false; job.collectionsApproved = false; vi.setSystemTime(new Date("2026-11-03T23:00:00Z")); });
  it("returns actual relay/from/to/receipt/fresh summary without activating or approving", async () => {
    const result = await sendManagedCollectionsTestToEthan(taskUid);
    expect(result).toMatchObject({ sent: true, from: "apartmentcorp44@gmail.com", to: ["ethan@apartmentcorp.com"], messageId: "synthetic-id", smtpReceipt: testReceipt,
      snapshotSummary: { source: "PropertyMax FLOW", buildingCount: 4, totalRentBilled: 400, totalRentCollected: 360, overallCollectionPct: 90 } });
    expect(mocks.prepareCollections).toHaveBeenCalledWith(collections, [recipients[0]], "collections_test");
    expect(job.enabled).toBe(false); expect(job.collectionsApproved).toBe(false); expect(mocks.send).not.toHaveBeenCalled();
    expect(ledger.has(ledgerKey("vacancy"))).toBe(false); expect(ledger.has(ledgerKey("collections"))).toBe(false);
  });
  it("second and concurrent test claims refuse even while production paused", async () => {
    const results = await Promise.all([sendManagedCollectionsTestToEthan(taskUid), sendManagedCollectionsTestToEthan(taskUid)]);
    expect(results.filter(result => result.sent)).toHaveLength(1); expect((await sendManagedCollectionsTestToEthan(taskUid)).status).toBe("already-claimed"); expect(mocks.sendCollections).toHaveBeenCalledOnce(); expect(mocks.fetchCollections).toHaveBeenCalledOnce();
  });
  it.each(["SMTP", "persistence", "source"])("%s test failure refuses a second claim that date", async mode => {
    if (mode === "SMTP") mocks.sendCollections.mockRejectedValueOnce(new Error("ambiguous"));
    if (mode === "source") mocks.fetchCollections.mockRejectedValueOnce(new Error("FLOW unavailable"));
    if (mode === "persistence") { const normal = mocks.transition.getMockImplementation()!; mocks.transition.mockImplementation(async (...args) => { if (args[4] === "sent" || args[4] === "unknown") throw new Error("DB unavailable"); return normal(...args); }); }
    const first = await sendManagedCollectionsTestToEthan(taskUid); expect(first.sent).toBe(false); expect(first.retrySafe).toBe(false);
    expect((await sendManagedCollectionsTestToEthan(taskUid)).status).toBe("already-claimed"); expect(mocks.sendCollections.mock.calls.length).toBe(mode === "source" ? 0 : 1);
    expect(job.enabled).toBe(false); expect(job.collectionsApproved).toBe(false);
  });
  it("requires the existing task and exact production recipient policy even for Ethan test", async () => {
    await expect(sendManagedCollectionsTestToEthan("other-task")).rejects.toThrow("not found"); job.recipients.push("extra@invalid.test");
    await expect(sendManagedCollectionsTestToEthan(taskUid)).rejects.toThrow("two approved"); expect(mocks.claim).not.toHaveBeenCalled();
  });
});
