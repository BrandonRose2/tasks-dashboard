import { randomUUID } from "node:crypto";
import type { Request, Response } from "express";
import type { AuxiliaryEmailJob, AuxiliaryEmailMessage, AuxiliaryEmailRun } from "../drizzle/schema";
import { sdk } from "./_core/sdk";
import { fetchDashboardData, getWeeklySummary, type DashboardData } from "./scraper";
import { prepareWeeklySummaryEmail, prepareEvictionMissingAmountEmail, type ScheduledDailyVacancyReceipt } from "./emailService";
import { createGmailReportTransport, GMAIL_REPORT_SENDER } from "./gmailReportTransport";
import { getEvictionReminderContacts } from "./evictionReminderContacts";
import { auxiliaryGate, getNewYorkCalendar, isAuxiliaryJobPolicyValid, type AuxiliaryReportType } from "./auxiliaryEmailSchedulePolicy";
import { claimAuxiliaryEmailRun, freezeAuxiliaryEmailPlan, getAuxiliaryEmailDeliveries, getAuxiliaryEmailJobByTaskUid, claimAuxiliaryEmailDelivery, transitionAuxiliaryEmailDelivery, transitionAuxiliaryEmailRun } from "./auxiliaryEmailScheduleDb";

export const AUXILIARY_CALLBACK_BUDGET_MS = 110_000; // platform cap 120s, total across all managers
const PREPARATION_BUDGET_MS = 45_000;
const SMTP_START_RESERVE_MS = 5_000;
export const AUXILIARY_SOURCE_MAX_AGE_MS = 5 * 60_000;

/** Timeout has no continuation that can initiate SMTP. Only the callback itself owns send invocation. */
async function beforeDeadline<T>(operation: () => Promise<T>, deadline: number): Promise<T> {
  const remaining = deadline - Date.now();
  if (remaining <= 0) throw new Error("Auxiliary budget exhausted");
  let timer: ReturnType<typeof setTimeout> | undefined;
  try {
    return await Promise.race([operation(), new Promise<never>((_, reject) => {
      timer = setTimeout(() => reject(new Error("Auxiliary budget exhausted")), remaining);
    })]);
  } finally { if (timer) clearTimeout(timer); }
}
export function assertAuxiliarySourceTime(sourceUpdatedAt: Date | null | undefined, now = new Date()) {
  const age = now.getTime() - (sourceUpdatedAt instanceof Date ? sourceUpdatedAt.getTime() : NaN);
  if (!Number.isFinite(age) || age < 0 || age > AUXILIARY_SOURCE_MAX_AGE_MS) throw new Error("Auxiliary source missing or stale");
}
export function assertAuxiliarySnapshot(data: DashboardData) {
  assertAuxiliarySourceTime(data.lastUpdated);
  if (data.sourceStatus && data.sourceStatus.state !== "live") throw new Error("Auxiliary source unavailable");
}
function messageRecipients(message: AuxiliaryEmailMessage): string[] {
  const recipients = [message.to, message.cc ?? ""].flatMap(v => v.split(",").map(s => s.trim()).filter(Boolean));
  if (!recipients.length || recipients.some(v => !/^[^\s<>,@]+@[^\s<>,@]+\.[^\s<>,@]+$/.test(v))) throw new Error("Auxiliary recipients invalid");
  return Array.from(new Set(recipients.map(v => v.toLowerCase())));
}
export function assertAuxiliaryMessage(message: AuxiliaryEmailMessage) {
  if (message.from !== `"Apartment Corp Reports" <${GMAIL_REPORT_SENDER}>` || message.replyTo !== "ethan@apartmentcorp.com"
    || !message.subject || !message.html) throw new Error("Auxiliary message policy invalid");
  messageRecipients(message);
}

/** Retain only expected envelope addresses and bounded message IDs. Never store arbitrary SMTP response/error payloads or credentials. */
export function sanitiseAuxiliaryReceipt(receipt: unknown, message: AuxiliaryEmailMessage): { receipt: ScheduledDailyVacancyReceipt; fullyAccepted: boolean } {
  const expected = messageRecipients(message);
  const r = receipt && typeof receipt === "object" ? receipt as Record<string, unknown> : {};
  const addresses = (value: unknown): string[] | null => {
    if (!Array.isArray(value)) return null;
    const list = value.map(v => typeof v === "string" ? v.toLowerCase() : v && typeof v === "object" && typeof v.address === "string" ? v.address.toLowerCase() : "");
    return list.some(v => !v || !expected.includes(v)) ? null : Array.from(new Set(list));
  };
  const accepted = addresses(r.accepted); const rejected = addresses(r.rejected);
  const fullyAccepted = !!accepted && !!rejected && rejected.length === 0 && expected.every(v => accepted.includes(v));
  const messageId = typeof r.messageId === "string" && /^[\w@.<>+\-]{1,512}$/.test(r.messageId) ? r.messageId : "";
  return { fullyAccepted, receipt: { messageId, accepted: accepted ?? [], rejected: rejected ?? [], response: fullyAccepted ? "accepted" : "unconfirmed" } };
}

type Result = { status: string; retrySafe: boolean; manualReviewNeeded: boolean; sent?: number; pending?: number };
const manual = (status = "delivery-not-retried"): Result => ({ status, retrySafe: false, manualReviewNeeded: true });

async function processAuxiliaryJob(job: AuxiliaryEmailJob, localDate: string, deadline: number): Promise<Result> {
  const token = randomUUID();
  let claim: Awaited<ReturnType<typeof claimAuxiliaryEmailRun>>;
  try { claim = await beforeDeadline(() => claimAuxiliaryEmailRun(job.id, localDate, token), deadline); }
  catch { return manual("claim-unconfirmed"); } // may have committed: never speculate
  let run = claim.run;
  if (run.state === "complete") return { status: run.outcome ?? "complete", retrySafe: false, manualReviewNeeded: false };
  if (["preparing", "failed_before_send"].includes(run.state) && !claim.ownedPreparation) return manual("already-claimed");
  if (["processing", "review"].includes(run.state)) return manual("already-claimed");
  if (claim.ownedPreparation) {
    const preparationDeadline = Math.min(Date.now() + PREPARATION_BUDGET_MS, deadline - SMTP_START_RESERVE_MS);
    let plan: { deliveryKey: string; message: AuxiliaryEmailMessage }[];
    let sourceUpdatedAt: Date;
    try {
      // Forced source pull MUST precede getWeeklySummary, whose snapshot/cache behavior is preserved.
      const data = await beforeDeadline(() => fetchDashboardData(true), preparationDeadline);
      assertAuxiliarySnapshot(data); sourceUpdatedAt = data.lastUpdated;
      // Validate selected Gmail configuration even on no-email outcomes. Creates a client, never connects.
      createGmailReportTransport();
      if (job.reportType === "weekly_vacancy") {
        const summary = await beforeDeadline(() => getWeeklySummary(), preparationDeadline);
        const prepared = await beforeDeadline(() => prepareWeeklySummaryEmail(summary), preparationDeadline);
        plan = [{ deliveryKey: "weekly-summary", message: prepared.message }];
      } else {
        if (!Array.isArray(data.evictions)) throw new Error("Auxiliary eviction source missing");
        plan = getEvictionReminderContacts(data.evictions ?? []).map(c => ({ deliveryKey: c.managerEmail, message: prepareEvictionMissingAmountEmail(c).message }));
      }
      plan.forEach(p => assertAuxiliaryMessage(p.message));
      assertAuxiliarySourceTime(sourceUpdatedAt);
      if (Date.now() >= preparationDeadline || auxiliaryGate(job, new Date())) throw new Error("Auxiliary preparation late");
    } catch {
      try {
        const confirmed = await beforeDeadline(() => transitionAuxiliaryEmailRun(run.id, token, "preparing", "failed_before_send", { failureCode: "preparation-failed" }), deadline);
        if (!confirmed) return manual("preparation-unconfirmed");
      } catch { return manual("preparation-unconfirmed"); }
      return { status: "preparation-failed", retrySafe: true, manualReviewNeeded: false };
    }
    try {
      if (!await beforeDeadline(() => freezeAuxiliaryEmailPlan(run.id, token, sourceUpdatedAt, plan), deadline)) return manual("plan-unconfirmed");
    } catch { return manual("plan-unconfirmed"); }
    if (!plan.length) return { status: "no-email", retrySafe: false, manualReviewNeeded: false, sent: 0, pending: 0 };
    run = { ...run, state: "ready", sourceUpdatedAt, planCount: plan.length };
  }
  if (run.state !== "ready") return manual("already-claimed");
  return deliverFrozenPlan(job, run, deadline);
}

/** Per-message pending→sending CAS is the ownership claim. Parallel callbacks can safely work on the frozen plan; no run lease can reset a sent prefix. */
async function deliverFrozenPlan(job: AuxiliaryEmailJob, run: AuxiliaryEmailRun, deadline: number): Promise<Result> {
  const runToken = run.attemptToken;
  let existingUncertainty = false;
  const recordSafeFailure = async (code: string): Promise<Result> => {
    try {
      if (!await beforeDeadline(() => transitionAuxiliaryEmailRun(run.id, runToken, "ready", "ready", { failureCode: code }), deadline)) return manual("run-update-unconfirmed");
      return { status: code, retrySafe: true, manualReviewNeeded: existingUncertainty };
    } catch { return manual("run-update-unconfirmed"); }
  };
  let rows: Awaited<ReturnType<typeof getAuxiliaryEmailDeliveries>>;
  let transporter: ReturnType<typeof createGmailReportTransport> | undefined;
  try {
    rows = await beforeDeadline(() => getAuxiliaryEmailDeliveries(run.id), deadline);
    existingUncertainty = rows.some(row => ["sending", "unknown"].includes(row.state));
    if (rows.length !== run.planCount) return manual("plan-incomplete");
    rows.forEach(row => assertAuxiliaryMessage(row.message));
    // Receipt-only finalization must not require fresh source or a working SMTP relay.
    if (rows.some(row => row.state === "pending")) {
      assertAuxiliarySourceTime(run.sourceUpdatedAt);
      transporter = createGmailReportTransport();
    }
  } catch { return recordSafeFailure("pre-send-validation-failed"); }
  for (const row of rows) {
    if (row.state !== "pending") continue; // sent/sending/unknown NEVER expire or get reclaimed
    if (Date.now() >= deadline - SMTP_START_RESERVE_MS || auxiliaryGate(job, new Date())) return recordSafeFailure("send-budget-or-slot-exhausted");
    try { assertAuxiliarySourceTime(run.sourceUpdatedAt); }
    catch { return recordSafeFailure("source-stale-before-send"); }
    const deliveryToken = randomUUID();
    let claimed: boolean;
    try { claimed = await beforeDeadline(() => claimAuxiliaryEmailDelivery(row.id, deliveryToken), deadline); }
    catch { return manual("delivery-claim-unconfirmed"); }
    if (!claimed) continue;
    // Late/uncertain CAS has no SMTP continuation. Keep sending fail-closed.
    if (Date.now() >= deadline - SMTP_START_RESERVE_MS || auxiliaryGate(job, new Date())) return manual("sending");
    try {
      assertAuxiliarySourceTime(run.sourceUpdatedAt);
      const raw = await beforeDeadline(() => transporter!.sendMail(row.message), deadline);
      const { receipt, fullyAccepted } = sanitiseAuxiliaryReceipt(raw, row.message);
      const persisted = await beforeDeadline(() => transitionAuxiliaryEmailDelivery(row.id, deliveryToken, fullyAccepted ? "sent" : "unknown", {
        messageId: receipt.messageId, smtpReceipt: receipt, failureCode: fullyAccepted ? null : "smtp-not-fully-accepted",
      }), deadline);
      if (!persisted) return manual("delivery-receipt-unconfirmed");
    } catch {
      try { await beforeDeadline(() => transitionAuxiliaryEmailDelivery(row.id, deliveryToken, "unknown", { failureCode: "delivery-ambiguous" }), deadline); }
      catch { /* sending remains non-reclaimable */ }
      // Continue only other pending managers. Never retry this manager or restart the batch.
    }
  }
  try {
    const final = await beforeDeadline(() => getAuxiliaryEmailDeliveries(run.id), deadline);
    const sent = final.filter(r => r.state === "sent").length;
    const pending = final.filter(r => r.state === "pending").length;
    const uncertain = final.some(r => ["sending", "unknown"].includes(r.state));
    if (pending) return { status: "pending", sent, pending, retrySafe: true, manualReviewNeeded: uncertain };
    const changed = await beforeDeadline(() => transitionAuxiliaryEmailRun(run.id, runToken, "ready", uncertain ? "review" : "complete", {
      outcome: uncertain ? "partial-or-ambiguous" : "sent", failureCode: uncertain ? "delivery-review-required" : null,
    }), deadline);
    if (!changed) return manual("run-completion-unconfirmed");
    return { status: uncertain ? "delivery-not-retried" : "sent", sent, pending, retrySafe: false, manualReviewNeeded: uncertain };
  } catch { return manual("run-completion-unconfirmed"); }
}

function scheduledHandler(type: AuxiliaryReportType) {
  return async (req: Request, res: Response) => {
    const deadline = Date.now() + AUXILIARY_CALLBACK_BUDGET_MS;
    let uid: string;
    try {
      const user = await beforeDeadline(() => sdk.authenticateRequest(req), deadline);
      if (!user.isCron || !user.taskUid) return res.status(403).json({ error: "cron-only" });
      uid = user.taskUid;
    } catch { return res.status(403).json({ error: "cron-only" }); }
    try {
      // Identity/policy/date/recipients never come from req.body.
      const job = await beforeDeadline(() => getAuxiliaryEmailJobByTaskUid(uid), deadline);
      if (!job) return res.json({ ok: true, skipped: "orphan" });
      if (!job.enabled) return res.json({ ok: true, skipped: "disabled" });
      if (!isAuxiliaryJobPolicyValid(job, uid, type)) return res.json({ ok: true, skipped: "invalid-config" });
      const now = new Date(); const skipped = auxiliaryGate(job, now);
      if (skipped) return res.json({ ok: true, skipped });
      const { localDate } = getNewYorkCalendar(now);
      const result = await processAuxiliaryJob(job, localDate, deadline);
      return res.status(result.retrySafe ? 503 : 200).json({ ok: !result.retrySafe, reportType: type, localDate, ...result });
    } catch {
      return res.status(500).json({ error: "auxiliary-email-callback-failed", reportType: type, timestamp: new Date().toISOString() });
    }
  };
}
export const weeklyVacancyScheduledHandler = scheduledHandler("weekly_vacancy");
export const evictionRemindersScheduledHandler = scheduledHandler("eviction_reminders");
