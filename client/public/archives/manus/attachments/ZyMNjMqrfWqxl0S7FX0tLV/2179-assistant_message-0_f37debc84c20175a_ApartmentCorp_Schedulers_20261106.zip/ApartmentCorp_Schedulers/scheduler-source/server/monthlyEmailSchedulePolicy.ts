import type { MonthlyEmailJob } from "../drizzle/schema";

export const MONTHLY_TIMEZONE = "America/Los_Angeles";
export const MONTHLY_SEND_HOUR = 13;
export const MONTHLY_SEND_DAY = 12;
export const MONTHLY_RECIPIENTS = ["ethan@apartmentcorp.com", "mam@22.bz"] as const;
export const MONTHLY_POLICY = {
  reportType: "monthly_net_cash_flow",
  scheduleKey: "monthly-net-cash-flow",
  endpointPath: "/api/scheduled/monthly-net-cash-flow",
  timezone: MONTHLY_TIMEZONE, sendHour: MONTHLY_SEND_HOUR, sendDay: MONTHLY_SEND_DAY,
  cron: "0 0 20,21 12 * *",
  description: "Monthly Net Cash Flow — 12th at 1 PM America/Los_Angeles, previous completed month, Ethan and Marc only; DST-gated and durable period-level duplicate protection.",
} as const;
const formatter = new Intl.DateTimeFormat("en-US", {
  timeZone: MONTHLY_TIMEZONE, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", hourCycle: "h23",
});
export function getMonthlyCalendar(now: Date) {
  const parts = formatter.formatToParts(now);
  const part = (name: string) => parts.find(p => p.type === name)!.value;
  return { localDate: `${part("year")}-${part("month")}-${part("day")}`, year: Number(part("year")), month: Number(part("month")), day: Number(part("day")), hour: Number(part("hour")) };
}
function assertLocalDate(localDate: string) {
  const date = new Date(`${localDate}T12:00:00Z`);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(localDate) || !Number.isFinite(date.getTime()) || date.toISOString().slice(0, 10) !== localDate) throw new Error("Invalid monthly local date");
}
export function monthlySlotUtc(localDate: string) {
  assertLocalDate(localDate);
  for (const hour of [20, 21]) {
    const candidate = new Date(`${localDate}T${hour}:00:00Z`);
    const local = getMonthlyCalendar(candidate);
    if (local.localDate === localDate && local.hour === MONTHLY_SEND_HOUR) return candidate;
  }
  throw new Error("Invalid monthly schedule date");
}
export function firstMonthlySendDate(activatedAt: Date) {
  if (!Number.isFinite(activatedAt.getTime())) throw new Error("Invalid monthly activation date");
  let date = getMonthlyCalendar(activatedAt).localDate;
  for (let i = 0; i < 64; i++) {
    if (Number(date.slice(8)) === MONTHLY_SEND_DAY && monthlySlotUtc(date) >= activatedAt) return date;
    date = new Date(new Date(`${date}T12:00:00Z`).getTime() + 86_400_000).toISOString().slice(0, 10);
  }
  throw new Error("Invalid monthly activation date");
}
export function assertMonthlyRecipients(recipients: unknown): asserts recipients is string[] {
  if (!Array.isArray(recipients) || recipients.length !== MONTHLY_RECIPIENTS.length
    || recipients.some((value, i) => typeof value !== "string" || value !== MONTHLY_RECIPIENTS[i])) throw new Error("Monthly recipients invalid");
}
export function isMonthlyJobPolicyValid(job: MonthlyEmailJob, uid: string) {
  try { assertMonthlyRecipients(job.recipientTo); } catch { return false; }
  return !!uid && job.scheduleCronTaskUid === uid && job.reportType === MONTHLY_POLICY.reportType
    && job.scheduleKey === MONTHLY_POLICY.scheduleKey && job.endpointPath === MONTHLY_POLICY.endpointPath
    && job.timezone === MONTHLY_TIMEZONE && job.sendHour === MONTHLY_SEND_HOUR && job.sendDay === MONTHLY_SEND_DAY;
}
export function monthlyGate(job: MonthlyEmailJob, now: Date): "off-time" | "before-activation" | null {
  const { localDate, day, hour } = getMonthlyCalendar(now);
  if (day !== MONTHLY_SEND_DAY || hour !== MONTHLY_SEND_HOUR) return "off-time";
  if (!job.activatedAt || !Number.isFinite(job.activatedAt.getTime()) || !job.firstSendDate
    || now < job.activatedAt || localDate < job.firstSendDate || monthlySlotUtc(localDate) < job.activatedAt) return "before-activation";
  return null;
}
