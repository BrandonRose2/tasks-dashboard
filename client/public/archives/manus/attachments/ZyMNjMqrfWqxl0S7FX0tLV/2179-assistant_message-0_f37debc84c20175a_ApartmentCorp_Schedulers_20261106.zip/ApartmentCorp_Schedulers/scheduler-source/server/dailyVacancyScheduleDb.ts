import { and, eq, sql } from "drizzle-orm";
import { dailyVacancyJobs, dailyVacancySendLedger, type DailyVacancyLedger } from "../drizzle/schema";
import { getDb } from "./db";
import {
  assertApprovedScheduledRecipients, DAILY_VACANCY_APPROVED_RECIPIENTS, DAILY_VACANCY_SCHEDULE_KEY,
  DAILY_REPORTS_LEGACY_COLLECTIONS_JOB_ANCHOR_HOUR, DAILY_VACANCY_TIMEZONE, firstDailyReportSendDate,
} from "./dailyVacancySchedulePolicy";

async function requireDb() {
  const db = await getDb();
  if (!db) throw new Error("Daily Vacancy schedule database unavailable");
  return db;
}

/** Provisioning only; never invoked on server startup or from the callback. */
export async function ensureDailyVacancyJob() {
  const db = await requireDb();
  await db.insert(dailyVacancyJobs).values({
    scheduleKey: DAILY_VACANCY_SCHEDULE_KEY, enabled: false, collectionsApproved: false,
    timezone: DAILY_VACANCY_TIMEZONE, sendHour: DAILY_REPORTS_LEGACY_COLLECTIONS_JOB_ANCHOR_HOUR,
    recipients: [...DAILY_VACANCY_APPROVED_RECIPIENTS],
  }).onDuplicateKeyUpdate({ set: { id: sql`${dailyVacancyJobs.id}` } });
  return (await db.select().from(dailyVacancyJobs)
    .where(eq(dailyVacancyJobs.scheduleKey, DAILY_VACANCY_SCHEDULE_KEY)).limit(1))[0];
}

/** Call only after publishing the handler and receiving the platform task UID. */
export async function activateDailyVacancyJob(taskUid: string) {
  if (!taskUid || taskUid.length > 65 || taskUid.trim() !== taskUid) throw new Error("Invalid cron task UID");
  const db = await requireDb();
  const job = await ensureDailyVacancyJob();
  // Repeating activation for the same task does not reset its start boundary.
  if (job.enabled && job.scheduleCronTaskUid === taskUid && job.activatedAt && job.firstSendDate) return job;
  const activatedAt = new Date();
  await db.update(dailyVacancyJobs).set({
    scheduleCronTaskUid: taskUid, enabled: true,
    timezone: DAILY_VACANCY_TIMEZONE, sendHour: DAILY_REPORTS_LEGACY_COLLECTIONS_JOB_ANCHOR_HOUR,
    recipients: [...DAILY_VACANCY_APPROVED_RECIPIENTS],
    // Retain the stored Collections boundary; callback also gates each report's own activation hour.
    activatedAt, firstSendDate: firstDailyReportSendDate(activatedAt, "collections"),
  }).where(eq(dailyVacancyJobs.id, job.id));
  return getDailyVacancyJobByTaskUid(taskUid);
}

export async function getDailyVacancyJobByTaskUid(taskUid: string) {
  const db = await requireDb();
  return (await db.select().from(dailyVacancyJobs)
    .where(eq(dailyVacancyJobs.scheduleCronTaskUid, taskUid)).limit(1))[0];
}

function isDuplicateKey(error: unknown): boolean {
  if (!error || typeof error !== "object") return false;
  const detail = error as { code?: string; errno?: number; cause?: unknown };
  return detail.code === "ER_DUP_ENTRY" || detail.errno === 1062
    || (detail.cause !== error && isDuplicateKey(detail.cause));
}

/** Plain unique INSERT is the ownership claim, not an in-memory lock or a SELECT. */
export type DailyReportType = DailyVacancyLedger["reportType"];

export async function claimDailyVacancySend(jobId: number, localDate: string, attemptToken: string, reportType: DailyReportType = "vacancy") {
  const db = await requireDb();
  try {
    await db.insert(dailyVacancySendLedger).values({ jobId, reportType, localDate, attemptToken, state: "preparing" });
    return { claimed: true, state: "preparing" as const };
  } catch (error) {
    if (!isDuplicateKey(error)) throw error;
  }
  const existing = (await db.select().from(dailyVacancySendLedger).where(and(
    eq(dailyVacancySendLedger.jobId, jobId), eq(dailyVacancySendLedger.reportType, reportType), eq(dailyVacancySendLedger.localDate, localDate),
  )).limit(1))[0];
  if (!existing) throw new Error("Daily Vacancy claim could not be confirmed");
  if (existing.state === "failed_before_send" && reportType !== "collections_test") {
    const result = await db.update(dailyVacancySendLedger).set({
      state: "preparing", attemptToken, failureCode: null,
    }).where(and(eq(dailyVacancySendLedger.id, existing.id),
      eq(dailyVacancySendLedger.state, "failed_before_send"),
      eq(dailyVacancySendLedger.attemptToken, existing.attemptToken)));
    if (result[0].affectedRows === 1) return { claimed: true, state: "preparing" as const };
  }
  // preparing/sending/unknown never expire and can never be automatically reclaimed.
  return { claimed: false, state: existing.state };
}

type LedgerPatch = Partial<Pick<DailyVacancyLedger,
  "sourceUpdatedAt" | "messageId" | "smtpReceipt" | "failureCode">>;

export async function transitionDailyVacancySend(
  jobId: number, localDate: string, attemptToken: string,
  expected: DailyVacancyLedger["state"], state: DailyVacancyLedger["state"], patch: LedgerPatch = {}, reportType: DailyReportType = "vacancy",
): Promise<boolean> {
  const db = await requireDb();
  const result = await db.update(dailyVacancySendLedger).set({ ...patch, state }).where(and(
    eq(dailyVacancySendLedger.jobId, jobId), eq(dailyVacancySendLedger.reportType, reportType), eq(dailyVacancySendLedger.localDate, localDate),
    eq(dailyVacancySendLedger.attemptToken, attemptToken), eq(dailyVacancySendLedger.state, expected),
  ));
  return result[0].affectedRows === 1;
}

/** Explicit provisioning action only AFTER the user approves the Ethan test. Never called by startup, test, or activation. */
export async function confirmDailyReportsDelivery(taskUid: string) {
  const job = await getDailyVacancyJobByTaskUid(taskUid);
  if (!job || job.scheduleKey !== DAILY_VACANCY_SCHEDULE_KEY
    || job.timezone !== DAILY_VACANCY_TIMEZONE || job.sendHour !== DAILY_REPORTS_LEGACY_COLLECTIONS_JOB_ANCHOR_HOUR) {
    throw new Error("Existing managed daily job policy is invalid");
  }
  assertApprovedScheduledRecipients(job.recipients);
  const db = await requireDb();
  const activatedAt = new Date();
  await db.update(dailyVacancyJobs).set({
    enabled: true, collectionsApproved: true,
    activatedAt, firstSendDate: firstDailyReportSendDate(activatedAt, "collections"),
  }).where(and(eq(dailyVacancyJobs.id, job.id), eq(dailyVacancyJobs.scheduleCronTaskUid, taskUid)));
  return getDailyVacancyJobByTaskUid(taskUid);
}
