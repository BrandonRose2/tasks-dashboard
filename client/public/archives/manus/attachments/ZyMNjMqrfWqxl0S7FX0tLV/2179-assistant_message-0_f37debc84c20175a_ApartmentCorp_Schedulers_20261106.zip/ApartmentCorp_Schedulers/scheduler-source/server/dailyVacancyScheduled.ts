import { randomUUID } from "node:crypto";
import type { Request, Response } from "express";
import type { DailyVacancyJob, DailyVacancyLedger } from "../drizzle/schema";
import { sdk } from "./_core/sdk";
import { fetchDashboardData, fetchAndSaveCollectionsSnapshot, hasVacancyUnitDetailCoverage, type CollectionsSnapshot, type DashboardData } from "./scraper";
import { DAILY_VACANCY_TEST_RECIPIENT, prepareScheduledDailyVacancy, sendPreparedScheduledDailyVacancy, prepareManagedCollections, sendPreparedManagedCollections, type ScheduledDailyVacancyReceipt } from "./emailService";
import { claimDailyVacancySend, getDailyVacancyJobByTaskUid, transitionDailyVacancySend, type DailyReportType } from "./dailyVacancyScheduleDb";
import { GMAIL_REPORT_SENDER } from "./gmailReportTransport";
import {
  assertApprovedScheduledRecipients, DAILY_VACANCY_SCHEDULE_KEY,
  DAILY_REPORTS_LEGACY_COLLECTIONS_JOB_ANCHOR_HOUR, DAILY_VACANCY_TIMEZONE,
  firstDailyReportSendDate, getDueDailyReport, getLosAngelesCalendar,
} from "./dailyVacancySchedulePolicy";

const PREPARATION_BUDGET_MS = 45_000;
export const DAILY_REPORTS_CALLBACK_BUDGET_MS = 110_000; // total, not per report; platform cap is 120s
const SOURCE_MAX_AGE_MS = 120_000;

/** Timed-out preparation has no continuation that can invoke SMTP. */
async function beforeDeadline<T>(operation: () => Promise<T>, deadline: number): Promise<T> {
  const remaining = deadline - Date.now();
  if (remaining <= 0) throw new Error("Scheduled operation budget exhausted");
  let timer: ReturnType<typeof setTimeout> | undefined;
  try {
    return await Promise.race([operation(), new Promise<never>((_, reject) => {
      timer = setTimeout(() => reject(new Error("Scheduled operation budget exhausted")), remaining);
    })]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}

export function assertScheduledVacancySnapshot(data: DashboardData, now: Date): void {
  const age = now.getTime() - data.lastUpdated?.getTime();
  if (!Number.isFinite(age) || age < 0 || age > SOURCE_MAX_AGE_MS
    || (data.sourceStatus && data.sourceStatus.state !== "live")) {
    throw new Error("Daily Vacancy source is missing or stale");
  }
  if (!Array.isArray(data.buildingVacancy) || data.buildingVacancy.length === 0
    || !hasVacancyUnitDetailCoverage(data)) throw new Error("Daily Vacancy source is incomplete");
  const fields = ["totalVacant", "vacUnleased", "vacPreleased"] as const;
  const count = (value: number) => Number.isInteger(value) && value >= 0;
  if (!fields.every(field => count(data.stats[field]))
    || data.stats.totalVacant !== data.stats.vacUnleased + data.stats.vacPreleased
    || !data.buildingVacancy.every(row => fields.every(field => count(row[field]))
      && row.totalVacant === row.vacUnleased + row.vacPreleased)
    || !fields.every(field => data.buildingVacancy.reduce((sum, row) => sum + row[field], 0) === data.stats[field])) {
    throw new Error("Daily Vacancy totals do not reconcile");
  }
  // On-notice/eviction tooltip and detail counts have different source semantics.
}

/** FLOW returns no timestamp: use the actual forced pull interval, never a cache timestamp. No report math is changed. */
export function assertScheduledCollectionsSnapshot(snapshot: CollectionsSnapshot, pullStartedAt: Date, pullCompletedAt: Date, now: Date): void {
  const age = now.getTime() - pullStartedAt.getTime();
  if (!Number.isFinite(age) || age < 0 || age > SOURCE_MAX_AGE_MS
    || !Number.isFinite(pullCompletedAt.getTime()) || pullCompletedAt < pullStartedAt || pullCompletedAt > now) {
    throw new Error("Collections FLOW source is missing or stale");
  }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(snapshot.snapshotDate)
    || !Number.isFinite(new Date(`${snapshot.snapshotDate}T12:00:00Z`).getTime())
    || !Array.isArray(snapshot.buildings) || snapshot.buildings.length === 0) {
    throw new Error("Collections FLOW source is incomplete");
  }
  const keys = new Set<string>();
  const regions = new Set<number>();
  const roundedRate = (billed: number, collected: number) => billed > 0 ? Math.round((collected / billed) * 1000) / 10 : 0;
  for (const row of snapshot.buildings) {
    const name = row.buildingName?.trim().toLocaleLowerCase();
    const key = `${row.regionId}:${name}`;
    if (!name || ![1, 2, 3, 4].includes(row.regionId) || keys.has(key)
      || ![row.rentBilled, row.rentCollected, row.utilityReimbursement, row.collectionPct, row.vouchersCount].every(Number.isFinite)
      || !Number.isInteger(row.vouchersCount) || row.vouchersCount < 0
      || row.collectionPct !== roundedRate(row.rentBilled, row.rentCollected)) {
      throw new Error("Collections FLOW rows are invalid or duplicated");
    }
    keys.add(key); regions.add(row.regionId);
  }
  const billed = snapshot.buildings.reduce((sum, row) => sum + row.rentBilled, 0);
  const collected = snapshot.buildings.reduce((sum, row) => sum + row.rentCollected, 0);
  if (regions.size !== 4 || ![billed, collected, snapshot.totalRentBilled, snapshot.totalRentCollected, snapshot.overallCollectionPct].every(Number.isFinite)
    || Math.abs(billed - snapshot.totalRentBilled) > 0.01 || Math.abs(collected - snapshot.totalRentCollected) > 0.01
    || snapshot.overallCollectionPct !== roundedRate(billed, collected)) {
    throw new Error("Collections FLOW totals or region coverage do not reconcile");
  }
}

function assertManagedJobPolicy(job: DailyVacancyJob, taskUid: string) {
  if (job.scheduleCronTaskUid !== taskUid || job.scheduleKey !== DAILY_VACANCY_SCHEDULE_KEY
    || job.timezone !== DAILY_VACANCY_TIMEZONE || job.sendHour !== DAILY_REPORTS_LEGACY_COLLECTIONS_JOB_ANCHOR_HOUR) {
    throw new Error("Existing managed daily job policy is invalid");
  }
  assertApprovedScheduledRecipients(job.recipients);
}

type SnapshotSummary = {
  source: "PropertyMax FLOW"; snapshotDate: string; buildingCount: number; regions: number[];
  totalRentBilled: number; totalRentCollected: number; overallCollectionPct: number;
  pullStartedAt: string; pullCompletedAt: string;
};
export type ManagedDailyReportResult = {
  reportType: DailyReportType; status: "sent" | "already-claimed" | "failed_before_send" | "delivery-not-retried";
  state: DailyVacancyLedger["state"]; retrySafe: boolean; manualReviewNeeded: boolean;
  messageId?: string; smtpReceipt?: ScheduledDailyVacancyReceipt; snapshotSummary?: SnapshotSummary;
};

/** Same claim/preparation/sending/CAS rules for automated reports and the Ethan test. Never automatically reclaims ambiguity. */
async function processManagedDailyReport(job: DailyVacancyJob, localDate: string, reportType: DailyReportType, callbackDeadline: number): Promise<ManagedDailyReportResult> {
  const attemptToken = randomUUID();
  const manual = (state: DailyVacancyLedger["state"] = "unknown"): ManagedDailyReportResult => ({
    reportType, status: "delivery-not-retried", state, retrySafe: false, manualReviewNeeded: true,
  });
  let claim: Awaited<ReturnType<typeof claimDailyVacancySend>>;
  try {
    claim = await beforeDeadline(() => claimDailyVacancySend(job.id, localDate, attemptToken, reportType), callbackDeadline);
  } catch { return manual(); } // INSERT may have committed: no speculative send/retry
  if (!claim.claimed) return {
    reportType, status: "already-claimed", state: claim.state, retrySafe: false,
    manualReviewNeeded: ["preparing", "sending", "unknown"].includes(claim.state),
  };
  const transition = (expected: DailyVacancyLedger["state"], state: DailyVacancyLedger["state"], patch?: Parameters<typeof transitionDailyVacancySend>[5]) =>
    transitionDailyVacancySend(job.id, localDate, attemptToken, expected, state, patch, reportType);
  const recipients = reportType === "collections_test" ? [DAILY_VACANCY_TEST_RECIPIENT] : [...job.recipients];
  const preparationDeadline = Math.min(Date.now() + PREPARATION_BUDGET_MS, callbackDeadline - 5_000);
  let prepared: Awaited<ReturnType<typeof prepareScheduledDailyVacancy>> | Awaited<ReturnType<typeof prepareManagedCollections>>;
  let sourceUpdatedAt: Date;
  let assertFresh: () => void;
  let snapshotSummary: SnapshotSummary | undefined;
  try {
    if (reportType === "vacancy") {
      const data = await beforeDeadline(() => fetchDashboardData(true), preparationDeadline);
      assertFresh = () => assertScheduledVacancySnapshot(data, new Date());
      assertFresh(); sourceUpdatedAt = data.lastUpdated;
      prepared = await beforeDeadline(() => prepareScheduledDailyVacancy(data, recipients), preparationDeadline);
    } else {
      const pullStartedAt = new Date();
      // DIRECT forced FLOW pull, not getCollectionsSnapshot's freshness/cache path. No Railway dependency.
      const snapshot = await beforeDeadline(() => fetchAndSaveCollectionsSnapshot(), preparationDeadline);
      const pullCompletedAt = new Date();
      assertFresh = () => assertScheduledCollectionsSnapshot(snapshot, pullStartedAt, pullCompletedAt, new Date());
      assertFresh(); sourceUpdatedAt = pullStartedAt;
      prepared = await beforeDeadline(() => prepareManagedCollections(snapshot, recipients, reportType), preparationDeadline);
      snapshotSummary = {
        source: "PropertyMax FLOW", snapshotDate: snapshot.snapshotDate, buildingCount: snapshot.buildings.length,
        regions: [1, 2, 3, 4], totalRentBilled: snapshot.totalRentBilled, totalRentCollected: snapshot.totalRentCollected,
        overallCollectionPct: snapshot.overallCollectionPct, pullStartedAt: pullStartedAt.toISOString(), pullCompletedAt: pullCompletedAt.toISOString(),
      };
    }
    if (Date.now() >= preparationDeadline) throw new Error("Preparation budget exhausted");
  } catch {
    // Preparation has no SMTP continuation. Only a confirmed CAS is a safe production retry.
    try {
      if (!await beforeDeadline(() => transition("preparing", "failed_before_send", { failureCode: "preparation-failed" }), callbackDeadline)) return manual("preparing");
    } catch { return manual("preparing"); }
    return { reportType, status: "failed_before_send", state: "failed_before_send", retrySafe: reportType !== "collections_test", manualReviewNeeded: false };
  }
  try {
    if (!await beforeDeadline(() => transition("preparing", "sending", { sourceUpdatedAt }), callbackDeadline)) return manual("preparing");
    // A late/uncertain sending CAS cannot cause a late SMTP invocation.
    if (Date.now() >= preparationDeadline) return manual("sending");
    assertFresh();
    const receipt = await beforeDeadline(() => reportType === "vacancy"
      ? sendPreparedScheduledDailyVacancy(prepared as Awaited<ReturnType<typeof prepareScheduledDailyVacancy>>)
      : sendPreparedManagedCollections(prepared as Awaited<ReturnType<typeof prepareManagedCollections>>), callbackDeadline);
    const accepted = receipt.accepted.map(email => email.toLowerCase());
    const fullyAccepted = receipt.rejected.length === 0 && recipients.every(email => accepted.includes(email))
      && accepted.every(email => recipients.includes(email));
    const persisted = await beforeDeadline(() => transition("sending", fullyAccepted ? "sent" : "unknown", {
      messageId: receipt.messageId, smtpReceipt: receipt, failureCode: fullyAccepted ? null : "smtp-not-fully-accepted",
    }), callbackDeadline);
    if (!persisted || !fullyAccepted) return manual("unknown");
    return { reportType, status: "sent", state: "sent", retrySafe: false, manualReviewNeeded: false,
      messageId: receipt.messageId, smtpReceipt: receipt, snapshotSummary };
  } catch {
    try { await beforeDeadline(() => transition("sending", "unknown", { failureCode: "delivery-ambiguous" }), callbackDeadline); } catch { /* retain non-reclaimable sending */ }
    return manual();
  }
}

/** One authorized Ethan-only Test3. May run while paused; never approves or enables the job. Second claim that day always refuses. */
export async function sendManagedCollectionsTestToEthan(taskUid: string) {
  const callbackDeadline = Date.now() + DAILY_REPORTS_CALLBACK_BUDGET_MS;
  const job = await beforeDeadline(() => getDailyVacancyJobByTaskUid(taskUid), callbackDeadline);
  if (!job) throw new Error("Existing managed daily job not found");
  assertManagedJobPolicy(job, taskUid);
  const { localDate } = getLosAngelesCalendar(new Date());
  const result = await processManagedDailyReport(job, localDate, "collections_test", callbackDeadline);
  return { ...result, sent: result.status === "sent", localDate,
    from: GMAIL_REPORT_SENDER, to: [DAILY_VACANCY_TEST_RECIPIENT] };
}

export async function dailyVacancyScheduledHandler(req: Request, res: Response) {
  const callbackDeadline = Date.now() + DAILY_REPORTS_CALLBACK_BUDGET_MS;
  let taskUid: string | undefined;
  try {
    const user = await beforeDeadline(() => sdk.authenticateRequest(req), callbackDeadline);
    if (!user.isCron || !user.taskUid) return res.status(403).json({ error: "cron-only" });
    taskUid = user.taskUid;
  } catch { return res.status(403).json({ error: "cron-only" }); }
  try {
    // Body never supplies identity, recipients, timing, dates, approval, or enabled state.
    const job = await beforeDeadline(() => getDailyVacancyJobByTaskUid(taskUid!), callbackDeadline);
    if (!job) return res.json({ ok: true, skipped: "orphan" });
    if (!job.enabled) return res.json({ ok: true, skipped: "disabled" });
    if (!job.collectionsApproved) return res.json({ ok: true, skipped: "awaiting-collections-approval" });
    if (job.scheduleKey !== DAILY_VACANCY_SCHEDULE_KEY || job.timezone !== DAILY_VACANCY_TIMEZONE
      || job.sendHour !== DAILY_REPORTS_LEGACY_COLLECTIONS_JOB_ANCHOR_HOUR || job.scheduleCronTaskUid !== taskUid) return res.json({ ok: true, skipped: "invalid-config" });
    const now = new Date();
    const { localDate, hour } = getLosAngelesCalendar(now);
    const reportType = getDueDailyReport(hour);
    if (!reportType) return res.json({ ok: true, skipped: "off-time" });
    if (!job.activatedAt || !job.firstSendDate || now < job.activatedAt || localDate < job.firstSendDate
      || localDate < firstDailyReportSendDate(job.activatedAt, reportType)) return res.json({ ok: true, skipped: "before-activation" });
    assertManagedJobPolicy(job, taskUid);
    // Never claim/fetch the other slot, including a missed or failed morning Vacancy at 1 PM.
    const report = await processManagedDailyReport(job, localDate, reportType, callbackDeadline);
    const reports = { [reportType]: report };
    const { retrySafe, manualReviewNeeded } = report;
    return res.status(retrySafe ? 503 : 200).json({
      ok: !retrySafe, localDate, reports, retrySafe, manualReviewNeeded,
      status: retrySafe ? "preparation-failed" : manualReviewNeeded ? "delivery-not-retried"
        : report.status === "sent" ? "sent" : "processed",
    });
  } catch {
    // Static errors only; upstream errors may contain secrets or SMTP payloads.
    return res.status(500).json({ error: "daily-reports-callback-failed", context: { url: req.originalUrl, taskUid }, timestamp: new Date().toISOString() });
  }
}
