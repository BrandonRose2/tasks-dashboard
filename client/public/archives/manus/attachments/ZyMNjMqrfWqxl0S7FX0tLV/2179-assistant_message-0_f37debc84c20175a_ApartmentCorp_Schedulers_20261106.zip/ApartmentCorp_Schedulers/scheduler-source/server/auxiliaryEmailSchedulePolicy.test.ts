import { describe, expect, it } from "vitest";
import type { AuxiliaryEmailJob } from "../drizzle/schema";
import { AUXILIARY_POLICIES, auxiliaryGate, firstAuxiliarySendDate, getNewYorkCalendar, isAuxiliaryJobPolicyValid } from "./auxiliaryEmailSchedulePolicy";
const job = (type: "weekly_vacancy" | "eviction_reminders") => ({ id: 1, reportType: type, ...AUXILIARY_POLICIES[type], scheduleCronTaskUid: "uid", enabled: true, timezone: "America/New_York", sendHour: 9,
  activatedAt: new Date("2026-01-01T00:00:00Z"), firstSendDate: "2026-01-01" } as AuxiliaryEmailJob);

describe("auxiliary NY calendar and activation (independent of server TZ)", () => {
  it.each([
    ["2026-03-07T14:00:00Z", "2026-03-07T13:00:00Z"],
    ["2026-03-14T13:00:00Z", "2026-03-14T14:00:00Z"],
    ["2026-10-31T13:00:00Z", "2026-10-31T14:00:00Z"],
    ["2026-11-07T14:00:00Z", "2026-11-07T13:00:00Z"],
  ])("weekly UTC candidates %s due / %s no-op through EST/EDT changes", (due, off) => {
    expect(auxiliaryGate(job("weekly_vacancy"), new Date(due))).toBeNull();
    expect(auxiliaryGate(job("weekly_vacancy"), new Date(off))).toBe("off-time");
  });
  it.each([
    ["2026-03-01T14:00:00Z", "2026-03-01T13:00:00Z"],
    ["2026-03-15T13:00:00Z", "2026-03-15T14:00:00Z"],
    ["2026-11-01T14:00:00Z", "2026-11-01T13:00:00Z"],
    ["2026-11-15T14:00:00Z", "2026-11-15T13:00:00Z"],
    ["2026-07-01T13:00:00Z", "2026-07-01T14:00:00Z"],
  ])("eviction UTC candidates %s due / %s no-op", (due, off) => {
    expect(auxiliaryGate(job("eviction_reminders"), new Date(due))).toBeNull();
    expect(auxiliaryGate(job("eviction_reminders"), new Date(off))).toBe("off-time");
  });
  it("keeps UTC date boundary and midnight hour independent of PST process time", () => {
    expect(getNewYorkCalendar(new Date("2026-11-07T02:00:00Z"))).toEqual({ localDate: "2026-11-06", day: 6, hour: 21, weekday: 5 });
    expect(getNewYorkCalendar(new Date("2026-11-07T05:00:00Z")).hour).toBe(0);
  });
  it.each(["2026-11-06T14:00:00Z", "2026-11-08T14:00:00Z"])("weekly ignores other weekdays %s", time => {
    expect(auxiliaryGate(job("weekly_vacancy"), new Date(time))).toBe("off-time");
  });
  it("eviction ignores 2nd and 16th and weekly dates not 1st/15th", () => {
    for (const day of ["02", "07", "16", "28"]) expect(auxiliaryGate(job("eviction_reminders"), new Date(`2026-11-${day}T14:00:00Z`))).toBe("off-time");
  });
  it.each([
    ["weekly_vacancy", "2026-11-07T13:59:59Z", "2026-11-07"],
    ["weekly_vacancy", "2026-11-07T14:00:00Z", "2026-11-07"],
    ["weekly_vacancy", "2026-11-07T14:00:01Z", "2026-11-14"],
    ["weekly_vacancy", "2026-03-07T15:00:00Z", "2026-03-14"],
    ["eviction_reminders", "2026-11-01T14:00:01Z", "2026-11-15"],
    ["eviction_reminders", "2026-11-15T14:01:00Z", "2026-12-01"],
    ["eviction_reminders", "2026-03-01T15:00:00Z", "2026-03-15"],
  ] as const)("first date %s activated %s => %s without backfill", (type, instant, expected) => {
    expect(firstAuxiliarySendDate(new Date(instant), type)).toBe(expected);
  });
  it("activation must precede that day's exact slot; missing/future activation/date refuse", () => {
    const now = new Date("2026-11-07T14:05:00Z");
    for (const patch of [{ activatedAt: null }, { firstSendDate: null }, { activatedAt: new Date("2026-11-07T14:01:00Z") }, { activatedAt: new Date("2026-11-08T14:00:00Z") }, { firstSendDate: "2026-11-14" }]) {
      expect(auxiliaryGate({ ...job("weekly_vacancy"), ...patch }, now)).toBe("before-activation");
    }
  });
  it("validates UID, type, schedule key, endpoint, timezone and hour", () => {
    const j = job("weekly_vacancy");
    expect(isAuxiliaryJobPolicyValid(j, "uid", "weekly_vacancy")).toBe(true);
    for (const patch of [{ reportType: "eviction_reminders" }, { scheduleKey: "daily-vacancy" }, { endpointPath: "/api/scheduled/eviction-reminders" }, { timezone: "America/Los_Angeles" }, { sendHour: 10 }, { scheduleCronTaskUid: "orphan" }]) {
      expect(isAuxiliaryJobPolicyValid({ ...j, ...patch } as AuxiliaryEmailJob, "uid", "weekly_vacancy")).toBe(false);
    }
  });
  it("preserves exact standalone platform cron candidates", () => {
    expect(AUXILIARY_POLICIES.weekly_vacancy.cron).toBe("0 0 13,14 * * 6");
    expect(AUXILIARY_POLICIES.eviction_reminders.cron).toBe("0 0 13,14 1,15 * *");
  });
});
