import { describe, expect, it } from "vitest";
import type { MonthlyEmailJob } from "../drizzle/schema";
import { MONTHLY_POLICY, MONTHLY_RECIPIENTS, assertMonthlyRecipients, firstMonthlySendDate, getMonthlyCalendar, isMonthlyJobPolicyValid, monthlyGate, monthlySlotUtc } from "./monthlyEmailSchedulePolicy";
const job = (patch: Partial<MonthlyEmailJob> = {}) => ({ id: 1, ...MONTHLY_POLICY, scheduleCronTaskUid: "monthly-uid", recipientTo: [...MONTHLY_RECIPIENTS], enabled: true,
  activatedAt: new Date("2026-11-05T01:00:00Z"), firstSendDate: "2026-11-12", createdAt: new Date(), updatedAt: new Date(), ...patch }) as MonthlyEmailJob;
describe("monthly Pacific schedule", () => {
  it("restores the original 12th/1 PM, not a weekly or daily job", () => {
    expect(MONTHLY_POLICY.cron).toBe("0 0 20,21 12 * *");
    expect(MONTHLY_POLICY.endpointPath).toBe("/api/scheduled/monthly-net-cash-flow");
  });
  it.each([["2026-01-12", "21"], ["2026-03-12", "20"], ["2026-07-12", "20"], ["2026-11-12", "21"], ["2026-12-12", "21"]])("%s selects UTC hour %s", (date, hour) => {
    expect(monthlySlotUtc(date).toISOString()).toBe(`${date}T${hour}:00:00.000Z`);
    expect(getMonthlyCalendar(monthlySlotUtc(date))).toMatchObject({ localDate: date, day: 12, hour: 13 });
  });
  it.each(["2026-11-12T20:00:00Z", "2026-11-13T21:00:00Z", "2026-11-12T22:00:00Z", "2026-11-01T21:00:00Z"])("wrong local time/date %s is a no-op", time => expect(monthlyGate(job(), new Date(time))).toBe("off-time"));
  it("accepts legitimate platform delay within the eligible local hour", () => expect(monthlyGate(job(), new Date("2026-11-12T21:08:19Z"))).toBeNull());
  it.each([["2026-11-05T01:00:00Z", "2026-11-12"], ["2026-11-12T21:00:00Z", "2026-11-12"], ["2026-11-12T21:00:01Z", "2026-12-12"], ["2026-12-31T23:59:59Z", "2027-01-12"]])("activation %s starts %s without backfill", (time, date) => expect(firstMonthlySendDate(new Date(time))).toBe(date));
  it("activation after the nominal slot never sends that month on a retry", () => {
    const late = job({ activatedAt: new Date("2026-11-12T21:01:00Z"), firstSendDate: "2026-12-12" });
    expect(monthlyGate(late, new Date("2026-11-12T21:05:00Z"))).toBe("before-activation");
  });
  it.each([{ activatedAt: null }, { firstSendDate: null }, { activatedAt: new Date(NaN) }, { firstSendDate: "2026-12-12" }])("invalid activation boundary %j cannot send", patch => expect(monthlyGate(job(patch), new Date("2026-11-12T21:00:00Z"))).toBe("before-activation"));
  it.each(["2026-02-30", "invalid", "2026-11-12T00:00:00Z"])("invalid date %s is rejected", date => expect(() => monthlySlotUtc(date)).toThrow());
  it("invalid activation is rejected", () => expect(() => firstMonthlySendDate(new Date(NaN))).toThrow());
});
describe("monthly identity and exact recipient policy", () => {
  it("accepts only the bound monthly identity and approved Ethan/Marc ordering", () => {
    expect(isMonthlyJobPolicyValid(job(), "monthly-uid")).toBe(true);
    expect(() => assertMonthlyRecipients([...MONTHLY_RECIPIENTS])).not.toThrow();
  });
  it.each([{ timezone: "America/New_York" }, { sendHour: 9 }, { sendDay: 1 }, { scheduleKey: "weekly-vacancy" }, { endpointPath: "/api/scheduled/daily-vacancy" }, { scheduleCronTaskUid: "other-uid" }, { reportType: "weekly_vacancy" }])("invalid policy %j is rejected", patch => expect(isMonthlyJobPolicyValid(job(patch as any), "monthly-uid")).toBe(false));
  it.each([[], ["Brandon@ApartmentCorp.com", "mam@22.bz"], ["ethan@apartmentcorp.com"], ["mam@22.bz", "ethan@apartmentcorp.com"], ["ethan@apartmentcorp.com", "mam@22.bz", "other@example.com"], null])("wrong recipient snapshot %j is rejected", value => {
    expect(() => assertMonthlyRecipients(value)).toThrow();
    expect(isMonthlyJobPolicyValid(job({ recipientTo: value as any }), "monthly-uid")).toBe(false);
  });
});
