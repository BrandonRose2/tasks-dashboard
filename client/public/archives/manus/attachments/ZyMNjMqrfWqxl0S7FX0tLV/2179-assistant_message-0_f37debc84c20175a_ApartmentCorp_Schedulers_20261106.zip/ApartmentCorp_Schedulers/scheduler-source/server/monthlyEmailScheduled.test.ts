import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import type { MonthlyEmailDelivery, MonthlyEmailJob, MonthlyEmailRun } from "../drizzle/schema";
const mocks = vi.hoisted(() => ({ auth: vi.fn(), lookup: vi.fn(), fetch: vi.fn(), period: vi.fn(), prepare: vi.fn(), create: vi.fn(), send: vi.fn(), claimRun: vi.fn(), freeze: vi.fn(), list: vi.fn(), claimDelivery: vi.fn(), transitionDelivery: vi.fn(), transitionRun: vi.fn() }));
vi.mock("./_core/sdk", () => ({ sdk: { authenticateRequest: mocks.auth } }));
vi.mock("./monthlyNetCashReport", () => ({ fetchFreshMonthlyNetCashReport: mocks.fetch, getPreviousCompletedMonth: mocks.period }));
vi.mock("./emailService", () => ({ prepareMonthlyNetCashEmail: mocks.prepare }));
vi.mock("nodemailer", () => ({ default: { createTransport: mocks.create } }));
vi.mock("./monthlyEmailScheduleDb", () => ({ getMonthlyEmailJobByTaskUid: mocks.lookup, claimMonthlyEmailRun: mocks.claimRun, freezeMonthlyEmailPlan: mocks.freeze, getMonthlyEmailDeliveries: mocks.list, claimMonthlyEmailDelivery: mocks.claimDelivery, transitionMonthlyEmailDelivery: mocks.transitionDelivery, transitionMonthlyEmailRun: mocks.transitionRun }));
import { assertMonthlyMessage, assertMonthlySourceTime, monthlyNetCashFlowScheduledHandler, sanitiseMonthlyReceipt } from "./monthlyEmailScheduled";
import { MONTHLY_POLICY, MONTHLY_RECIPIENTS, getMonthlyCalendar } from "./monthlyEmailSchedulePolicy";
const copy = <T>(value: T): T => structuredClone(value);
const envelope = { from: '"Apartment Corp Reports" <apartmentcorp44@gmail.com>', replyTo: "ethan@apartmentcorp.com", to: MONTHLY_RECIPIENTS.join(", "), subject: "Marc's Net Cash Flow — October 2026", html: "<html><body>Monthly report</body></html>" };
let job: MonthlyEmailJob; let runs: MonthlyEmailRun[]; let deliveries: MonthlyEmailDelivery[];
async function trigger(body: unknown = { taskUid: "attacker", periodKey: "1999-12", recipient: "attacker@example.com", recipientTo: ["Brandon@ApartmentCorp.com"], timezone: "UTC" }) {
  const response = { code: 200, body: null as any, status(code: number) { this.code = code; return this; }, json(body: any) { this.body = body; return this; } };
  await monthlyNetCashFlowScheduledHandler({ body } as any, response as any); return response;
}
beforeEach(() => {
  vi.resetAllMocks(); vi.useFakeTimers(); vi.setSystemTime(new Date("2026-11-12T21:00:00Z"));
  vi.stubEnv("GMAIL_USER", "apartmentcorp44@gmail.com"); vi.stubEnv("GMAIL_APP_PASSWORD", "abcdefghijklmnop");
  job = { id: 1, ...MONTHLY_POLICY, scheduleCronTaskUid: "monthly-uid", recipientTo: [...MONTHLY_RECIPIENTS], enabled: true,
    activatedAt: new Date("2026-11-05T01:00:00Z"), firstSendDate: "2026-11-12", createdAt: new Date(), updatedAt: new Date() };
  runs = []; deliveries = [];
  mocks.auth.mockResolvedValue({ isCron: true, taskUid: "monthly-uid" }); mocks.lookup.mockImplementation(async () => copy(job));
  mocks.period.mockImplementation((now: Date) => { const local = getMonthlyCalendar(now); const month = local.month === 1 ? 12 : local.month - 1; const year = local.month === 1 ? local.year - 1 : local.year; const periodKey = `${year}-${String(month).padStart(2, "0")}`; return { year, month, periodKey, sourceDate: `${periodKey}-01`, monthName: "test month", label: "test month" }; });
  mocks.fetch.mockImplementation(async period => ({ month: { ...period, regions: [], grandTotal: 100 }, sourceUpdatedAt: new Date() }));
  mocks.prepare.mockImplementation((_month, recipients) => ({ message: { ...envelope, to: recipients.join(", ") } }));
  mocks.create.mockReturnValue({ sendMail: mocks.send });
  mocks.send.mockResolvedValue({ accepted: [...MONTHLY_RECIPIENTS], rejected: [], messageId: "<monthly@gmail.com>", response: "private smtp text" });
  mocks.claimRun.mockImplementation(async (jobId, periodKey, token) => {
    let r = runs.find(r => r.jobId === jobId && r.periodKey === periodKey);
    if (!r) { r = { id: runs.length + 1, jobId, periodKey, state: "preparing", attemptToken: token, planCount: null, sourceUpdatedAt: null, outcome: null, failureCode: null, createdAt: new Date(), updatedAt: new Date() }; runs.push(r); }
    else if (r.state === "failed_before_send" && r.planCount === null) Object.assign(r, { state: "preparing", attemptToken: token, failureCode: null });
    return { run: copy(r), ownedPreparation: r.state === "preparing" && r.attemptToken === token };
  });
  mocks.transitionRun.mockImplementation(async (id, token, expected, state, patch) => { const r = runs.find(r => r.id === id && r.attemptToken === token && r.state === expected); if (!r) return false; Object.assign(r, patch, { state }); return true; });
  mocks.freeze.mockImplementation(async (id, token, sourceUpdatedAt, plan) => {
    const r = runs.find(r => r.id === id && r.attemptToken === token && r.state === "preparing" && r.planCount === null); if (!r) return false;
    Object.assign(r, { state: "ready", sourceUpdatedAt, planCount: plan.length });
    deliveries.push(...plan.map((p: any) => ({ id: deliveries.length + 1, runId: id, ...copy(p), state: "pending", attemptToken: null, messageId: null, smtpReceipt: null, failureCode: null, createdAt: new Date(), updatedAt: new Date() }))); return true;
  });
  mocks.list.mockImplementation(async id => copy(deliveries.filter(d => d.runId === id)));
  mocks.claimDelivery.mockImplementation(async (id, token) => { const d = deliveries.find(d => d.id === id && d.state === "pending"); if (!d) return false; Object.assign(d, { state: "sending", attemptToken: token }); return true; });
  mocks.transitionDelivery.mockImplementation(async (id, token, state, patch) => { const d = deliveries.find(d => d.id === id && d.state === "sending" && d.attemptToken === token); if (!d) return false; Object.assign(d, patch, { state }); return true; });
});
afterEach(() => { vi.useRealTimers(); vi.unstubAllEnvs(); });
describe("monthly identity and policy", () => {
  it.each([{ isCron: false, taskUid: "monthly-uid" }, { isCron: true }, {}])("rejects non-cron identity %j before lookup", async user => { mocks.auth.mockResolvedValue(user); expect((await trigger()).code).toBe(403); expect(mocks.lookup).not.toHaveBeenCalled(); expect(mocks.send).not.toHaveBeenCalled(); });
  it("authentication failures never expose secrets", async () => { mocks.auth.mockRejectedValue(new Error("private")); const r = await trigger(); expect(r.code).toBe(403); expect(JSON.stringify(r.body)).not.toContain("private"); });
  it("orphan/disabled jobs cannot prepare or send", async () => { mocks.lookup.mockResolvedValueOnce(undefined); expect((await trigger()).body.skipped).toBe("orphan"); job.enabled = false; expect((await trigger()).body.skipped).toBe("disabled"); expect(mocks.claimRun).not.toHaveBeenCalled(); });
  it.each([{ timezone: "UTC" }, { sendHour: 9 }, { sendDay: 1 }, { reportType: "weekly_vacancy" }, { scheduleCronTaskUid: "other" }, { recipientTo: ["Brandon@ApartmentCorp.com", "mam@22.bz"] }])("invalid monthly policy %j cannot send", async patch => { Object.assign(job, patch); expect((await trigger()).body.skipped).toBe("invalid-config"); expect(mocks.fetch).not.toHaveBeenCalled(); expect(mocks.send).not.toHaveBeenCalled(); });
  it("local DST gate prevents wrong UTC candidate or backfill", async () => { vi.setSystemTime(new Date("2026-11-12T20:00:00Z")); expect((await trigger()).body.skipped).toBe("off-time"); vi.setSystemTime(new Date("2026-11-12T21:05:00Z")); job.activatedAt = new Date("2026-11-12T21:01:00Z"); expect((await trigger()).body.skipped).toBe("before-activation"); expect(mocks.claimRun).not.toHaveBeenCalled(); });
  it("lookup failure returns controlled JSON rather than leaking error", async () => { mocks.lookup.mockRejectedValue(new Error("credential")); const r = await trigger(); expect(r.code).toBe(500); expect(JSON.stringify(r.body)).not.toContain("credential"); });
});
describe("monthly frozen plan and duplicate boundary", () => {
  it("freezes previous month and exact approved envelope before SMTP, never trusts body", async () => {
    mocks.send.mockImplementationOnce(async message => { expect(deliveries[0].state).toBe("sending"); expect(runs[0].periodKey).toBe("2026-10"); expect(message).toEqual(envelope); expect(message).not.toHaveProperty("cc"); expect(message).not.toHaveProperty("bcc"); return { accepted: [...MONTHLY_RECIPIENTS], rejected: [], messageId: "<monthly@gmail.com>" }; });
    expect((await trigger()).body.status).toBe("sent"); expect(mocks.lookup).toHaveBeenCalledWith("monthly-uid"); expect(mocks.fetch.mock.calls[0][0].sourceDate).toBe("2026-10-01");
    expect(deliveries[0].smtpReceipt?.response).toBe("accepted"); await trigger(); expect(mocks.send).toHaveBeenCalledOnce(); expect(mocks.fetch).toHaveBeenCalledOnce();
  });
  it("parallel callbacks send one message for one monthly reporting period", async () => { await Promise.all([trigger(), trigger(), trigger()]); expect(runs).toHaveLength(1); expect(deliveries).toHaveLength(1); expect(mocks.send).toHaveBeenCalledOnce(); });
  it("December and January are distinct reporting keys and correctly cross the year", async () => { vi.setSystemTime(new Date("2027-01-12T21:00:00Z")); await trigger(); vi.setSystemTime(new Date("2027-02-12T21:00:00Z")); await trigger(); expect(runs.map(r => r.periodKey)).toEqual(["2026-12", "2027-01"]); expect(mocks.send).toHaveBeenCalledTimes(2); });
  it("a source reporting period mismatch stops before freeze or SMTP", async () => { mocks.fetch.mockResolvedValue({ month: { year: 2026, month: 11 }, sourceUpdatedAt: new Date() }); expect((await trigger()).code).toBe(503); expect(mocks.freeze).not.toHaveBeenCalled(); expect(mocks.send).not.toHaveBeenCalled(); });
  it("fresh source is not re-fetched and message is not rebuilt when a pending plan safely resumes", async () => { mocks.claimDelivery.mockResolvedValueOnce(false); await trigger(); const plan = copy(deliveries[0].message); mocks.fetch.mockRejectedValue(new Error("must not fetch")); mocks.prepare.mockImplementation(() => ({ message: { ...envelope, html: "changed" } })); expect((await trigger()).body.status).toBe("sent"); expect(mocks.fetch).toHaveBeenCalledOnce(); expect(mocks.send).toHaveBeenCalledWith(plan); });
  it.each([null, new Date(NaN), new Date("2026-11-12T20:54:59Z"), new Date("2026-11-12T21:00:01Z")])("stale/missing/future source %s fails safely before SMTP", async sourceUpdatedAt => { mocks.fetch.mockResolvedValue({ month: { year: 2026, month: 10 }, sourceUpdatedAt }); expect((await trigger()).code).toBe(503); expect(runs[0].state).toBe("failed_before_send"); expect(mocks.send).not.toHaveBeenCalled(); });
  it("freshness exactly five minutes is accepted; older is rejected", () => { expect(() => assertMonthlySourceTime(new Date(Date.now() - 300_000))).not.toThrow(); expect(() => assertMonthlySourceTime(new Date(Date.now() - 300_001))).toThrow(); });
  it("confirmed preparation failure can retry without duplicate or frozen plan reset", async () => { mocks.fetch.mockRejectedValueOnce(new Error("source private")); expect((await trigger()).code).toBe(503); expect((await trigger()).body.status).toBe("sent"); expect(runs).toHaveLength(1); expect(mocks.send).toHaveBeenCalledOnce(); });
  it.each(["GMAIL_USER", "GMAIL_APP_PASSWORD"])("missing fixed Gmail configuration %s stops before data or SMTP", async key => { vi.stubEnv(key, ""); expect((await trigger()).code).toBe(503); expect(mocks.fetch).not.toHaveBeenCalled(); expect(mocks.send).not.toHaveBeenCalled(); });
  it("wrong Gmail does not fall back to another account", async () => { vi.stubEnv("GMAIL_USER", "other@gmail.com"); expect((await trigger()).code).toBe(503); expect(mocks.send).not.toHaveBeenCalled(); });
  it("unknown claim/freeze/CAS outcomes cannot initiate SMTP", async () => {
    mocks.claimRun.mockRejectedValueOnce(new Error("unknown insert")); expect((await trigger()).body.status).toBe("claim-unconfirmed");
    mocks.freeze.mockRejectedValueOnce(new Error("unknown plan commit")); expect((await trigger()).body.status).toBe("plan-unconfirmed"); expect((await trigger()).body.status).toBe("already-claimed"); expect(mocks.send).not.toHaveBeenCalled();
  });
  it("uncertain sending claim never invokes SMTP", async () => { mocks.claimDelivery.mockRejectedValueOnce(new Error("unknown CAS")); expect((await trigger()).body.status).toBe("delivery-claim-unconfirmed"); expect(mocks.send).not.toHaveBeenCalled(); });
  it("late sending claim cannot start SMTP and cannot be reclaimed", async () => { mocks.claimDelivery.mockImplementationOnce(async (id, token) => { Object.assign(deliveries[0], { state: "sending", attemptToken: token }); vi.setSystemTime(new Date(Date.now() + 106_000)); return true; }); expect((await trigger()).body.status).toBe("sending"); await trigger(); expect(mocks.send).not.toHaveBeenCalled(); });
  it("a 75-second cold source bootstrap can finish within the 110-second callback budget", async () => { mocks.fetch.mockImplementationOnce(async period => { vi.setSystemTime(new Date(Date.now() + 75_000)); return { month: { ...period, regions: [], grandTotal: 100 }, sourceUpdatedAt: new Date() }; }); expect((await trigger()).body.status).toBe("sent"); expect(mocks.send).toHaveBeenCalledOnce(); });
  it("preparation timeout has no SMTP continuation", async () => { let resolve: (value: any) => void = () => {}; mocks.fetch.mockImplementationOnce(() => new Promise(r => { resolve = r; })); const pending = trigger(); await vi.advanceTimersByTimeAsync(80_000); expect((await pending).code).toBe(503); resolve({ month: { year: 2026, month: 10 }, sourceUpdatedAt: new Date() }); await Promise.resolve(); expect(mocks.send).not.toHaveBeenCalled(); });
  it("unconfirmed failure CAS refuses automatic preparation retry", async () => { mocks.fetch.mockRejectedValueOnce(new Error("source")); mocks.transitionRun.mockResolvedValueOnce(false); expect((await trigger()).body.status).toBe("preparation-unconfirmed"); expect((await trigger()).body.status).toBe("already-claimed"); expect(mocks.send).not.toHaveBeenCalled(); });
  it("stale retained pending plan cannot send or silently refresh financial numbers", async () => { mocks.claimDelivery.mockResolvedValueOnce(false); await trigger(); const ledger = copy(deliveries); vi.setSystemTime(new Date(Date.now() + 301_000)); expect((await trigger()).code).toBe(503); expect(deliveries).toEqual(ledger); expect(mocks.fetch).toHaveBeenCalledOnce(); expect(mocks.send).not.toHaveBeenCalled(); });
  it("receipt-only completion does not require fresh source or working Gmail", async () => { mocks.transitionRun.mockResolvedValueOnce(false); await trigger(); expect(deliveries[0].state).toBe("sent"); vi.setSystemTime(new Date(Date.now() + 360_000)); vi.stubEnv("GMAIL_USER", ""); expect((await trigger()).body.status).toBe("sent"); expect(mocks.send).toHaveBeenCalledOnce(); });
});
describe("monthly ambiguity and no CC/BCC", () => {
  it.each([{ accepted: ["ethan@apartmentcorp.com"], rejected: ["mam@22.bz"] }, { accepted: [...MONTHLY_RECIPIENTS] }, { accepted: [...MONTHLY_RECIPIENTS, "other@example.com"], rejected: [] }])("unconfirmed recipient acceptance %j is never retried", async receipt => { mocks.send.mockResolvedValue(receipt); expect((await trigger()).body.manualReviewNeeded).toBe(true); expect(deliveries[0].state).toBe("unknown"); await trigger(); expect(mocks.send).toHaveBeenCalledOnce(); });
  it("SMTP exception and uncertain receipt persistence remain fail-closed", async () => { mocks.send.mockRejectedValueOnce(new Error("secret")); const r = await trigger(); expect(r.body.manualReviewNeeded).toBe(true); expect(deliveries[0].state).toBe("unknown"); expect(JSON.stringify(deliveries)).not.toContain("secret"); await trigger(); expect(mocks.send).toHaveBeenCalledOnce(); });
  it("SMTP timeout returns within the 2-minute platform limit and never resends", async () => { mocks.send.mockImplementationOnce(() => new Promise(() => {})); const pending = trigger(); await vi.advanceTimersByTimeAsync(110_000); expect((await pending).body.manualReviewNeeded).toBe(true); expect(deliveries[0].state).toBe("sending"); await trigger(); expect(mocks.send).toHaveBeenCalledOnce(); });
  it.each([{ cc: "other@example.com" }, { bcc: "other@example.com" }, { envelope: { to: "other@example.com" } }, { from: "other@gmail.com" }, { to: "Brandon@ApartmentCorp.com, mam@22.bz" }, { html: "" }])("forbidden message policy %j fails before freeze", async patch => { mocks.prepare.mockReturnValueOnce({ message: { ...envelope, ...patch } }); expect((await trigger()).code).toBe(503); expect(mocks.freeze).not.toHaveBeenCalled(); expect(mocks.send).not.toHaveBeenCalled(); });
  it("receipt retains only expected addresses and safe message ID", () => { const result = sanitiseMonthlyReceipt({ accepted: [...MONTHLY_RECIPIENTS], rejected: [], messageId: "password=private\n", response: "private" }, envelope); expect(result.fullyAccepted).toBe(true); expect(result.receipt.messageId).toBe(""); expect(JSON.stringify(result)).not.toContain("private"); expect(() => assertMonthlyMessage({ ...envelope, bcc: "other@example.com" } as any)).toThrow(); });
});
