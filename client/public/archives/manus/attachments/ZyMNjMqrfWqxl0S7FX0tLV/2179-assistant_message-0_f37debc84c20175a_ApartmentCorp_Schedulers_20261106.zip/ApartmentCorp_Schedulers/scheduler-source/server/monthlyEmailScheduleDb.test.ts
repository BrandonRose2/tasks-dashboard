import { beforeEach, describe, expect, it, vi } from "vitest";
import { MySqlDialect, getTableConfig } from "drizzle-orm/mysql-core";
import { readFileSync } from "node:fs";
const mocks = vi.hoisted(() => ({
  getDb: vi.fn(),
  values: vi.fn(),
  limit: vi.fn(),
  set: vi.fn(),
  updateWhere: vi.fn(),
  orderBy: vi.fn(),
  transaction: vi.fn(),
}));
vi.mock("./db", () => ({ getDb: mocks.getDb }));
import {
  activateMonthlyEmailJob,
  bindMonthlyEmailHeartbeat,
  claimMonthlyEmailDelivery,
  claimMonthlyEmailRun,
  freezeMonthlyEmailPlan,
  getMonthlyEmailDeliveries,
  getMonthlyEmailJobByTaskUid,
  provisionMonthlyEmailJob,
  transitionMonthlyEmailDelivery,
  transitionMonthlyEmailRun,
} from "./monthlyEmailScheduleDb";
import {
  monthlyEmailJobs,
  monthlyEmailRuns,
  monthlyEmailDeliveries,
  type MonthlyEmailMessage,
} from "../drizzle/schema";
import {
  MONTHLY_POLICY,
  MONTHLY_RECIPIENTS,
  firstMonthlySendDate,
} from "./monthlyEmailSchedulePolicy";
const dialect = new MySqlDialect();
const job = {
  id: 7,
  ...MONTHLY_POLICY,
  recipientTo: [...MONTHLY_RECIPIENTS],
  scheduleCronTaskUid: null,
  enabled: false,
  activatedAt: null,
  firstSendDate: null,
};
const boundJob = { ...job, scheduleCronTaskUid: "uid" };
const run = {
  id: 1,
  jobId: 7,
  periodKey: "2026-01",
  attemptToken: "old",
  state: "preparing",
  planCount: null,
  sourceUpdatedAt: null,
};
const sourceUpdatedAt = new Date("2026-02-12T21:00:00Z");
const makeMessage = (): MonthlyEmailMessage => ({
  from: '"Apartment Corp Reports" <reports@gmail.com>',
  replyTo: "ethan@apartmentcorp.com",
  to: MONTHLY_RECIPIENTS.join(", "),
  subject: "January 2026 Net Cash Flow",
  html: "<p>Frozen monthly report</p>",
});
const makePlan = () => [{ deliveryKey: "2026-01", message: makeMessage() }];
const query = (index = 0) =>
  dialect.sqlToQuery(mocks.updateWhere.mock.calls[index][0]);
let db: any;
beforeEach(() => {
  vi.resetAllMocks();
  db = {
    insert: vi.fn(() => ({ values: mocks.values })),
    select: vi.fn(() => ({
      from: vi.fn(() => ({
        where: vi.fn(() => ({ limit: mocks.limit, orderBy: mocks.orderBy })),
      })),
    })),
    update: vi.fn(() => ({ set: mocks.set })),
    transaction: mocks.transaction,
  };
  mocks.getDb.mockResolvedValue(db);
  mocks.values.mockResolvedValue([]);
  mocks.set.mockReturnValue({ where: mocks.updateWhere });
  mocks.updateWhere.mockResolvedValue([{ affectedRows: 1 }]);
  mocks.orderBy.mockResolvedValue([]);
  mocks.transaction.mockImplementation(async callback => callback(db));
});

describe("monthly SQL ownership by reporting period", () => {
  it.each(["2026-01", "2026-12", "2027-01"])(
    "claims one job/%s, not a send date",
    async periodKey => {
      mocks.limit.mockResolvedValue([
        { ...run, periodKey, attemptToken: "new" },
      ]);
      expect(
        (await claimMonthlyEmailRun(7, periodKey, "new")).ownedPreparation
      ).toBe(true);
      expect(mocks.values).toHaveBeenCalledWith({
        jobId: 7,
        periodKey,
        attemptToken: "new",
        state: "preparing",
      });
      expect(db.insert).toHaveBeenCalledWith(monthlyEmailRuns);
    }
  );
  it.each(["2026-01", "2026-12"])(
    "duplicate %s never resets ownership or ledgers",
    async periodKey => {
      mocks.values.mockRejectedValueOnce({ cause: { code: "ER_DUP_ENTRY" } });
      mocks.limit.mockResolvedValue([{ ...run, periodKey }]);
      const result = await claimMonthlyEmailRun(7, periodKey, "new");
      expect(result.ownedPreparation).toBe(false);
      expect(result.run.attemptToken).toBe("old");
      expect(mocks.set).not.toHaveBeenCalled();
    }
  );
  it.each(["preparing", "processing", "ready", "review", "complete"])(
    "existing %s is never automatically reclaimed",
    async state => {
      mocks.values.mockRejectedValueOnce({ errno: 1062 });
      mocks.limit.mockResolvedValue([{ ...run, state }]);
      expect(
        (await claimMonthlyEmailRun(7, "2026-01", "new")).ownedPreparation
      ).toBe(false);
      expect(mocks.set).not.toHaveBeenCalled();
    }
  );
  it("only failed-before-send with null plan has state/token/unfrozen CAS", async () => {
    mocks.values.mockRejectedValueOnce({ errno: 1062 });
    mocks.limit.mockResolvedValue([{ ...run, state: "failed_before_send" }]);
    expect(
      (await claimMonthlyEmailRun(7, "2026-01", "new")).ownedPreparation
    ).toBe(true);
    expect(query().params).toEqual([1, "failed_before_send", "old"]);
    expect(query().sql).toContain("`plan_count` is null");
    expect(mocks.set).toHaveBeenCalledWith({
      state: "preparing",
      attemptToken: "new",
      failureCode: null,
    });
  });
  it("failed-before-send with a frozen plan and a lost retry CAS never own preparation", async () => {
    mocks.values.mockRejectedValue({ code: "ER_DUP_ENTRY" });
    mocks.limit.mockResolvedValueOnce([
      { ...run, state: "failed_before_send", planCount: 1 },
    ]);
    expect(
      (await claimMonthlyEmailRun(7, "2026-01", "new")).ownedPreparation
    ).toBe(false);
    expect(mocks.set).not.toHaveBeenCalled();
    mocks.limit.mockResolvedValueOnce([
      { ...run, state: "failed_before_send" },
    ]);
    mocks.updateWhere.mockResolvedValueOnce([{ affectedRows: 0 }]);
    expect(
      (await claimMonthlyEmailRun(7, "2026-01", "loser")).ownedPreparation
    ).toBe(false);
  });
  it.each([
    "2026-00",
    "2026-13",
    "2026-1",
    "2026-01-12",
    "0000-01",
    "2026-12 ",
  ])("rejects invalid period %s before DB access", async periodKey => {
    await expect(claimMonthlyEmailRun(7, periodKey, "new")).rejects.toThrow(
      "reporting period"
    );
    expect(mocks.getDb).not.toHaveBeenCalled();
  });
  it("nonduplicate insert error, unconfirmed insert and unknown retry commit never grant ownership", async () => {
    mocks.values.mockRejectedValueOnce(new Error("unknown insert commit"));
    await expect(claimMonthlyEmailRun(7, "2026-01", "new")).rejects.toThrow(
      "unknown insert commit"
    );
    mocks.limit.mockResolvedValueOnce([]);
    await expect(claimMonthlyEmailRun(7, "2026-01", "new")).rejects.toThrow(
      "not confirmed"
    );
    mocks.values.mockRejectedValueOnce({ code: "ER_DUP_ENTRY" });
    mocks.limit.mockResolvedValueOnce([
      { ...run, state: "failed_before_send" },
    ]);
    mocks.updateWhere.mockRejectedValueOnce(new Error("unknown retry commit"));
    await expect(claimMonthlyEmailRun(7, "2026-01", "new")).rejects.toThrow(
      "unknown retry commit"
    );
  });
});

describe("frozen single monthly message", () => {
  it("atomically freezes exact To recipients and message without CC/BCC under owner/unfrozen CAS", async () => {
    const plan = makePlan();
    expect(await freezeMonthlyEmailPlan(1, "new", sourceUpdatedAt, plan)).toBe(
      true
    );
    expect(mocks.transaction).toHaveBeenCalledOnce();
    expect(db.insert).toHaveBeenCalledWith(monthlyEmailDeliveries);
    expect(mocks.values).toHaveBeenCalledWith([
      { ...plan[0], runId: 1, state: "pending" },
    ]);
    expect(query().params).toEqual([1, "new", "preparing"]);
    expect(query().sql).toContain("`plan_count` is null");
    const snapshot = mocks.values.mock.calls[0][0][0].message;
    expect(snapshot.to.split(",").map((value: string) => value.trim())).toEqual(
      ["ethan@apartmentcorp.com", "mam@22.bz"]
    );
    expect(Object.keys(snapshot).sort()).toEqual([
      "from",
      "html",
      "replyTo",
      "subject",
      "to",
    ]);
    expect(mocks.set).toHaveBeenCalledWith({
      state: "ready",
      sourceUpdatedAt,
      planCount: 1,
      outcome: null,
      failureCode: null,
    });
  });
  it("snapshots message/source primitives before awaits and leaves caller plan untouched", async () => {
    const plan = makePlan();
    const expected = structuredClone(plan);
    const date = new Date(sourceUpdatedAt);
    const frozen = freezeMonthlyEmailPlan(1, "new", date, plan);
    plan[0].message.html = "changed by caller";
    plan[0].message.to = "attacker@example.com";
    date.setUTCFullYear(2030);
    expect(await frozen).toBe(true);
    expect(mocks.values).toHaveBeenCalledWith([
      { ...expected[0], runId: 1, state: "pending" },
    ]);
    expect(mocks.set.mock.calls[0][0].sourceUpdatedAt).toEqual(sourceUpdatedAt);
    expect(plan[0].message.html).toBe("changed by caller");
  });
  it("lost/repeated freeze never inserts or overwrites original plan", async () => {
    expect(
      await freezeMonthlyEmailPlan(1, "old", sourceUpdatedAt, makePlan())
    ).toBe(true);
    mocks.updateWhere.mockResolvedValueOnce([{ affectedRows: 0 }]);
    const changed = makePlan();
    changed[0].message.subject = "replacement";
    expect(await freezeMonthlyEmailPlan(1, "new", new Date(), changed)).toBe(
      false
    );
    expect(mocks.values).toHaveBeenCalledTimes(1);
    expect(mocks.values.mock.calls[0][0][0].message.subject).toBe(
      "January 2026 Net Cash Flow"
    );
  });
  it("empty/no-email plan commits complete atomically and cannot insert deliveries", async () => {
    expect(await freezeMonthlyEmailPlan(1, "new", sourceUpdatedAt, [])).toBe(
      true
    );
    expect(mocks.set.mock.calls[0][0]).toMatchObject({
      state: "complete",
      planCount: 0,
      outcome: "no-email",
    });
    expect(db.insert).not.toHaveBeenCalled();
  });
  it.each([
    { to: "ethan@apartmentcorp.com" },
    { to: "mam@22.bz, ethan@apartmentcorp.com" },
    { to: "ethan@apartmentcorp.com, mam@22.bz, extra@example.com" },
    { to: "ethan@apartmentcorp.com, ethan@apartmentcorp.com" },
    { cc: "extra@example.com" },
    { bcc: "extra@example.com" },
    { headers: { Bcc: "extra@example.com" } },
    { subject: "" },
  ])("rejects recipient/field expansion %j before transaction", async patch => {
    const plan = makePlan();
    Object.assign(plan[0].message, patch);
    await expect(
      freezeMonthlyEmailPlan(1, "new", sourceUpdatedAt, plan)
    ).rejects.toThrow();
    expect(mocks.transaction).not.toHaveBeenCalled();
  });
  it("rejects two deliveries and invalid source time before transaction", async () => {
    await expect(
      freezeMonthlyEmailPlan(1, "new", sourceUpdatedAt, [
        ...makePlan(),
        ...makePlan(),
      ])
    ).rejects.toThrow("at most one");
    await expect(
      freezeMonthlyEmailPlan(1, "new", new Date(NaN), makePlan())
    ).rejects.toThrow("source timestamp");
    expect(mocks.transaction).not.toHaveBeenCalled();
  });
  it("insert rollback and uncertain transaction commit never confirm an SMTP plan", async () => {
    mocks.values.mockRejectedValueOnce(new Error("rollback"));
    await expect(
      freezeMonthlyEmailPlan(1, "new", sourceUpdatedAt, makePlan())
    ).rejects.toThrow("rollback");
    mocks.transaction.mockImplementationOnce(async callback => {
      await callback(db);
      throw new Error("unknown transaction commit");
    });
    await expect(
      freezeMonthlyEmailPlan(1, "new", sourceUpdatedAt, makePlan())
    ).rejects.toThrow("unknown transaction commit");
    expect(db.update).toHaveBeenCalledTimes(2);
    expect(
      db.update.mock.calls.every((call: any) => call[0] === monthlyEmailRuns)
    ).toBe(true);
  });
  it("returns ordered frozen deliveries with no mutation", async () => {
    const rows = [{ id: 4, runId: 1, state: "sent", message: makeMessage() }];
    mocks.orderBy.mockResolvedValueOnce(rows);
    expect(await getMonthlyEmailDeliveries(1)).toEqual(rows);
    expect(mocks.orderBy).toHaveBeenCalledOnce();
    expect(db.update).not.toHaveBeenCalled();
  });
});

describe("confirmed non-reclaimable delivery CAS", () => {
  it("pending->sending requires confirmed affected row; lost CAS never authorizes send", async () => {
    expect(await claimMonthlyEmailDelivery(4, "new")).toBe(true);
    expect(query().params).toEqual([4, "pending"]);
    expect(mocks.set).toHaveBeenCalledWith({
      state: "sending",
      attemptToken: "new",
    });
    mocks.updateWhere.mockResolvedValueOnce([{ affectedRows: 0 }]);
    expect(await claimMonthlyEmailDelivery(4, "loser")).toBe(false);
  });
  it.each(["sending", "sent", "unknown"])(
    "cannot reclaim %s by time, token or reset",
    async () => {
      mocks.updateWhere.mockResolvedValueOnce([{ affectedRows: 0 }]);
      expect(await claimMonthlyEmailDelivery(4, "new")).toBe(false);
      expect(query().params).toEqual([4, "pending"]);
      expect(query().sql).not.toMatch(/updated_at|created_at|attempt_token/);
    }
  );
  it.each(["sent", "unknown"] as const)(
    "receipt %s only changes sending owned by token",
    async target => {
      expect(
        await transitionMonthlyEmailDelivery(4, "new", target, {
          messageId: "id",
          failureCode: null,
        })
      ).toBe(true);
      expect(query().params).toEqual([4, "new", "sending"]);
      expect(db.insert).not.toHaveBeenCalled();
      mocks.updateWhere.mockResolvedValueOnce([{ affectedRows: 0 }]);
      expect(await transitionMonthlyEmailDelivery(4, "stale", target)).toBe(
        false
      );
    }
  );
  it("uncertain sending and receipt commits reject instead of returning authorization/success", async () => {
    mocks.updateWhere.mockRejectedValueOnce(new Error("unknown claim commit"));
    await expect(claimMonthlyEmailDelivery(4, "new")).rejects.toThrow(
      "unknown claim commit"
    );
    mocks.updateWhere.mockRejectedValueOnce(
      new Error("unknown receipt commit")
    );
    await expect(
      transitionMonthlyEmailDelivery(4, "new", "sent")
    ).rejects.toThrow("unknown receipt commit");
    mocks.getDb.mockResolvedValueOnce(null);
    await expect(claimMonthlyEmailDelivery(4, "new")).rejects.toThrow(
      "unavailable"
    );
  });
  it("run transitions CAS token/state, preserve plans and never update deliveries", async () => {
    expect(
      await transitionMonthlyEmailRun(1, "new", "ready", "complete", {
        outcome: "sent",
      })
    ).toBe(true);
    expect(query().params).toEqual([1, "new", "ready"]);
    expect(db.update).toHaveBeenCalledWith(monthlyEmailRuns);
    expect(db.insert).not.toHaveBeenCalled();
    mocks.updateWhere.mockResolvedValueOnce([{ affectedRows: 0 }]);
    expect(await transitionMonthlyEmailRun(1, "stale", "ready", "review")).toBe(
      false
    );
  });
  it("preparation failure requires unfrozen CAS; transition APIs cannot mutate frozen message/source/plan or reset terminal states", async () => {
    expect(
      await transitionMonthlyEmailRun(
        1,
        "new",
        "preparing",
        "failed_before_send",
        { failureCode: "preparation-failed" }
      )
    ).toBe(true);
    expect(query().sql).toContain("`plan_count` is null");
    await expect(
      transitionMonthlyEmailRun(1, "new", "ready", "ready", {
        planCount: 9,
      } as any)
    ).rejects.toThrow();
    await expect(
      transitionMonthlyEmailRun(1, "new", "ready", "ready", {
        sourceUpdatedAt,
      } as any)
    ).rejects.toThrow();
    await expect(
      transitionMonthlyEmailRun(1, "new", "review", "preparing")
    ).rejects.toThrow();
    await expect(
      transitionMonthlyEmailRun(1, "new", "complete", "ready")
    ).rejects.toThrow();
    await expect(
      transitionMonthlyEmailDelivery(4, "new", "pending" as any)
    ).rejects.toThrow();
    await expect(
      transitionMonthlyEmailDelivery(4, "new", "sent", {
        message: makeMessage(),
      } as any)
    ).rejects.toThrow();
    expect(db.update).toHaveBeenCalledTimes(1);
  });
});

describe("explicit monthly provisioning/binding/activation only", () => {
  it.each(["bind", "activate", "resume"])("%s compares recipient JSON as JSON, not a scalar string", async operation => {
    const now = new Date("2026-11-05T18:45:00Z");
    const active = { ...boundJob, enabled: true, activatedAt: now, firstSendDate: firstMonthlySendDate(now) };
    if (operation === "bind") {
      mocks.limit.mockResolvedValueOnce([job]).mockResolvedValueOnce([]).mockResolvedValueOnce([boundJob]);
      await bindMonthlyEmailHeartbeat(7, "uid");
    } else {
      mocks.limit.mockResolvedValueOnce([operation === "resume" ? { ...active, enabled: false } : boundJob]).mockResolvedValueOnce([active]);
      await activateMonthlyEmailJob(7, now);
    }
    const q = query();
    expect(q.sql).toMatch(/`recipient_to` = CAST\(\? AS JSON\)/i);
    expect(q.params).toContain(JSON.stringify([...MONTHLY_RECIPIENTS]));
    expect(q.sql).not.toContain("daily_vacancy_jobs");
    expect(q.sql).not.toContain("auxiliary_email_jobs");
  });
  it("provisions disabled fixed job with JSON approved pair and duplicate no-op only", async () => {
    const duplicate = vi.fn().mockResolvedValue([]);
    mocks.values.mockReturnValueOnce({ onDuplicateKeyUpdate: duplicate });
    mocks.limit.mockResolvedValueOnce([job]);
    expect(await provisionMonthlyEmailJob()).toEqual(job);
    expect(mocks.values).toHaveBeenCalledWith({
      scheduleKey: "monthly-net-cash-flow",
      reportType: "monthly_net_cash_flow",
      endpointPath: "/api/scheduled/monthly-net-cash-flow",
      timezone: "America/Los_Angeles",
      sendHour: 13,
      sendDay: 12,
      recipientTo: ["ethan@apartmentcorp.com", "mam@22.bz"],
      enabled: false,
    });
    const noOp = dialect.sqlToQuery(duplicate.mock.calls[0][0].set.id);
    expect(noOp.sql).toContain("`monthly_email_jobs`.`id`");
    expect(mocks.set).not.toHaveBeenCalled();
    expect(db.insert).toHaveBeenCalledWith(monthlyEmailJobs);
  });
  it("duplicate provisioning preserves active UID/boundaries and never repairs invalid recipients", async () => {
    const active = {
      ...boundJob,
      enabled: true,
      activatedAt: new Date("2026-11-05T00:00:00Z"),
      firstSendDate: "2026-11-12",
    };
    mocks.values.mockReturnValue({
      onDuplicateKeyUpdate: vi.fn().mockResolvedValue([]),
    });
    mocks.limit.mockResolvedValueOnce([active]);
    expect(await provisionMonthlyEmailJob()).toEqual(active);
    expect(mocks.set).not.toHaveBeenCalled();
    mocks.limit.mockResolvedValueOnce([
      { ...active, recipientTo: ["extra@example.com"] },
    ]);
    await expect(provisionMonthlyEmailJob()).rejects.toThrow("recipients");
    expect(mocks.set).not.toHaveBeenCalled();
  });
  it("looks up UID rather than body/job name, rejects blank/invalid identity", async () => {
    mocks.limit.mockResolvedValueOnce([boundJob]);
    expect(await getMonthlyEmailJobByTaskUid("uid")).toEqual(boundJob);
    await expect(getMonthlyEmailJobByTaskUid(" uid ")).rejects.toThrow();
    await expect(getMonthlyEmailJobByTaskUid("x".repeat(66))).rejects.toThrow();
    expect(mocks.limit).toHaveBeenCalledOnce();
  });
  it("new bind requires exact disabled/unbound/unactivated policy and touches UID only", async () => {
    mocks.limit
      .mockResolvedValueOnce([job])
      .mockResolvedValueOnce([])
      .mockResolvedValueOnce([boundJob]);
    expect(await bindMonthlyEmailHeartbeat(7, "uid")).toEqual(boundJob);
    expect(mocks.set).toHaveBeenCalledWith({ scheduleCronTaskUid: "uid" });
    const q = query();
    expect(q.sql).toContain("`schedule_cron_task_uid` is null");
    expect(q.sql).toContain("`activated_at` is null");
    expect(q.sql).toContain("`first_send_date` is null");
    expect(q.params).toContain(false);
    expect(q.params).toContain('["ethan@apartmentcorp.com","mam@22.bz"]');
    expect(db.insert).not.toHaveBeenCalled();
  });
  it("same UID same job is read-only idempotent; cross-job UID refuses", async () => {
    mocks.limit
      .mockResolvedValueOnce([boundJob])
      .mockResolvedValueOnce([boundJob]);
    expect(await bindMonthlyEmailHeartbeat(7, "uid")).toEqual(boundJob);
    expect(mocks.set).not.toHaveBeenCalled();
    mocks.limit
      .mockResolvedValueOnce([job])
      .mockResolvedValueOnce([{ ...boundJob, id: 9 }]);
    await expect(bindMonthlyEmailHeartbeat(7, "uid")).rejects.toThrow(
      "already bound"
    );
    expect(mocks.set).not.toHaveBeenCalled();
  });
  it.each([
    { enabled: true },
    { scheduleCronTaskUid: "old" },
    { activatedAt: new Date() },
    { firstSendDate: "2026-11-12" },
  ])("refuses replacement/invalid binding boundary %j", async patch => {
    mocks.limit
      .mockResolvedValueOnce([{ ...job, ...patch }])
      .mockResolvedValueOnce([]);
    await expect(bindMonthlyEmailHeartbeat(7, "uid")).rejects.toThrow(
      "boundary invalid"
    );
    expect(mocks.set).not.toHaveBeenCalled();
  });
  it("lost/unknown binding commit fails closed when no matching durable row", async () => {
    mocks.limit
      .mockResolvedValueOnce([job])
      .mockResolvedValueOnce([])
      .mockResolvedValueOnce([]);
    mocks.updateWhere.mockResolvedValueOnce([{ affectedRows: 0 }]);
    await expect(bindMonthlyEmailHeartbeat(7, "uid")).rejects.toThrow(
      "not confirmed"
    );
    mocks.limit.mockResolvedValueOnce([job]).mockResolvedValueOnce([]);
    mocks.updateWhere.mockRejectedValueOnce(new Error("unknown bind commit"));
    await expect(bindMonthlyEmailHeartbeat(7, "uid")).rejects.toThrow(
      "unknown bind commit"
    );
  });
  it("sets UTC activation and first future eligible Pacific date once, no backfill after November slot", async () => {
    const now = new Date("2026-11-12T21:00:01Z");
    const activated = {
      ...boundJob,
      enabled: true,
      activatedAt: now,
      firstSendDate: "2026-12-12",
    };
    mocks.limit
      .mockResolvedValueOnce([boundJob])
      .mockResolvedValueOnce([activated]);
    expect(await activateMonthlyEmailJob(7, now)).toEqual(activated);
    expect(mocks.set).toHaveBeenCalledWith({
      enabled: true,
      activatedAt: now,
      firstSendDate: "2026-12-12",
    });
    expect(query().sql).toContain("`activated_at` is null");
    expect(query().sql).toContain("`first_send_date` is null");
    expect(db.insert).not.toHaveBeenCalled();
  });
  it("same active job is read-only and paused same job enables without resetting dates/ledgers", async () => {
    const now = new Date("2026-11-05T00:00:00Z");
    const active = {
      ...boundJob,
      enabled: true,
      activatedAt: now,
      firstSendDate: firstMonthlySendDate(now),
    };
    mocks.limit.mockResolvedValueOnce([active]);
    expect(
      await activateMonthlyEmailJob(7, new Date("2027-01-01T00:00:00Z"))
    ).toEqual(active);
    expect(mocks.set).not.toHaveBeenCalled();
    mocks.limit
      .mockResolvedValueOnce([{ ...active, enabled: false }])
      .mockResolvedValueOnce([active]);
    expect(await activateMonthlyEmailJob(7, new Date())).toEqual(active);
    expect(mocks.set).toHaveBeenCalledWith({ enabled: true });
    expect(db.insert).not.toHaveBeenCalled();
  });
  it.each([
    undefined,
    job,
    { ...boundJob, timezone: "UTC" },
    { ...boundJob, recipientTo: ["mam@22.bz", "ethan@apartmentcorp.com"] },
    { ...boundJob, activatedAt: new Date() },
    { ...boundJob, firstSendDate: "2026-11-12" },
    { ...boundJob, enabled: true },
    {
      ...boundJob,
      activatedAt: new Date("2026-11-05T00:00:00Z"),
      firstSendDate: "2020-01-12",
    },
  ])(
    "refuses missing/unbound/partial/invalid activation policy %j",
    async invalid => {
      mocks.limit.mockResolvedValueOnce(invalid ? [invalid] : []);
      await expect(activateMonthlyEmailJob(7, new Date())).rejects.toThrow();
      expect(mocks.set).not.toHaveBeenCalled();
    }
  );
  it("lost and unknown activation commits never claim enabled without durable confirmation", async () => {
    mocks.limit
      .mockResolvedValueOnce([boundJob])
      .mockResolvedValueOnce([boundJob]);
    mocks.updateWhere.mockResolvedValueOnce([{ affectedRows: 0 }]);
    await expect(activateMonthlyEmailJob(7, new Date())).rejects.toThrow(
      "not confirmed"
    );
    mocks.limit.mockResolvedValueOnce([boundJob]);
    mocks.updateWhere.mockRejectedValueOnce(
      new Error("unknown activation commit")
    );
    await expect(activateMonthlyEmailJob(7, new Date())).rejects.toThrow(
      "unknown activation commit"
    );
  });
  it("invalid IDs/tokens/time cannot trigger SQL effects", async () => {
    await expect(bindMonthlyEmailHeartbeat(0, "uid")).rejects.toThrow();
    await expect(activateMonthlyEmailJob(7, new Date(NaN))).rejects.toThrow();
    await expect(claimMonthlyEmailDelivery(4, "")).rejects.toThrow();
    await expect(
      claimMonthlyEmailRun(7, "2026-01", "x".repeat(37))
    ).rejects.toThrow();
    expect(mocks.getDb).not.toHaveBeenCalled();
  });
});

describe("monthly additive schema contract (no generated/applied migration)", () => {
  it("has monthly-only tables, disabled default, indexed nullable UID and unique job+period/run+delivery", () => {
    const config = getTableConfig(monthlyEmailJobs);
    expect(config.name).toBe("monthly_email_jobs");
    expect(monthlyEmailJobs.enabled.default).toBe(false);
    expect(monthlyEmailJobs.scheduleCronTaskUid.notNull).toBe(false);
    expect(
      config.indexes.some(index =>
        index.config.columns.includes(monthlyEmailJobs.scheduleCronTaskUid)
      )
    ).toBe(true);
    const period = getTableConfig(monthlyEmailRuns).indexes.find(
      index => index.config.name === "monthly_email_job_period_unique"
    )!;
    expect(period.config.unique).toBe(true);
    expect(period.config.columns).toEqual([
      monthlyEmailRuns.jobId,
      monthlyEmailRuns.periodKey,
    ]);
    const delivery = getTableConfig(monthlyEmailDeliveries).indexes.find(
      index => index.config.name === "monthly_email_run_delivery_unique"
    )!;
    expect(delivery.config.unique).toBe(true);
    expect(delivery.config.columns).toEqual([
      monthlyEmailDeliveries.runId,
      monthlyEmailDeliveries.deliveryKey,
    ]);
  });
  it("new schema and helper never reference old daily/auxiliary/recipient tables", () => {
    const schema = readFileSync(
      new URL("../drizzle/schema.ts", import.meta.url),
      "utf8"
    ).split("// Dedicated monthly net-cash-flow Heartbeat;")[1];
    expect(schema.match(/mysqlTable\(/g)).toHaveLength(3);
    expect(schema).not.toMatch(/dailyVacancy|auxiliaryEmail|emailRecipients/);
    const helper = readFileSync(
      new URL("./monthlyEmailScheduleDb.ts", import.meta.url),
      "utf8"
    );
    expect(helper).not.toMatch(
      /dailyVacancy|auxiliaryEmail|emailRecipients|sendMail|createHeartbeat|fetchFresh/
    );
  });
});

describe("monthly activation instant precision", () => {
  it("persists UTC milliseconds required to retain first-send-date on round trip", () => {
    expect(monthlyEmailJobs.activatedAt.getSQLType()).toBe("timestamp(3)");
  });
  it("activation even one millisecond after the December slot starts in January without backfill", async () => {
    const now = new Date("2026-12-12T21:00:00.001Z");
    const activated = {
      ...boundJob,
      enabled: true,
      activatedAt: now,
      firstSendDate: "2027-01-12",
    };
    mocks.limit
      .mockResolvedValueOnce([boundJob])
      .mockResolvedValueOnce([activated]);
    expect(await activateMonthlyEmailJob(7, now)).toEqual(activated);
    expect(mocks.set).toHaveBeenCalledWith({
      enabled: true,
      activatedAt: now,
      firstSendDate: "2027-01-12",
    });
  });
});
