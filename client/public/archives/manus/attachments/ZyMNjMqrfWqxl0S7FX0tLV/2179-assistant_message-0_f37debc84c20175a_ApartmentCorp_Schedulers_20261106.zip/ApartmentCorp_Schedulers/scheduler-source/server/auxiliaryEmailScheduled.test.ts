import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import type { AuxiliaryEmailDelivery, AuxiliaryEmailJob, AuxiliaryEmailRun } from "../drizzle/schema";

const mocks = vi.hoisted(() => ({ auth: vi.fn(), lookup: vi.fn(), fetch: vi.fn(), summary: vi.fn(), recipients: vi.fn(), dates: vi.fn(), payments: vi.fn(), send: vi.fn(), create: vi.fn(),
  claimRun: vi.fn(), freeze: vi.fn(), list: vi.fn(), claimDelivery: vi.fn(), transitionDelivery: vi.fn(), transitionRun: vi.fn() }));
vi.mock("./_core/sdk", () => ({ sdk: { authenticateRequest: mocks.auth } }));
vi.mock("./scraper", () => ({ fetchDashboardData: mocks.fetch, getWeeklySummary: mocks.summary }));
vi.mock("./db", () => ({ getDailyVacancyRecipients: mocks.recipients, getPaymentsDates: mocks.dates, getPaymentsForDateDb: mocks.payments }));
vi.mock("nodemailer", () => ({ default: { createTransport: mocks.create } }));
vi.mock("./auxiliaryEmailScheduleDb", () => ({ getAuxiliaryEmailJobByTaskUid: mocks.lookup, claimAuxiliaryEmailRun: mocks.claimRun, freezeAuxiliaryEmailPlan: mocks.freeze,
  getAuxiliaryEmailDeliveries: mocks.list, claimAuxiliaryEmailDelivery: mocks.claimDelivery, transitionAuxiliaryEmailDelivery: mocks.transitionDelivery, transitionAuxiliaryEmailRun: mocks.transitionRun }));
import { weeklyVacancyScheduledHandler, evictionRemindersScheduledHandler, assertAuxiliarySourceTime, sanitiseAuxiliaryReceipt } from "./auxiliaryEmailScheduled";
import { AUXILIARY_POLICIES } from "./auxiliaryEmailSchedulePolicy";
import { getEvictionReminderContacts } from "./evictionReminderContacts";
import { prepareWeeklySummaryEmail, prepareEvictionMissingAmountEmail, sendWeeklySummaryEmail, sendEvictionMissingAmountEmails, buildWeeklySummaryHtml } from "./emailService";

const activeRecipients = ["Brandon@ApartmentCorp.com", "mam@22.bz", "Myles@menowitz.com", "Todd@menowitz.com", "ethan@apartmentcorp.com"];
const weeklyRecipients = ["ethan@apartmentcorp.com", "mam@22.bz", "Myles@menowitz.com", "Todd@menowitz.com"];
const summary = { weekStart: "2026-11-01", weekEnd: "2026-11-07", totalNetChange: 0, startTotalVacant: 4, endTotalVacant: 4, totalBuildingsChanged: 0,
  topIncreases: [], topDecreases: [], dailyChanges: [], buildingTrends: [], currentStats: null, currentAtRisk: [] };
let runs: AuxiliaryEmailRun[]; let deliveries: AuxiliaryEmailDelivery[]; let job: AuxiliaryEmailJob;
const copy = <T>(v: T): T => structuredClone(v);
const qualify = (building: string, unit: string, amountOwed: any = 0) => ({ building, unit, amountOwed, dates: "" });
const setType = (type: "weekly_vacancy" | "eviction_reminders") => {
  job = { id: 1, reportType: type, scheduleKey: AUXILIARY_POLICIES[type].scheduleKey, endpointPath: AUXILIARY_POLICIES[type].endpointPath,
    scheduleCronTaskUid: "task-uid", enabled: true, timezone: "America/New_York", sendHour: 9, activatedAt: new Date("2026-10-01T00:00:00Z"), firstSendDate: "2026-10-01",
    createdAt: new Date(), updatedAt: new Date() };
  vi.setSystemTime(new Date(type === "weekly_vacancy" ? "2026-11-07T14:00:00Z" : "2026-11-15T14:00:00Z"));
};
async function trigger(type: "weekly_vacancy" | "eviction_reminders" = job.reportType, body: unknown = { taskUid: "attacker", to: "attacker@example.com", recipients: ["attacker@example.com"], localDate: "1999-01-01", hour: 9 }) {
  const response = { code: 200, body: null as any, status(code: number) { this.code = code; return this; }, json(body: any) { this.body = body; return this; } };
  await (type === "weekly_vacancy" ? weeklyVacancyScheduledHandler : evictionRemindersScheduledHandler)({ body } as any, response as any);
  return response;
}
beforeEach(() => {
  vi.resetAllMocks(); vi.useFakeTimers(); vi.stubEnv("GMAIL_USER", "apartmentcorp44@gmail.com"); vi.stubEnv("GMAIL_APP_PASSWORD", "abcdefghijklmnop");
  runs = []; deliveries = []; setType("weekly_vacancy");
  mocks.auth.mockResolvedValue({ isCron: true, taskUid: "task-uid" }); mocks.lookup.mockImplementation(async () => copy(job));
  mocks.recipients.mockResolvedValue(activeRecipients); mocks.dates.mockResolvedValue([]); mocks.summary.mockResolvedValue(summary);
  mocks.fetch.mockImplementation(async () => ({ lastUpdated: new Date(), evictions: [], sourceStatus: { state: "live" } }));
  mocks.create.mockReturnValue({ sendMail: mocks.send });
  mocks.send.mockImplementation(async message => ({ messageId: "<receipt@gmail.com>", accepted: [message.to, message.cc ?? ""].flatMap((s: string) => s.split(",").map(v => v.trim()).filter(Boolean)), rejected: [], response: "250 secret credentials should not be stored" }));
  mocks.claimRun.mockImplementation(async (jobId, localDate, token) => {
    let r = runs.find(r => r.jobId === jobId && r.localDate === localDate);
    if (!r) { r = { id: runs.length + 1, jobId, localDate, state: "preparing", attemptToken: token, planCount: null, sourceUpdatedAt: null, outcome: null, failureCode: null, createdAt: new Date(), updatedAt: new Date() }; runs.push(r); }
    else if (r.state === "failed_before_send" && r.planCount === null) Object.assign(r, { state: "preparing", attemptToken: token, failureCode: null });
    return { run: copy(r), ownedPreparation: r.state === "preparing" && r.attemptToken === token };
  });
  mocks.transitionRun.mockImplementation(async (id, token, expected, state, patch) => {
    const r = runs.find(r => r.id === id && r.state === expected && r.attemptToken === token);
    if (!r) return false; Object.assign(r, patch, { state }); return true;
  });
  mocks.freeze.mockImplementation(async (id, token, sourceUpdatedAt, plan) => {
    const r = runs.find(r => r.id === id && r.state === "preparing" && r.attemptToken === token && r.planCount === null);
    if (!r) return false;
    Object.assign(r, { state: plan.length ? "ready" : "complete", planCount: plan.length, sourceUpdatedAt, outcome: plan.length ? null : "no-email" });
    deliveries.push(...plan.map((p: any) => ({ id: deliveries.length + 1 + plan.indexOf(p), runId: id, ...copy(p), state: "pending", attemptToken: null, messageId: null, smtpReceipt: null, failureCode: null, createdAt: new Date(), updatedAt: new Date() })));
    return true;
  });
  mocks.list.mockImplementation(async id => copy(deliveries.filter(d => d.runId === id)));
  mocks.claimDelivery.mockImplementation(async (id, token) => { const d = deliveries.find(d => d.id === id && d.state === "pending"); if (!d) return false; Object.assign(d, { state: "sending", attemptToken: token }); return true; });
  mocks.transitionDelivery.mockImplementation(async (id, token, state, patch) => { const d = deliveries.find(d => d.id === id && d.state === "sending" && d.attemptToken === token); if (!d) return false; Object.assign(d, patch, { state }); return true; });
});
afterEach(() => { vi.useRealTimers(); vi.unstubAllEnvs(); });

describe("authenticated auxiliary callbacks", () => {
  it.each([{ isCron: false, taskUid: "task-uid" }, { isCron: true }, {}])("rejects missing cron identity %j before lookup", async user => {
    mocks.auth.mockResolvedValue(user); expect((await trigger()).code).toBe(403); expect(mocks.lookup).not.toHaveBeenCalled(); expect(mocks.send).not.toHaveBeenCalled();
  });
  it("rejects failed authentication without leaking error payload", async () => {
    mocks.auth.mockRejectedValue(new Error("secret")); const r = await trigger(); expect(r.code).toBe(403); expect(JSON.stringify(r.body)).not.toContain("secret");
  });
  it("orphan/disabled/wrong-type jobs do not claim or send; body identity is ignored", async () => {
    mocks.lookup.mockResolvedValueOnce(undefined); expect((await trigger()).body.skipped).toBe("orphan");
    job.enabled = false; expect((await trigger()).body.skipped).toBe("disabled"); job.enabled = true;
    expect((await trigger("eviction_reminders")).body.skipped).toBe("invalid-config");
    expect(mocks.lookup).toHaveBeenCalledWith("task-uid"); expect(mocks.claimRun).not.toHaveBeenCalled();
  });
  it.each([{ timezone: "UTC" }, { sendHour: 10 }, { scheduleKey: "daily-vacancy" }, { endpointPath: "/api/other" }, { scheduleCronTaskUid: "wrong" }])("invalid policy %j stops before claim", async patch => {
    Object.assign(job, patch); expect((await trigger()).body.skipped).toBe("invalid-config"); expect(mocks.send).not.toHaveBeenCalled(); expect(mocks.fetch).not.toHaveBeenCalled();
  });
  it("off-time and before activation cannot claim a backfill", async () => {
    vi.setSystemTime(new Date("2026-11-07T13:00:00Z")); expect((await trigger()).body.skipped).toBe("off-time");
    vi.setSystemTime(new Date("2026-11-07T14:05:00Z")); job.activatedAt = new Date("2026-11-07T14:01:00Z"); expect((await trigger()).body.skipped).toBe("before-activation");
    expect(mocks.claimRun).not.toHaveBeenCalled();
  });
  it("sanitizes lookup errors", async () => { mocks.lookup.mockRejectedValue(new Error("credential")); const r = await trigger(); expect(r.code).toBe(500); expect(JSON.stringify(r.body)).not.toContain("credential"); });
});

describe("weekly frozen ledger and freshness", () => {
  it("forces fresh pull before cached weekly summary, owns sending ledger before mail and ignores body recipients", async () => {
    mocks.send.mockImplementationOnce(async message => {
      expect(deliveries[0].state).toBe("sending"); expect(runs[0].planCount).toBe(1); expect(message.from).toBe('"Apartment Corp Reports" <apartmentcorp44@gmail.com>');
      expect(message.to).toBe(weeklyRecipients.join(", ")); expect(message.html).toBe(buildWeeklySummaryHtml(summary));
      return { accepted: weeklyRecipients, rejected: [], messageId: "<ok@gmail.com>", response: "secret" };
    });
    expect((await trigger()).body.status).toBe("sent"); expect(mocks.fetch).toHaveBeenCalledWith(true);
    expect(mocks.fetch.mock.invocationCallOrder[0]).toBeLessThan(mocks.summary.mock.invocationCallOrder[0]);
    expect(runs[0].sourceUpdatedAt).toEqual(new Date()); expect(deliveries[0].smtpReceipt?.response).toBe("accepted");
    expect(JSON.stringify(deliveries)).not.toContain("secret");
    await trigger(); expect(mocks.send).toHaveBeenCalledOnce(); expect(mocks.fetch).toHaveBeenCalledOnce();
  });
  it("concurrent weekly callbacks own one unique day and never send duplicates", async () => {
    await Promise.all([trigger(), trigger(), trigger()]); expect(runs).toHaveLength(1); expect(deliveries).toHaveLength(1); expect(mocks.send).toHaveBeenCalledOnce();
  });
  it.each([null, new Date("2026-11-07T13:54:59Z"), new Date("2026-11-07T14:00:01Z"), new Date(NaN)])("missing/stale/future source %s safely fails before SMTP", async lastUpdated => {
    mocks.fetch.mockResolvedValue({ lastUpdated, evictions: [] }); expect((await trigger()).code).toBe(503); expect(runs[0].state).toBe("failed_before_send"); expect(mocks.send).not.toHaveBeenCalled(); expect(mocks.summary).not.toHaveBeenCalled();
  });
  it("source exactly five minutes old allowed, older/future/missing rejected", () => {
    expect(() => assertAuxiliarySourceTime(new Date(Date.now() - 300_000))).not.toThrow();
    for (const value of [undefined, null, new Date(Date.now() - 300_001), new Date(Date.now() + 1)]) expect(() => assertAuxiliarySourceTime(value)).toThrow();
  });
  it("preparation failure can retry with fresh source and no frozen plan reset", async () => {
    mocks.summary.mockRejectedValueOnce(new Error("secret")); expect((await trigger()).code).toBe(503); expect(deliveries).toHaveLength(0);
    expect((await trigger()).body.status).toBe("sent"); expect(runs).toHaveLength(1); expect(mocks.send).toHaveBeenCalledOnce();
  });
  it.each(["GMAIL_USER", "GMAIL_APP_PASSWORD"])("missing config %s stops before mail; confirmed pre-send failure can retry", async key => {
    vi.stubEnv(key, ""); expect((await trigger()).code).toBe(503); expect(mocks.send).not.toHaveBeenCalled();
  });
  it("wrong Gmail and no active weekly recipients cannot mail", async () => {
    vi.stubEnv("GMAIL_USER", "other@gmail.com"); expect((await trigger()).code).toBe(503);
    vi.stubEnv("GMAIL_USER", "apartmentcorp44@gmail.com"); mocks.recipients.mockResolvedValue([]); expect((await trigger()).code).toBe(503); expect(mocks.send).not.toHaveBeenCalled();
  });
  it("preparing and uncertain freeze/CAS fail closed without automatic reclaim", async () => {
    mocks.freeze.mockRejectedValueOnce(new Error("unknown commit")); expect((await trigger()).body.manualReviewNeeded).toBe(true);
    expect((await trigger()).body.status).toBe("already-claimed"); expect(mocks.send).not.toHaveBeenCalled();
  });
  it("uncertain claim or sending CAS never invokes SMTP", async () => {
    mocks.claimRun.mockRejectedValueOnce(new Error("unknown insert")); expect((await trigger()).body.status).toBe("claim-unconfirmed");
    mocks.claimDelivery.mockRejectedValueOnce(new Error("unknown CAS")); expect((await trigger()).body.status).toBe("delivery-claim-unconfirmed"); expect(mocks.send).not.toHaveBeenCalled();
  });
  it("late sending CAS and preparation deadlines prohibit a late SMTP start", async () => {
    mocks.claimDelivery.mockImplementationOnce(async (id, token) => { Object.assign(deliveries[0], { state: "sending", attemptToken: token }); vi.setSystemTime(new Date(Date.now() + 106_000)); return true; });
    expect((await trigger()).body.status).toBe("sending"); expect(mocks.send).not.toHaveBeenCalled();
    await trigger(); expect(mocks.send).not.toHaveBeenCalled();
  });
  it("preparation timeout has no SMTP continuation, and confirmed failure is safely retryable", async () => {
    let resolveSource: (value: any) => void = () => {};
    mocks.fetch.mockImplementationOnce(() => new Promise(resolve => { resolveSource = resolve; }));
    const result = trigger(); await vi.advanceTimersByTimeAsync(45_000); expect((await result).code).toBe(503);
    resolveSource({ lastUpdated: new Date(), evictions: [] }); await Promise.resolve(); expect(mocks.send).not.toHaveBeenCalled();
    expect((await trigger()).body.status).toBe("sent"); expect(mocks.send).toHaveBeenCalledOnce();
  });
  it("unconfirmed preparation-failure CAS refuses safe retry and sends nothing", async () => {
    mocks.fetch.mockRejectedValueOnce(new Error("source failure")); mocks.transitionRun.mockResolvedValueOnce(false);
    expect((await trigger()).body.status).toBe("preparation-unconfirmed"); expect((await trigger()).body.status).toBe("already-claimed"); expect(mocks.send).not.toHaveBeenCalled();
  });
  it("receipt-only finalization records completed/uncertain ledgers after source ages out and config disappears", async () => {
    mocks.transitionRun.mockResolvedValueOnce(false); await trigger(); expect(runs[0].state).toBe("ready"); expect(deliveries[0].state).toBe("sent");
    vi.setSystemTime(new Date(Date.now() + 360_000)); vi.stubEnv("GMAIL_USER", "");
    expect((await trigger()).body.status).toBe("sent"); expect(runs[0].state).toBe("complete"); expect(mocks.send).toHaveBeenCalledOnce();
  });
  it("SMTP timeout returns within total budget and never retries ambiguous mail", async () => {
    mocks.send.mockImplementationOnce(() => new Promise(() => {})); const result = trigger(); await vi.advanceTimersByTimeAsync(110_000);
    expect((await result).body.manualReviewNeeded).toBe(true); expect(deliveries[0].state).toBe("sending"); await trigger(); expect(mocks.send).toHaveBeenCalledOnce();
  });
});

describe("per-manager eviction delivery", () => {
  const source = () => mocks.fetch.mockImplementation(async () => ({ lastUpdated: new Date(), evictions: [qualify("Yorkshire", "A"), qualify("Windsor", "B"), qualify("Pelican", "C"), qualify("Granite", "D")], sourceStatus: { state: "live" } }));
  beforeEach(() => { setType("eviction_reminders"); source(); });
  it("preserves missing predicate, manager merge, mapping and no-manager skip", () => {
    const contacts = getEvictionReminderContacts([qualify("Yorkshire", "A", 0), qualify("Windsor", "B", undefined), qualify("Windsor", "C", 100), qualify("Windsor", "String zero", "0"), qualify("Arbor", "no manager"), qualify("unknown", "no mapping")]);
    expect(contacts).toHaveLength(1); expect(contacts[0].units).toEqual(["A", "B"]); expect(contacts[0].managerEmail).toBe("windsor@apartmentcorp.com");
    expect(contacts[0].managerName).toBe("Kimberly Powell");
  });
  it("one merged mail per manager, exact regional+Ethan+mam CC and unchanged HTML", async () => {
    expect((await trigger()).body.status).toBe("sent"); expect(mocks.send).toHaveBeenCalledTimes(3); expect(deliveries[0].message.cc).toBe("ginger@apartmentcorp.com, ethan@apartmentcorp.com, mam@22.bz");
    expect(deliveries[2].message.cc).toBe("blake@apartmentcorp.com, ethan@apartmentcorp.com, mam@22.bz"); expect(deliveries[0].message.html).toContain("Hello Kimberly,");
    expect(deliveries[0].message.html).toContain("2 eviction units"); await trigger(); expect(mocks.send).toHaveBeenCalledTimes(3);
  });
  it.each([{ evictions: [] }, { evictions: [qualify("Windsor", "owed", 50)] }, { evictions: [qualify("Arbor", "no manager")] }, { evictions: [qualify("unknown", "no map")] }])("no qualifying contacts %j persists no-email without spurious SMTP", async ({ evictions }) => {
    mocks.fetch.mockImplementation(async () => ({ lastUpdated: new Date(), evictions })); expect((await trigger()).body.status).toBe("no-email"); expect(runs[0]).toMatchObject({ state: "complete", planCount: 0, outcome: "no-email" });
    await trigger(); expect(mocks.fetch).toHaveBeenCalledOnce(); expect(mocks.send).not.toHaveBeenCalled();
  });
  it("partial failure after SMTP leaves one unknown, sends other managers, never retries batch or unknown manager", async () => {
    mocks.send.mockRejectedValueOnce(new Error("credentials private")); const r = await trigger(); expect(r.body.manualReviewNeeded).toBe(true); expect(r.body.sent).toBe(2);
    expect(deliveries.map(d => d.state)).toEqual(["unknown", "sent", "sent"]); expect(runs[0].state).toBe("review"); await trigger(); expect(mocks.send).toHaveBeenCalledTimes(3);
    expect(JSON.stringify(deliveries)).not.toContain("credentials");
  });
  it("partial safe failure before SMTP resumes only frozen pending managers, not sent prefix, without a fresh batch", async () => {
    const original = mocks.claimDelivery.getMockImplementation()!;
    mocks.claimDelivery.mockImplementation(async (id, token) => { if (id === 2) throw new Error("DB before send"); return original(id, token); });
    expect((await trigger()).body.status).toBe("delivery-claim-unconfirmed"); expect(deliveries.map(d => d.state)).toEqual(["sent", "pending", "pending"]);
    const firstMessage = copy(deliveries[0]); mocks.claimDelivery.mockImplementation(original); mocks.fetch.mockRejectedValue(new Error("must not refetch frozen plan"));
    expect((await trigger()).body.status).toBe("sent"); expect(mocks.fetch).toHaveBeenCalledOnce(); expect(mocks.send).toHaveBeenCalledTimes(3); expect(deliveries[0]).toEqual(firstMessage);
  });
  it("uncertain receipt persistence keeps sending non-reclaimable and pending suffix can safely resume", async () => {
    mocks.transitionDelivery.mockRejectedValueOnce(new Error("DB commit unknown")); mocks.transitionDelivery.mockRejectedValueOnce(new Error("DB down"));
    await trigger(); expect(deliveries[0].state).toBe("sending"); await trigger(); expect(mocks.send).toHaveBeenCalledTimes(3); expect(deliveries[0].state).toBe("sending");
  });
  it("partial total-budget stop safely retries only frozen pending suffix within the same NY hour", async () => {
    const original = mocks.send.getMockImplementation()!;
    mocks.send.mockImplementationOnce(async message => { const receipt = await original(message); vi.setSystemTime(new Date(Date.now() + 106_000)); return receipt; });
    const first = await trigger(); expect(first.code).toBe(503); expect(deliveries.map(d => d.state)).toEqual(["sent", "pending", "pending"]);
    const prefix = copy(deliveries[0]); expect((await trigger()).body.status).toBe("sent"); expect(deliveries[0]).toEqual(prefix); expect(mocks.send).toHaveBeenCalledTimes(3); expect(mocks.fetch).toHaveBeenCalledOnce();
  });
  it("retained pending plan with stale timestamp fails before SMTP without resetting ledgers", async () => {
    mocks.claimDelivery.mockResolvedValueOnce(false).mockResolvedValueOnce(false).mockResolvedValueOnce(false); await trigger();
    const ledger = copy(deliveries); vi.setSystemTime(new Date(Date.now() + 301_000));
    expect((await trigger()).code).toBe(503); expect(deliveries).toEqual(ledger); expect(mocks.fetch).toHaveBeenCalledOnce(); expect(mocks.send).not.toHaveBeenCalled();
  });
  it("concurrent callbacks on a retained ready plan use per-manager CAS once", async () => {
    mocks.claimDelivery.mockResolvedValueOnce(false).mockResolvedValueOnce(false).mockResolvedValueOnce(false);
    await trigger(); expect(deliveries.map(d => d.state)).toEqual(["pending", "pending", "pending"]);
    await Promise.all([trigger(), trigger(), trigger()]); expect(mocks.fetch).toHaveBeenCalledOnce(); expect(mocks.send).toHaveBeenCalledTimes(3);
  });
  it("retained sending or sent manager is never reset even if ancient; pending fresh-plan suffix only", async () => {
    mocks.claimDelivery.mockResolvedValueOnce(false).mockResolvedValueOnce(false).mockResolvedValueOnce(false); await trigger();
    deliveries[0].state = "sending"; deliveries[0].updatedAt = new Date(0); deliveries[1].state = "sent";
    await trigger(); expect(mocks.send).toHaveBeenCalledOnce(); expect(deliveries[0].state).toBe("sending"); expect(deliveries[1].state).toBe("sent");
  });
});

describe("SMTP ambiguity and manual compatibility", () => {
  it.each([
    { accepted: weeklyRecipients.slice(1), rejected: [weeklyRecipients[0]] },
    { accepted: weeklyRecipients, rejected: [weeklyRecipients[0]] },
    { accepted: weeklyRecipients },
    { accepted: [...weeklyRecipients, "unexpected@example.com"], rejected: [] },
  ])("incomplete or ambiguous acceptance %j never retries that message", async receipt => {
    mocks.send.mockResolvedValue(receipt); expect((await trigger()).body.manualReviewNeeded).toBe(true); expect(deliveries[0].state).toBe("unknown"); await trigger(); expect(mocks.send).toHaveBeenCalledOnce();
  });
  it("sanitizes receipts and refuses unexpected addresses", async () => {
    const prepared = await prepareWeeklySummaryEmail(summary);
    const value = sanitiseAuxiliaryReceipt({ accepted: weeklyRecipients, rejected: [], messageId: "password=secret\n", response: "secret smtp" }, prepared.message);
    expect(value.fullyAccepted).toBe(true); expect(value.receipt.messageId).toBe(""); expect(JSON.stringify(value)).not.toContain("secret");
  });
  it("non-sending prepare helpers and manual sender produce identical messages", async () => {
    const weekly = await prepareWeeklySummaryEmail(summary); expect(mocks.send).not.toHaveBeenCalled(); await sendWeeklySummaryEmail(summary); expect(mocks.send).toHaveBeenLastCalledWith(weekly.message);
    const c = getEvictionReminderContacts([qualify("Yorkshire", "A")])[0]; const eviction = prepareEvictionMissingAmountEmail(c);
    await sendEvictionMissingAmountEmails([c]); expect(mocks.send).toHaveBeenLastCalledWith(eviction.message);
    await sendWeeklySummaryEmail(summary, "manual@example.com"); expect(mocks.send.mock.calls.at(-1)![0].to).toBe("manual@example.com");
  });
  it("legacy saved payments comparison selects closest prior week unchanged", async () => {
    mocks.dates.mockResolvedValue(["2026-11-07", "2026-11-06", "2026-10-31", "2026-10-28"]);
    mocks.payments.mockImplementation(async date => [{ buildingName: "Property", regionId: 1, netRentCollected: date === "2026-11-07" ? "110" : "100", netCashFlow: "5" }]);
    const prepared = await prepareWeeklySummaryEmail(summary);
    expect(mocks.payments).toHaveBeenCalledWith("2026-10-31"); expect(prepared.message.html).toContain("Comparing 2026-11-07 vs 2026-10-31"); expect(prepared.message.html).toContain("+10.0%");
  });
});
