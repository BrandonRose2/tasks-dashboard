import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { MySqlDialect } from "drizzle-orm/mysql-core";

const mocks = vi.hoisted(() => ({ getDb: vi.fn(), values: vi.fn(), limit: vi.fn(), set: vi.fn(), whereUpdate: vi.fn() }));
vi.mock("./db", () => ({ getDb: mocks.getDb }));
import { activateDailyVacancyJob, claimDailyVacancySend, confirmDailyReportsDelivery, ensureDailyVacancyJob, transitionDailyVacancySend } from "./dailyVacancyScheduleDb";

beforeEach(() => {
  vi.resetAllMocks();
  mocks.getDb.mockResolvedValue({
    insert: vi.fn(() => ({ values: mocks.values })),
    select: vi.fn(() => ({ from: vi.fn(() => ({ where: vi.fn(() => ({ limit: mocks.limit })) })) })),
    update: vi.fn(() => ({ set: mocks.set })),
  });
  mocks.set.mockReturnValue({ where: mocks.whereUpdate });
  mocks.whereUpdate.mockResolvedValue([{ affectedRows: 1 }]);
});
afterEach(() => { vi.useRealTimers(); });

describe("durable daily claim SQL boundary (mocked database)", () => {
  it("claims with unique insert and no initial select", async () => {
    mocks.values.mockResolvedValueOnce([{ affectedRows: 1 }]);
    await expect(claimDailyVacancySend(7, "2026-11-03", "attempt-one")).resolves.toEqual({ claimed: true, state: "preparing" });
    expect(mocks.values).toHaveBeenCalledWith({ jobId: 7, localDate: "2026-11-03", reportType: "vacancy", attemptToken: "attempt-one", state: "preparing" });
    expect(mocks.limit).not.toHaveBeenCalled();
  });
  it.each(["preparing", "sending", "sent", "unknown"])("never reclaims %s regardless of age", async state => {
    mocks.values.mockRejectedValueOnce({ cause: { code: "ER_DUP_ENTRY" } });
    mocks.limit.mockResolvedValueOnce([{ id: 1, state, attemptToken: "older-attempt", updatedAt: new Date(0) }]);
    await expect(claimDailyVacancySend(7, "2026-11-03", "attempt-two")).resolves.toEqual({ claimed: false, state });
    expect(mocks.set).not.toHaveBeenCalled();
  });
  it("allows retry only when conditional failed-before-send CAS owns the row", async () => {
    mocks.values.mockRejectedValueOnce({ errno: 1062 });
    mocks.limit.mockResolvedValueOnce([{ id: 1, state: "failed_before_send", attemptToken: "old" }]);
    await expect(claimDailyVacancySend(7, "2026-11-03", "new")).resolves.toMatchObject({ claimed: true });
    expect(mocks.set).toHaveBeenCalledWith({ state: "preparing", attemptToken: "new", failureCode: null });
    // SQL where includes both state and prior token rather than an elapsed-time lease.
    const where = mocks.whereUpdate.mock.calls[0][0];
    expect(where).toBeDefined();
  });
  it("a lost concurrent failed-before-send CAS cannot claim", async () => {
    mocks.values.mockRejectedValueOnce({ code: "ER_DUP_ENTRY" });
    mocks.limit.mockResolvedValueOnce([{ id: 1, state: "failed_before_send", attemptToken: "old" }]);
    mocks.whereUpdate.mockResolvedValueOnce([{ affectedRows: 0 }]);
    await expect(claimDailyVacancySend(7, "2026-11-03", "loser")).resolves.toMatchObject({ claimed: false });
  });
  it("does not mistake another DB error for a unique claim conflict", async () => {
    mocks.values.mockRejectedValueOnce(new Error("DB disconnected"));
    await expect(claimDailyVacancySend(7, "2026-11-03", "new")).rejects.toThrow("DB disconnected");
    expect(mocks.limit).not.toHaveBeenCalled();
  });
  it("CAS transitions require exactly one affected row", async () => {
    mocks.whereUpdate.mockResolvedValueOnce([{ affectedRows: 0 }]);
    await expect(transitionDailyVacancySend(7, "2026-11-03", "token", "preparing", "sending")).resolves.toBe(false);
    expect(mocks.set).toHaveBeenCalledWith({ state: "sending" });
  });
  it("provisions only a disabled fixed approved job with no send or platform action", async () => {
    const duplicate = vi.fn().mockResolvedValue([]);
    mocks.values.mockReturnValueOnce({ onDuplicateKeyUpdate: duplicate });
    mocks.limit.mockResolvedValueOnce([{ id: 7, enabled: false }]);
    await ensureDailyVacancyJob();
    expect(mocks.values).toHaveBeenCalledWith({ scheduleKey: "daily-vacancy", enabled: false, collectionsApproved: false,
      timezone: "America/Los_Angeles", sendHour: 13, recipients: ["ethan@apartmentcorp.com", "mam@22.bz"] });
    expect(mocks.set).not.toHaveBeenCalled();
  });
  it.each(["vacancy", "collections", "collections_test"] as const)("unique insert and transition SQL includes report discriminator %s", async reportType => {
    mocks.values.mockResolvedValueOnce([{ affectedRows: 1 }]);
    await claimDailyVacancySend(7, "2026-11-04", "token", reportType);
    expect(mocks.values).toHaveBeenCalledWith({ jobId: 7, reportType, localDate: "2026-11-04", attemptToken: "token", state: "preparing" });
    await transitionDailyVacancySend(7, "2026-11-04", "token", "preparing", "sending", {}, reportType);
    const query = new MySqlDialect().sqlToQuery(mocks.whereUpdate.mock.calls[0][0]);
    expect(query.sql).toContain("`report_type`");
    expect(query.params).toEqual([7, reportType, "2026-11-04", "token", "preparing"]);
  });
  it("a failed-before-send Ethan test claim is NEVER reclaimed on the same date", async () => {
    mocks.values.mockRejectedValueOnce({ code: "ER_DUP_ENTRY" });
    mocks.limit.mockResolvedValueOnce([{ id: 1, state: "failed_before_send", attemptToken: "first-test" }]);
    await expect(claimDailyVacancySend(7, "2026-11-04", "second-test", "collections_test")).resolves.toEqual({ claimed: false, state: "failed_before_send" });
    expect(mocks.set).not.toHaveBeenCalled();
  });
  it("legacy activation never implicitly approves Collections", async () => {
    mocks.values.mockReturnValueOnce({ onDuplicateKeyUpdate: vi.fn().mockResolvedValue([]) });
    mocks.limit.mockResolvedValueOnce([{ id: 7, enabled: false, collectionsApproved: false }]).mockResolvedValueOnce([{ id: 7 }]);
    await activateDailyVacancyJob("existing-task");
    expect(mocks.set).toHaveBeenCalledOnce();
    expect(mocks.set.mock.calls[0][0]).not.toHaveProperty("collectionsApproved");
  });
  it("explicit post-user-approval helper updates only existing UID policy and next-send boundary", async () => {
    const job = { id: 7, scheduleCronTaskUid: "existing-task", scheduleKey: "daily-vacancy", timezone: "America/Los_Angeles", sendHour: 13, recipients: ["ethan@apartmentcorp.com", "mam@22.bz"] };
    mocks.limit.mockResolvedValueOnce([job]).mockResolvedValueOnce([job]);
    await confirmDailyReportsDelivery("existing-task");
    expect(mocks.set).toHaveBeenCalledWith({ enabled: true, collectionsApproved: true, activatedAt: expect.any(Date), firstSendDate: expect.stringMatching(/^\d{4}-\d{2}-\d{2}$/) });
    expect(mocks.values).not.toHaveBeenCalled();
  });
  it("same enabled UID activation preserves the existing start boundary and ledger without updates", async () => {
    const existing = { id: 7, enabled: true, collectionsApproved: true, scheduleCronTaskUid: "VZyvdDPMbzyNdrdFimtdHj",
      activatedAt: new Date("2026-11-03T19:00:00Z"), firstSendDate: "2026-11-03" };
    mocks.values.mockReturnValueOnce({ onDuplicateKeyUpdate: vi.fn().mockResolvedValue([]) });
    mocks.limit.mockResolvedValueOnce([existing]);
    await expect(activateDailyVacancyJob(existing.scheduleCronTaskUid)).resolves.toBe(existing);
    expect(mocks.set).not.toHaveBeenCalled();
  });
  it.each([
    ["2026-11-03T17:59:59Z", "2026-11-03"],
    ["2026-11-03T19:00:00Z", "2026-11-03"],
    ["2026-11-03T21:00:00Z", "2026-11-04"],
    ["2026-07-03T18:00:00Z", "2026-07-03"],
    ["2026-07-03T20:00:00Z", "2026-07-04"],
  ])("provisioning activation at %s retains legacy Collections first-send anchor %s", async (instant, firstSendDate) => {
    vi.useFakeTimers(); vi.setSystemTime(new Date(instant));
    mocks.values.mockReturnValueOnce({ onDuplicateKeyUpdate: vi.fn().mockResolvedValue([]) });
    mocks.limit.mockResolvedValueOnce([{ id: 7, enabled: false }]).mockResolvedValueOnce([{ id: 7 }]);
    await activateDailyVacancyJob("VZyvdDPMbzyNdrdFimtdHj");
    expect(mocks.set).toHaveBeenCalledWith(expect.objectContaining({ sendHour: 13, activatedAt: new Date(instant), firstSendDate }));
    expect(mocks.set.mock.calls[0][0]).not.toHaveProperty("collectionsApproved");
  });
  it("explicit approval still anchors stored date at Collections13 without clearing or touching ledger rows", async () => {
    vi.useFakeTimers(); vi.setSystemTime(new Date("2026-11-03T19:00:00Z"));
    const job = { id: 7, scheduleCronTaskUid: "VZyvdDPMbzyNdrdFimtdHj", scheduleKey: "daily-vacancy", timezone: "America/Los_Angeles", sendHour: 13, recipients: ["ethan@apartmentcorp.com", "mam@22.bz"] };
    mocks.limit.mockResolvedValueOnce([job]).mockResolvedValueOnce([job]);
    await confirmDailyReportsDelivery(job.scheduleCronTaskUid);
    expect(mocks.set).toHaveBeenCalledOnce();
    expect(mocks.set).toHaveBeenCalledWith({ enabled: true, collectionsApproved: true, activatedAt: new Date(), firstSendDate: "2026-11-03" });
    expect(mocks.values).not.toHaveBeenCalled();
  });
  it("database unavailable fails closed", async () => {
    mocks.getDb.mockResolvedValueOnce(null);
    await expect(claimDailyVacancySend(7, "2026-11-03", "token")).rejects.toThrow("database unavailable");
  });
});
