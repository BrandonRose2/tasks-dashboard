import { and, asc, eq, isNull, or, sql } from "drizzle-orm";
import { auxiliaryEmailJobs as jobs, auxiliaryEmailRuns as runs, auxiliaryEmailDeliveries as deliveries, type AuxiliaryEmailRun, type AuxiliaryEmailDelivery, type AuxiliaryEmailMessage } from "../drizzle/schema";
import { getDb } from "./db";
import { AUXILIARY_POLICIES, AUXILIARY_SEND_HOUR, AUXILIARY_TIMEZONE, firstAuxiliarySendDate, isAuxiliaryJobPolicyValid, type AuxiliaryReportType } from "./auxiliaryEmailSchedulePolicy";

async function requireDb() {
  const db = await getDb();
  if (!db) throw new Error("Auxiliary email schedule database unavailable");
  return db;
}
const validUid = (uid: string) => typeof uid === "string" && uid.length > 0 && uid.length <= 65 && uid.trim() === uid;

/** Explicit post-deployment provisioning ONLY. Insert missing disabled rows; never reset existing flags, identity, activation, or ledgers. */
export async function ensureAuxiliaryEmailJobsDisabled() {
  const db = await requireDb();
  for (const [reportType, policy] of Object.entries(AUXILIARY_POLICIES)) {
    await db.insert(jobs).values({ reportType: reportType as AuxiliaryReportType, scheduleKey: policy.scheduleKey,
      endpointPath: policy.endpointPath, timezone: AUXILIARY_TIMEZONE, sendHour: AUXILIARY_SEND_HOUR, enabled: false,
    }).onDuplicateKeyUpdate({ set: { id: sql`${jobs.id}` } });
  }
  return db.select().from(jobs).where(or(...Object.values(AUXILIARY_POLICIES).map(p => eq(jobs.scheduleKey, p.scheduleKey))));
}
export async function getAuxiliaryEmailJobByTaskUid(uid: string) {
  const db = await requireDb();
  return (await db.select().from(jobs).where(eq(jobs.scheduleCronTaskUid, uid)).limit(1))[0];
}

/** Bind a newly-created platform UID to an existing disabled policy row. Refuse replacement and cross-job UIDs. No activation or ledger mutations. */
export async function bindAuxiliaryEmailJobTaskUid(type: AuxiliaryReportType, uid: string) {
  if (!validUid(uid) || !AUXILIARY_POLICIES[type]) throw new Error("Invalid auxiliary identity");
  const db = await requireDb();
  const occupied = await getAuxiliaryEmailJobByTaskUid(uid);
  if (occupied) {
    if (!isAuxiliaryJobPolicyValid(occupied, uid, type)) throw new Error("Auxiliary UID already bound or policy invalid");
    return occupied;
  }
  const result = await db.update(jobs).set({ scheduleCronTaskUid: uid }).where(and(
    eq(jobs.scheduleKey, AUXILIARY_POLICIES[type].scheduleKey), eq(jobs.reportType, type),
    eq(jobs.endpointPath, AUXILIARY_POLICIES[type].endpointPath), eq(jobs.timezone, AUXILIARY_TIMEZONE),
    eq(jobs.sendHour, AUXILIARY_SEND_HOUR), eq(jobs.enabled, false), isNull(jobs.scheduleCronTaskUid),
  ));
  const job = await getAuxiliaryEmailJobByTaskUid(uid);
  if (result[0].affectedRows !== 1 && !job) throw new Error("Auxiliary binding not confirmed");
  if (!job || !isAuxiliaryJobPolicyValid(job, uid, type)) throw new Error("Auxiliary binding policy invalid");
  return job;
}

/** Activate by authenticated platform UID only after publishing. Same UID is idempotent; never resets activation/first date or any run/delivery state. */
export async function activateAuxiliaryEmailJobByTaskUid(uid: string) {
  if (!validUid(uid)) throw new Error("Invalid auxiliary identity");
  const db = await requireDb();
  const job = await getAuxiliaryEmailJobByTaskUid(uid);
  if (!job || !AUXILIARY_POLICIES[job.reportType] || !isAuxiliaryJobPolicyValid(job, uid, job.reportType)) throw new Error("Auxiliary job policy invalid");
  if (job.activatedAt && job.firstSendDate) {
    if (!job.enabled) await db.update(jobs).set({ enabled: true }).where(and(eq(jobs.id, job.id), eq(jobs.scheduleCronTaskUid, uid)));
    return getAuxiliaryEmailJobByTaskUid(uid);
  }
  if (job.activatedAt || job.firstSendDate || job.enabled) throw new Error("Auxiliary activation boundary invalid");
  const activatedAt = new Date();
  await db.update(jobs).set({ enabled: true, activatedAt, firstSendDate: firstAuxiliarySendDate(activatedAt, job.reportType) }).where(and(
    eq(jobs.id, job.id), eq(jobs.scheduleCronTaskUid, uid), eq(jobs.enabled, false), isNull(jobs.activatedAt), isNull(jobs.firstSendDate),
  ));
  return getAuxiliaryEmailJobByTaskUid(uid);
}

function isDuplicate(error: unknown): boolean {
  if (!error || typeof error !== "object") return false;
  const e = error as { code?: string; errno?: number; cause?: unknown };
  return e.code === "ER_DUP_ENTRY" || e.errno === 1062 || (e.cause !== error && isDuplicate(e.cause));
}
export async function getAuxiliaryEmailRun(jobId: number, localDate: string) {
  const db = await requireDb();
  return (await db.select().from(runs).where(and(eq(runs.jobId, jobId), eq(runs.localDate, localDate))).limit(1))[0];
}

/** Plain unique INSERT owns preparation. Only confirmed failed-before-send CAS may replace its token. Frozen ready plans resume without any delivery reset. */
export async function claimAuxiliaryEmailRun(jobId: number, localDate: string, token: string) {
  const db = await requireDb();
  try { await db.insert(runs).values({ jobId, localDate, attemptToken: token, state: "preparing" }); }
  catch (error) { if (!isDuplicate(error)) throw error; }
  let run = await getAuxiliaryEmailRun(jobId, localDate);
  if (!run) throw new Error("Auxiliary run claim not confirmed");
  if (run.state === "failed_before_send") {
    const changed = await db.update(runs).set({ state: "preparing", attemptToken: token, failureCode: null }).where(and(
      eq(runs.id, run.id), eq(runs.state, "failed_before_send"), eq(runs.attemptToken, run.attemptToken), isNull(runs.planCount),
    ));
    if (changed[0].affectedRows === 1) run = { ...run, state: "preparing", attemptToken: token, failureCode: null };
  }
  return { run, ownedPreparation: run.state === "preparing" && run.attemptToken === token };
}

type RunPatch = Partial<Pick<AuxiliaryEmailRun, "sourceUpdatedAt" | "planCount" | "outcome" | "failureCode">>;
export async function transitionAuxiliaryEmailRun(runId: number, token: string, expected: AuxiliaryEmailRun["state"], state: AuxiliaryEmailRun["state"], patch: RunPatch = {}) {
  const db = await requireDb();
  const result = await db.update(runs).set({ ...patch, state }).where(and(eq(runs.id, runId), eq(runs.attemptToken, token), eq(runs.state, expected)));
  return result[0].affectedRows === 1;
}

/** The whole immutable send plan and ready/no-email state commit atomically. A rollback/unknown commit can never invoke SMTP. */
export async function freezeAuxiliaryEmailPlan(runId: number, token: string, sourceUpdatedAt: Date, plan: { deliveryKey: string; message: AuxiliaryEmailMessage }[]) {
  const db = await requireDb();
  return db.transaction(async tx => {
    const changed = await tx.update(runs).set({ state: plan.length ? "ready" : "complete", sourceUpdatedAt, planCount: plan.length,
      outcome: plan.length ? null : "no-email", failureCode: null,
    }).where(and(eq(runs.id, runId), eq(runs.attemptToken, token), eq(runs.state, "preparing"), isNull(runs.planCount)));
    if (changed[0].affectedRows !== 1) return false;
    if (plan.length) await tx.insert(deliveries).values(plan.map(p => ({ ...p, runId, state: "pending" as const })));
    return true;
  });
}
export async function getAuxiliaryEmailDeliveries(runId: number) {
  const db = await requireDb();
  return db.select().from(deliveries).where(eq(deliveries.runId, runId)).orderBy(asc(deliveries.id));
}
export async function claimAuxiliaryEmailDelivery(id: number, token: string) {
  const db = await requireDb();
  const result = await db.update(deliveries).set({ state: "sending", attemptToken: token }).where(and(eq(deliveries.id, id), eq(deliveries.state, "pending")));
  return result[0].affectedRows === 1;
}
type DeliveryPatch = Partial<Pick<AuxiliaryEmailDelivery, "messageId" | "smtpReceipt" | "failureCode">>;
export async function transitionAuxiliaryEmailDelivery(id: number, token: string, state: "sent" | "unknown", patch: DeliveryPatch = {}) {
  const db = await requireDb();
  const result = await db.update(deliveries).set({ ...patch, state }).where(and(eq(deliveries.id, id), eq(deliveries.attemptToken, token), eq(deliveries.state, "sending")));
  return result[0].affectedRows === 1;
}
