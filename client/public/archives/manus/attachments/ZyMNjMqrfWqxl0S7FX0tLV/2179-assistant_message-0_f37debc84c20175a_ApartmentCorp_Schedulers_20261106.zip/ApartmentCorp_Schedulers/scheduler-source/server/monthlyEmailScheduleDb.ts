import { and, asc, eq, isNull, sql } from "drizzle-orm";
import {
  monthlyEmailJobs as jobs,
  monthlyEmailRuns as runs,
  monthlyEmailDeliveries as deliveries,
  type MonthlyEmailJob,
  type MonthlyEmailRun,
  type MonthlyEmailDelivery,
  type MonthlyEmailMessage,
} from "../drizzle/schema";
import { getDb } from "./db";
import {
  MONTHLY_POLICY,
  MONTHLY_RECIPIENTS,
  assertMonthlyRecipients,
  firstMonthlySendDate,
  isMonthlyJobPolicyValid,
} from "./monthlyEmailSchedulePolicy";

export type MonthlyEmailPlanEntry = {
  deliveryKey: string;
  message: MonthlyEmailMessage;
};
// Frozen source/plan/message/identity fields cannot be altered through transition metadata.
export type MonthlyEmailRunMetadata = Partial<
  Pick<MonthlyEmailRun, "outcome" | "failureCode">
>;
export type MonthlyEmailDeliveryMetadata = Partial<
  Pick<MonthlyEmailDelivery, "messageId" | "smtpReceipt" | "failureCode">
>;

async function requireDb() {
  const db = await getDb();
  if (!db) throw new Error("Monthly email schedule database unavailable");
  return db;
}
function assertId(id: number) {
  if (!Number.isSafeInteger(id) || id <= 0)
    throw new Error("Invalid monthly row identity");
}
function assertToken(token: string) {
  if (
    typeof token !== "string" ||
    !token ||
    token.length > 36 ||
    token.trim() !== token
  )
    throw new Error("Invalid monthly attempt token");
}
function assertUid(uid: string) {
  if (typeof uid !== "string" || !uid || uid.length > 65 || uid.trim() !== uid)
    throw new Error("Invalid monthly heartbeat identity");
}
function assertPeriod(periodKey: string) {
  if (
    typeof periodKey !== "string" ||
    !/^(?!0000)\d{4}-(0[1-9]|1[0-2])$/.test(periodKey)
  )
    throw new Error("Invalid monthly reporting period");
}
function assertFixedJobPolicy(
  job: MonthlyEmailJob | undefined
): asserts job is MonthlyEmailJob {
  if (
    !job ||
    job.scheduleKey !== MONTHLY_POLICY.scheduleKey ||
    job.reportType !== MONTHLY_POLICY.reportType ||
    job.endpointPath !== MONTHLY_POLICY.endpointPath ||
    job.timezone !== MONTHLY_POLICY.timezone ||
    job.sendHour !== MONTHLY_POLICY.sendHour ||
    job.sendDay !== MONTHLY_POLICY.sendDay
  )
    throw new Error("Monthly job policy invalid");
  assertMonthlyRecipients(job.recipientTo);
}
function fixedJobConditions() {
  return and(
    eq(jobs.scheduleKey, MONTHLY_POLICY.scheduleKey),
    eq(jobs.reportType, MONTHLY_POLICY.reportType),
    eq(jobs.endpointPath, MONTHLY_POLICY.endpointPath),
    eq(jobs.timezone, MONTHLY_POLICY.timezone),
    eq(jobs.sendHour, MONTHLY_POLICY.sendHour),
    eq(jobs.sendDay, MONTHLY_POLICY.sendDay),
    // MySQL/TiDB compares an uncast bound string as a JSON scalar, not the recipient array.
    sql`${jobs.recipientTo} = CAST(${JSON.stringify([...MONTHLY_RECIPIENTS])} AS JSON)`
  );
}
async function getMonthlyEmailJob(jobId: number) {
  const db = await requireDb();
  return (await db.select().from(jobs).where(eq(jobs.id, jobId)).limit(1))[0];
}

/** Explicit post-deployment provisioning only. Duplicate INSERT is a no-op, never a reset or repair of an existing row. */
export async function provisionMonthlyEmailJob() {
  const db = await requireDb();
  await db
    .insert(jobs)
    .values({
      scheduleKey: MONTHLY_POLICY.scheduleKey,
      reportType: MONTHLY_POLICY.reportType,
      endpointPath: MONTHLY_POLICY.endpointPath,
      timezone: MONTHLY_POLICY.timezone,
      sendHour: MONTHLY_POLICY.sendHour,
      sendDay: MONTHLY_POLICY.sendDay,
      recipientTo: [...MONTHLY_RECIPIENTS],
      enabled: false,
    })
    .onDuplicateKeyUpdate({ set: { id: sql`${jobs.id}` } });
  const job = (
    await db
      .select()
      .from(jobs)
      .where(eq(jobs.scheduleKey, MONTHLY_POLICY.scheduleKey))
      .limit(1)
  )[0];
  assertFixedJobPolicy(job);
  return job;
}
export async function getMonthlyEmailJobByTaskUid(uid: string) {
  assertUid(uid);
  const db = await requireDb();
  return (
    await db
      .select()
      .from(jobs)
      .where(eq(jobs.scheduleCronTaskUid, uid))
      .limit(1)
  )[0];
}

/** Bind only an existing disabled, unbound, unactivated fixed-policy job. Never replaces a UID or changes boundaries/ledgers. */
export async function bindMonthlyEmailHeartbeat(jobId: number, uid: string) {
  assertId(jobId);
  assertUid(uid);
  const db = await requireDb();
  const job = await getMonthlyEmailJob(jobId);
  assertFixedJobPolicy(job);
  const occupied = await getMonthlyEmailJobByTaskUid(uid);
  if (occupied) {
    if (occupied.id !== jobId || !isMonthlyJobPolicyValid(occupied, uid))
      throw new Error("Monthly UID already bound or policy invalid");
    return occupied;
  }
  if (
    job.enabled ||
    job.scheduleCronTaskUid ||
    job.activatedAt ||
    job.firstSendDate
  )
    throw new Error("Monthly binding boundary invalid");
  const result = await db
    .update(jobs)
    .set({ scheduleCronTaskUid: uid })
    .where(
      and(
        eq(jobs.id, jobId),
        fixedJobConditions(),
        eq(jobs.enabled, false),
        isNull(jobs.scheduleCronTaskUid),
        isNull(jobs.activatedAt),
        isNull(jobs.firstSendDate)
      )
    );
  const bound = await getMonthlyEmailJobByTaskUid(uid);
  if (!bound || bound.id !== jobId || !isMonthlyJobPolicyValid(bound, uid))
    throw new Error("Monthly binding not confirmed");
  if (result[0].affectedRows !== 1 && bound.scheduleCronTaskUid !== uid)
    throw new Error("Monthly binding not confirmed");
  return bound;
}

function assertActivationBoundary(job: MonthlyEmailJob) {
  if (
    !job.activatedAt ||
    !Number.isFinite(job.activatedAt.getTime()) ||
    !job.firstSendDate ||
    job.firstSendDate !== firstMonthlySendDate(job.activatedAt)
  )
    throw new Error("Monthly activation boundary invalid");
}
/** Activate a bound policy row explicitly. UTC activation + first eligible Pacific send date are set once, never backfilled or reset. */
export async function activateMonthlyEmailJob(jobId: number, now: Date) {
  assertId(jobId);
  if (!(now instanceof Date) || !Number.isFinite(now.getTime()))
    throw new Error("Invalid monthly activation date");
  const db = await requireDb();
  const job = await getMonthlyEmailJob(jobId);
  assertFixedJobPolicy(job);
  if (
    !job.scheduleCronTaskUid ||
    !isMonthlyJobPolicyValid(job, job.scheduleCronTaskUid)
  )
    throw new Error("Monthly job must be bound before activation");
  assertUid(job.scheduleCronTaskUid);
  if (job.activatedAt || job.firstSendDate) {
    assertActivationBoundary(job);
    if (job.enabled) return job;
    await db
      .update(jobs)
      .set({ enabled: true })
      .where(
        and(
          eq(jobs.id, jobId),
          fixedJobConditions(),
          eq(jobs.scheduleCronTaskUid, job.scheduleCronTaskUid),
          eq(jobs.enabled, false),
          eq(jobs.activatedAt, job.activatedAt!),
          eq(jobs.firstSendDate, job.firstSendDate!)
        )
      );
  } else {
    if (job.enabled) throw new Error("Monthly activation boundary invalid");
    const activatedAt = new Date(now.getTime());
    await db
      .update(jobs)
      .set({
        enabled: true,
        activatedAt,
        firstSendDate: firstMonthlySendDate(activatedAt),
      })
      .where(
        and(
          eq(jobs.id, jobId),
          fixedJobConditions(),
          eq(jobs.scheduleCronTaskUid, job.scheduleCronTaskUid),
          eq(jobs.enabled, false),
          isNull(jobs.activatedAt),
          isNull(jobs.firstSendDate)
        )
      );
  }
  const activated = await getMonthlyEmailJob(jobId);
  assertFixedJobPolicy(activated);
  if (
    !activated.enabled ||
    !isMonthlyJobPolicyValid(activated, job.scheduleCronTaskUid)
  )
    throw new Error("Monthly activation not confirmed");
  assertActivationBoundary(activated);
  return activated;
}

function isDuplicate(error: unknown): boolean {
  if (!error || typeof error !== "object") return false;
  const e = error as { code?: string; errno?: number; cause?: unknown };
  return (
    e.code === "ER_DUP_ENTRY" ||
    e.errno === 1062 ||
    (e.cause !== error && isDuplicate(e.cause))
  );
}
export async function getMonthlyEmailRun(jobId: number, periodKey: string) {
  assertId(jobId);
  assertPeriod(periodKey);
  const db = await requireDb();
  return (
    await db
      .select()
      .from(runs)
      .where(and(eq(runs.jobId, jobId), eq(runs.periodKey, periodKey)))
      .limit(1)
  )[0];
}
/** Plain unique INSERT owns preparation per job/reporting month. Only failed_before_send with no frozen plan can retry. */
export async function claimMonthlyEmailRun(
  jobId: number,
  periodKey: string,
  attemptToken: string
) {
  assertId(jobId);
  assertPeriod(periodKey);
  assertToken(attemptToken);
  const db = await requireDb();
  try {
    await db
      .insert(runs)
      .values({ jobId, periodKey, attemptToken, state: "preparing" });
  } catch (error) {
    if (!isDuplicate(error)) throw error;
  }
  let run = await getMonthlyEmailRun(jobId, periodKey);
  if (!run) throw new Error("Monthly run claim not confirmed");
  if (run.state === "failed_before_send" && run.planCount === null) {
    const changed = await db
      .update(runs)
      .set({ state: "preparing", attemptToken, failureCode: null })
      .where(
        and(
          eq(runs.id, run.id),
          eq(runs.state, "failed_before_send"),
          eq(runs.attemptToken, run.attemptToken),
          isNull(runs.planCount)
        )
      );
    if (changed[0].affectedRows === 1)
      run = { ...run, state: "preparing", attemptToken, failureCode: null };
  }
  return {
    run,
    ownedPreparation:
      run.state === "preparing" && run.attemptToken === attemptToken,
  };
}
export async function transitionMonthlyEmailRun(
  id: number,
  token: string,
  from: MonthlyEmailRun["state"],
  to: MonthlyEmailRun["state"],
  metadata: MonthlyEmailRunMetadata = {}
) {
  assertId(id);
  assertToken(token);
  // Preparation retry and plan freezing have their own stronger CAS; terminal/frozen state cannot be reopened here.
  const allowed =
    (from === "preparing" && to === "failed_before_send") ||
    (from === "ready" &&
      ["ready", "processing", "complete", "review"].includes(to)) ||
    (from === "processing" && ["complete", "review"].includes(to));
  if (
    !allowed ||
    Object.keys(metadata).some(key => !["outcome", "failureCode"].includes(key))
  )
    throw new Error("Invalid monthly run transition");
  const db = await requireDb();
  const result = await db
    .update(runs)
    .set({ ...metadata, state: to })
    .where(
      and(
        eq(runs.id, id),
        eq(runs.attemptToken, token),
        eq(runs.state, from),
        from === "preparing" ? isNull(runs.planCount) : undefined
      )
    );
  return result[0].affectedRows === 1;
}

function snapshotPlan(plan: MonthlyEmailPlanEntry[]): MonthlyEmailPlanEntry[] {
  if (!Array.isArray(plan) || plan.length > 1)
    throw new Error("Monthly plan must contain at most one report");
  return plan.map(entry => {
    if (
      !entry ||
      typeof entry.deliveryKey !== "string" ||
      !entry.deliveryKey ||
      entry.deliveryKey.length > 320 ||
      entry.deliveryKey.trim() !== entry.deliveryKey
    )
      throw new Error("Invalid monthly delivery key");
    const message = entry.message;
    const fields = ["from", "replyTo", "to", "subject", "html"] as const;
    if (
      !message ||
      Object.keys(message).length !== fields.length ||
      Object.keys(message).some(
        key => !fields.includes(key as (typeof fields)[number])
      ) ||
      fields.some(
        key => typeof message[key] !== "string" || !message[key].trim()
      )
    )
      throw new Error("Invalid monthly message fields");
    assertMonthlyRecipients(
      message.to.split(",").map(recipient => recipient.trim())
    );
    // Copy primitives before the first await; callers cannot mutate the message during transaction preparation.
    return {
      deliveryKey: entry.deliveryKey,
      message: {
        from: message.from,
        replyTo: message.replyTo,
        to: message.to,
        subject: message.subject,
        html: message.html,
      },
    };
  });
}
/** The immutable complete message and source timestamp commit with ready/no-email state atomically. Errors/unknown commit never confirm an SMTP plan. */
export async function freezeMonthlyEmailPlan(
  runId: number,
  attemptToken: string,
  sourceUpdatedAt: Date,
  plan: MonthlyEmailPlanEntry[]
) {
  assertId(runId);
  assertToken(attemptToken);
  if (
    !(sourceUpdatedAt instanceof Date) ||
    !Number.isFinite(sourceUpdatedAt.getTime())
  )
    throw new Error("Invalid monthly source timestamp");
  const frozenSourceUpdatedAt = new Date(sourceUpdatedAt.getTime());
  const snapshot = snapshotPlan(plan);
  const db = await requireDb();
  return db.transaction(async tx => {
    const changed = await tx
      .update(runs)
      .set({
        state: snapshot.length ? "ready" : "complete",
        sourceUpdatedAt: frozenSourceUpdatedAt,
        planCount: snapshot.length,
        outcome: snapshot.length ? null : "no-email",
        failureCode: null,
      })
      .where(
        and(
          eq(runs.id, runId),
          eq(runs.attemptToken, attemptToken),
          eq(runs.state, "preparing"),
          isNull(runs.planCount)
        )
      );
    if (changed[0].affectedRows !== 1) return false;
    if (snapshot.length)
      await tx
        .insert(deliveries)
        .values(
          snapshot.map(entry => ({
            ...entry,
            runId,
            state: "pending" as const,
          }))
        );
    return true;
  });
}
export async function getMonthlyEmailDeliveries(runId: number) {
  assertId(runId);
  const db = await requireDb();
  return db
    .select()
    .from(deliveries)
    .where(eq(deliveries.runId, runId))
    .orderBy(asc(deliveries.id));
}
/** Only a CONFIRMED pending->sending CAS authorizes SMTP. Throw/false means do not send; sending/sent/unknown never reclaim. */
export async function claimMonthlyEmailDelivery(id: number, token: string) {
  assertId(id);
  assertToken(token);
  const db = await requireDb();
  const result = await db
    .update(deliveries)
    .set({ state: "sending", attemptToken: token })
    .where(and(eq(deliveries.id, id), eq(deliveries.state, "pending")));
  return result[0].affectedRows === 1;
}
export async function transitionMonthlyEmailDelivery(
  id: number,
  token: string,
  target: "sent" | "unknown",
  metadata: MonthlyEmailDeliveryMetadata = {}
) {
  assertId(id);
  assertToken(token);
  if (
    !["sent", "unknown"].includes(target) ||
    Object.keys(metadata).some(
      key => !["messageId", "smtpReceipt", "failureCode"].includes(key)
    )
  )
    throw new Error("Invalid monthly delivery transition");
  const db = await requireDb();
  const result = await db
    .update(deliveries)
    .set({ ...metadata, state: target })
    .where(
      and(
        eq(deliveries.id, id),
        eq(deliveries.attemptToken, token),
        eq(deliveries.state, "sending")
      )
    );
  return result[0].affectedRows === 1;
}
