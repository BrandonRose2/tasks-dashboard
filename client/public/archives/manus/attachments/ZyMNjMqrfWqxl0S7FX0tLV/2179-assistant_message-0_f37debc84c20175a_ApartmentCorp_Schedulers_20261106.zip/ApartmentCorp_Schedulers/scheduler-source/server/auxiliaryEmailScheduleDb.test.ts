import { beforeEach, describe, expect, it, vi } from "vitest";
import { MySqlDialect } from "drizzle-orm/mysql-core";
import { readFileSync } from "node:fs";
const mocks = vi.hoisted(() => ({ getDb: vi.fn(), values: vi.fn(), limit: vi.fn(), set: vi.fn(), updateWhere: vi.fn(), transaction: vi.fn() }));
vi.mock("./db", () => ({ getDb: mocks.getDb }));
import { activateAuxiliaryEmailJobByTaskUid, bindAuxiliaryEmailJobTaskUid, claimAuxiliaryEmailDelivery, claimAuxiliaryEmailRun, ensureAuxiliaryEmailJobsDisabled, freezeAuxiliaryEmailPlan, transitionAuxiliaryEmailDelivery, transitionAuxiliaryEmailRun } from "./auxiliaryEmailScheduleDb";
import { AUXILIARY_POLICIES } from "./auxiliaryEmailSchedulePolicy";
const dialect = new MySqlDialect();
const job = { id: 7, reportType: "weekly_vacancy", ...AUXILIARY_POLICIES.weekly_vacancy, timezone: "America/New_York", sendHour: 9, scheduleCronTaskUid: "uid", enabled: false, activatedAt: null, firstSendDate: null };
const run = { id: 1, jobId: 7, localDate: "2026-11-07", attemptToken: "old", state: "preparing", planCount: null, sourceUpdatedAt: null };
let db: any;
beforeEach(() => {
  vi.resetAllMocks();
  db = { insert: vi.fn(() => ({ values: mocks.values })), select: vi.fn(() => ({ from: vi.fn(() => ({ where: vi.fn(() => ({ limit: mocks.limit, then: (resolve: any) => resolve([]) })) })) })), update: vi.fn(() => ({ set: mocks.set })), transaction: mocks.transaction };
  mocks.getDb.mockResolvedValue(db); mocks.values.mockResolvedValue([]); mocks.set.mockReturnValue({ where: mocks.updateWhere }); mocks.updateWhere.mockResolvedValue([{ affectedRows: 1 }]);
  mocks.transaction.mockImplementation(async callback => callback(db));
});
describe("auxiliary SQL ownership and immutable ledgers", () => {
  it("plain INSERT unique per job/date, no body/time/recipient claim inputs", async () => {
    mocks.limit.mockResolvedValue([{ ...run, attemptToken: "new" }]);
    expect((await claimAuxiliaryEmailRun(7, "2026-11-07", "new")).ownedPreparation).toBe(true);
    expect(mocks.values).toHaveBeenCalledWith({ jobId: 7, localDate: "2026-11-07", attemptToken: "new", state: "preparing" });
  });
  it.each(["preparing", "processing", "ready", "review", "complete"])("existing %s never reclaims or resets old ledgers", async state => {
    mocks.values.mockRejectedValueOnce({ cause: { code: "ER_DUP_ENTRY" } }); mocks.limit.mockResolvedValue([{ ...run, state }]);
    const result = await claimAuxiliaryEmailRun(7, "2026-11-07", "new"); expect(result.ownedPreparation).toBe(false); expect(result.run.attemptToken).toBe("old"); expect(mocks.set).not.toHaveBeenCalled();
  });
  it("safe failed-before-send ownership CAS requires state, token and no frozen plan", async () => {
    mocks.values.mockRejectedValueOnce({ errno: 1062 }); mocks.limit.mockResolvedValue([{ ...run, state: "failed_before_send" }]);
    expect((await claimAuxiliaryEmailRun(7, "2026-11-07", "new")).ownedPreparation).toBe(true);
    const query = dialect.sqlToQuery(mocks.updateWhere.mock.calls[0][0]); expect(query.params).toEqual([1, "failed_before_send", "old"]); expect(query.sql).toContain("`plan_count` is null");
    expect(mocks.set).toHaveBeenCalledWith({ state: "preparing", attemptToken: "new", failureCode: null });
  });
  it("lost concurrent safe claim CAS never owns preparation", async () => {
    mocks.values.mockRejectedValueOnce({ code: "ER_DUP_ENTRY" }); mocks.limit.mockResolvedValue([{ ...run, state: "failed_before_send" }]); mocks.updateWhere.mockResolvedValue([{ affectedRows: 0 }]);
    expect((await claimAuxiliaryEmailRun(7, "2026-11-07", "loser")).ownedPreparation).toBe(false);
  });
  it("nonduplicate and unavailable DB never count as claimed", async () => {
    mocks.values.mockRejectedValueOnce(new Error("database offline")); await expect(claimAuxiliaryEmailRun(7, "2026-11-07", "new")).rejects.toThrow();
    mocks.getDb.mockResolvedValueOnce(null); await expect(claimAuxiliaryEmailDelivery(1, "new")).rejects.toThrow();
  });
  it("delivery CAS only pending; receipt CAS requires sending + owner token", async () => {
    await claimAuxiliaryEmailDelivery(4, "new"); let q = dialect.sqlToQuery(mocks.updateWhere.mock.calls[0][0]); expect(q.params).toEqual([4, "pending"]);
    await transitionAuxiliaryEmailDelivery(4, "new", "sent", { failureCode: null }); q = dialect.sqlToQuery(mocks.updateWhere.mock.calls[1][0]); expect(q.params).toEqual([4, "new", "sending"]);
    mocks.updateWhere.mockResolvedValueOnce([{ affectedRows: 0 }]); expect(await claimAuxiliaryEmailDelivery(4, "loser")).toBe(false);
  });
  it("run CAS does not update any delivery rows", async () => {
    await transitionAuxiliaryEmailRun(1, "new", "ready", "complete", { outcome: "sent" });
    expect(dialect.sqlToQuery(mocks.updateWhere.mock.calls[0][0]).params).toEqual([1, "new", "ready"]); expect(db.insert).not.toHaveBeenCalled();
  });
  it("freeze transaction atomically changes preparing owner state and inserts immutable per-manager plan", async () => {
    const plan = [{ deliveryKey: "manager@example.com", message: { from: "fixed", replyTo: "fixed", to: "manager@example.com", subject: "fixed", html: "fixed" } }];
    expect(await freezeAuxiliaryEmailPlan(1, "new", new Date(), plan)).toBe(true); expect(mocks.transaction).toHaveBeenCalledOnce();
    expect(mocks.values).toHaveBeenCalledWith([{ ...plan[0], runId: 1, state: "pending" }]);
    const q = dialect.sqlToQuery(mocks.updateWhere.mock.calls[0][0]); expect(q.params).toEqual([1, "new", "preparing"]); expect(q.sql).toContain("`plan_count` is null");
  });
  it("lost freeze ownership never inserts, no-email outcome atomically completes", async () => {
    mocks.updateWhere.mockResolvedValueOnce([{ affectedRows: 0 }]); expect(await freezeAuxiliaryEmailPlan(1, "new", new Date(), [])).toBe(false); expect(mocks.values).not.toHaveBeenCalled();
    expect(await freezeAuxiliaryEmailPlan(1, "new", new Date(), [])).toBe(true); expect(mocks.set.mock.calls[1][0]).toMatchObject({ state: "complete", planCount: 0, outcome: "no-email" }); expect(mocks.values).not.toHaveBeenCalled();
  });
  it("freeze insert failure rejects transaction and cannot return an SMTP plan", async () => {
    mocks.values.mockRejectedValueOnce(new Error("rollback")); await expect(freezeAuxiliaryEmailPlan(1, "new", new Date(), [{ deliveryKey: "manager", message: {} as any }])).rejects.toThrow("rollback");
    expect(mocks.transaction).toHaveBeenCalledOnce();
  });
});
describe("explicit idempotent provisioning only", () => {
  it("ensure inserts both disabled policies with duplicate no-op, never resets existing job/delivery state", async () => {
    mocks.values.mockReturnValue({ onDuplicateKeyUpdate: vi.fn().mockResolvedValue([]) }); await ensureAuxiliaryEmailJobsDisabled();
    expect(mocks.values).toHaveBeenCalledTimes(2); for (const [values] of mocks.values.mock.calls) expect(values).toMatchObject({ enabled: false, timezone: "America/New_York", sendHour: 9 }); expect(mocks.set).not.toHaveBeenCalled();
  });
  it("binding same UID is read-only idempotent and wrong job refuses", async () => {
    mocks.limit.mockResolvedValueOnce([job]); expect(await bindAuxiliaryEmailJobTaskUid("weekly_vacancy", "uid")).toEqual(job); expect(mocks.set).not.toHaveBeenCalled();
    mocks.limit.mockResolvedValueOnce([job]); await expect(bindAuxiliaryEmailJobTaskUid("eviction_reminders", "uid")).rejects.toThrow();
  });
  it("new UID binding only existing disabled/unbound fixed policy; no boundary or ledger updates", async () => {
    mocks.limit.mockResolvedValueOnce([]).mockResolvedValueOnce([job]); await bindAuxiliaryEmailJobTaskUid("weekly_vacancy", "uid"); expect(mocks.set).toHaveBeenCalledWith({ scheduleCronTaskUid: "uid" });
    const q = dialect.sqlToQuery(mocks.updateWhere.mock.calls[0][0]); expect(q.sql).toContain("`schedule_cron_task_uid` is null"); expect(q.params).toContain(false);
  });
  it("activation repeated for same active UID retains boundaries; disabled same UID enables without resetting", async () => {
    const active = { ...job, enabled: true, activatedAt: new Date("2026-11-05T00:00:00Z"), firstSendDate: "2026-11-07" };
    mocks.limit.mockResolvedValue([active]); await activateAuxiliaryEmailJobByTaskUid("uid"); expect(mocks.set).not.toHaveBeenCalled();
    mocks.limit.mockResolvedValue([{ ...active, enabled: false }]); await activateAuxiliaryEmailJobByTaskUid("uid"); expect(mocks.set).toHaveBeenCalledWith({ enabled: true });
  });
  it("first activation uses null-boundary CAS, never resets ledger or touches daily tables", async () => {
    mocks.limit.mockResolvedValue([job]); await activateAuxiliaryEmailJobByTaskUid("uid"); expect(mocks.set).toHaveBeenCalledWith({ enabled: true, activatedAt: expect.any(Date), firstSendDate: expect.any(String) });
    expect(dialect.sqlToQuery(mocks.updateWhere.mock.calls[0][0]).sql).toContain("`activated_at` is null"); expect(db.insert).not.toHaveBeenCalled();
  });
  it("invalid/missing policy or partial activation refuses", async () => {
    for (const j of [undefined, { ...job, timezone: "UTC" }, { ...job, activatedAt: new Date() }]) {
      mocks.limit.mockResolvedValueOnce(j ? [j] : []); await expect(activateAuxiliaryEmailJobByTaskUid("uid")).rejects.toThrow();
    }
    await expect(bindAuxiliaryEmailJobTaskUid("weekly_vacancy", " uid ")).rejects.toThrow(); expect(mocks.set).not.toHaveBeenCalled();
  });
  it("generated migration is exclusively additive to auxiliary tables, with uniqueness and disabled default", () => {
    const sql = readFileSync(new URL("../drizzle/0011_auxiliary_email_heartbeats.sql", import.meta.url), "utf8");
    expect(sql).not.toMatch(/\bDROP\s|DELETE\s+FROM|UPDATE\s+`|INSERT\s+INTO|daily_vacancy|email_recipients/i); expect(sql.match(/CREATE TABLE/g)).toHaveLength(3);
    expect(sql).toContain("DEFAULT false"); expect(sql).toContain("UNIQUE(`job_id`,`local_date`)"); expect(sql).toContain("UNIQUE(`run_id`,`delivery_key`)");
  });
});
