import { randomUUID } from "node:crypto";
import type { Request, Response } from "express";
import type { MonthlyEmailJob, MonthlyEmailMessage, MonthlyEmailRun } from "../drizzle/schema";
import { sdk } from "./_core/sdk";
import { createGmailReportTransport, GMAIL_REPORT_SENDER } from "./gmailReportTransport";
import { prepareMonthlyNetCashEmail } from "./emailService";
import { fetchFreshMonthlyNetCashReport, getPreviousCompletedMonth } from "./monthlyNetCashReport";
import { assertMonthlyRecipients, getMonthlyCalendar, isMonthlyJobPolicyValid, monthlyGate } from "./monthlyEmailSchedulePolicy";
import { claimMonthlyEmailRun, freezeMonthlyEmailPlan, getMonthlyEmailDeliveries, getMonthlyEmailJobByTaskUid, claimMonthlyEmailDelivery, transitionMonthlyEmailDelivery, transitionMonthlyEmailRun } from "./monthlyEmailScheduleDb";

export const MONTHLY_CALLBACK_BUDGET_MS = 110_000;
export const MONTHLY_SOURCE_MAX_AGE_MS = 300_000;
export const MONTHLY_PREPARATION_BUDGET_MS = 80_000; // observed cold PropertyMax bootstrap can take ~75s
const SMTP_START_RESERVE_MS = 5_000;
async function beforeDeadline<T>(operation: () => Promise<T>, deadline: number): Promise<T> {
  const remaining = deadline - Date.now();
  if (remaining <= 0) throw new Error("Monthly budget exhausted");
  let timer: ReturnType<typeof setTimeout> | undefined;
  try {
    return await Promise.race([operation(), new Promise<never>((_, reject) => {
      timer = setTimeout(() => reject(new Error("Monthly budget exhausted")), remaining);
    })]);
  } finally { if (timer) clearTimeout(timer); }
}
export function assertMonthlySourceTime(sourceUpdatedAt: Date | null | undefined, now = new Date()) {
  const age = now.getTime() - (sourceUpdatedAt instanceof Date ? sourceUpdatedAt.getTime() : NaN);
  if (!Number.isFinite(age) || age < 0 || age > MONTHLY_SOURCE_MAX_AGE_MS) throw new Error("Monthly source missing or stale");
}
export function assertMonthlyMessage(message: MonthlyEmailMessage) {
  const allowed = ["from", "replyTo", "to", "subject", "html"];
  if (!message || Object.keys(message).some(key => !allowed.includes(key))
    || message.from !== `"Apartment Corp Reports" <${GMAIL_REPORT_SENDER}>` || message.replyTo !== "ethan@apartmentcorp.com"
    || typeof message.subject !== "string" || !message.subject || typeof message.html !== "string" || !message.html
    || typeof message.to !== "string") throw new Error("Monthly message policy invalid");
  assertMonthlyRecipients(message.to.split(",").map(value => value.trim()));
}
export function sanitiseMonthlyReceipt(raw: unknown, message: MonthlyEmailMessage) {
  assertMonthlyMessage(message);
  const expected = message.to.split(",").map(value => value.trim());
  const receipt = raw && typeof raw === "object" ? raw as Record<string, unknown> : {};
  const addresses = (value: unknown): string[] | null => {
    if (!Array.isArray(value)) return null;
    const list = value.map(v => typeof v === "string" ? v.toLowerCase() : v && typeof v === "object" && typeof v.address === "string" ? v.address.toLowerCase() : "");
    return list.some(v => !v || !expected.includes(v)) ? null : Array.from(new Set(list));
  };
  const accepted = addresses(receipt.accepted); const rejected = addresses(receipt.rejected);
  const fullyAccepted = !!accepted && !!rejected && !rejected.length && expected.every(value => accepted.includes(value));
  const messageId = typeof receipt.messageId === "string" && /^[\w@.<>+\-]{1,512}$/.test(receipt.messageId) ? receipt.messageId : "";
  return { fullyAccepted, receipt: { messageId, accepted: accepted ?? [], rejected: rejected ?? [], response: fullyAccepted ? "accepted" : "unconfirmed" } };
}
type Result = { status: string; retrySafe: boolean; manualReviewNeeded: boolean; sent?: number };
const manual = (status: string): Result => ({ status, retrySafe: false, manualReviewNeeded: true });
async function processMonthlyJob(job: MonthlyEmailJob, deadline: number): Promise<Result> {
  const period = getPreviousCompletedMonth(new Date());
  const token = randomUUID();
  let claim: Awaited<ReturnType<typeof claimMonthlyEmailRun>>;
  try { claim = await beforeDeadline(() => claimMonthlyEmailRun(job.id, period.periodKey, token), deadline); }
  catch { return manual("claim-unconfirmed"); }
  let run = claim.run;
  if (run.jobId !== job.id || run.periodKey !== period.periodKey) return manual("run-policy-invalid");
  if (run.state === "complete") return { status: run.outcome ?? "complete", retrySafe: false, manualReviewNeeded: false };
  if (["preparing", "failed_before_send"].includes(run.state) && !claim.ownedPreparation) return manual("already-claimed");
  if (["processing", "review"].includes(run.state)) return manual("already-claimed");
  if (claim.ownedPreparation) {
    const preparationDeadline = Math.min(Date.now() + MONTHLY_PREPARATION_BUDGET_MS, deadline - SMTP_START_RESERVE_MS);
    let message: MonthlyEmailMessage;
    let sourceUpdatedAt: Date;
    try {
      assertMonthlyRecipients(job.recipientTo);
      createGmailReportTransport(); // configuration only; never connects or sends
      const fresh = await beforeDeadline(() => fetchFreshMonthlyNetCashReport(period), preparationDeadline);
      if (fresh.month.year !== period.year || fresh.month.month !== period.month) throw new Error("Monthly period mismatch");
      sourceUpdatedAt = fresh.sourceUpdatedAt;
      assertMonthlySourceTime(sourceUpdatedAt);
      const prepared = await beforeDeadline(async () => prepareMonthlyNetCashEmail(fresh.month, job.recipientTo), preparationDeadline);
      message = prepared.message; assertMonthlyMessage(message);
      if (Date.now() >= preparationDeadline || monthlyGate(job, new Date())) throw new Error("Monthly preparation late");
    } catch {
      try {
        if (!await beforeDeadline(() => transitionMonthlyEmailRun(run.id, token, "preparing", "failed_before_send", { failureCode: "preparation-failed" }), deadline)) return manual("preparation-unconfirmed");
      } catch { return manual("preparation-unconfirmed"); }
      return { status: "preparation-failed", retrySafe: true, manualReviewNeeded: false };
    }
    try {
      if (!await beforeDeadline(() => freezeMonthlyEmailPlan(run.id, token, sourceUpdatedAt, [{ deliveryKey: period.periodKey, message }]), deadline)) return manual("plan-unconfirmed");
    } catch { return manual("plan-unconfirmed"); }
    run = { ...run, state: "ready", planCount: 1, sourceUpdatedAt };
  }
  if (run.state !== "ready") return manual("already-claimed");
  return deliverMonthlyPlan(job, run, deadline);
}
async function deliverMonthlyPlan(job: MonthlyEmailJob, run: MonthlyEmailRun, deadline: number): Promise<Result> {
  let rows: Awaited<ReturnType<typeof getMonthlyEmailDeliveries>>;
  let transporter: ReturnType<typeof createGmailReportTransport> | undefined;
  const safeFailure = async (code: string): Promise<Result> => {
    try {
      if (!await beforeDeadline(() => transitionMonthlyEmailRun(run.id, run.attemptToken, "ready", "ready", { failureCode: code }), deadline)) return manual("run-update-unconfirmed");
      return { status: code, retrySafe: true, manualReviewNeeded: false };
    } catch { return manual("run-update-unconfirmed"); }
  };
  try {
    rows = await beforeDeadline(() => getMonthlyEmailDeliveries(run.id), deadline);
    if (run.planCount !== 1 || rows.length !== 1 || rows[0].runId !== run.id || rows[0].deliveryKey !== run.periodKey) return manual("plan-incomplete");
    assertMonthlyMessage(rows[0].message);
    if (rows[0].state === "pending") { assertMonthlySourceTime(run.sourceUpdatedAt); transporter = createGmailReportTransport(); }
  } catch { return safeFailure("pre-send-validation-failed"); }
  const row = rows[0];
  if (row.state === "pending") {
    if (Date.now() >= deadline - SMTP_START_RESERVE_MS || monthlyGate(job, new Date())) return safeFailure("send-budget-or-slot-exhausted");
    const deliveryToken = randomUUID();
    let claimed: boolean;
    try { claimed = await beforeDeadline(() => claimMonthlyEmailDelivery(row.id, deliveryToken), deadline); }
    catch { return manual("delivery-claim-unconfirmed"); }
    if (claimed) {
      // A late/uncertain CAS cannot start SMTP. Sending never expires or becomes pending.
      if (Date.now() >= deadline - SMTP_START_RESERVE_MS || monthlyGate(job, new Date())) return manual("sending");
      try {
        assertMonthlySourceTime(run.sourceUpdatedAt);
        const raw = await beforeDeadline(() => transporter!.sendMail(row.message), deadline);
        const { receipt, fullyAccepted } = sanitiseMonthlyReceipt(raw, row.message);
        if (!await beforeDeadline(() => transitionMonthlyEmailDelivery(row.id, deliveryToken, fullyAccepted ? "sent" : "unknown", {
          messageId: receipt.messageId, smtpReceipt: receipt, failureCode: fullyAccepted ? null : "smtp-not-fully-accepted",
        }), deadline)) return manual("delivery-receipt-unconfirmed");
      } catch {
        try { await beforeDeadline(() => transitionMonthlyEmailDelivery(row.id, deliveryToken, "unknown", { failureCode: "delivery-ambiguous" }), deadline); }
        catch { /* sending remains non-reclaimable */ }
        return manual("delivery-not-retried");
      }
    }
  }
  try {
    const final = await beforeDeadline(() => getMonthlyEmailDeliveries(run.id), deadline);
    if (final.length !== 1) return manual("plan-incomplete");
    if (final[0].state === "pending") return { status: "pending", retrySafe: true, manualReviewNeeded: false };
    const confirmed = final[0].state === "sent";
    if (!await beforeDeadline(() => transitionMonthlyEmailRun(run.id, run.attemptToken, "ready", confirmed ? "complete" : "review", {
      outcome: confirmed ? "sent" : "partial-or-ambiguous", failureCode: confirmed ? null : "delivery-review-required",
    }), deadline)) return manual("run-completion-unconfirmed");
    return { status: confirmed ? "sent" : "delivery-not-retried", sent: confirmed ? 1 : 0, retrySafe: false, manualReviewNeeded: !confirmed };
  } catch { return manual("run-completion-unconfirmed"); }
}
export async function monthlyNetCashFlowScheduledHandler(req: Request, res: Response) {
  const deadline = Date.now() + MONTHLY_CALLBACK_BUDGET_MS;
  let uid: string;
  try {
    const user = await beforeDeadline(() => sdk.authenticateRequest(req), deadline);
    if (!user.isCron || !user.taskUid) return res.status(403).json({ error: "cron-only" });
    uid = user.taskUid;
  } catch { return res.status(403).json({ error: "cron-only" }); }
  try {
    // Policy, period, recipients, and identity are never taken from the request body.
    const job = await beforeDeadline(() => getMonthlyEmailJobByTaskUid(uid), deadline);
    if (!job) return res.json({ ok: true, skipped: "orphan" });
    if (!job.enabled) return res.json({ ok: true, skipped: "disabled" });
    if (!isMonthlyJobPolicyValid(job, uid)) return res.json({ ok: true, skipped: "invalid-config" });
    const now = new Date(); const skipped = monthlyGate(job, now);
    if (skipped) return res.json({ ok: true, skipped });
    const result = await processMonthlyJob(job, deadline);
    return res.status(result.retrySafe ? 503 : 200).json({ ok: !result.retrySafe, reportType: "monthly_net_cash_flow", localDate: getMonthlyCalendar(now).localDate, ...result });
  } catch { return res.status(500).json({ error: "monthly-email-callback-failed", timestamp: new Date().toISOString() }); }
}
