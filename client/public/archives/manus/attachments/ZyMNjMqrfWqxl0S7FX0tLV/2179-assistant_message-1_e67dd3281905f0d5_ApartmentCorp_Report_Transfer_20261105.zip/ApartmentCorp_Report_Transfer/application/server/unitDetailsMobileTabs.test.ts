import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const source = readFileSync(
  new URL("../client/src/pages/VacancyDashboard.tsx", import.meta.url),
  "utf8"
);

describe("Unit Details mobile tab rail", () => {
  it("uses a scrollable, non-wrapping tab rail with touch-friendly triggers", () => {
    expect(source).toContain("overflow-x-auto overscroll-x-contain");
    expect(source).toContain("min-w-max justify-start");
    expect(source).toContain("shrink-0 min-h-10");
    expect(source).toContain("whitespace-nowrap text-xs sm:text-sm");
    expect(source).toContain("data-[state=active]:font-extrabold");
    expect(source).toContain("bg-gradient-to-l from-background via-background/90 to-transparent");
    expect(source).toContain("Searches all Unit Details tabs");
  });
});
