CREATE TABLE `vacancy_snapshots` (
	`id` int AUTO_INCREMENT NOT NULL,
	`snapshotDate` varchar(10) NOT NULL,
	`buildingData` json NOT NULL,
	`totalVacant` int NOT NULL DEFAULT 0,
	`vacUnleased` int NOT NULL DEFAULT 0,
	`vacPreleased` int NOT NULL DEFAULT 0,
	`onNotice` int NOT NULL DEFAULT 0,
	`eviction` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `vacancy_snapshots_id` PRIMARY KEY(`id`)
);
