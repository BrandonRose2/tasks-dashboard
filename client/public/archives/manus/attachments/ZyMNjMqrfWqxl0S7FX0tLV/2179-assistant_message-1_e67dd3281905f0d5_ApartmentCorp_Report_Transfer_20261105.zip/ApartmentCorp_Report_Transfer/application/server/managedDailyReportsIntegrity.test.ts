import { readFileSync } from "node:fs";
import ts from "typescript";
import { describe, expect, it } from "vitest";
import { buildCurrentCollectionsHtml, buildDailyVacancyHtml, LEGACY_COLLECTIONS_DISTRIBUTION_RETIRED } from "./emailService";
import { assertScheduledCollectionsSnapshot } from "./dailyVacancyScheduled";
import { DAILY_VACANCY_PLATFORM_CRON } from "./dailyVacancySchedulePolicy";
import type { CollectionsSnapshot } from "./scraper";

const source = readFileSync(new URL("./emailService.ts", import.meta.url), "utf8");
function renderer(name: string) {
  const ast = ts.createSourceFile("emailService.ts", source, ts.ScriptTarget.Latest, true);
  const fn = ast.statements.find(statement => ts.isFunctionDeclaration(statement) && statement.name?.text === name)!;
  return source.slice(fn.getStart(ast), fn.end) + "\n";
}
const correctedMetadata = (value: string) => value
  .replaceAll("Railway Vacancy snapshot", "PropertyMax Vacancy snapshot")
  .replaceAll("Railway Collections snapshot", "PropertyMax FLOW Collections snapshot")
  .replaceAll("prior Railway snapshot", "prior PropertyMax FLOW snapshot")
  .replaceAll("https://vacancyapp-42vudntx.manus.space", "https://vacancyreport.manus.space");

describe("unchanged current report templates and single-sender contract", () => {
  it.each([["buildDailyVacancyHtml", "vacancy"], ["buildCurrentCollectionsHtml", "collections"]])("%s function bytes match original apart from approved source metadata", (name, fixture) => {
    const baseline = readFileSync(new URL(`./__fixtures__/${fixture}-renderer-before.txt`, import.meta.url), "utf8");
    expect(renderer(name)).toBe(correctedMetadata(baseline));
  });
  it("reproduces September25 saved FLOW totals with the EXISTING builder, not a current-source verification", () => {
    const snapshot: CollectionsSnapshot = JSON.parse(readFileSync(new URL("./fixtures/collections-2026-09-25.json", import.meta.url), "utf8"));
    expect(snapshot.buildings).toHaveLength(41);
    expect(new Set(snapshot.buildings.map(row => `${row.regionId}:${row.buildingName.trim().toLocaleLowerCase()}`)).size).toBe(41);
    const now = new Date();
    expect(() => assertScheduledCollectionsSnapshot(snapshot, now, now, now)).not.toThrow();
    expect(snapshot.buildings.reduce((sum, row) => sum + row.rentBilled, 0)).toBeCloseTo(5572493.60, 2);
    expect(snapshot.buildings.reduce((sum, row) => sum + row.rentCollected, 0)).toBeCloseTo(5331592.68, 2);
    const html = buildCurrentCollectionsHtml(snapshot, []);
    expect(html).toContain("$5,572,493.60"); expect(html).toContain("$5,331,592.68"); expect(html).toContain("95.7%");
    expect(html).toContain("-$240,900.92");
    expect(html).toContain('href="https://vacancyreport.manus.space?tab=collections"');
    expect(html).not.toMatch(/Railway|railway|vacancyapp-42vudntx/);
  });
  it("rendered Vacancy retains live root and Collections link with no obsolete host/source references", () => {
    const html = buildDailyVacancyHtml({ stats: { totalVacant: 0, vacUnleased: 0, vacPreleased: 0, onNotice: 0, eviction: 0 },
      buildingVacancy: [], dailyChanges: [], vacantUnleased: [], vacantPreleased: [], onNotice: [], evictions: [], historicalMonths: [], lastUpdated: new Date("2026-11-04T21:00:00Z") });
    expect(html).toContain('href="https://vacancyreport.manus.space"');
    expect(html).toContain('href="https://vacancyreport.manus.space?tab=collections"');
    expect(html).not.toMatch(/Railway|railway|vacancyapp-42vudntx/);
  });
  it("retains the original daily callback and exact UTC cron alongside isolated weekly, eviction and monthly callbacks; no startup DB mutation", () => {
    const entry = readFileSync(new URL("./_core/index.ts", import.meta.url), "utf8");
    expect(entry.match(/app\.post\("\/api\/scheduled\//g)).toHaveLength(4);
    expect(entry).toContain('app.post("/api/scheduled/daily-vacancy", dailyVacancyScheduledHandler)');
    expect(entry).toContain('app.post("/api/scheduled/monthly-net-cash-flow", monthlyNetCashFlowScheduledHandler)');
    expect(entry).not.toMatch(/ensureDailyVacancyJob|activateDailyVacancyJob|confirmDailyReportsDelivery/);
    expect(DAILY_VACANCY_PLATFORM_CRON).toBe("0 0 17,18,20,21 * * *");
  });
  it("retains daily timer retirement while retiring weekly/eviction timers for isolated Heartbeats", () => {
    const scheduler = readFileSync(new URL("./emailScheduler.ts", import.meta.url), "utf8");
    expect(scheduler).toContain("LEGACY_DAILY_VACANCY_TIMER_RETIRED = true");
    expect(scheduler).toContain("LEGACY_DAILY_COLLECTIONS_TIMER_RETIRED = true");
    expect(scheduler).not.toMatch(/runDaily|dailyInterval|dailyTimer|sendDailyCollectionsEmail|sendDailyVacancyEmail/);
    expect(scheduler).toContain("LEGACY_WEEKLY_TIMER_RETIRED = true");
    expect(scheduler).toContain("LEGACY_EVICTION_TIMER_RETIRED = true");
    expect(scheduler).not.toMatch(/setTimeout|setInterval/);
    expect(LEGACY_COLLECTIONS_DISTRIBUTION_RETIRED).toBe(true);
  });
  it("current delivery has no Railway dependency and old local Collections scripts cannot send", () => {
    const managed = readFileSync(new URL("./dailyVacancyScheduled.ts", import.meta.url), "utf8");
    expect(source).not.toContain('from "./railwayReports"');
    expect(managed).not.toMatch(/fetchRailway|from "\.\/railwayReports"|getCollectionsSnapshot\(/);
    expect(managed).toContain("fetchAndSaveCollectionsSnapshot()");
    for (const name of ["send_current_flow_test3.mjs", "send_corrected_daily_collections_test.mjs"]) {
      const script = readFileSync(new URL(`../${name}`, import.meta.url), "utf8");
      expect(script).not.toMatch(/sendMail\(|await send|import /);
    }
    const preview = readFileSync(new URL("../render_railway_report_previews.mts", import.meta.url), "utf8");
    expect(preview).not.toMatch(/sendMail|sendDaily|nodemailer|createTransport/);
  });
  it("existing manual daily distribution endpoints fail closed with no recipient fallback or extra routes", () => {
    const routes = readFileSync(new URL("./routers.ts", import.meta.url), "utf8");
    expect(routes).not.toContain("await sendDailyVacancyEmail(");
    expect(routes).not.toContain("sendDailyCollectionsEmail");
    expect(routes.match(/Manual daily distribution retired/g)).toHaveLength(2);
  });
  it("non-destructive migration defaults historical rows to vacancy and maintains uniqueness throughout", () => {
    const migration = readFileSync(new URL("../drizzle/0010_late_white_queen.sql", import.meta.url), "utf8");
    expect(migration).toContain("DEFAULT 'vacancy' NOT NULL"); expect(migration).toContain("DEFAULT false NOT NULL");
    expect(migration).toContain("UNIQUE(`job_id`,`report_type`,`local_date`)");
    expect(migration.indexOf("ADD CONSTRAINT")).toBeLessThan(migration.indexOf("DROP INDEX"));
    expect(migration).not.toMatch(/DROP TABLE|DELETE FROM|TRUNCATE|UPDATE /i);
    const historical = [{ jobId: 1, localDate: "2026-11-03", state: "sent", messageId: "preserved-Nov3" }, { jobId: 1, localDate: "2026-11-04", state: "sent", messageId: "preserved-Nov4" }];
    const migrated = historical.map(row => ({ ...row, reportType: "vacancy" }));
    const keys = new Set(migrated.map(row => `${row.jobId}:${row.reportType}:${row.localDate}`));
    expect(keys.has("1:vacancy:2026-11-03")).toBe(true); expect(keys.has("1:vacancy:2026-11-04")).toBe(true);
    expect(keys.has("1:collections:2026-11-04")).toBe(false); expect(migrated.map(({ reportType, ...row }) => row)).toEqual(historical);
  });
});
