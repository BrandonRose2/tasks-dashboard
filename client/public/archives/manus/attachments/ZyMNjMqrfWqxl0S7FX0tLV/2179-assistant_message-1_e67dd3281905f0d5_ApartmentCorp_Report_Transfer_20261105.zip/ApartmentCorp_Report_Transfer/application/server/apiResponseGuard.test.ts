import { describe, expect, it } from "vitest";
import {
  API_NON_JSON_RESPONSE_MESSAGE,
  requireJsonApiResponse,
} from "../shared/apiResponseGuard";

function response(contentType: string | null, status = 200) {
  return {
    status,
    statusText: status === 200 ? "OK" : "Not Found",
    headers: { get: () => contentType },
  };
}

describe("requireJsonApiResponse", () => {
  it("accepts JSON API responses", () => {
    const apiResponse = response("application/json; charset=utf-8");
    expect(requireJsonApiResponse(apiResponse)).toBe(apiResponse);
  });

  it("converts an HTML SPA fallback into a controlled API error", () => {
    expect(() => requireJsonApiResponse(response("text/html; charset=utf-8", 200))).toThrow(
      API_NON_JSON_RESPONSE_MESSAGE,
    );
  });

  it("rejects missing content types from an API response", () => {
    expect(() => requireJsonApiResponse(response(null, 502))).toThrow("HTTP 502");
  });
});
