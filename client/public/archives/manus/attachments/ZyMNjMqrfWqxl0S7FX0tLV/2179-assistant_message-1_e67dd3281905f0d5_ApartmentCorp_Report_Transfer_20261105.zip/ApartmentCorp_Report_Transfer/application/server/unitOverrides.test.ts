import { describe, it, expect, vi, beforeEach } from "vitest";

// Mock the db module so we don't need a real DB connection
vi.mock("./db", () => ({
  getAllUnitOverrides: vi.fn().mockResolvedValue([
    { id: 1, buildingName: "Boca Ciega", totalUnits: 200, updatedAt: new Date() },
  ]),
  upsertUnitOverride: vi.fn().mockResolvedValue(undefined),
  deleteUnitOverride: vi.fn().mockResolvedValue(undefined),
  getAllRecipients: vi.fn().mockResolvedValue([]),
  addRecipient: vi.fn().mockResolvedValue(undefined),
  updateRecipient: vi.fn().mockResolvedValue(undefined),
  deleteRecipient: vi.fn().mockResolvedValue(undefined),
  getUnitOverridesMap: vi.fn().mockResolvedValue({ "Boca Ciega": 200 }),
}));

vi.mock("./scraper", () => ({
  fetchDashboardData: vi.fn().mockResolvedValue({ lastUpdated: new Date(), buildings: [] }),
  invalidateCache: vi.fn(),
  fetchAllRegionsMarcsNetCash: vi.fn().mockResolvedValue([]),
  getVacancyHistory: vi.fn().mockResolvedValue([]),
  getWeeklySummary: vi.fn().mockResolvedValue({ buildings: [] }),
  parseAndIngestRawData: vi.fn().mockResolvedValue({ lastUpdated: new Date() }),
  getCachedData: vi.fn().mockResolvedValue(null),
}));

vi.mock("./emailService", () => ({
  sendDailyVacancyEmail: vi.fn().mockResolvedValue(true),
  sendMonthlyNetCashEmail: vi.fn().mockResolvedValue(true),
  sendWeeklySummaryEmail: vi.fn().mockResolvedValue(true),
  buildDailyVacancyHtml: vi.fn().mockReturnValue("<html></html>"),
  buildWeeklySummaryHtml: vi.fn().mockReturnValue("<html></html>"),
}));

import { getAllUnitOverrides, upsertUnitOverride, deleteUnitOverride } from "./db";

describe("Unit Count Override DB helpers", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("getAllUnitOverrides returns list of overrides", async () => {
    const result = await getAllUnitOverrides();
    expect(result).toHaveLength(1);
    expect(result[0].buildingName).toBe("Boca Ciega");
    expect(result[0].totalUnits).toBe(200);
  });

  it("upsertUnitOverride is called with correct args", async () => {
    await upsertUnitOverride("Boca Ciega", 250);
    expect(upsertUnitOverride).toHaveBeenCalledWith("Boca Ciega", 250);
  });

  it("deleteUnitOverride is called with correct id", async () => {
    await deleteUnitOverride(1);
    expect(deleteUnitOverride).toHaveBeenCalledWith(1);
  });
});

describe("Unit Count Override tRPC procedures (via router)", () => {
  it("unitOverrides.list requires valid PIN", async () => {
    const { appRouter } = await import("./routers");
    const caller = appRouter.createCaller({} as any);
    await expect(caller.unitOverrides.list({ pin: "wrong" })).rejects.toThrow("Invalid PIN");
  });

  it("unitOverrides.list returns overrides with correct PIN", async () => {
    const { appRouter } = await import("./routers");
    const caller = appRouter.createCaller({} as any);
    const result = await caller.unitOverrides.list({ pin: "3060" });
    expect(Array.isArray(result)).toBe(true);
    expect(result[0].buildingName).toBe("Boca Ciega");
  });

  it("unitOverrides.upsert requires valid PIN", async () => {
    const { appRouter } = await import("./routers");
    const caller = appRouter.createCaller({} as any);
    await expect(
      caller.unitOverrides.upsert({ pin: "wrong", buildingName: "Test", totalUnits: 100 })
    ).rejects.toThrow("Invalid PIN");
  });

  it("unitOverrides.upsert calls upsertUnitOverride with correct args", async () => {
    const { appRouter } = await import("./routers");
    const caller = appRouter.createCaller({} as any);
    const result = await caller.unitOverrides.upsert({
      pin: "3060",
      buildingName: "Boca Ciega",
      totalUnits: 250,
    });
    expect(result.success).toBe(true);
    expect(upsertUnitOverride).toHaveBeenCalledWith("Boca Ciega", 250);
  });

  it("unitOverrides.delete requires valid PIN", async () => {
    const { appRouter } = await import("./routers");
    const caller = appRouter.createCaller({} as any);
    await expect(
      caller.unitOverrides.delete({ pin: "wrong", id: 1 })
    ).rejects.toThrow("Invalid PIN");
  });

  it("unitOverrides.delete calls deleteUnitOverride with correct id", async () => {
    const { appRouter } = await import("./routers");
    const caller = appRouter.createCaller({} as any);
    const result = await caller.unitOverrides.delete({ pin: "3060", id: 1 });
    expect(result.success).toBe(true);
    expect(deleteUnitOverride).toHaveBeenCalledWith(1);
  });
});
