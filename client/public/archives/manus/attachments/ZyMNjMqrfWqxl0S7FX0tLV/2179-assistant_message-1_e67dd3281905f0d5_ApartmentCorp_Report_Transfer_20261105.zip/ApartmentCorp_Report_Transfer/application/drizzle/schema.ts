import { boolean, int, json, mysqlEnum, mysqlTable, text, timestamp, uniqueIndex, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// Daily vacancy snapshots for tracking changes
export const vacancySnapshots = mysqlTable("vacancy_snapshots", {
  id: int("id").autoincrement().primaryKey(),
  snapshotDate: varchar("snapshotDate", { length: 10 }).notNull(), // YYYY-MM-DD
  buildingData: json("buildingData").notNull(), // JSON array of BuildingVacancy
  totalVacant: int("totalVacant").notNull().default(0),
  vacUnleased: int("vacUnleased").notNull().default(0),
  vacPreleased: int("vacPreleased").notNull().default(0),
  onNotice: int("onNotice").notNull().default(0),
  eviction: int("eviction").notNull().default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type VacancySnapshot = typeof vacancySnapshots.$inferSelect;
export type InsertVacancySnapshot = typeof vacancySnapshots.$inferInsert;

// Cached historical monthly data to avoid re-scraping
export const historicalCache = mysqlTable("historical_cache", {
  id: int("id").autoincrement().primaryKey(),
  monthKey: varchar("monthKey", { length: 7 }).notNull().unique(), // YYYY-MM
  data: json("data").notNull(), // JSON of HistoricalMonth
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type HistoricalCache = typeof historicalCache.$inferSelect;

// Email recipients with report type preferences
export const emailRecipients = mysqlTable("email_recipients", {
  id: int("id").autoincrement().primaryKey(),
  email: varchar("email", { length: 320 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  receiveDailyVacancy: int("receiveDailyVacancy").notNull().default(1), // 1 = yes, 0 = no
  receiveMonthlyNetCash: int("receiveMonthlyNetCash").notNull().default(0), // 1 = yes, 0 = no
  scheduleGroup: mysqlEnum("scheduleGroup", ["early", "admin"]).default("early").notNull(), // early = 9AM ET, admin = 1PM PST
  isActive: int("isActive").notNull().default(1), // 1 = active, 0 = paused
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type EmailRecipient = typeof emailRecipients.$inferSelect;
export type InsertEmailRecipient = typeof emailRecipients.$inferInsert;

// Per-building unit count overrides (admin-managed, takes priority over hardcoded values)
export const buildingUnitOverrides = mysqlTable("building_unit_overrides", {
  id: int("id").autoincrement().primaryKey(),
  buildingName: varchar("buildingName", { length: 255 }).notNull().unique(),
  totalUnits: int("totalUnits").notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type BuildingUnitOverride = typeof buildingUnitOverrides.$inferSelect;
export type InsertBuildingUnitOverride = typeof buildingUnitOverrides.$inferInsert;

// Daily payments snapshots: Net Rent Collected and Net Cash Flow per building
export const buildingPayments = mysqlTable("building_payments", {
  id: int("id").autoincrement().primaryKey(),
  snapshotDate: varchar("snapshotDate", { length: 10 }).notNull(), // YYYY-MM-DD
  buildingName: varchar("buildingName", { length: 255 }).notNull(),
  regionId: int("regionId").notNull(), // 1-4
  netRentCollected: varchar("netRentCollected", { length: 32 }).notNull().default("0"), // stored as string to preserve exact value
  netCashFlow: varchar("netCashFlow", { length: 32 }).notNull().default("0"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type BuildingPayment = typeof buildingPayments.$inferSelect;
export type InsertBuildingPayment = typeof buildingPayments.$inferInsert;

// Detailed collections data from the FLOW tab: Rent Billed, Rent Collected, Utility Reimbursement, Vouchers
export const buildingCollections = mysqlTable("building_collections", {
  id: int("id").autoincrement().primaryKey(),
  snapshotDate: varchar("snapshotDate", { length: 10 }).notNull(), // YYYY-MM-DD
  buildingName: varchar("buildingName", { length: 255 }).notNull(),
  regionId: int("regionId").notNull(), // 1-4
  rentBilled: varchar("rentBilled", { length: 32 }).notNull().default("0"),
  rentCollected: varchar("rentCollected", { length: 32 }).notNull().default("0"),
  utilityReimbursement: varchar("utilityReimbursement", { length: 32 }).notNull().default("0"),
  vouchersCount: int("vouchersCount").notNull().default(0),
  collectionPct: varchar("collectionPct", { length: 10 }).notNull().default("0"), // e.g. "91.4"
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type BuildingCollection = typeof buildingCollections.$inferSelect;
export type InsertBuildingCollection = typeof buildingCollections.$inferInsert;

// Delegated Microsoft Graph connection for the report sender. Refresh tokens are
// encrypted before storage; the plaintext token is never persisted.
export const microsoftMailConnections = mysqlTable("microsoft_mail_connections", {
  id: int("id").autoincrement().primaryKey(),
  accountEmail: varchar("accountEmail", { length: 320 }).notNull().unique(),
  refreshTokenCiphertext: text("refreshTokenCiphertext").notNull(),
  refreshTokenExpiresAt: timestamp("refreshTokenExpiresAt"),
  connectedAt: timestamp("connectedAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type MicrosoftMailConnection = typeof microsoftMailConnections.$inferSelect;
export type InsertMicrosoftMailConnection = typeof microsoftMailConnections.$inferInsert;

// Separate from Admin-tab recipients: only this business row owns the native job.
export const dailyVacancyJobs = mysqlTable("daily_vacancy_jobs", {
  id: int("id").autoincrement().primaryKey(),
  scheduleKey: varchar("schedule_key", { length: 64 }).notNull().unique(),
  scheduleCronTaskUid: varchar("schedule_cron_task_uid", { length: 65 }),
  enabled: boolean("enabled").notNull().default(false),
  collectionsApproved: boolean("collections_approved").notNull().default(false),
  timezone: varchar("timezone", { length: 64 }).notNull().default("America/Los_Angeles"),
  sendHour: int("send_hour").notNull().default(13),
  recipients: json("recipients").$type<string[]>().notNull(),
  activatedAt: timestamp("activated_at"),
  firstSendDate: varchar("first_send_date", { length: 10 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
}, table => [uniqueIndex("daily_vacancy_task_uid_unique").on(table.scheduleCronTaskUid)]);

export type DailyVacancyJob = typeof dailyVacancyJobs.$inferSelect;

export const dailyVacancySendLedger = mysqlTable("daily_vacancy_send_ledger", {
  id: int("id").autoincrement().primaryKey(),
  jobId: int("job_id").notNull().references(() => dailyVacancyJobs.id),
  reportType: mysqlEnum("report_type", ["vacancy", "collections", "collections_test"]).notNull().default("vacancy"),
  localDate: varchar("local_date", { length: 10 }).notNull(),
  state: mysqlEnum("state", ["preparing", "sending", "sent", "failed_before_send", "unknown"]).notNull(),
  attemptToken: varchar("attempt_token", { length: 36 }).notNull(),
  sourceUpdatedAt: timestamp("source_updated_at"),
  messageId: varchar("message_id", { length: 512 }),
  smtpReceipt: json("smtp_receipt").$type<{ messageId: string; accepted: string[]; rejected: string[]; response: string }>(),
  failureCode: varchar("failure_code", { length: 64 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
}, table => [uniqueIndex("daily_vacancy_job_report_date_unique").on(table.jobId, table.reportType, table.localDate)]);

export type DailyVacancyLedger = typeof dailyVacancySendLedger.$inferSelect;

// Standalone weekly/eviction Heartbeats; never share identity or ledgers with daily reports.
export const auxiliaryEmailJobs = mysqlTable("auxiliary_email_jobs", {
  id: int("id").autoincrement().primaryKey(),
  scheduleKey: varchar("schedule_key", { length: 64 }).notNull().unique(),
  reportType: mysqlEnum("report_type", ["weekly_vacancy", "eviction_reminders"]).notNull(),
  scheduleCronTaskUid: varchar("schedule_cron_task_uid", { length: 65 }),
  endpointPath: varchar("endpoint_path", { length: 128 }).notNull(),
  enabled: boolean("enabled").notNull().default(false),
  timezone: varchar("timezone", { length: 64 }).notNull().default("America/New_York"),
  sendHour: int("send_hour").notNull().default(9),
  activatedAt: timestamp("activated_at"),
  firstSendDate: varchar("first_send_date", { length: 10 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
}, table => [uniqueIndex("auxiliary_email_task_uid_unique").on(table.scheduleCronTaskUid)]);
export type AuxiliaryEmailJob = typeof auxiliaryEmailJobs.$inferSelect;

export type AuxiliaryEmailMessage = { from: string; replyTo: string; to: string; cc?: string; subject: string; html: string };
export const auxiliaryEmailRuns = mysqlTable("auxiliary_email_runs", {
  id: int("id").autoincrement().primaryKey(),
  jobId: int("job_id").notNull().references(() => auxiliaryEmailJobs.id),
  localDate: varchar("local_date", { length: 10 }).notNull(),
  state: mysqlEnum("state", ["preparing", "processing", "ready", "failed_before_send", "complete", "review"]).notNull(),
  attemptToken: varchar("attempt_token", { length: 36 }).notNull(),
  sourceUpdatedAt: timestamp("source_updated_at"),
  planCount: int("plan_count"),
  outcome: varchar("outcome", { length: 64 }),
  failureCode: varchar("failure_code", { length: 64 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
}, table => [uniqueIndex("auxiliary_email_job_date_unique").on(table.jobId, table.localDate)]);
export type AuxiliaryEmailRun = typeof auxiliaryEmailRuns.$inferSelect;

export const auxiliaryEmailDeliveries = mysqlTable("auxiliary_email_deliveries", {
  id: int("id").autoincrement().primaryKey(),
  runId: int("run_id").notNull().references(() => auxiliaryEmailRuns.id),
  deliveryKey: varchar("delivery_key", { length: 320 }).notNull(),
  message: json("message").$type<AuxiliaryEmailMessage>().notNull(),
  state: mysqlEnum("state", ["pending", "sending", "sent", "unknown"]).notNull().default("pending"),
  attemptToken: varchar("attempt_token", { length: 36 }),
  messageId: varchar("message_id", { length: 512 }),
  smtpReceipt: json("smtp_receipt").$type<{ messageId: string; accepted: string[]; rejected: string[]; response: string }>(),
  failureCode: varchar("failure_code", { length: 64 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
}, table => [uniqueIndex("auxiliary_email_run_delivery_unique").on(table.runId, table.deliveryKey)]);
export type AuxiliaryEmailDelivery = typeof auxiliaryEmailDeliveries.$inferSelect;

// Dedicated monthly net-cash-flow Heartbeat; identity, recipients and ledgers never share daily/auxiliary state.
export const monthlyEmailJobs = mysqlTable("monthly_email_jobs", {
  id: int("id").autoincrement().primaryKey(),
  scheduleKey: varchar("schedule_key", { length: 64 }).notNull().unique(),
  reportType: mysqlEnum("report_type", ["monthly_net_cash_flow"]).notNull(),
  scheduleCronTaskUid: varchar("schedule_cron_task_uid", { length: 65 }),
  endpointPath: varchar("endpoint_path", { length: 128 }).notNull(),
  enabled: boolean("enabled").notNull().default(false),
  timezone: varchar("timezone", { length: 64 }).notNull().default("America/Los_Angeles"),
  sendHour: int("send_hour").notNull().default(13),
  sendDay: int("send_day").notNull().default(12),
  recipientTo: json("recipient_to").$type<string[]>().notNull(),
  activatedAt: timestamp("activated_at", { fsp: 3 }), // UTC milliseconds; preserve just-after-slot no-backfill boundary.
  firstSendDate: varchar("first_send_date", { length: 10 }), // Pacific YYYY-MM-DD; no historical backfill.
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
}, table => [uniqueIndex("monthly_email_task_uid_unique").on(table.scheduleCronTaskUid)]);
export type MonthlyEmailJob = typeof monthlyEmailJobs.$inferSelect;
export type InsertMonthlyEmailJob = typeof monthlyEmailJobs.$inferInsert;

// Only these fields can be frozen/sent. No CC or BCC in the monthly message contract.
export type MonthlyEmailMessage = { from: string; replyTo: string; to: string; subject: string; html: string };
export type MonthlyEmailSmtpReceipt = { messageId: string; accepted: string[]; rejected: string[]; response: string };
export const monthlyEmailRuns = mysqlTable("monthly_email_runs", {
  id: int("id").autoincrement().primaryKey(),
  jobId: int("job_id").notNull().references(() => monthlyEmailJobs.id),
  periodKey: varchar("period_key", { length: 7 }).notNull(), // Reporting period YYYY-MM, NOT trigger/send date.
  state: mysqlEnum("state", ["preparing", "processing", "ready", "failed_before_send", "complete", "review"]).notNull(),
  attemptToken: varchar("attempt_token", { length: 36 }).notNull(),
  sourceUpdatedAt: timestamp("source_updated_at"),
  planCount: int("plan_count"),
  outcome: varchar("outcome", { length: 64 }),
  failureCode: varchar("failure_code", { length: 64 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
}, table => [uniqueIndex("monthly_email_job_period_unique").on(table.jobId, table.periodKey)]);
export type MonthlyEmailRun = typeof monthlyEmailRuns.$inferSelect;
export type InsertMonthlyEmailRun = typeof monthlyEmailRuns.$inferInsert;

export const monthlyEmailDeliveries = mysqlTable("monthly_email_deliveries", {
  id: int("id").autoincrement().primaryKey(),
  runId: int("run_id").notNull().references(() => monthlyEmailRuns.id),
  deliveryKey: varchar("delivery_key", { length: 320 }).notNull(),
  message: json("message").$type<MonthlyEmailMessage>().notNull(),
  state: mysqlEnum("state", ["pending", "sending", "sent", "unknown"]).notNull().default("pending"),
  attemptToken: varchar("attempt_token", { length: 36 }),
  messageId: varchar("message_id", { length: 512 }),
  smtpReceipt: json("smtp_receipt").$type<MonthlyEmailSmtpReceipt>(),
  failureCode: varchar("failure_code", { length: 64 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
}, table => [uniqueIndex("monthly_email_run_delivery_unique").on(table.runId, table.deliveryKey)]);
export type MonthlyEmailDelivery = typeof monthlyEmailDeliveries.$inferSelect;
export type InsertMonthlyEmailDelivery = typeof monthlyEmailDeliveries.$inferInsert;
