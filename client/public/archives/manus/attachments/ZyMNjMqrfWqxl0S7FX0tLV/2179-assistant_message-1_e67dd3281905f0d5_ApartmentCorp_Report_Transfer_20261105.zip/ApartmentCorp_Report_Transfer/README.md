# Vacancy Report — Transfer Handoff

Prepared November 5, 2026 · Source checkpoint `48233d76` · Existing React / Express / Drizzle application

Open **START_HERE.html** in a browser for the mobile-readable version of this guide. It is a self-contained document, not a deployed website: no scripts, external fonts, images, or tracking are required. Reading either guide does not change the application.

**Handoff only. The current application and four source jobs remain active.** This package does not deploy a new app, transfer account ownership, stop the original senders, or activate destination jobs. It is not a one-click deployment bundle. A future live cutover requires a separate, approved action.

## Verified export

The package includes **226 application files**, **17 database tables with 8,500 rows**, nine configured application credential values and seven source-account recovery dependencies inside the encrypted archive, and one backed-up public logo. The packaged application passed **795 tests** with seven live-gated tests skipped, plus TypeScript and production build checks. The original application source files are byte-identical; seven root support files preserve parser tests and retired no-send guards.

## Package map

Keep the package together and use `manifest.json` as the authoritative inventory, including any supplied hashes and export notes. This guide describes the intended layout; it does not independently certify every file or credential export.

- **`application/`** — Application source from checkpoint `48233d76`, preserved byte-for-byte. Known credential values were checked and not found in source files. Supply the corresponding destination environment variables; do not put secrets back into source code.
- **`configuration/report-configuration.json`** — Exported report settings and actual recipient addresses. This is the reference for recipients; do not guess addresses from names in this guide.
- **`configuration/source-heartbeats-reference.json`** — Source external-job reference information. Its unique IDs, or UIDs, identify source-owned jobs only.
- **`configuration/destination-heartbeats-disabled.json`** — Disabled destination templates. Destination-owned jobs must be created and bound to new UIDs before activation.
- **`configuration/credential-inventory.json`** — Credential names, export status, and classification only. It contains no password or token values. Review missing, unavailable, expired, and source account-bound dependencies.
- **`PRIVATE_DATA_AND_CREDENTIALS.zip`** — AES-256-encrypted credentials and confidential full database snapshot. The unlock key is delivered separately.
- **`tools/unlock_private.py`** — Optional Python decryption helper for a technician, not a deployment or migration tool.
- **`manifest.json`** — Package inventory and recorded export details.

Review the package’s asset inventory as well. The public logo is backed up at `assets/asset_1.png`. Do not assume unavailable private assets have been backed up. Stable preview assets were tested in the original environment; destination access and rendering still require validation.

### Inside the encrypted private archive

**`credentials/application-secrets.json`** and **`credentials/transfer.env`** contain exported user-configured credential values, with source account-bound dependencies identified. Possessing a credential does not prove transfer rights or guarantee that it will remain valid.

**`credentials/source-account-dependencies.json`** identifies dependencies tied to the original account or platform. Do not plug these credentials into another account. Generate destination platform credentials and authorize integrations under the proper owner. The source JWT secret is retained privately to recover legacy encrypted refresh-token records; do not use source database credentials or old app identity as the recipient runtime. Platform-managed Forge API keys and transient browser cookies are not exported as portable authorization.

**`database/tables/*.json`** contains the exact read-only, point-in-time table snapshot. **`database/schema.sql`** contains the exported schema. This full snapshot includes confidential active-job rows and historical sending ledgers; it is not a pre-sanitized live destination import.

**`database/snapshot-metadata.json`** and **`database/table-manifest.json`** record snapshot timing and table inventory for reconciliation. **`database/schedule-rows-disabled-for-destination.json`** supplies disabled migration seeds; use a reviewed migration instead of importing source active flags and old UIDs directly into a recipient account.

## Open the private archive using a GUI

1. **Save a private working copy.** Use a company-approved device and restricted folder. Retain the original archive unchanged. Do not upload the archive or decrypted database to public links, shared repositories, public web folders, or online ZIP-unlock services.
2. **Receive the unlock key separately.** Use the separately agreed secure channel. Do not store the key beside the ZIP or forward both in the same message. Keep it out of screenshots, support tickets, and logs.
3. **Open the ZIP in a trusted AES-capable archive app.** For example, use 7-Zip on Windows, choose Extract in its interface, and enter the separate key when prompted. A default operating-system extractor may not support AES-encrypted ZIP files. An unsupported-format message alone does not mean the archive is damaged.
4. **Protect extracted files.** Extract to a private folder accessible only to authorized people. Enter necessary values through the destination’s secret-settings interface or an approved secrets manager. Never publish `transfer.env`, database files, or any private archive contents as application assets.

No password or token values are displayed in these guides. A technician can review the optional Python helper’s instructions and dependencies if needed; no terminal instructions are required for the GUI route.

## Prepare a separate destination

Source-code portability is not automatic migration of database rows, hosted services, logins, assets, domains, or external scheduler bindings. The new owner needs a separately owned project or hosting environment and technical validation.

### Confirm authority and admin identity

Confirm permission to transfer the application, confidential records, and each third-party integration. Establish and test the new owner’s administrator identity. Do not assume the source owner’s login or imported user roles make the recipient an administrator. Verify unauthorized users cannot access sensitive data.

### Create destination infrastructure

Have a technician use the destination platform’s supported interface to configure the React frontend, Express backend, database, and authentication. Create the destination’s own database connection, platform keys, storage access, and scheduler ownership. Follow the application’s source documentation and dependency files for build/runtime requirements; this package does not promise an automatic setup flow.

### Configure secrets correctly

Review both credential inventories. Regenerate platform and account-bound credentials in the destination. Reauthorize third-party services. Reuse an exported user-configured credential only when the owner permits it and it remains valid. Keep secrets in destination settings, not source control or browser-visible code.

### Import with destination sending blocked

Review the schema, restore business data, preserve historical sending ledgers, and reconcile table counts and relationships against the private table manifest. Use disabled destination schedule seeds. Do not import source active-job flags or old UIDs as live destination bindings.

Keep every destination job disabled and block outbound production email, including manual sends, during validation. Importing schedule rows alone does not recreate external jobs.

### Replace URLs and validate assets

Update the **public dashboard URL and environment-specific asset URLs**. Verify logo, branding, images, report links, exports/downloads, and access permissions. Original preview tests do not establish that assets will work in the recipient’s environment. Resolve missing or inaccessible items in the asset inventory before sign-off; unavailable private assets are not guaranteed to be included.

## Five email report types, four external jobs

Vacancy and Collections share one daily, external, project-owned job. The weekly, evictions, and monthly report types each have their own external job. Recreate four destination-owned jobs with new UIDs; the source job export is reference only.

**Current Gmail identity:** From `apartmentcorp44@gmail.com`; Reply-To Ethan. The destination must be authorized to use the approved sender, or use an explicitly approved replacement. Ethan’s actual address and all recipient addresses come from `configuration/report-configuration.json`.

### Daily shared job

- Vacancy: every day at **10:00 AM**, `America/Los_Angeles`.
- Collections: every day at **1:00 PM**, `America/Los_Angeles`.

Both use the same source daily job. Preserve both report times in the destination implementation. Daily To: Ethan and `mam@22.bz`.

### Weekly job

Saturday at **9:00 AM**, `America/New_York`. Preserve Ethan, `mam@22.bz`, Myles, and Todd as configured. Use the actual exported addresses, not guessed substitutes.

### Evictions job

The **1st and 15th** of each month at **9:00 AM**, `America/New_York`. Manager in To; configured regional contact, Ethan, and Marc in CC. Preserve the exported manager/regional routing, not a single replacement list for every manager.

### Monthly job

The **12th** of each month at **1:00 PM**, `America/Los_Angeles`. Report the **previous completed calendar month**, not the current partial month. To: Ethan and Marc at `mam@22.bz`.

Use named time zones, including daylight-saving behavior, rather than fixed UTC offsets. Compare exact exported settings and recipient routing with the owner before activation.

**Destination jobs start disabled.** Create four destination-owned external jobs, verify their scheduling semantics, and bind their newly created UIDs using the disabled destination configuration. Old UIDs and exported active flags are not permission to send.

## Controlled cutover — a later, separately approved action

This database export is a **point-in-time snapshot, not the final cutover state**. New data, changes, and report sends can occur after capture while the source remains active. The snapshot does not keep syncing.

1. **Validate in isolation.** Leave source production unchanged. Keep destination jobs and production outbound email disabled. Test previews and calculations without sending. If email testing is approved, use a controlled test mailbox with explicit recipient overrides; do not trigger production report lists.
2. **Agree on a cutover window.** Record the authorizer, final source reporting period, pending sends, and rollback owner. Arrange a short source-write freeze or reviewed reconciliation so the final snapshot stays consistent through activation.
3. **Stop all old sending paths first.** During the approved window, disable the four source external jobs and manual or alternate production-send paths. Confirm in-flight sends have finished or have been explicitly reconciled. A database inactive flag alone is not evidence that an external sender has stopped.
4. **Capture and reconcile a final fresh snapshot.** After source senders are stopped and in-flight work is resolved, take a fresh database/configuration snapshot. Reconcile changes since this package. Preserve historical ledgers and report-period identifiers. **Do not reset `sent`, `sending`, or `unknown` states to force resends.** Investigate uncertain outcomes before any retry.
5. **Enable only after explicit sign-off.** Verify new UIDs, job ownership, time zones, recipients, sender authorization, URLs, and duplicate-send protections. Enable destination jobs only after old senders are confirmed stopped. Monitor and reconcile the first production cycle.

**Never run both production senders at once.** If rollback is necessary, stop destination sending first and reconcile its delivery history before re-enabling source senders. Do not automatically replay already sent or uncertain report periods.

None of these cutover actions is performed by creating or opening this package.

## Owner and technician sign-off checklist

This checklist is for review, not a claim that transfer or deployment has occurred.

- [ ] Package contents and any supplied hashes match the manifest; export limitations and snapshot time are understood.
- [ ] The new owner can sign in as the correct administrator; unauthorized access is denied.
- [ ] Secrets are private; source-bound platform credentials have been replaced or reauthorized appropriately.
- [ ] Business data, table counts, relationships, and historical sending ledgers reconcile.
- [ ] Source active-job flags and old UIDs were not imported as live destination bindings.
- [ ] Public dashboard URL, asset URLs, logos, permissions, previews, and exports/downloads work in the destination.
- [ ] All five report types match approved routing, time zones, recipients, and reporting periods; controlled tests did not send to production lists.
- [ ] Four destination-owned external jobs have new UIDs and remain disabled until the approved cutover.
- [ ] Before activation, old senders are stopped, a final fresh snapshot is reconciled, uncertain send states are resolved, and rollback responsibility is documented.
- [ ] After verified handoff, reusable credentials are rotated as appropriate and temporary decrypted copies are removed according to company retention policy.

## Technician appendix — no copy-paste shell commands

This is a full-stack React/Express/Drizzle app, not a static-site deployment. Review exported source documentation and dependency files to choose supported build, runtime, and database-import procedures. There is no promise of a universal importer or one-click deployment script.

Review `tools/unlock_private.py` before using it. It is an optional decryption route only. Keep the separate key out of logs and recorded command arguments.

Treat `database/schema.sql` as the exported schema and `database/tables/*.json` as the exact source snapshot. Adapt the migration to the destination database, verifying IDs, data types, relationships, timestamps, and report ledger semantics. Preserve the untouched snapshot for audit and apply disabled schedule seeds separately.

External jobs and database schedule rows are separate. Document the source-to-destination UID mapping privately, confirm the shared daily job handles both report times, and ensure only one sender can claim each report period. Preserve source history rather than clearing it to simplify migration.

## Official guidance and its limits

Manus **Code Control** describes source-code download and portability.[1] Code export alone does not recreate this app’s hosted services, external jobs, or confidential database state.

**Make a Copy** currently applies to a user’s own projects. It copies code, schema, and secrets, but **not database rows**; copies start unpublished.[2] It is not a complete cross-account transfer workflow.

Official **How to Restore Your Data** guidance requires the backup to match the proper original account.[3] It is not an import route into an unrelated owner’s account. This custom handoff package is not an official Manus restoration package.

Sources reviewed November 5, 2026. These documents do not claim that account ownership, domain ownership, deployment, or scheduler ownership has changed.

## References

[1]: https://manus.im/docs/website-builder/code-control "Manus Code Control"
[2]: https://manus.im/docs/website-builder/make-a-copy "Manus Make a Copy"
[3]: https://help.manus.im/en/articles/16147895-service-change-overview-how-to-restore-your-data "Manus How to Restore Your Data"
