CREATE TABLE `auxiliary_email_deliveries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`run_id` int NOT NULL,
	`delivery_key` varchar(320) NOT NULL,
	`message` json NOT NULL,
	`state` enum('pending','sending','sent','unknown') NOT NULL DEFAULT 'pending',
	`attempt_token` varchar(36),
	`message_id` varchar(512),
	`smtp_receipt` json,
	`failure_code` varchar(64),
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `auxiliary_email_deliveries_id` PRIMARY KEY(`id`),
	CONSTRAINT `auxiliary_email_run_delivery_unique` UNIQUE(`run_id`,`delivery_key`)
);
--> statement-breakpoint
CREATE TABLE `auxiliary_email_jobs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`schedule_key` varchar(64) NOT NULL,
	`report_type` enum('weekly_vacancy','eviction_reminders') NOT NULL,
	`schedule_cron_task_uid` varchar(65),
	`endpoint_path` varchar(128) NOT NULL,
	`enabled` boolean NOT NULL DEFAULT false,
	`timezone` varchar(64) NOT NULL DEFAULT 'America/New_York',
	`send_hour` int NOT NULL DEFAULT 9,
	`activated_at` timestamp,
	`first_send_date` varchar(10),
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `auxiliary_email_jobs_id` PRIMARY KEY(`id`),
	CONSTRAINT `auxiliary_email_jobs_schedule_key_unique` UNIQUE(`schedule_key`),
	CONSTRAINT `auxiliary_email_task_uid_unique` UNIQUE(`schedule_cron_task_uid`)
);
--> statement-breakpoint
CREATE TABLE `auxiliary_email_runs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`job_id` int NOT NULL,
	`local_date` varchar(10) NOT NULL,
	`state` enum('preparing','processing','ready','failed_before_send','complete','review') NOT NULL,
	`attempt_token` varchar(36) NOT NULL,
	`source_updated_at` timestamp,
	`plan_count` int,
	`outcome` varchar(64),
	`failure_code` varchar(64),
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `auxiliary_email_runs_id` PRIMARY KEY(`id`),
	CONSTRAINT `auxiliary_email_job_date_unique` UNIQUE(`job_id`,`local_date`)
);
--> statement-breakpoint
ALTER TABLE `auxiliary_email_deliveries` ADD CONSTRAINT `auxiliary_email_deliveries_run_id_auxiliary_email_runs_id_fk` FOREIGN KEY (`run_id`) REFERENCES `auxiliary_email_runs`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `auxiliary_email_runs` ADD CONSTRAINT `auxiliary_email_runs_job_id_auxiliary_email_jobs_id_fk` FOREIGN KEY (`job_id`) REFERENCES `auxiliary_email_jobs`(`id`) ON DELETE no action ON UPDATE no action;