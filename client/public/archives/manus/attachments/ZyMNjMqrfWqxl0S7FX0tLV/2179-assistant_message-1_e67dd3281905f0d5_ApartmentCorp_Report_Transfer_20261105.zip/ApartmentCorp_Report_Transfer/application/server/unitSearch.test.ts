import { describe, expect, it } from "vitest";
import { matchesUnitSearch } from "../client/src/lib/unitSearch";

describe("matchesUnitSearch", () => {
  const sample = {
    building: "Arbor Crest",
    unit: "2211",
    dateBy: "8/14/2026 Erica",
    dates: "8/14/2026",
    leased: "Y",
  };

  it("matches a building, unit, manager, status, or date without regard to case", () => {
    expect(matchesUnitSearch(sample, "arbor")).toBe(true);
    expect(matchesUnitSearch(sample, "2211")).toBe(true);
    expect(matchesUnitSearch(sample, "ERICA")).toBe(true);
    expect(matchesUnitSearch(sample, "y")).toBe(true);
    expect(matchesUnitSearch(sample, "8/14")).toBe(true);
  });

  it("keeps all units for an empty search and excludes non-matches", () => {
    expect(matchesUnitSearch(sample, "  ")).toBe(true);
    expect(matchesUnitSearch(sample, "River Pointe")).toBe(false);
  });
});
