export const API_NON_JSON_RESPONSE_MESSAGE =
  "The dashboard API is temporarily unavailable. Please retry in a moment.";

/**
 * Prevent an SPA fallback document from being parsed as a tRPC JSON payload.
 * Vite may briefly serve index.html for an API request during an HMR/server
 * transition; callers receive a controlled error instead of a JSON parse error.
 */
export function requireJsonApiResponse<T extends {
  headers: { get(name: string): string | null };
  status: number;
  statusText?: string;
}>(response: T): T {
  const contentType = response.headers.get("content-type")?.toLowerCase() ?? "";
  if (contentType.includes("application/json")) {
    return response;
  }

  const status = response.status ? ` (HTTP ${response.status})` : "";
  throw new Error(`${API_NON_JSON_RESPONSE_MESSAGE}${status}`);
}
