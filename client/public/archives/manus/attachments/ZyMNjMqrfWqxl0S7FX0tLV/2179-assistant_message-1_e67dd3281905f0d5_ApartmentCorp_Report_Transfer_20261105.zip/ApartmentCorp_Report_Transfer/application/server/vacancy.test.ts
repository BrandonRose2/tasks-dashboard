import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// ─── Mock the scraper module ──────────────────────────────────────────────────

vi.mock("./scraper", () => ({
  fetchDashboardData: vi.fn(),
  getCachedData: vi.fn(),
  getLastCompleteDashboardData: vi.fn(),
  invalidateCache: vi.fn(),
}));

import * as scraper from "./scraper";

// ─── Helpers ──────────────────────────────────────────────────────────────────

function createCtx(): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

const mockDashboardData = {
  stats: {
    totalVacant: 131,
    vacUnleased: 72,
    vacPreleased: 59,
    onNotice: 43,
    eviction: 11,
  },
  vacantUnleased: [
    {
      dateBy: "10/16/2025 Erica",
      building: "Arbor Crest",
      unit: "1304",
      moveOut: "11/19/2025",
      alertDays: "Ops Call Mgr",
      days: 118,
      beds: 3,
      askRent: 1260.0,
      percentReady: 80,
    },
  ],
  vacantPreleased: [
    {
      dateBy: "11/17/2025 Erica",
      building: "Arbor Crest",
      unit: "1107",
      moveOut: "1/7/2026",
      alertDays: "Ops Call Mgr",
      days: 69,
      moveIn: "3/26/2026",
      beds: 3,
      askRent: 1272.0,
      percentReady: 60,
    },
  ],
  onNotice: [
    {
      building: "Boca Ciega",
      unit: "40",
      leased: "N",
    },
  ],
  evictions: [
    {
      building: "Arbor Crest",
      unit: "1318",
      dates: "Served 3/3/2026",
      amountOwed: 2805,
    },
  ],
  marcsNetCash: [
    {
      region: 1,
      regionName: "Region 1",
      total: 214822.99,
      buildings: [
        { name: "Boca Ciega", value: 31936.35 },
        { name: "Jefferson", value: 7111.08 },
      ],
    },
    {
      region: 2,
      regionName: "Region 2",
      total: 109213.62,
      buildings: [{ name: "Grace Townhomes", value: 23365.84 }],
    },
    {
      region: 3,
      regionName: "Region 3",
      total: 170981.3,
      buildings: [{ name: "Gates", value: 15778.48 }],
    },
    {
      region: 4,
      regionName: "Region 4",
      total: 472576.22,
      buildings: [{ name: "Wilmington", value: 53264.59 }],
    },
  ],
  historicalMonths: [
    {
      year: 2026,
      month: 2,
      monthName: "February",
      label: "February 2026",
      regions: [
        { region: 1, regionName: "Region 1", total: 127963.16, buildings: [] },
        { region: 2, regionName: "Region 2", total: 91523.46, buildings: [] },
        { region: 3, regionName: "Region 3", total: 151378.2, buildings: [] },
        { region: 4, regionName: "Region 4", total: 264563.84, buildings: [] },
      ],
      grandTotal: 635428.66,
    },
  ],
  lastUpdated: new Date("2026-03-17T22:10:24.764Z"),
};

// ─── Tests ────────────────────────────────────────────────────────────────────

describe("vacancy.getDashboard", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("returns dashboard data from the scraper", async () => {
    vi.mocked(scraper.fetchDashboardData).mockResolvedValue(mockDashboardData);

    const ctx = createCtx();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.vacancy.getDashboard({ forceRefresh: false });

    expect(result.stats.totalVacant).toBe(131);
    expect(result.stats.vacUnleased).toBe(72);
    expect(result.stats.vacPreleased).toBe(59);
    expect(result.stats.onNotice).toBe(43);
    expect(result.stats.eviction).toBe(11);
  });

  it("returns unit tables with correct data", async () => {
    vi.mocked(scraper.fetchDashboardData).mockResolvedValue(mockDashboardData);

    const ctx = createCtx();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.vacancy.getDashboard({ forceRefresh: false });

    expect(result.vacantUnleased).toHaveLength(1);
    expect(result.vacantUnleased[0]?.building).toBe("Arbor Crest");
    expect(result.vacantUnleased[0]?.unit).toBe("1304");
    expect(result.vacantUnleased[0]?.days).toBe(118);
    expect(result.vacantUnleased[0]?.askRent).toBe(1260.0);

    expect(result.vacantPreleased).toHaveLength(1);
    expect(result.vacantPreleased[0]?.moveIn).toBe("3/26/2026");

    expect(result.onNotice).toHaveLength(1);
    expect(result.onNotice[0]?.building).toBe("Boca Ciega");

    expect(result.evictions).toHaveLength(1);
    expect(result.evictions[0]?.amountOwed).toBe(2805);
  });

  it("returns Marc's Net Cash for all 4 regions", async () => {
    vi.mocked(scraper.fetchDashboardData).mockResolvedValue(mockDashboardData);

    const ctx = createCtx();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.vacancy.getDashboard({ forceRefresh: false });

    expect(result.marcsNetCash).toHaveLength(4);
    expect(result.marcsNetCash[0]?.region).toBe(1);
    expect(result.marcsNetCash[0]?.total).toBe(214822.99);
    expect(result.marcsNetCash[3]?.region).toBe(4);
    expect(result.marcsNetCash[3]?.total).toBe(472576.22);
  });

  it("returns historical months with only complete months", async () => {
    vi.mocked(scraper.fetchDashboardData).mockResolvedValue(mockDashboardData);

    const ctx = createCtx();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.vacancy.getDashboard({ forceRefresh: false });

    expect(result.historicalMonths).toHaveLength(1);
    expect(result.historicalMonths[0]?.label).toBe("February 2026");
    expect(result.historicalMonths[0]?.grandTotal).toBe(635428.66);
    expect(result.historicalMonths[0]?.regions).toHaveLength(4);
  });

  it("calls fetchDashboardData with forceRefresh=true when requested", async () => {
    vi.mocked(scraper.fetchDashboardData).mockResolvedValue(mockDashboardData);

    const ctx = createCtx();
    const caller = appRouter.createCaller(ctx);
    await caller.vacancy.getDashboard({ forceRefresh: true });

    expect(scraper.fetchDashboardData).toHaveBeenCalledWith(true);
  });

  it("returns the last complete snapshot with a stale status when a live refresh fails", async () => {
    vi.mocked(scraper.fetchDashboardData).mockRejectedValue(new Error("PropertyMax SESSION.mybuildings initialization failed"));
    vi.mocked(scraper.getLastCompleteDashboardData).mockReturnValue(mockDashboardData);

    const ctx = createCtx();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.vacancy.getDashboard({ forceRefresh: false });

    expect(result.stats.totalVacant).toBe(131);
    expect(result.sourceStatus?.state).toBe("stale");
    expect(result.sourceStatus?.message).toContain("last complete snapshot");
  });

  it("returns a controlled unavailable state when no complete snapshot exists", async () => {
    vi.mocked(scraper.fetchDashboardData).mockRejectedValue(new Error("PropertyMax SESSION.mybuildings initialization failed"));
    vi.mocked(scraper.getLastCompleteDashboardData).mockReturnValue(null);

    const ctx = createCtx();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.vacancy.getDashboard({ forceRefresh: false });

    expect(result.stats.totalVacant).toBe(0);
    expect(result.sourceStatus?.state).toBe("unavailable");
  });
});

describe("vacancy data structure validation", () => {
  it("verifies isCompleteMonth logic: past months are complete", () => {
    // March 2026 is the current month — not complete
    // February 2026 is last month — complete
    const now = new Date();
    const currentYear = now.getFullYear();
    const currentMonth = now.getMonth() + 1;

    // A month is complete if it's strictly before the current month
    const isComplete = (year: number, month: number) => {
      if (year < currentYear) return true;
      if (year === currentYear && month < currentMonth) return true;
      return false;
    };

    // Current month should NOT be complete
    expect(isComplete(currentYear, currentMonth)).toBe(false);

    // Previous month should be complete
    const prevMonth = currentMonth === 1 ? 12 : currentMonth - 1;
    const prevYear = currentMonth === 1 ? currentYear - 1 : currentYear;
    expect(isComplete(prevYear, prevMonth)).toBe(true);

    // Last year should be complete
    expect(isComplete(currentYear - 1, 12)).toBe(true);
  });

  it("verifies Marc's Net Cash building mapping", () => {
    const buildingNames = ["Boca Ciega", "Jefferson", "Macedonia"];
    const strongValues = [31936.35, 7111.08, 34652.72];

    const buildings = buildingNames.map((name, i) => ({
      name,
      value: strongValues[i] ?? 0,
    }));

    expect(buildings[0]).toEqual({ name: "Boca Ciega", value: 31936.35 });
    expect(buildings[1]).toEqual({ name: "Jefferson", value: 7111.08 });
    expect(buildings[2]).toEqual({ name: "Macedonia", value: 34652.72 });
  });

  it("verifies grand total calculation across regions", () => {
    const regions = [
      { total: 127963.16 },
      { total: 91523.46 },
      { total: 151378.2 },
      { total: 264563.84 },
    ];
    const grandTotal = regions.reduce((sum, r) => sum + r.total, 0);
    expect(grandTotal).toBeCloseTo(635428.66, 1);
  });
});
