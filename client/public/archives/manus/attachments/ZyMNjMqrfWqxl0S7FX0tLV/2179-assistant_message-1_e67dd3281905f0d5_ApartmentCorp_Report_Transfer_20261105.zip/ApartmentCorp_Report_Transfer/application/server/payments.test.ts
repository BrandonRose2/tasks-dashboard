import { describe, it, expect, vi, beforeEach } from "vitest";

// ─── Unit tests for payments email section builder ────────────────────────────

// We test the pure logic functions by importing them via a dynamic import trick
// since they are not exported directly. Instead we test the logic inline.

describe("Payments comparison logic", () => {
  it("computes rentChangePct correctly for a positive change", () => {
    const prevRent = 100_000;
    const todayRent = 110_000;
    const rentChangePct = ((todayRent - prevRent) / Math.abs(prevRent)) * 100;
    expect(Math.round(rentChangePct * 10) / 10).toBe(10);
  });

  it("computes rentChangePct correctly for a negative change", () => {
    const prevRent = 100_000;
    const todayRent = 90_000;
    const rentChangePct = ((todayRent - prevRent) / Math.abs(prevRent)) * 100;
    expect(Math.round(rentChangePct * 10) / 10).toBe(-10);
  });

  it("returns 0 for rentChangePct when prevRent is 0", () => {
    const prevRent = 0;
    const todayRent = 50_000;
    const rentChangePct = prevRent !== 0 ? ((todayRent - prevRent) / Math.abs(prevRent)) * 100 : 0;
    expect(rentChangePct).toBe(0);
  });

  it("flags buildings with >5% rent change", () => {
    const rentChangePct = 6.2;
    expect(Math.abs(rentChangePct) >= 5).toBe(true);
  });

  it("flags buildings with <-5% rent change", () => {
    const rentChangePct = -7.1;
    expect(Math.abs(rentChangePct) >= 5).toBe(true);
  });

  it("does NOT flag buildings with <=5% change", () => {
    const rentChangePct = 4.9;
    expect(Math.abs(rentChangePct) >= 5).toBe(false);
  });

  it("does NOT flag buildings with exactly 5% change", () => {
    // Boundary: exactly 5% should NOT be flagged (>= 5 means 5.0 IS flagged)
    const rentChangePct = 5.0;
    expect(Math.abs(rentChangePct) >= 5).toBe(true);
  });

  it("computes portfolio totals correctly", () => {
    const comparison = [
      { todayRent: 50_000, todayCash: 40_000, prevRent: 45_000, prevCash: 38_000 },
      { todayRent: 30_000, todayCash: 25_000, prevRent: 28_000, prevCash: 24_000 },
    ];
    const totalRent = comparison.reduce((s, r) => s + r.todayRent, 0);
    const totalCash = comparison.reduce((s, r) => s + r.todayCash, 0);
    expect(totalRent).toBe(80_000);
    expect(totalCash).toBe(65_000);
  });

  it("groups buildings by regionId correctly", () => {
    const rows = [
      { buildingName: "A", regionId: 1 },
      { buildingName: "B", regionId: 1 },
      { buildingName: "C", regionId: 2 },
      { buildingName: "D", regionId: 3 },
    ];
    const byRegion = [1, 2, 3, 4]
      .map(rid => ({ rid, rows: rows.filter(r => r.regionId === rid) }))
      .filter(g => g.rows.length > 0);

    expect(byRegion.length).toBe(3);
    expect(byRegion[0].rows.length).toBe(2);
    expect(byRegion[1].rows.length).toBe(1);
    expect(byRegion[2].rows.length).toBe(1);
  });

  it("identifies flagged rows correctly from a mixed list", () => {
    const comparison = [
      { rentFlagged: true, cashFlagged: false },
      { rentFlagged: false, cashFlagged: true },
      { rentFlagged: false, cashFlagged: false },
      { rentFlagged: true, cashFlagged: true },
    ];
    const flaggedCount = comparison.filter(r => r.rentFlagged || r.cashFlagged).length;
    expect(flaggedCount).toBe(3);
  });
});

describe("parsePaymentsHtml parser logic", () => {
  // Test the building name extraction logic (filtering rules)
  function filterBuildingName(text: string): boolean {
    if (!text) return false;
    if (/\d{4}/.test(text)) return false; // skip year-containing headers
    if (text.length > 40) return false; // skip long text
    return true;
  }

  it("keeps valid building names", () => {
    expect(filterBuildingName("Boca Ciega")).toBe(true);
    expect(filterBuildingName("Macedonia")).toBe(true);
    expect(filterBuildingName("Windsor/Yorkshire")).toBe(true);
  });

  it("filters out year-containing headers like month columns", () => {
    expect(filterBuildingName("Mar 2026")).toBe(false);
    expect(filterBuildingName("Apr 2025")).toBe(false);
  });

  it("filters out empty strings", () => {
    expect(filterBuildingName("")).toBe(false);
  });

  it("filters out long text strings (not building names)", () => {
    const longText = "This is a very long header that is definitely not a building name at all";
    expect(filterBuildingName(longText)).toBe(false);
  });

  // Test the value extraction logic
  function extractLastStrongNumber(tdHtml: string): number | null {
    // Simulate extractTdStrongValues: find last <strong> in a td and parse it
    const matches = [...tdHtml.matchAll(/<strong[^>]*>([^<]+)<\/strong>/gi)];
    if (!matches.length) return null;
    const lastMatch = matches[matches.length - 1];
    const text = lastMatch[1].trim().replace(/,/g, "").replace(/\s/g, "");
    const num = parseFloat(text);
    return isNaN(num) ? null : num;
  }

  it("extracts the last strong value from a value td", () => {
    const td = `<td align="right">194,111.00<br/>-3,052.00<br/><strong> 191,059.00 </strong></td>`;
    expect(extractLastStrongNumber(td)).toBe(191059);
  });

  it("returns null for a label td (no numeric strong)", () => {
    const td = `<td colspan="2"><strong>Net Rent Collected</strong></td>`;
    expect(extractLastStrongNumber(td)).toBeNull();
  });

  it("handles negative values in strong tags", () => {
    const td = `<td align="right"><strong>-2,263.16</strong></td>`;
    expect(extractLastStrongNumber(td)).toBe(-2263.16);
  });

  it("handles zero values in strong tags", () => {
    const td = `<td align="right"><strong>0.00</strong></td>`;
    expect(extractLastStrongNumber(td)).toBe(0);
  });
});

describe("fmtCurrencyShort helper", () => {
  function fmtCurrencyShort(val: number): string {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(val);
  }

  it("formats positive values correctly", () => {
    expect(fmtCurrencyShort(100_000)).toBe("$100,000");
  });

  it("formats negative values correctly", () => {
    expect(fmtCurrencyShort(-50_000)).toBe("-$50,000");
  });

  it("formats zero correctly", () => {
    expect(fmtCurrencyShort(0)).toBe("$0");
  });

  it("rounds to nearest dollar", () => {
    expect(fmtCurrencyShort(1234.56)).toBe("$1,235");
  });
});
