import * as cheerio from "cheerio";
import type { MarcsNetCash } from "./scraper";

const CANONICAL_CASH_LABEL = /^Net Cash Flow$/i;
const LEGACY_CASH_LABEL = /^Marc['’]s Net Cash(?: Flow)?$/i;
const normalize = (text: string) => text.replace(/\u00a0/g, " ").replace(/\s+/g, " ").trim();

/** Unlike the dashboard parser, never accepts prefixes, missing amounts, or nonfinite numbers. */
function parseCashAmount(text: string): number {
  const normalized = normalize(text);
  const accounting = /^\(.*\)$/.test(normalized);
  const amount = accounting ? normalized.slice(1, -1).trim() : normalized;
  if (!/^-?\$?(?:\d+|\d{1,3}(?:,\d{3})+)(?:\.\d{1,2})?$/.test(amount)
    || (accounting && amount.startsWith("-"))) {
    throw new Error("Monthly Net Cash source contains an invalid cash amount");
  }
  const value = Number(amount.replace(/[$,]/g, "")) * (accounting ? -1 : 1);
  if (!Number.isFinite(value)) throw new Error("Monthly Net Cash source contains a nonfinite cash amount");
  return value;
}

/** Parse only the verified FLOW layout; opted into exclusively by monthly deliveries. No I/O. */
export function parseStrictMonthlyNetCashHtml(raw: string, regionId: number): MarcsNetCash {
  if (![1, 2, 3, 4].includes(regionId)) throw new Error("Monthly Net Cash requires region IDs 1 through 4");
  let html = raw;
  if (raw.trim().startsWith('"')) {
    try {
      const decoded: unknown = JSON.parse(raw);
      if (typeof decoded !== "string") throw new Error();
      html = decoded;
    } catch {
      throw new Error("Monthly Net Cash source returned invalid encoded HTML");
    }
  }
  const $ = cheerio.load(html);
  type Cell = ReturnType<typeof $>;
  const sourceRows = $("tr").toArray();
  const label = (row: (typeof sourceRows)[number]) => normalize($(row).children("th, td").first().text());
  const canonicalRows = sourceRows.filter(row => CANONICAL_CASH_LABEL.test(label(row)));
  // Preserve the legacy per-building calculation: current Marc/Todd rows are separate rollups.
  // A present canonical row must be unique and valid; never fall back if it is malformed.
  const rows = canonicalRows.length > 0
    ? canonicalRows
    : sourceRows.filter(row => LEGACY_CASH_LABEL.test(label(row)));
  if (rows.length !== 1) throw new Error(`Monthly Net Cash region ${regionId} must contain exactly one cash row`);
  const row = $(rows[0]);
  const table = row.closest("table");
  const headerRows = table.children("thead").children("tr");
  if (headerRows.length !== 1) throw new Error("Monthly Net Cash source has missing or ambiguous building headers");

  // Expand colspan without filtering blanks: both label columns and every spacer keep their indexes.
  function expand(cells: Cell): Cell[] {
    const columns: Cell[] = [];
    cells.each((_, element) => {
      const cell = $(element);
      const spanText = cell.attr("colspan") ?? "1";
      const span = Number(spanText);
      if (!/^\d+$/.test(spanText) || !Number.isInteger(span) || span < 1 || span > 100
        || (cell.attr("rowspan") !== undefined && cell.attr("rowspan") !== "1")
        || cell.find("table").length > 0) {
        throw new Error("Monthly Net Cash source has an unsupported cell layout");
      }
      for (let i = 0; i < span; i++) columns.push(cell);
    });
    return columns;
  }
  const headers = expand(headerRows.first().children("th, td"));
  const values = expand(row.children("th, td"));
  if (headers.length === 0 || headers.length !== values.length) {
    throw new Error("Monthly Net Cash source has incomplete or misaligned columns");
  }
  const labelCell = row.children("th, td").first()[0];
  const names = new Set<string>();
  const buildings: MarcsNetCash["buildings"] = [];
  for (let column = 0; column < headers.length; column++) {
    const header = headers[column];
    const cell = values[column];
    const name = normalize(header.text().replace(/★/g, ""));
    if (cell[0] === labelCell) {
      if (name) throw new Error("Monthly Net Cash source label overlaps a building header");
      continue;
    }
    if (!name) {
      if (normalize(cell.text())) throw new Error("Monthly Net Cash source contains unexpected spacer values");
      continue;
    }
    if (Number(header.attr("colspan") ?? "1") !== 1 || Number(cell.attr("colspan") ?? "1") !== 1
      || names.has(name.toLowerCase()) || /^(?:total|grand total|all regions)$/i.test(name)) {
      throw new Error("Monthly Net Cash source has ambiguous building columns");
    }
    const strong = cell.find("strong");
    let value: number;
    if (strong.length > 0) {
      if (strong.length !== 1) throw new Error("Monthly Net Cash source contains ambiguous strong cash values");
      value = parseCashAmount(strong.first().text());
      // FLOW can show component amounts outside its one authoritative black/strong value.
      // Validate those amounts as well: never silently swallow arbitrary text or bad prefixes.
      const extra = cell.clone();
      extra.find("strong").remove();
      extra.find("br").replaceWith("\n");
      for (const line of extra.text().split(/[\r\n]+/).map(normalize).filter(Boolean)) parseCashAmount(line);
    } else {
      value = parseCashAmount(cell.text());
    }
    names.add(name.toLowerCase());
    buildings.push({ name, value });
  }
  if (buildings.length === 0) throw new Error(`Monthly Net Cash region ${regionId} has no building cash values`);
  const total = buildings.reduce((sum, building) => sum + building.value, 0);
  if (!Number.isFinite(total)) throw new Error("Monthly Net Cash region total is nonfinite");
  return { region: regionId, regionName: `Region ${regionId}`, buildings, total };
}
