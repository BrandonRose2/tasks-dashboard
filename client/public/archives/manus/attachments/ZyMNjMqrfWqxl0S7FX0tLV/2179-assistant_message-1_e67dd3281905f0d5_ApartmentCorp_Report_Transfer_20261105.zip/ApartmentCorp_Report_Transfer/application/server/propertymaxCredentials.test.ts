import { describe, expect, it } from "vitest";
import { fetchVacancyStats, getPropertyMaxCredentials } from "./scraper";

describe("PropertyMax credential configuration", () => {
  it("reads the active login only from runtime configuration", () => {
    expect(getPropertyMaxCredentials({
      PROPERTYMAX_USERNAME: "active.user@example.com",
      PROPERTYMAX_PASSWORD: "secure-password",
    } as NodeJS.ProcessEnv)).toEqual({
      username: "active.user@example.com",
      password: "secure-password",
    });
  });

  it("refuses to run without both encrypted runtime credentials", () => {
    expect(() => getPropertyMaxCredentials({} as NodeJS.ProcessEnv))
      .toThrow("PropertyMax credentials are not configured");
  });

  it.runIf(process.env.PROPERTYMAX_LIVE_VERIFY === "true")(
    "authenticates with the configured account and reads a live Vacancy summary without sending mail",
    async () => {
      const stats = await fetchVacancyStats();
      expect(stats.totalVacant).toBeGreaterThan(0);
      expect(stats.vacUnleased + stats.vacPreleased).toBe(stats.totalVacant);
    },
    20_000,
  );
});
