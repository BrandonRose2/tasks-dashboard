import { fetchAllRegionsMarcsNetCash, type HistoricalMonth, type MarcsNetCash } from "./scraper";

export const MONTHLY_NET_CASH_TIME_ZONE = "America/Los_Angeles";
export const MIN_MONTHLY_NET_CASH_YEAR = 2000;
export const MAX_MONTHLY_NET_CASH_YEAR = 2100;
const MONTH_NAMES = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December",
];

export type MonthlyNetCashPeriod = {
  year: number;
  /** Calendar month, 1 through 12; never JavaScript's zero-based month. */
  month: number;
  monthName: string;
  label: string;
  periodKey: string;
  sourceDate: string;
};

function pacificCalendarMonth(now: Date): { year: number; month: number } {
  if (!(now instanceof Date) || !Number.isFinite(now.getTime())) throw new Error("Monthly Net Cash requires a valid current date");
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: MONTHLY_NET_CASH_TIME_ZONE, year: "numeric", month: "numeric",
  }).formatToParts(now);
  return {
    year: Number(parts.find(part => part.type === "year")!.value),
    month: Number(parts.find(part => part.type === "month")!.value),
  };
}

/** Validate explicit calendar inputs and reject any month still open in Pacific time. No I/O. */
export function getCompletedMonthlyNetCashPeriod(year: number, month: number, now = new Date()): MonthlyNetCashPeriod {
  if (!Number.isInteger(year) || year < MIN_MONTHLY_NET_CASH_YEAR || year > MAX_MONTHLY_NET_CASH_YEAR
    || !Number.isInteger(month) || month < 1 || month > 12) {
    throw new Error("Monthly Net Cash requires an integer year (2000–2100) and calendar month (1–12)");
  }
  const current = pacificCalendarMonth(now);
  if (year > current.year || (year === current.year && month >= current.month)) {
    throw new Error("Monthly Net Cash requires a previous completed month in America/Los_Angeles");
  }
  const periodKey = `${year}-${String(month).padStart(2, "0")}`;
  const monthName = MONTH_NAMES[month - 1];
  return { year, month, monthName, label: `${monthName} ${year}`, periodKey, sourceDate: `${periodKey}-01` };
}

/** Pure business-calendar default, including January/December rollover and UTC/Pacific boundaries. */
export function getPreviousCompletedMonth(now = new Date()): MonthlyNetCashPeriod {
  const current = pacificCalendarMonth(now);
  return getCompletedMonthlyNetCashPeriod(
    current.month === 1 ? current.year - 1 : current.year,
    current.month === 1 ? 12 : current.month - 1,
    now,
  );
}

function assertAmount(value: unknown): asserts value is number {
  if (typeof value !== "number" || !Number.isFinite(value)) {
    throw new Error("Monthly Net Cash contains a missing or nonfinite amount");
  }
}

function reconciles(actual: number, expected: number): boolean {
  return Number.isFinite(expected) && Math.abs(actual - expected) < 0.005;
}

/** Shared validation for forced source pulls and side-effect-free email preparation. Zero and negative cash are valid. */
export function assertCompleteMonthlyNetCashReport(month: HistoricalMonth, now = new Date()): void {
  if (!month || typeof month !== "object") throw new Error("Monthly Net Cash report is missing");
  const period = getCompletedMonthlyNetCashPeriod(month.year, month.month, now);
  if (month.monthName !== period.monthName || month.label !== period.label) {
    throw new Error("Monthly Net Cash report has inconsistent period metadata");
  }
  if (!Array.isArray(month.regions) || month.regions.length !== 4) {
    throw new Error("Monthly Net Cash source must include all four regions");
  }
  const seen = new Set<number>();
  for (const region of month.regions) {
    if (!region || ![1, 2, 3, 4].includes(region.region) || seen.has(region.region)) {
      throw new Error("Monthly Net Cash source must include each of region IDs 1–4 exactly once");
    }
    seen.add(region.region);
    if (typeof region.regionName !== "string" || !region.regionName.trim()
      || !Array.isArray(region.buildings) || region.buildings.length === 0) {
      throw new Error("Monthly Net Cash source has an empty or partial region");
    }
    const names = new Set<string>();
    for (const building of region.buildings) {
      if (!building || typeof building.name !== "string" || !building.name.trim()
        || names.has(building.name.trim().toLowerCase())) {
        throw new Error("Monthly Net Cash source has missing or duplicate building names");
      }
      names.add(building.name.trim().toLowerCase());
      assertAmount(building.value);
    }
    assertAmount(region.total);
    if (!reconciles(region.total, region.buildings.reduce((sum, building) => sum + building.value, 0))) {
      throw new Error("Monthly Net Cash region total does not reconcile to its building cash values");
    }
  }
  assertAmount(month.grandTotal);
  if (!reconciles(month.grandTotal, month.regions.reduce((sum, region) => sum + region.total, 0))) {
    throw new Error("Monthly Net Cash grand total does not reconcile to all four regions");
  }
}

/** Always fetch the selected completed month from authenticated FLOW; never use historical/dashboard cache. */
export async function fetchFreshMonthlyNetCashReport(period: MonthlyNetCashPeriod): Promise<{
  month: HistoricalMonth;
  sourceUpdatedAt: Date;
}> {
  if (!period || typeof period !== "object") throw new Error("Monthly Net Cash period is required");
  const validated = getCompletedMonthlyNetCashPeriod(period.year, period.month);
  for (const field of ["periodKey", "sourceDate", "monthName", "label"] as const) {
    if (period[field] !== validated[field]) throw new Error("Monthly Net Cash period metadata does not match its calendar month");
  }
  const regions: MarcsNetCash[] = await fetchAllRegionsMarcsNetCash(validated.sourceDate, { strict: true });
  const month: HistoricalMonth = {
    year: validated.year, month: validated.month, monthName: validated.monthName, label: validated.label,
    regions,
    grandTotal: Array.isArray(regions) ? regions.reduce((sum, region) => sum + (region?.total ?? NaN), 0) : NaN,
  };
  assertCompleteMonthlyNetCashReport(month);
  // Stable ID order preserves the original template's four region colors, without changing any amount.
  month.regions = [...regions].sort((a, b) => a.region - b.region);
  return { month, sourceUpdatedAt: new Date() };
}
