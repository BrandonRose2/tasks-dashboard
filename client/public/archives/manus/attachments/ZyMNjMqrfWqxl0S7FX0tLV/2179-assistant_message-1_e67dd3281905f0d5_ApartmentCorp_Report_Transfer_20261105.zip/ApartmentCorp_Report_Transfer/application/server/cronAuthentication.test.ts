import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import type { Request } from "express";

vi.mock("./_core/env", () => ({ ENV: { appId: "test-project", cookieSecret: "synthetic-secret", oAuthServerUrl: "https://auth.invalid" } }));
vi.mock("./db", () => ({ getUserByOpenId: vi.fn(), upsertUser: vi.fn() }));
import * as db from "./db";
import { sdk } from "./_core/sdk";

const req = { headers: { cookie: "app_session_id=synthetic-token" } } as Request;
const session = { openId: "cron_confirmed", appId: "test-project", name: "Cron" };
const confirmed = { openId: "cron_confirmed", projectId: "test-project", name: "Cron", taskUid: "task-confirmed" };

beforeEach(() => {
  vi.spyOn(sdk, "verifySession").mockResolvedValue(session);
  vi.spyOn(sdk, "getUserInfoWithJwt").mockResolvedValue(confirmed);
  vi.mocked(db.getUserByOpenId).mockClear();
  vi.mocked(db.upsertUser).mockClear();
});
afterEach(() => vi.restoreAllMocks());

describe("legacy SDK cron identity confirmation", () => {
  it("returns confirmed task UID without synchronizing a surrogate user to the database", async () => {
    await expect(sdk.authenticateRequest(req)).resolves.toMatchObject({ isCron: true, taskUid: "task-confirmed", openId: "cron_confirmed", id: -1 });
    expect(sdk.getUserInfoWithJwt).toHaveBeenCalledWith("synthetic-token");
    expect(db.getUserByOpenId).not.toHaveBeenCalled();
    expect(db.upsertUser).not.toHaveBeenCalled();
  });
  it("rejects a verified token for another app before confirmation", async () => {
    vi.mocked(sdk.verifySession).mockResolvedValue({ ...session, appId: "other-project" });
    await expect(sdk.authenticateRequest(req)).rejects.toThrow("project mismatch");
    expect(sdk.getUserInfoWithJwt).not.toHaveBeenCalled();
  });
  it.each([
    { openId: "cron_different" }, { openId: "real-user" }, { projectId: "other-project" },
    { taskUid: null }, { taskUid: "" }, { taskUid: " task-whitespace" }, { taskUid: "x".repeat(66) },
  ])("rejects an inconsistent cron confirmation %j", async patch => {
    vi.mocked(sdk.getUserInfoWithJwt).mockResolvedValue({ ...confirmed, ...patch });
    await expect(sdk.authenticateRequest(req)).rejects.toThrow("identity confirmation failed");
    expect(db.upsertUser).not.toHaveBeenCalled();
  });
  it("rejects missing/invalid session", async () => {
    vi.mocked(sdk.verifySession).mockResolvedValue(null);
    await expect(sdk.authenticateRequest(req)).rejects.toThrow("Invalid session");
  });
  it("preserves normal user authentication and never attaches cron privileges", async () => {
    vi.mocked(sdk.verifySession).mockResolvedValue({ ...session, openId: "real-user" });
    const user = { id: 1, openId: "real-user", role: "admin" };
    vi.mocked(db.getUserByOpenId).mockResolvedValue(user as never);
    await expect(sdk.authenticateRequest(req)).resolves.toEqual(user);
    expect(sdk.getUserInfoWithJwt).not.toHaveBeenCalled();
    expect(db.upsertUser).toHaveBeenCalledWith(expect.objectContaining({ openId: "real-user" }));
  });
});
