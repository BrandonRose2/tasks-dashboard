import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { replaceScopedReportRecipients } from "./scopedReportRecipients";
import type { WeeklySummaryData } from "./scraper";

const mocks = vi.hoisted(() => ({ recipients: vi.fn(), dates: vi.fn(), send: vi.fn(), transport: vi.fn() }));
vi.mock("./db", () => ({ getDailyVacancyRecipients: mocks.recipients, getPaymentsDates: mocks.dates }));
vi.mock("./scraper", () => ({ fetchDashboardData: vi.fn(() => { throw new Error("No live source access permitted"); }) }));
vi.mock("nodemailer", () => ({ default: { createTransport: mocks.transport } }));
import { prepareWeeklySummaryEmail, sendWeeklySummaryEmail, prepareEvictionMissingAmountEmail, sendEvictionMissingAmountEmails, buildWeeklySummaryHtml } from "./emailService";

const activeRecipients = ["Brandon@ApartmentCorp.com", "mam@22.bz", "Myles@menowitz.com", "Todd@menowitz.com", "ethan@apartmentcorp.com"];
const weeklyTo = "ethan@apartmentcorp.com, mam@22.bz, Myles@menowitz.com, Todd@menowitz.com";
const summary: WeeklySummaryData = {
  weekStart: "2026-11-01", weekEnd: "2026-11-07", totalNetChange: 0, startTotalVacant: 4, endTotalVacant: 4, totalBuildingsChanged: 0,
  topIncreases: [], topDecreases: [], dailyChanges: [], buildingTrends: [], currentStats: null, currentAtRisk: [],
};
const contact = { property: "Synthetic Property", managerName: "Sam Manager", managerEmail: "Manager@One.test", regionalEmail: "Regional@One.test", units: ["A101"] };
const sender = { from: '"Apartment Corp Reports" <apartmentcorp44@gmail.com>', replyTo: "ethan@apartmentcorp.com" };

beforeEach(() => {
  vi.resetAllMocks();
  vi.stubEnv("GMAIL_USER", "apartmentcorp44@gmail.com");
  vi.stubEnv("GMAIL_APP_PASSWORD", "abcdefghijklmnop");
  vi.stubGlobal("fetch", vi.fn(() => { throw new Error("No network requests permitted"); }));
  mocks.recipients.mockResolvedValue(activeRecipients);
  mocks.dates.mockResolvedValue([]);
  mocks.transport.mockReturnValue({ sendMail: mocks.send });
  mocks.send.mockResolvedValue({ messageId: "mock-only" });
});
afterEach(() => {
  expect(fetch).not.toHaveBeenCalled();
  vi.unstubAllGlobals();
  vi.unstubAllEnvs();
});

describe("pure recipient replacement scoped to weekly and eviction reports", () => {
  it("replaces in place and dedupes the five active recipients without mutating the input", () => {
    const input = Object.freeze([...activeRecipients]);
    expect(replaceScopedReportRecipients(input)).toEqual({ to: weeklyTo, cc: "" });
    expect(input).toEqual(activeRecipients);
    expect(mocks.transport).not.toHaveBeenCalled();
    expect(mocks.recipients).not.toHaveBeenCalled();
  });

  it.each(["Brandon@ApartmentCorp.com", "BRANDON@APARTMENTCORP.COM", "bRaNdOn@aPaRtMeNtCoRp.CoM"])("replaces exact mailbox case variant %s", address => {
    expect(replaceScopedReportRecipients([address, "ETHAN@APARTMENTCORP.COM", "mam@22.bz"]).to).toBe("ethan@apartmentcorp.com, mam@22.bz");
  });

  it.each([
    { input: [], expected: "" },
    { input: ["mam@22.bz", "Myles@menowitz.com"], expected: "mam@22.bz, Myles@menowitz.com" },
    { input: ["Ethan@ApartmentCorp.com", "mam@22.bz", "ETHAN@APARTMENTCORP.COM"], expected: "Ethan@ApartmentCorp.com, mam@22.bz" },
    { input: ["Brandon@Other.test", "notBrandon@ApartmentCorp.com"], expected: "Brandon@Other.test, notBrandon@ApartmentCorp.com" },
  ])("does not re-add Ethan or alter unrelated addresses when Brandon is absent: $expected", ({ input, expected }) => {
    expect(replaceScopedReportRecipients(input)).toEqual({ to: expected, cc: "" });
  });

  it("dedupes every mailbox case-insensitively while preserving first address casing/order", () => {
    expect(replaceScopedReportRecipients(["Myles@menowitz.com", "myles@MENOWITZ.COM", "Todd@menowitz.com", "TODD@MENOWITZ.COM", "mam@22.bz"]).to)
      .toBe("Myles@menowitz.com, Todd@menowitz.com, mam@22.bz");
  });

  it("preserves an existing Ethan before a later replacement rather than moving or recasing him", () => {
    expect(replaceScopedReportRecipients(["Ethan@ApartmentCorp.com", "Myles@menowitz.com", "BRANDON@APARTMENTCORP.COM"]).to)
      .toBe("Ethan@ApartmentCorp.com, Myles@menowitz.com");
  });

  it("dedupes across To and CC without demoting the manager", () => {
    expect(replaceScopedReportRecipients("Manager@One.test", ["manager@ONE.TEST", "Brandon@ApartmentCorp.com", "ETHAN@APARTMENTCORP.COM", "mam@22.bz"]))
      .toEqual({ to: "Manager@One.test", cc: "ethan@apartmentcorp.com, mam@22.bz" });
  });

  it("parses named mailbox overrides safely, including quoted commas", () => {
    expect(replaceScopedReportRecipients('"Manager, Sam" <Manager@One.test>, "Brandon Rose" <BRANDON@APARTMENTCORP.COM>, Ethan@ApartmentCorp.com'))
      .toEqual({ to: '"Manager, Sam" <Manager@One.test>, "Brandon Rose" <ethan@apartmentcorp.com>', cc: "" });
    expect(replaceScopedReportRecipients('"Brandon@ApartmentCorp.com" <Other@One.test>').to)
      .toBe('"Brandon@ApartmentCorp.com" <Other@One.test>');
  });

  it("rejects header line injection rather than broadening recipients", () => {
    expect(() => replaceScopedReportRecipients("manual@one.test\r\nBcc: other@one.test")).toThrow("Invalid scoped report recipient header");
    expect(() => replaceScopedReportRecipients("manager@one.test", ["regional@one.test\nBcc: other@one.test"])).toThrow("Invalid scoped report recipient header");
  });
});

describe("weekly default and manual recipient paths (mocked SMTP/database)", () => {
  it("prepares then sends Ethan, mam, Myles, Todd with unchanged headers, subject and HTML", async () => {
    const prepared = await prepareWeeklySummaryEmail(summary);
    expect(prepared.message).toEqual({ ...sender, to: weeklyTo, subject: "📊 Weekly Vacancy Summary — 2026-11-01 to 2026-11-07", html: buildWeeklySummaryHtml(summary) });
    expect(prepared.message).not.toHaveProperty("cc");
    expect(prepared.message).not.toHaveProperty("bcc");
    expect(mocks.send).not.toHaveBeenCalled();
    await expect(sendWeeklySummaryEmail(summary)).resolves.toBe(true);
    expect(mocks.send).toHaveBeenCalledWith(prepared.message);
    expect(activeRecipients[0]).toBe("Brandon@ApartmentCorp.com");
  });

  it("removes case variants from weekly database recipients", async () => {
    mocks.recipients.mockResolvedValue(["BRANDON@APARTMENTCORP.COM", "mam@22.bz", "bRaNdOn@ApartmentCorp.com", "Ethan@ApartmentCorp.com"]);
    expect((await prepareWeeklySummaryEmail(summary)).message.to).toBe("ethan@apartmentcorp.com, mam@22.bz");
  });

  it("does not append Ethan to a weekly database list with neither Brandon nor Ethan", async () => {
    mocks.recipients.mockResolvedValue(["mam@22.bz", "Myles@menowitz.com", "Todd@menowitz.com"]);
    expect((await prepareWeeklySummaryEmail(summary)).message.to).toBe("mam@22.bz, Myles@menowitz.com, Todd@menowitz.com");
  });

  it.each([
    { override: "manual@one.test", expected: "manual@one.test" },
    { override: "Brandon@ApartmentCorp.com", expected: "ethan@apartmentcorp.com" },
    { override: " BRaNDoN@APARTMENTCORP.COM , ETHAN@APARTMENTCORP.COM, Manual@One.test, manual@one.test", expected: "ethan@apartmentcorp.com, Manual@One.test" },
    { override: "Ethan@ApartmentCorp.com, BRANDON@APARTMENTCORP.COM, Other@One.test", expected: "Ethan@ApartmentCorp.com, Other@One.test" },
  ])("keeps manual override selection, transformed safely: $override", async ({ override, expected }) => {
    const prepared = await prepareWeeklySummaryEmail(summary, override);
    expect(prepared.message.to).toBe(expected);
    expect(mocks.recipients).not.toHaveBeenCalled();
    await expect(sendWeeklySummaryEmail(summary, override)).resolves.toBe(true);
    expect(mocks.send).toHaveBeenCalledWith(prepared.message);
  });

  it("retains the existing empty-string override fallback", async () => {
    expect((await prepareWeeklySummaryEmail(summary, "")).message.to).toBe(weeklyTo);
    expect(mocks.recipients).toHaveBeenCalledOnce();
  });

  it.each(["   ", "manual@one.test\r\nBcc: other@one.test"])("invalid nonempty override fails without falling back to database recipients: %j", async override => {
    await expect(sendWeeklySummaryEmail(summary, override)).resolves.toBe(false);
    expect(mocks.recipients).not.toHaveBeenCalled();
    expect(mocks.send).not.toHaveBeenCalled();
  });

  it("empty default recipient list still blocks sending", async () => {
    mocks.recipients.mockResolvedValue([]);
    await expect(sendWeeklySummaryEmail(summary)).resolves.toBe(false);
    expect(mocks.send).not.toHaveBeenCalled();
  });
});

describe("eviction To/CC recipient handling (mocked SMTP)", () => {
  it("keeps manager primary, regional+Ethan+mam CC and the original Brandon body signature", async () => {
    const prepared = prepareEvictionMissingAmountEmail(contact);
    expect(prepared.message).toMatchObject({ ...sender, to: "Manager@One.test", cc: "Regional@One.test, ethan@apartmentcorp.com, mam@22.bz", subject: "Action Required: Missing Amount Owed — Eviction Records (Synthetic Property)" });
    expect(prepared.message.html).toContain("Hello Sam,");
    expect(prepared.message.html).toContain("<strong>Brandon Rose</strong>");
    expect(mocks.send).not.toHaveBeenCalled();
    await expect(sendEvictionMissingAmountEmails([contact])).resolves.toEqual({ sent: 1, skipped: 0 });
    expect(mocks.send).toHaveBeenCalledWith(prepared.message);
  });

  it.each([
    { managerEmail: "Manager@One.test", regionalEmail: "BRANDON@APARTMENTCORP.COM", to: "Manager@One.test", cc: "ethan@apartmentcorp.com, mam@22.bz" },
    { managerEmail: "BRANDON@APARTMENTCORP.COM", regionalEmail: "Regional@One.test", to: "ethan@apartmentcorp.com", cc: "Regional@One.test, mam@22.bz" },
    { managerEmail: "Ethan@ApartmentCorp.com", regionalEmail: "Regional@One.test", to: "Ethan@ApartmentCorp.com", cc: "Regional@One.test, mam@22.bz" },
    { managerEmail: "Manager@One.test", regionalEmail: "ETHAN@APARTMENTCORP.COM", to: "Manager@One.test", cc: "ETHAN@APARTMENTCORP.COM, mam@22.bz" },
    { managerEmail: "Manager@One.test", regionalEmail: "manager@ONE.TEST", to: "Manager@One.test", cc: "ethan@apartmentcorp.com, mam@22.bz" },
    { managerEmail: "MAM@22.BZ", regionalEmail: "mam@22.bz", to: "MAM@22.BZ", cc: "ethan@apartmentcorp.com" },
  ])("transforms all recipients and dedupes across To/CC: $managerEmail / $regionalEmail", async ({ managerEmail, regionalEmail, to, cc }) => {
    const c = { ...contact, managerEmail, regionalEmail };
    const prepared = prepareEvictionMissingAmountEmail(c);
    expect(prepared.message).toMatchObject({ to, cc });
    await expect(sendEvictionMissingAmountEmails([c])).resolves.toEqual({ sent: 1, skipped: 0 });
    expect(mocks.send).toHaveBeenCalledWith(prepared.message);
    expect(`${to}, ${cc}`.toLowerCase()).not.toContain("brandon@apartmentcorp.com");
    const addresses = `${to}, ${cc}`.split(", ").map(address => address.toLowerCase());
    expect(new Set(addresses).size).toBe(addresses.length);
  });
});
