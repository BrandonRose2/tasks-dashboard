import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const source = readFileSync(
  new URL("../client/src/components/CollectionsPanel.tsx", import.meta.url),
  "utf8"
);

describe("Collections mobile layout contract", () => {
  it("keeps the property history modal inside narrow phone viewports with scrollable content", () => {
    expect(source).toContain("w-[calc(100vw-1.25rem)]");
    expect(source).toContain("max-h-[calc(100dvh-1.25rem)]");
    expect(source).toContain("overflow-y-auto");
    expect(source).toContain("grid-cols-2 sm:grid-cols-4");
    expect(source).toContain("Phone history list: all metrics visible without horizontal scrolling");
  });

  it("uses adaptive collection controls and preserves horizontal access to dense data", () => {
    expect(source).toContain("flex flex-col items-stretch gap-3 sm:flex-row");
    expect(source).toContain("min-[375px]:grid-cols-2 sm:grid-cols-3 lg:grid-cols-5");
    expect(source).toContain("min-[480px]:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4");
    expect(source).toContain("overflow-x-auto");
    expect(source).toContain("min-w-[560px]");
    expect(source).toContain("hidden sm:block");
  });

  it("shows expected-rent variance and the configured tolerance in cards, table, and history views", () => {
    expect(source).toContain("getCollectionVariance");
    expect(source).toContain("Expected Rent");
    expect(source).toContain("Variance vs Expected");
    expect(source).toContain("Variance tolerance: ±");
    expect(source).toContain("🚨");
    expect(source).toContain("⭐");
    expect(source).toContain("absolute right-3 top-2");
    expect(source).toContain("COLLECTION_VARIANCE_TOLERANCE");
    expect(source).toContain('mode="region-asc"');
    expect(source).toContain('label="Region 1–4"');
  });
});
