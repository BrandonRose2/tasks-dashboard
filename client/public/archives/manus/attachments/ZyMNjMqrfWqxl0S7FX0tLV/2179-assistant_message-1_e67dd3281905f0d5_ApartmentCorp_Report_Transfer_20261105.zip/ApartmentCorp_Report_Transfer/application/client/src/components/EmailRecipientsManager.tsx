import { useState, useCallback } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Mail,
  Plus,
  Trash2,
  Loader2,
  Users,
  X,
  Check,
  Clock,
  Send,
} from "lucide-react";
import { toast } from "sonner";

interface Props {
  adminPin: string;
}

interface RecipientFormData {
  email: string;
  name: string;
  receiveDailyVacancy: boolean;
  receiveMonthlyNetCash: boolean;
  scheduleGroup: "early" | "admin";
}

export default function EmailRecipientsManager({ adminPin }: Props) {
  const [showAddForm, setShowAddForm] = useState(false);
  const [formData, setFormData] = useState<RecipientFormData>({
    email: "",
    name: "",
    receiveDailyVacancy: true,
    receiveMonthlyNetCash: false,
    scheduleGroup: "early",
  });
  const [deleteConfirmId, setDeleteConfirmId] = useState<number | null>(null);
  const [sendingNowId, setSendingNowId] = useState<number | null>(null);

  const utils = trpc.useUtils();

  const { data: recipients, isLoading } = trpc.recipients.list.useQuery(undefined, {
    staleTime: 60 * 1000,
  });

  const addMutation = trpc.recipients.add.useMutation({
    onSuccess: () => {
      utils.recipients.list.invalidate();
      setShowAddForm(false);
      resetForm();
      toast.success("Recipient added successfully");
    },
    onError: (err) => {
      toast.error(`Failed to add recipient: ${err.message}`);
    },
  });

  const updateMutation = trpc.recipients.update.useMutation({
    onSuccess: () => {
      utils.recipients.list.invalidate();
      toast.success("Recipient updated");
    },
    onError: (err) => {
      toast.error(`Failed to update: ${err.message}`);
    },
  });

  const removeMutation = trpc.recipients.remove.useMutation({
    onSuccess: () => {
      utils.recipients.list.invalidate();
      setDeleteConfirmId(null);
      toast.success("Recipient removed");
    },
    onError: (err) => {
      toast.error(`Failed to remove: ${err.message}`);
    },
  });

  const sendNowMutation = trpc.recipients.sendNow.useMutation({
    onSuccess: (data, variables) => {
      setSendingNowId(null);
      if (data.success) {
        toast.success(`Report sent to ${variables.email}`);
      } else {
        toast.error(`Failed to send report to ${variables.email}`);
      }
    },
    onError: (err) => {
      setSendingNowId(null);
      toast.error(`Send failed: ${err.message}`);
    },
  });

  const resetForm = useCallback(() => {
    setFormData({
      email: "",
      name: "",
      receiveDailyVacancy: true,
      receiveMonthlyNetCash: false,
      scheduleGroup: "early",
    });
  }, []);

  const handleAdd = useCallback(() => {
    if (!formData.email.trim()) {
      toast.error("Email is required");
      return;
    }
    addMutation.mutate({
      pin: adminPin,
      email: formData.email.trim(),
      name: formData.name.trim() || undefined,
      receiveDailyVacancy: formData.receiveDailyVacancy,
      receiveMonthlyNetCash: formData.receiveMonthlyNetCash,
      scheduleGroup: formData.scheduleGroup,
    });
  }, [formData, adminPin, addMutation]);

  const handleToggle = useCallback(
    (id: number, field: "receiveDailyVacancy" | "receiveMonthlyNetCash" | "isActive", currentValue: boolean) => {
      updateMutation.mutate({
        pin: adminPin,
        id,
        [field]: !currentValue,
      });
    },
    [adminPin, updateMutation]
  );

  const handleScheduleGroupChange = useCallback(
    (id: number, newGroup: "early" | "admin") => {
      updateMutation.mutate({
        pin: adminPin,
        id,
        scheduleGroup: newGroup,
      });
    },
    [adminPin, updateMutation]
  );

  const handleDelete = useCallback(
    (id: number) => {
      removeMutation.mutate({ pin: adminPin, id });
    },
    [adminPin, removeMutation]
  );

  const handleSendNow = useCallback(
    (id: number, email: string) => {
      setSendingNowId(id);
      sendNowMutation.mutate({ pin: adminPin, email });
    },
    [adminPin, sendNowMutation]
  );

  const activeDaily = recipients?.filter((r) => r.receiveDailyVacancy && r.isActive).length ?? 0;
  const activeMonthly = recipients?.filter((r) => r.receiveMonthlyNetCash && r.isActive).length ?? 0;

  return (
    <section>
      <h2 className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-4">
        Email Recipients Management
      </h2>
      <Card className="neon-card rounded-xl">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-[oklch(0.85_0.18_192_/_10%)]">
                <Users className="w-5 h-5 neon-cyan" />
              </div>
              <div>
                <CardTitle className="text-lg text-foreground">Email Recipients</CardTitle>
                <p className="text-xs text-muted-foreground mt-0.5">
                  Manage who receives automated reports
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="flex gap-2">
                <Badge variant="outline" className="text-xs border-[oklch(0.85_0.18_192_/_30%)] text-[oklch(0.85_0.18_192)]">
                  <Mail className="w-3 h-3 mr-1" />
                  Daily: {activeDaily}
                </Badge>
                <Badge variant="outline" className="text-xs border-[oklch(0.82_0.22_145_/_30%)] text-[oklch(0.82_0.22_145)]">
                  <Mail className="w-3 h-3 mr-1" />
                  Monthly: {activeMonthly}
                </Badge>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  resetForm();
                  setShowAddForm(!showAddForm);
                }}
                className="border-[oklch(0.85_0.18_192_/_30%)] text-[oklch(0.85_0.18_192)] hover:bg-[oklch(0.85_0.18_192_/_10%)]"
              >
                {showAddForm ? (
                  <><X className="w-4 h-4 mr-1" /> Cancel</>
                ) : (
                  <><Plus className="w-4 h-4 mr-1" /> Add Recipient</>
                )}
              </Button>
            </div>
          </div>
        </CardHeader>

        <CardContent>
          {/* Add Recipient Form */}
          {showAddForm && (
            <div className="mb-6 p-4 rounded-xl border border-[oklch(0.85_0.18_192_/_20%)] bg-[oklch(0.12_0.02_260)]">
              <h4 className="text-sm font-bold text-foreground mb-3 flex items-center gap-2">
                <Plus className="w-4 h-4 neon-cyan" />
                Add New Recipient
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-3">
                <div>
                  <label className="text-xs text-muted-foreground block mb-1">Email *</label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData((f) => ({ ...f, email: e.target.value }))}
                    onKeyDown={(e) => { if (e.key === "Enter") handleAdd(); }}
                    placeholder="name@example.com"
                    className="w-full px-3 py-2 text-sm rounded-lg bg-[oklch(0.15_0.02_260)] border border-[oklch(0.85_0.12_85_/_20%)] text-foreground focus:outline-none focus:border-[oklch(0.85_0.18_192_/_50%)] transition-all"
                  />
                </div>
                <div>
                  <label className="text-xs text-muted-foreground block mb-1">Name (optional)</label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData((f) => ({ ...f, name: e.target.value }))}
                    onKeyDown={(e) => { if (e.key === "Enter") handleAdd(); }}
                    placeholder="Display name"
                    className="w-full px-3 py-2 text-sm rounded-lg bg-[oklch(0.15_0.02_260)] border border-[oklch(0.85_0.12_85_/_20%)] text-foreground focus:outline-none focus:border-[oklch(0.85_0.18_192_/_50%)] transition-all"
                  />
                </div>
              </div>
              <div className="flex items-center gap-6 mb-3">
                <label className="flex items-center gap-2 text-sm text-foreground cursor-pointer">
                  <Switch
                    checked={formData.receiveDailyVacancy}
                    onCheckedChange={(v) => setFormData((f) => ({ ...f, receiveDailyVacancy: v }))}
                  />
                  Daily Vacancy Report
                </label>
                <label className="flex items-center gap-2 text-sm text-foreground cursor-pointer">
                  <Switch
                    checked={formData.receiveMonthlyNetCash}
                    onCheckedChange={(v) => setFormData((f) => ({ ...f, receiveMonthlyNetCash: v }))}
                  />
                  Monthly Net Cash Flow
                </label>
              </div>
              <div className="mb-4">
                <label className="text-xs text-muted-foreground block mb-2">
                  <Clock className="w-3 h-3 inline mr-1" />
                  Schedule Group
                </label>
                <div className="flex gap-2">
                  <button
                    onClick={() => setFormData((f) => ({ ...f, scheduleGroup: "early" }))}
                    className={`px-3 py-1.5 text-xs font-bold rounded-lg border transition-all ${
                      formData.scheduleGroup === "early"
                        ? "border-[oklch(0.85_0.18_192_/_50%)] bg-[oklch(0.85_0.18_192_/_15%)] text-[oklch(0.85_0.18_192)]"
                        : "border-border/50 bg-transparent text-muted-foreground hover:border-border"
                    }`}
                  >
                    9 AM ET
                  </button>
                  <button
                    onClick={() => setFormData((f) => ({ ...f, scheduleGroup: "admin" }))}
                    className={`px-3 py-1.5 text-xs font-bold rounded-lg border transition-all ${
                      formData.scheduleGroup === "admin"
                        ? "border-[oklch(0.82_0.22_145_/_50%)] bg-[oklch(0.82_0.22_145_/_15%)] text-[oklch(0.82_0.22_145)]"
                        : "border-border/50 bg-transparent text-muted-foreground hover:border-border"
                    }`}
                  >
                    1 PM PST
                  </button>
                </div>
              </div>
              <Button
                onClick={handleAdd}
                disabled={!formData.email.trim() || addMutation.isPending}
                className="bg-[oklch(0.85_0.18_192_/_15%)] text-[oklch(0.85_0.18_192)] border border-[oklch(0.85_0.18_192_/_30%)] hover:bg-[oklch(0.85_0.18_192_/_25%)] font-bold"
              >
                {addMutation.isPending ? (
                  <Loader2 className="w-4 h-4 animate-spin mr-2" />
                ) : (
                  <Check className="w-4 h-4 mr-2" />
                )}
                Add Recipient
              </Button>
            </div>
          )}

          {/* Recipients Table */}
          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-6 h-6 animate-spin neon-cyan" />
              <span className="ml-2 text-muted-foreground">Loading recipients...</span>
            </div>
          ) : !recipients || recipients.length === 0 ? (
            <div className="text-center py-12">
              <Users className="w-10 h-10 mx-auto mb-3 text-muted-foreground opacity-40" />
              <p className="text-muted-foreground">No recipients configured</p>
              <p className="text-xs text-muted-foreground mt-1">Add recipients to start sending automated reports</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-border/50 hover:bg-transparent">
                    <TableHead className="text-xs uppercase tracking-wider text-muted-foreground font-bold">Recipient</TableHead>
                    <TableHead className="text-xs uppercase tracking-wider text-muted-foreground font-bold text-center">Daily Vacancy</TableHead>
                    <TableHead className="text-xs uppercase tracking-wider text-muted-foreground font-bold text-center">Monthly Net Cash</TableHead>
                    <TableHead className="text-xs uppercase tracking-wider text-muted-foreground font-bold text-center">Schedule</TableHead>
                    <TableHead className="text-xs uppercase tracking-wider text-muted-foreground font-bold text-center">Active</TableHead>
                    <TableHead className="text-xs uppercase tracking-wider text-muted-foreground font-bold text-center">Send Now</TableHead>
                    <TableHead className="text-xs uppercase tracking-wider text-muted-foreground font-bold text-center w-16">Delete</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recipients.map((r) => (
                    <TableRow key={r.id} className={`border-border/30 ${!r.isActive ? "opacity-50" : ""}`}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <div className="p-1.5 rounded-md bg-[oklch(0.85_0.18_192_/_8%)]">
                            <Mail className="w-3.5 h-3.5 neon-cyan" />
                          </div>
                          <div>
                            <p className="text-sm font-medium text-foreground">{r.email}</p>
                            {r.name && <p className="text-xs text-muted-foreground">{r.name}</p>}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="text-center">
                        <Switch
                          checked={r.receiveDailyVacancy}
                          onCheckedChange={() => handleToggle(r.id, "receiveDailyVacancy", r.receiveDailyVacancy)}
                          disabled={updateMutation.isPending}
                        />
                      </TableCell>
                      <TableCell className="text-center">
                        <Switch
                          checked={r.receiveMonthlyNetCash}
                          onCheckedChange={() => handleToggle(r.id, "receiveMonthlyNetCash", r.receiveMonthlyNetCash)}
                          disabled={updateMutation.isPending}
                        />
                      </TableCell>
                      <TableCell className="text-center">
                        <button
                          onClick={() => handleScheduleGroupChange(r.id, r.scheduleGroup === "early" ? "admin" : "early")}
                          disabled={updateMutation.isPending}
                          className={`px-2.5 py-1 text-xs font-bold rounded-md border transition-all cursor-pointer ${
                            r.scheduleGroup === "early"
                              ? "border-[oklch(0.85_0.18_192_/_40%)] bg-[oklch(0.85_0.18_192_/_10%)] text-[oklch(0.85_0.18_192)]"
                              : "border-[oklch(0.82_0.22_145_/_40%)] bg-[oklch(0.82_0.22_145_/_10%)] text-[oklch(0.82_0.22_145)]"
                          }`}
                        >
                          {r.scheduleGroup === "early" ? "9 AM ET" : "1 PM PST"}
                        </button>
                      </TableCell>
                      <TableCell className="text-center">
                        <Switch
                          checked={r.isActive}
                          onCheckedChange={() => handleToggle(r.id, "isActive", r.isActive)}
                          disabled={updateMutation.isPending}
                        />
                      </TableCell>
                      <TableCell className="text-center">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleSendNow(r.id, r.email)}
                          disabled={sendingNowId === r.id || sendNowMutation.isPending}
                          className="h-7 px-2.5 text-xs font-bold border-[oklch(0.85_0.18_192_/_30%)] text-[oklch(0.85_0.18_192)] hover:bg-[oklch(0.85_0.18_192_/_15%)] whitespace-nowrap"
                        >
                          {sendingNowId === r.id ? (
                            <Loader2 className="w-3 h-3 animate-spin mr-1" />
                          ) : (
                            <Send className="w-3 h-3 mr-1" />
                          )}
                          Email Me Report Now
                        </Button>
                      </TableCell>
                      <TableCell className="text-center">
                        {deleteConfirmId === r.id ? (
                          <div className="flex items-center gap-1 justify-center">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleDelete(r.id)}
                              disabled={removeMutation.isPending}
                              className="h-7 px-2 text-xs border-[oklch(0.68_0.25_25_/_40%)] text-[oklch(0.68_0.25_25)] hover:bg-[oklch(0.68_0.25_25_/_15%)]"
                            >
                              {removeMutation.isPending ? (
                                <Loader2 className="w-3 h-3 animate-spin" />
                              ) : (
                                "Yes"
                              )}
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => setDeleteConfirmId(null)}
                              className="h-7 px-2 text-xs border-border text-muted-foreground hover:bg-secondary"
                            >
                              No
                            </Button>
                          </div>
                        ) : (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setDeleteConfirmId(r.id)}
                            className="h-7 w-7 p-0 text-muted-foreground hover:text-[oklch(0.68_0.25_25)] hover:bg-[oklch(0.68_0.25_25_/_10%)]"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}

          {/* Schedule info */}
          <div className="mt-4 pt-4 border-t border-border/30">
            <div className="flex flex-wrap gap-4 text-xs text-muted-foreground">
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-[oklch(0.85_0.18_192)]" />
                Early Group: Daily Vacancy at 9:00 AM ET
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-[oklch(0.82_0.22_145)]" />
                Admin Group: Daily Vacancy at 1:00 PM PST
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-[oklch(0.72_0.25_330)]" />
                Weekly Summary: Saturdays at 9:00 AM ET (all recipients)
              </span>
            </div>
          </div>
        </CardContent>
      </Card>
    </section>
  );
}
