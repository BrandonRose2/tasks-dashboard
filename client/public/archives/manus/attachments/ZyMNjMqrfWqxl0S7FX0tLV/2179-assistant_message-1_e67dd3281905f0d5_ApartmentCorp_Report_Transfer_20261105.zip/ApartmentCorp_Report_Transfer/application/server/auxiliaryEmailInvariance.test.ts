import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
const source = (path: string) => readFileSync(new URL(path, import.meta.url), "utf8");
const hash = (text: string) => createHash("sha256").update(text).digest("hex");
const slice = (text: string, start: string, end: string) => text.slice(text.indexOf(start), text.indexOf(end, text.indexOf(start)));

describe("approved auxiliary migration preserves original code/content and daily ownership", () => {
  it.each([
    ["./dailyVacancyScheduled.ts", "81e3dc81a56f668a1632f9f218b06c64c68501cc443f75fa6bc1ff8f29fb1931"],
    ["./dailyVacancyScheduleDb.ts", "4bd607e12a4fbe421fb481d8224a89460f990296e32b370714d3207cddca08a4"],
    ["./dailyVacancySchedulePolicy.ts", "043035607692702adb56f7b5c4d228537db2c90b8ea63f438b03f3a67b49c2e2"],
    ["./db.ts", "d307f78c6eb1da8ad189bda500b822c5bad5a21d9eddced1e88ad117372838ed"],
    ["./gmailReportTransport.ts", "d4262b513ec58682ed72f3a84ab032877ffd0546921df52e5e58019b00440cd4"],
  ])("%s byte-identical to pre-migration baseline", (path, expected) => expect(hash(source(path))).toBe(expected));
  it("weekly HTML renderer is byte-identical", () => {
    expect(hash(slice(source("./emailService.ts"), "function buildWeeklySummaryHtml(", "\n/** Renders"))).toBe("d02d9133f50598a71a773a307d859296c45e31e3777ef15da3d757eb75182625");
  });
  it("eviction HTML renderer is byte-identical", () => {
    expect(hash(slice(source("./emailService.ts"), "function buildEvictionMissingAmountHtml(", "\n/**"))).toBe("7feb810be79c3a6e414f99a5e0d5d339d3285532888bf0203df02f88cb68cec4");
  });
  it("legacy saved-payment comparison math is byte-identical", () => {
    expect(hash(slice(source("./emailService.ts"), "  // Fetch payments data for weekly email", "\n  } catch {"))).toBe("d562505e894aaa641e69f36c529a84b1a3de77c4b1384fbf6f0d37f9d7041a88");
  });
  it("existing schema tables remain unchanged in generated snapshot", () => {
    const old = JSON.parse(source("../drizzle/meta/0010_snapshot.json")); const next = JSON.parse(source("../drizzle/meta/0011_snapshot.json"));
    for (const [name, table] of Object.entries(old.tables)) expect(next.tables[name]).toEqual(table);
  });
  it("four isolated route mounts, no startup provisioning or monthly mail from the auxiliary callback", () => {
    const entry = source("./_core/index.ts"); expect(entry.match(/app\.post\("\/api\/scheduled\//g)).toHaveLength(4);
    expect(entry).toContain('app.post("/api/scheduled/monthly-net-cash-flow", monthlyNetCashFlowScheduledHandler)');
    expect(entry).not.toMatch(/startEmailScheduler|ensureAuxiliary|bindAuxiliary|activateAuxiliary|createHeartbeat|updateHeartbeat/);
    const scheduler = source("./emailScheduler.ts"); expect(scheduler).not.toMatch(/setInterval|setTimeout|sendMail/); expect(scheduler).toContain("No startup provisioning or activation");
    const callback = source("./auxiliaryEmailScheduled.ts"); expect(callback).not.toMatch(/req\.body\.[A-Za-z_$]|dailyVacancyJobs|dailyVacancySendLedger|sendMonthly|createHeartbeat|updateHeartbeat/);
  });
});
