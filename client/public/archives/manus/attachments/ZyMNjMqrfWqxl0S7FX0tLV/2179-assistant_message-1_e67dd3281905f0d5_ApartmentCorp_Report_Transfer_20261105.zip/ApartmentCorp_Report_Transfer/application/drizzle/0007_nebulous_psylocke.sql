CREATE TABLE `building_collections` (
	`id` int AUTO_INCREMENT NOT NULL,
	`snapshotDate` varchar(10) NOT NULL,
	`buildingName` varchar(255) NOT NULL,
	`regionId` int NOT NULL,
	`rentBilled` varchar(32) NOT NULL DEFAULT '0',
	`rentCollected` varchar(32) NOT NULL DEFAULT '0',
	`utilityReimbursement` varchar(32) NOT NULL DEFAULT '0',
	`vouchersCount` int NOT NULL DEFAULT 0,
	`collectionPct` varchar(10) NOT NULL DEFAULT '0',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `building_collections_id` PRIMARY KEY(`id`)
);
