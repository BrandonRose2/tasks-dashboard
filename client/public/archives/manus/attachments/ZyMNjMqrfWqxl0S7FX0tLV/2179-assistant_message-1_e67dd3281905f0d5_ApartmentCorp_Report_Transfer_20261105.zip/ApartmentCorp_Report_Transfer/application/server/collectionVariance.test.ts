import { describe, expect, it } from "vitest";
import { COLLECTION_VARIANCE_TOLERANCE, getCollectionVariance } from "../shared/collectionVariance";

describe("getCollectionVariance", () => {
  it("treats the inclusive ±$7,500 boundary as within tolerance", () => {
    expect(getCollectionVariance(100_000, 107_500)).toMatchObject({ variance: 7_500, status: "within_tolerance" });
    expect(getCollectionVariance(100_000, 92_500)).toMatchObject({ variance: -7_500, status: "within_tolerance" });
    expect(COLLECTION_VARIANCE_TOLERANCE).toBe(7_500);
  });

  it("classifies material shortfalls and over-collections", () => {
    expect(getCollectionVariance(100_000, 92_499)).toMatchObject({ variance: -7_501, status: "shortfall" });
    expect(getCollectionVariance(100_000, 107_501)).toMatchObject({ variance: 7_501, status: "over_collected" });
  });

  it("does not apply a tolerance status where expected rent is unavailable", () => {
    expect(getCollectionVariance(0, 500)).toMatchObject({ status: "no_expected_rent", variance: 500 });
  });
});
