CREATE TABLE `building_payments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`snapshotDate` varchar(10) NOT NULL,
	`buildingName` varchar(255) NOT NULL,
	`regionId` int NOT NULL,
	`netRentCollected` varchar(32) NOT NULL DEFAULT '0',
	`netCashFlow` varchar(32) NOT NULL DEFAULT '0',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `building_payments_id` PRIMARY KEY(`id`)
);
