CREATE TABLE `historical_cache` (
	`id` int AUTO_INCREMENT NOT NULL,
	`monthKey` varchar(7) NOT NULL,
	`data` json NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `historical_cache_id` PRIMARY KEY(`id`),
	CONSTRAINT `historical_cache_monthKey_unique` UNIQUE(`monthKey`)
);
