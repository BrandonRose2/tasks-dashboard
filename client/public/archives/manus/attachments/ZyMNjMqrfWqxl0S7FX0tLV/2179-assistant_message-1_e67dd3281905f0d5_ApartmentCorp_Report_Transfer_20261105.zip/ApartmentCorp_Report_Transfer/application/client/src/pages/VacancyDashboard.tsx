import { useState, useEffect, useCallback, useMemo, useRef } from "react";
import { Sparkline } from "@/components/Sparkline";
import EmailRecipientsManager from "@/components/EmailRecipientsManager";
import UnitCountOverrideManager from "@/components/UnitCountOverrideManager";
import CollectionsPanel from "@/components/CollectionsPanel";
import { matchesUnitSearch } from "@/lib/unitSearch";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  RefreshCw,
  AlertTriangle,
  Home,
  Clock,
  Gavel,
  DollarSign,
  ChevronLeft,
  ChevronRight,
  TrendingUp,
  TrendingDown,
  Minus,
  Loader2,
  Zap,
  Building2,
  ArrowUpRight,
  ArrowDownRight,
  Lock,
  Unlock,
  ShieldCheck,
  X,
  ArrowUp,
  ArrowDown,
  ChevronsUpDown,
  Eye,
  Mail,
  CalendarDays,
  WifiOff,
  Wifi,
  ChevronDown,
  ServerCrash,
  ExternalLink,
  CheckCircle2,
  XCircle,
  Sun,
  Moon,
  Info,
  Search,
} from "lucide-react";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { toast } from "sonner";
import { useTheme } from "@/contexts/ThemeContext";

// ─── Helpers ──────────────────────────────────────────────────────────────────

function formatCurrency(val: number): string {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 2,
  }).format(val);
}

function formatDate(d: Date | string | null | undefined): string {
  if (!d) return "—";
  const date = new Date(d);
  if (isNaN(date.getTime())) return String(d);
  return date.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}

// ─── Trend Description Helper ────────────────────────────────────────────────

function describeTrend(buildingName: string, values: number[], dates: string[]): { headline: string; body: string; color: string } {
  if (values.length < 2) {
    return { headline: "Not enough data", body: "Fewer than 2 data points are available for this building.", color: "text-muted-foreground" };
  }
  const first = values[0];
  const last = values[values.length - 1];
  const net = last - first;
  const min = Math.min(...values);
  const max = Math.max(...values);
  const minIdx = values.indexOf(min);
  const maxIdx = values.indexOf(max);
  const startDate = dates[0] ? new Date(dates[0]).toLocaleDateString("en-US", { month: "short", day: "numeric" }) : "start";
  const endDate = dates[dates.length - 1] ? new Date(dates[dates.length - 1]).toLocaleDateString("en-US", { month: "short", day: "numeric" }) : "today";
  const minDate = dates[minIdx] ? new Date(dates[minIdx]).toLocaleDateString("en-US", { month: "short", day: "numeric" }) : "";
  const maxDate = dates[maxIdx] ? new Date(dates[maxIdx]).toLocaleDateString("en-US", { month: "short", day: "numeric" }) : "";
  const days = dates.length;

  let direction: string;
  let color: string;
  if (net < 0) {
    direction = "improving";
    color = "text-[oklch(0.72_0.22_145)]";
  } else if (net > 0) {
    direction = "worsening";
    color = "text-[oklch(0.65_0.22_25)]";
  } else {
    direction = "stable";
    color = "text-[oklch(0.75_0.12_85)]";
  }

  const netLabel = net === 0 ? "no net change" : net > 0 ? `+${net} unit${Math.abs(net) !== 1 ? "s" : ""}` : `${net} unit${Math.abs(net) !== 1 ? "s" : ""}`;
  const headline = net < 0
    ? `Vacancy decreasing ↓ (${netLabel})`
    : net > 0
    ? `Vacancy increasing ↑ (${netLabel})`
    : `Vacancy stable — no change`;

  const body = `Over the last ${days} day${days !== 1 ? "s" : ""} (${startDate} → ${endDate}), ${buildingName} went from ${first} to ${last} vacant unit${last !== 1 ? "s" : ""} — a ${direction} trend with ${netLabel}. ` +
    (min !== max ? `Peak was ${max} unit${max !== 1 ? "s" : ""} on ${maxDate}; lowest was ${min} unit${min !== 1 ? "s" : ""} on ${minDate}.` : `Vacancy held steady at ${first} unit${first !== 1 ? "s" : ""} throughout.`);

  return { headline, body, color };
}

// ─── Stat Card ────────────────────────────────────────────────────────────────

interface StatCardProps {
  label: string;
  value: number;
  colorClass: string;
  neonClass: string;
  icon: React.ReactNode;
}

function StatCard({ label, value, colorClass, neonClass, icon }: StatCardProps) {
  return (
    <Card className={`overflow-hidden border-0 rounded-xl ${colorClass}`}>
      <div className="p-4 text-white">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider opacity-80">{label}</p>
            <p className={`text-4xl font-black mt-1 ${neonClass}`}>{value}</p>
          </div>
          <div className="opacity-60">{icon}</div>
        </div>
      </div>
    </Card>
  );
}

// ─── Loading Skeleton ─────────────────────────────────────────────────────────

function DashboardSkeleton() {
  return (
    <div className="min-h-screen bg-background">
      <div className="bg-[oklch(0.10_0.02_260)] border-b border-[oklch(0.85_0.18_192_/_15%)] py-4 px-6">
        <div className="flex items-center gap-3">
          <Zap className="w-7 h-7 neon-cyan" />
          <div>
            <div className="h-6 w-48 bg-white/10 rounded animate-pulse" />
            <div className="h-4 w-32 bg-white/5 rounded animate-pulse mt-1" />
          </div>
        </div>
      </div>
      <div className="container py-6">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
          {Array.from({ length: 5 }).map((_, i) => (
            <Card key={i} className="overflow-hidden border-0">
              <div className="bg-secondary p-4 h-24 animate-pulse" />
            </Card>
          ))}
        </div>
        <div className="h-64 bg-secondary rounded-lg animate-pulse" />
      </div>
    </div>
  );
}

// ─── Error State ─────────────────────────────────────────────────────────────

interface DashboardErrorStateProps {
  error: { message: string };
  onRetry: () => void;
  isRetrying: boolean;
}

function DashboardErrorState({ error, onRetry, isRetrying }: DashboardErrorStateProps) {
  const [showDetails, setShowDetails] = useState(false);
  const [countdown, setCountdown] = useState(30);

  // Auto-retry countdown
  useEffect(() => {
    setCountdown(30);
    const tick = setInterval(() => {
      setCountdown((c) => {
        if (c <= 1) {
          clearInterval(tick);
          onRetry();
          return 30;
        }
        return c - 1;
      });
    }, 1000);
    return () => clearInterval(tick);
  }, [onRetry]);

  // Classify error for a friendlier message
  const isAuthError = error.message.toLowerCase().includes("authentication") || error.message.toLowerCase().includes("login");
  const isNetworkError = error.message.toLowerCase().includes("fetch") || error.message.toLowerCase().includes("network") || error.message.toLowerCase().includes("econnreset");

  const headline = isAuthError
    ? "Unable to connect to PropertyMax"
    : isNetworkError
    ? "Network connection issue"
    : "Data could not be loaded";

  const description = isAuthError
    ? "The dashboard lost its connection to PropertyMax.ai. This usually resolves on its own — the system will retry automatically."
    : isNetworkError
    ? "A network error prevented the dashboard from fetching the latest vacancy data. Check your connection or wait for the automatic retry."
    : "An unexpected error occurred while loading vacancy data. The system will retry automatically.";

  const Icon = isNetworkError ? WifiOff : ServerCrash;

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Keep the header visible so users know they're in the right place */}
      <header className="bg-[oklch(0.10_0.02_260)] border-b border-[oklch(0.85_0.18_192_/_20%)] shadow-[0_2px_20px_oklch(0.85_0.18_192_/_10%)]">
        <div className="container py-4">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div className="flex items-center gap-4">
              <div className="gold-shimmer-wrap rounded-lg">
                <img
                  src="https://d2xsxph8kpxj0f.cloudfront.net/310519663449376037/42VuDntxHxNeoLPYMuqTxk/ApartmentCorpLOGO_0ca11dd4.png"
                  alt="Apartment Corp"
                  className="h-10 w-auto"
                  style={{ filter: 'sepia(1) saturate(3) brightness(1.1) hue-rotate(10deg)' }}
                />
              </div>
              <div className="h-8 w-px bg-[oklch(0.85_0.12_85_/_30%)]" />
              <div>
                <h1 className="text-xl font-bold tracking-tight neon-cyan">Vacancy Report Dashboard</h1>
                <p className="text-xs text-muted-foreground">Connection Error</p>
              </div>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={onRetry}
              disabled={isRetrying}
              className="border-[oklch(0.85_0.18_192_/_30%)] text-[oklch(0.85_0.18_192)] hover:bg-[oklch(0.85_0.18_192_/_10%)] hover:text-[oklch(0.85_0.18_192)]"
            >
              {isRetrying ? (
                <Loader2 className="w-4 h-4 animate-spin mr-1" />
              ) : (
                <RefreshCw className="w-4 h-4 mr-1" />
              )}
              Retry Now
            </Button>
          </div>
        </div>
      </header>

      {/* Main error content */}
      <div className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-lg">
          {/* Error card */}
          <div className="rounded-2xl border border-[oklch(0.65_0.22_25_/_30%)] bg-[oklch(0.10_0.02_260)] shadow-[0_0_40px_oklch(0.65_0.22_25_/_15%)] overflow-hidden">
            {/* Red accent bar */}
            <div className="h-1 w-full bg-gradient-to-r from-[oklch(0.65_0.22_25)] via-[oklch(0.72_0.20_35)] to-transparent" />

            <div className="p-8">
              {/* Icon + headline */}
              <div className="flex items-start gap-4 mb-6">
                <div className="shrink-0 w-12 h-12 rounded-xl bg-[oklch(0.65_0.22_25_/_15%)] border border-[oklch(0.65_0.22_25_/_30%)] flex items-center justify-center">
                  <Icon className="w-6 h-6 text-[oklch(0.72_0.20_35)]" />
                </div>
                <div>
                  <h2 className="text-lg font-bold text-card-foreground mb-1">{headline}</h2>
                  <p className="text-sm text-muted-foreground leading-relaxed">{description}</p>
                </div>
              </div>

              {/* Auto-retry progress */}
              <div className="mb-6 rounded-lg bg-[oklch(0.14_0.02_260)] border border-white/5 p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs text-muted-foreground">Auto-retrying in</span>
                  <span className="text-xs font-mono font-bold text-[oklch(0.85_0.18_192)]">{countdown}s</span>
                </div>
                <div className="h-1.5 w-full rounded-full bg-white/5 overflow-hidden">
                  <div
                    className="h-full rounded-full bg-[oklch(0.85_0.18_192)] transition-all duration-1000 ease-linear"
                    style={{ width: `${((30 - countdown) / 30) * 100}%` }}
                  />
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex gap-3 mb-4">
                <Button
                  onClick={onRetry}
                  disabled={isRetrying}
                  className="flex-1 bg-[oklch(0.85_0.18_192_/_15%)] border border-[oklch(0.85_0.18_192_/_40%)] text-[oklch(0.85_0.18_192)] hover:bg-[oklch(0.85_0.18_192_/_25%)] hover:border-[oklch(0.85_0.18_192_/_60%)] transition-all"
                  variant="outline"
                >
                  {isRetrying ? (
                    <><Loader2 className="w-4 h-4 animate-spin mr-2" /> Retrying…</>
                  ) : (
                    <><RefreshCw className="w-4 h-4 mr-2" /> Retry Now</>
                  )}
                </Button>
                <Button
                  variant="outline"
                  onClick={() => window.location.reload()}
                  className="border-white/10 text-muted-foreground hover:bg-white/5 hover:text-card-foreground"
                >
                  Reload Page
                </Button>
              </div>

              {/* Collapsible technical details */}
              <button
                onClick={() => setShowDetails((v) => !v)}
                className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-card-foreground transition-colors w-full"
              >
                <ChevronDown
                  className={`w-3.5 h-3.5 transition-transform duration-200 ${showDetails ? "rotate-180" : ""}`}
                />
                {showDetails ? "Hide" : "Show"} technical details
              </button>
              {showDetails && (
                <div className="mt-3 rounded-lg bg-black/30 border border-white/5 p-3">
                  <p className="text-xs font-mono text-[oklch(0.72_0.20_35)] break-all leading-relaxed">
                    {error.message}
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Help text */}
          <p className="text-center text-xs text-muted-foreground mt-4">
            If this error persists, the PropertyMax.ai credentials may need to be updated.
          </p>
        </div>
      </div>
    </div>
  );
}

// ─── Sort Types & Helper ─────────────────────────────────────────────────────

type SortField = "name" | "vacancyPct" | "totalVacant" | "totalUnits" | "vacUnleased" | "vacPreleased" | "onNotice" | "eviction";
type SortDir = "asc" | "desc";

interface SortState {
  field: SortField;
  dir: SortDir;
}

function SortIcon({ field, sort }: { field: SortField; sort: SortState }) {
  if (sort.field !== field) return <ChevronsUpDown className="w-3 h-3 opacity-40 ml-1 inline-block" />;
  return sort.dir === "desc"
    ? <ArrowDown className="w-3 h-3 ml-1 inline-block" />
    : <ArrowUp className="w-3 h-3 ml-1 inline-block" />;
}

// ─── Main Dashboard ───────────────────────────────────────────────────────────

export default function VacancyDashboard() {
  const { theme, toggleTheme } = useTheme();
  const [historyIndex, setHistoryIndex] = useState(0);
  const [activeTab, setActiveTab] = useState(() =>
    new URLSearchParams(window.location.search).get("tab") === "collections" ? "collections" : "unleased"
  );
  const [unitSearchQuery, setUnitSearchQuery] = useState("");
  const [atRiskSort, setAtRiskSort] = useState<SortState>({ field: "vacancyPct", dir: "desc" });
  const [isAdmin, setIsAdmin] = useState(() => {
    return sessionStorage.getItem("admin_unlocked") === "true";
  });
  const [showPinDialog, setShowPinDialog] = useState(false);
  const [pinValue, setPinValue] = useState("");
  const [storedPin, setStoredPin] = useState("");
  const [pinError, setPinError] = useState(false);
  const pinInputRef = useRef<HTMLInputElement>(null);
  // Error banner state (must be before early returns to satisfy Rules of Hooks)
  const [dismissedError, setDismissedError] = useState(false);

  const { data, isLoading, error, refetch } = trpc.vacancy.getDashboard.useQuery(
    { forceRefresh: false },
    {
      refetchInterval: 30 * 60 * 1000,
      staleTime: 25 * 60 * 1000,
      retry: 2,
    }
  );

  // Fetch vacancy history for sparklines
  const { data: historyData } = trpc.vacancy.getHistory.useQuery(undefined, {
    staleTime: 30 * 60 * 1000,
    refetchInterval: 30 * 60 * 1000,
  });

  // Build sparkline data per building
  const buildingSparklines = useMemo(() => {
    if (!historyData || historyData.length < 2) return new Map<string, number[]>();
    const map = new Map<string, number[]>();
    for (const point of historyData) {
      for (const [name, val] of Object.entries(point.buildings)) {
        if (!map.has(name)) map.set(name, []);
        map.get(name)!.push(val);
      }
    }
    return map;
  }, [historyData]);
  // Build sparkline dates per building (parallel to buildingSparklines values)
  const buildingSparklineDates = useMemo(() => {
    if (!historyData || historyData.length < 2) return new Map<string, string[]>();
    const map = new Map<string, string[]>();
    for (const point of historyData) {
      for (const name of Object.keys(point.buildings)) {
        if (!map.has(name)) map.set(name, []);
        map.get(name)!.push(point.date);
      }
    }
    return map;
  }, [historyData]);

  const totalSparkline = useMemo(() => {
    if (!historyData || historyData.length < 2) return [];
    return historyData.map((p) => p.totalVacant);
  }, [historyData]);

  const verifyPinMutation = trpc.vacancy.verifyPin.useMutation({
    onSuccess: (result) => {
      if (result.valid) {
        setIsAdmin(true);
        setStoredPin(pinValue);
        sessionStorage.setItem("admin_unlocked", "true");
        setShowPinDialog(false);
        setPinValue("");
        setPinError(false);
        toast.success("Admin access granted");
      } else {
        setPinError(true);
        setPinValue("");
        pinInputRef.current?.focus();
      }
    },
    onError: () => {
      setPinError(true);
      setPinValue("");
    },
  });

  const handlePinSubmit = useCallback(() => {
    if (pinValue.length === 0) return;
    verifyPinMutation.mutate({ pin: pinValue });
  }, [pinValue, verifyPinMutation]);

  const handleLockToggle = useCallback(() => {
    if (isAdmin) {
      setIsAdmin(false);
      setStoredPin("");
      sessionStorage.removeItem("admin_unlocked");
      toast.info("Admin access locked");
    } else {
      setShowPinDialog(true);
      setPinError(false);
      setPinValue("");
      setTimeout(() => pinInputRef.current?.focus(), 100);
    }
  }, [isAdmin]);

  const [previewType, setPreviewType] = useState<"daily" | "weekly" | null>(null);

  const dailyPreviewQuery = trpc.vacancy.previewDailyEmail.useQuery(
    { pin: storedPin },
    { enabled: previewType === "daily" && !!storedPin, staleTime: 5 * 60 * 1000 }
  );

  const weeklyPreviewQuery = trpc.vacancy.previewWeeklyEmail.useQuery(
    { pin: storedPin },
    { enabled: previewType === "weekly" && !!storedPin, staleTime: 5 * 60 * 1000 }
  );

  const activePreviewHtml = previewType === "daily"
    ? dailyPreviewQuery.data?.html
    : weeklyPreviewQuery.data?.html;

  const isPreviewLoading = previewType === "daily"
    ? dailyPreviewQuery.isLoading
    : weeklyPreviewQuery.isLoading;

  const [connStatus, setConnStatus] = useState<{ success: boolean; message: string; latencyMs: number } | null>(null);
  const testConnectionMutation = trpc.vacancy.testConnection.useMutation({
    onSuccess: (data) => {
      setConnStatus(data);
      if (data.success) {
        toast.success(`Connected to PropertyMax.ai (${data.latencyMs}ms)`, { duration: 6000 });
      } else {
        toast.error(`Connection failed: ${data.message}`, { duration: 8000 });
      }
    },
    onError: (err: { message: string }) => {
      setConnStatus({ success: false, message: err.message, latencyMs: 0 });
      toast.error(`Connection test failed: ${err.message}`);
    },
  });
  const clearHistoricalCacheMutation = trpc.vacancy.clearHistoricalCache.useMutation({
    onSuccess: () => {
      toast.success("Cache cleared! Re-fetching all months...", { duration: 8000 });
      setTimeout(() => toast.info("Refresh the page in ~60 seconds to see updated data.", { duration: 10000 }), 1000);
      refetch();
    },
    onError: (err: { message: string }) => {
      toast.error(`Cache clear failed: ${err.message}`);
    },
  });

  const refreshMutation = trpc.vacancy.refresh.useMutation({
    onSuccess: (result) => {
      if (result.success) {
        refetch();
        toast.success("Data refreshed successfully");
      } else {
        toast.info(result.message ?? "Live PropertyMax data is temporarily unavailable. The last complete snapshot remains visible.");
      }
    },
    onError: (err: { message: string }) => {
      toast.error(`Refresh failed: ${err.message}`);
    },
  });

  const handleRefresh = useCallback(() => {
    refreshMutation.mutate();
  }, [refreshMutation]);

  useEffect(() => {
    const interval = setInterval(() => {
      handleRefresh();
    }, 30 * 60 * 1000);
    return () => clearInterval(interval);
  }, [handleRefresh]);

  // Weekly summary data
  const { data: weeklySummary } = trpc.vacancy.getWeeklySummary.useQuery();

  // Payments queries kept for email/backend use but tab removed from UI
  const { data: paymentsComparison, isLoading: paymentsLoading } = trpc.payments.getYesterdayComparison.useQuery(undefined, {
    staleTime: 30 * 60 * 1000,
    refetchInterval: 30 * 60 * 1000,
  });
  const { data: paymentsSnapshot } = trpc.payments.getSnapshot.useQuery(undefined, {
    staleTime: 30 * 60 * 1000,
    refetchInterval: 30 * 60 * 1000,
  });

  // Sort toggle for At-Risk table (must be before early returns to keep hooks stable)
  const toggleAtRiskSort = useCallback((field: SortField) => {
    setAtRiskSort((prev) => {
      if (prev.field === field) return { field, dir: prev.dir === "desc" ? "asc" : "desc" };
      return { field, dir: field === "name" ? "asc" : "desc" };
    });
  }, []);

  // Sorted at-risk buildings memo (must be before early returns)
  const buildingVacancyData = data?.buildingVacancy ?? [];
  const atRiskBuildingsRaw = buildingVacancyData.filter((b: { atRisk: boolean }) => b.atRisk);
  const atRiskBuildings = useMemo(() => {
    type BV = typeof atRiskBuildingsRaw[number];
    const sorted = [...atRiskBuildingsRaw];
    sorted.sort((a: BV, b: BV) => {
      const field = atRiskSort.field;
      const aVal = a[field as keyof BV];
      const bVal = b[field as keyof BV];
      if (typeof aVal === "string" && typeof bVal === "string") {
        return atRiskSort.dir === "asc" ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
      }
      const aNum = Number(aVal) || 0;
      const bNum = Number(bVal) || 0;
      return atRiskSort.dir === "asc" ? aNum - bNum : bNum - aNum;
    });
    return sorted;
  }, [atRiskBuildingsRaw, atRiskSort]);

  const scrollToBuilding = useCallback((buildingName: string) => {
    const row = document.querySelector(`[data-building-name="${buildingName}"]`);
    if (row) {
      row.scrollIntoView({ behavior: 'smooth', block: 'center' });
      row.classList.add('highlight-row');
      setTimeout(() => row.classList.remove('highlight-row'), 2000);
    }
  }, []);

  // Reset the source-status notice whenever a new PropertyMax error/status arrives.
  useEffect(() => {
    if (error || (data?.sourceStatus && data.sourceStatus.state !== "live")) setDismissedError(false);
  }, [error, data?.sourceStatus?.state]);

  if (isLoading) return <DashboardSkeleton />;

  // Full-page error: no data at all
  if (error && !data) {
    return <DashboardErrorState error={error} onRetry={() => refetch()} isRetrying={isLoading} />;
  }

  if (!data) return <DashboardSkeleton />;

  const { stats, vacantUnleased, vacantPreleased, onNotice, evictions, buildingVacancy, dailyChanges, historicalMonths } = data;
  const sourceStatus = data.sourceStatus;
  const filteredVacantUnleased = vacantUnleased.filter((unit) => matchesUnitSearch(unit, unitSearchQuery));
  const filteredVacantPreleased = vacantPreleased.filter((unit) => matchesUnitSearch(unit, unitSearchQuery));
  const filteredOnNotice = onNotice.filter((unit) => matchesUnitSearch(unit, unitSearchQuery));
  const filteredEvictions = evictions.filter((unit) => matchesUnitSearch(unit, unitSearchQuery));
  const visibleUnitCount = filteredVacantUnleased.length + filteredVacantPreleased.length + filteredOnNotice.length + filteredEvictions.length;
  const lastUpdated = new Date(data.lastUpdated);

  const currentHistMonth = historicalMonths[historyIndex];
  const canGoPrev = historyIndex < historicalMonths.length - 1;
  const canGoNext = historyIndex > 0;

  // Filter daily changes to only show buildings with actual changes
  const changesWithDiff = dailyChanges.filter((c: { change: number }) => c.change !== 0);
  const changesNoChange = dailyChanges.filter((c: { change: number }) => c.change === 0);

  // Build a lookup map for daily changes by building name (for table indicators)
  const dailyChangeMap = new Map<string, number>();
  for (const c of dailyChanges as { building: string; change: number }[]) {
    if (c.change !== 0) dailyChangeMap.set(c.building, c.change);
  }

  // At-risk buildings already computed above early returns

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-[oklch(0.10_0.02_260)] border-b border-[oklch(0.85_0.18_192_/_20%)] shadow-[0_2px_20px_oklch(0.85_0.18_192_/_10%)]">
        <div className="container py-4">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div className="flex items-center gap-4">
              <div className="gold-shimmer-wrap rounded-lg">
                <img
                  src="https://d2xsxph8kpxj0f.cloudfront.net/310519663449376037/42VuDntxHxNeoLPYMuqTxk/ApartmentCorpLOGO_0ca11dd4.png"
                  alt="Apartment Corp"
                  className="h-10 w-auto"
                  style={{ filter: 'sepia(1) saturate(3) brightness(1.1) hue-rotate(10deg)' }}
                />
              </div>
              <div className="h-8 w-px bg-[oklch(0.85_0.12_85_/_30%)]" />
              <div>
                <h1 className="text-xl font-bold tracking-tight neon-cyan">Vacancy Report Dashboard</h1>
                <p className="text-xs text-muted-foreground">Live Data</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              {/* PropertyMax fetch status */}
              <span className="text-xs text-muted-foreground">
                Updated: {formatDate(lastUpdated)} {lastUpdated.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" })}
              </span>

              <Button
                variant="outline"
                size="sm"
                onClick={handleLockToggle}
                className={`border-[oklch(0.85_0.12_85_/_30%)] transition-all ${
                  isAdmin
                    ? "text-[oklch(0.82_0.22_145)] border-[oklch(0.82_0.22_145_/_30%)] hover:bg-[oklch(0.82_0.22_145_/_10%)]"
                    : "text-muted-foreground hover:bg-secondary"
                }`}
              >
                {isAdmin ? (
                  <><Unlock className="w-4 h-4 mr-1" /> Admin</>  
                ) : (
                  <><Lock className="w-4 h-4 mr-1" /> Admin</>  
                )}
              </Button>
              {/* Theme toggle */}
              <Button
                variant="outline"
                size="sm"
                onClick={toggleTheme}
                title={theme === "light" ? "Switch to dark mode" : "Switch to light mode"}
                className="border-[oklch(0.85_0.12_85_/_30%)] text-muted-foreground hover:bg-secondary"
              >
                {theme === "light" ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={handleRefresh}
                disabled={refreshMutation.isPending}
                className="border-[oklch(0.85_0.18_192_/_30%)] text-[oklch(0.85_0.18_192)] hover:bg-[oklch(0.85_0.18_192_/_10%)] hover:text-[oklch(0.85_0.18_192)]"
              >
                {refreshMutation.isPending ? (
                  <Loader2 className="w-4 h-4 animate-spin mr-1" />
                ) : (
                  <RefreshCw className="w-4 h-4 mr-1" />
                )}
                Refresh
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Source-status banner: current data remains visible during a recoverable PropertyMax refresh failure. */}
      {sourceStatus?.state !== "live" && !dismissedError && (
        <div className="bg-[oklch(0.14_0.04_25)] border-b border-[oklch(0.65_0.22_25_/_40%)] px-4 py-2.5">
          <div className="container flex items-center gap-3">
            <AlertTriangle className="w-4 h-4 shrink-0 text-[oklch(0.72_0.20_35)]" />
            <div className="flex-1 min-w-0">
              <span className="text-sm font-medium text-[oklch(0.90_0.05_35)]">
                {sourceStatus?.state === "stale" ? "Showing the last complete snapshot — live refresh is temporarily unavailable." : "Live PropertyMax vacancy details are temporarily unavailable."}
              </span>
              {sourceStatus?.message && <span className="text-xs text-muted-foreground ml-2 hidden sm:inline">{sourceStatus.message}</span>}
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <Button
                size="sm"
                variant="outline"
                onClick={() => refetch()}
                disabled={refreshMutation.isPending}
                className="h-7 text-xs border-[oklch(0.65_0.22_25_/_40%)] text-[oklch(0.72_0.20_35)] hover:bg-[oklch(0.65_0.22_25_/_15%)] hover:text-[oklch(0.85_0.10_35)]"
              >
                {refreshMutation.isPending ? (
                  <Loader2 className="w-3 h-3 animate-spin mr-1" />
                ) : (
                  <RefreshCw className="w-3 h-3 mr-1" />
                )}
                Retry
              </Button>
              <button
                onClick={() => setDismissedError(true)}
                className="p-1 rounded hover:bg-white/10 text-muted-foreground hover:text-card-foreground transition-colors"
                aria-label="Dismiss error banner"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Breaking News Ticker */}
      <div className="ticker-wrap">
        <div className="ticker-label">
          <Zap className="w-3.5 h-3.5" />
          VACANCY CHANGES
        </div>
        <div className="ticker-scroll-area">
          {changesWithDiff.length > 0 ? (
            <div
              className="ticker-track"
              style={{ '--ticker-duration': `${Math.max(25, changesWithDiff.length * 10)}s` } as React.CSSProperties}
            >
              {changesWithDiff.map((c: { building: string; todayVacant: number; yesterdayVacant: number; change: number }, idx: number) => {
                const bldg = buildingVacancy.find((b: { name: string }) => b.name === c.building);
                return (
                  <div key={idx} className="ticker-item ticker-item-clickable" onClick={() => scrollToBuilding(c.building)}>
                    <span className="building-name" style={{ cursor: 'pointer', textDecoration: 'underline', textDecorationStyle: 'dotted', textUnderlineOffset: '3px' }}>{c.building}</span>
                    <span className={c.change > 0 ? 'change-up' : 'change-down'}>
                      {c.change > 0 ? '▲' : '▼'} {c.change > 0 ? '+' : ''}{c.change}
                    </span>
                    <span className="detail">
                      {c.yesterdayVacant} → {c.todayVacant} vacant
                    </span>
                    {bldg && (
                      <span className="detail">
                        | {(bldg as any).vacancyPct}% of {(bldg as any).totalUnits} units
                      </span>
                    )}
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="ticker-no-changes">
              ✓ No vacancy changes today — all buildings unchanged from yesterday
            </div>
          )}
        </div>
      </div>

      <div className="container py-6 space-y-8">
        {/* ── Stats Row ── */}
        <section>
          <h2 className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-4">
            Current Vacancy Overview
          </h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">
            <StatCard
              label="Total Vacant"
              value={stats.totalVacant}
              colorClass="stat-vacant"
              neonClass="neon-cyan"
              icon={<Home className="w-10 h-10" />}
            />
            <StatCard
              label="Vac / Unleased"
              value={stats.vacUnleased}
              colorClass="stat-unleased"
              neonClass="neon-orange"
              icon={<AlertTriangle className="w-10 h-10" />}
            />
            <StatCard
              label="Vac / Preleased"
              value={stats.vacPreleased}
              colorClass="stat-preleased"
              neonClass="neon-green"
              icon={<TrendingUp className="w-10 h-10" />}
            />
            <StatCard
              label="On Notice"
              value={stats.onNotice}
              colorClass="stat-notice"
              neonClass="neon-purple"
              icon={<Clock className="w-10 h-10" />}
            />
            <StatCard
              label="Eviction"
              value={stats.eviction}
              colorClass="stat-eviction"
              neonClass="neon-magenta"
              icon={<Gavel className="w-10 h-10" />}
            />
          </div>
        </section>

        {/* ── Daily Change ── */}
        <section>
          <h2 className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-4">
            Daily Change (vs. Previous Day)
          </h2>
          {dailyChanges.length === 0 ? (
            <Card className="neon-card rounded-xl">
              <CardContent className="py-8 text-center">
                <p className="text-muted-foreground text-sm">
                  No previous day data available yet. Daily comparison will appear after the first full day of tracking.
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {/* Buildings with changes */}
              {changesWithDiff.length > 0 && (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
                  {changesWithDiff.map((c: { building: string; todayVacant: number; yesterdayVacant: number; change: number }, idx: number) => (
                    <Card key={`daily-${idx}-${c.building}`} className={`rounded-xl overflow-hidden ${c.change > 0 ? "border-[oklch(0.68_0.25_25_/_30%)] shadow-[0_0_10px_oklch(0.68_0.25_25_/_10%)]" : "border-[oklch(0.82_0.22_145_/_30%)] shadow-[0_0_10px_oklch(0.82_0.22_145_/_10%)]"} bg-card`}>
                      <div className="p-3">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-sm font-medium text-foreground truncate mr-2">{c.building}</span>
                          <div className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-bold ${
                            c.change > 0
                              ? "bg-[oklch(0.68_0.25_25_/_15%)] neon-red"
                              : "bg-[oklch(0.82_0.22_145_/_15%)] neon-green"
                          }`}>
                            {c.change > 0 ? (
                              <ArrowUpRight className="w-3 h-3" />
                            ) : (
                              <ArrowDownRight className="w-3 h-3" />
                            )}
                            {c.change > 0 ? "+" : ""}{c.change}
                          </div>
                        </div>
                        <div className="flex items-center gap-3 text-xs text-muted-foreground">
                          <span>Yesterday: {c.yesterdayVacant}</span>
                          <span>→</span>
                          <span className="text-foreground font-medium">Today: {c.todayVacant}</span>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              )}

              {/* Summary of unchanged buildings */}
              {changesNoChange.length > 0 && (
                <div className="flex items-center gap-2 text-xs text-muted-foreground px-1">
                  <Minus className="w-3.5 h-3.5" />
                  <span>{changesNoChange.length} building{changesNoChange.length !== 1 ? "s" : ""} with no change</span>
                </div>
              )}
            </div>
          )}
        </section>

        {/* ── Weekly Change ── */}
        <section>
          <h2 className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-4">
            Weekly Change (7-Day Trend)
          </h2>
          {!weeklySummary || weeklySummary.buildingTrends.length === 0 ? (
            <Card className="neon-card rounded-xl">
              <CardContent className="py-8 text-center">
                <p className="text-muted-foreground text-sm">
                  Not enough snapshot data yet. Weekly trends will appear after multiple days of tracking.
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {/* Week summary stats */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <Card className="neon-card rounded-xl">
                  <CardContent className="p-3 text-center">
                    <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">Period</p>
                    <p className="text-sm font-bold text-foreground mt-1">{weeklySummary.weekStart.slice(5)} → {weeklySummary.weekEnd.slice(5)}</p>
                  </CardContent>
                </Card>
                <Card className="neon-card rounded-xl">
                  <CardContent className="p-3 text-center">
                    <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">Net Change</p>
                    <p className={`text-lg font-black mt-1 ${weeklySummary.totalNetChange > 0 ? 'neon-red' : weeklySummary.totalNetChange < 0 ? 'neon-green' : 'text-foreground'}`}>
                      {weeklySummary.totalNetChange > 0 ? '+' : ''}{weeklySummary.totalNetChange}
                    </p>
                  </CardContent>
                </Card>
                <Card className="neon-card rounded-xl">
                  <CardContent className="p-3 text-center">
                    <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">Start → End</p>
                    <p className="text-sm font-bold text-foreground mt-1">{weeklySummary.startTotalVacant} → {weeklySummary.endTotalVacant}</p>
                  </CardContent>
                </Card>
                <Card className="neon-card rounded-xl">
                  <CardContent className="p-3 text-center">
                    <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">Buildings Changed</p>
                    <p className="text-lg font-black neon-cyan mt-1">{weeklySummary.totalBuildingsChanged}</p>
                  </CardContent>
                </Card>
              </div>

              {/* New Vacancies */}
              {weeklySummary.topIncreases.length > 0 && (
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-widest neon-red flex items-center gap-1 mb-2">
                    <ArrowUpRight className="w-3 h-3" /> New Vacancies This Week
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-3">
                    {weeklySummary.topIncreases.map((b, idx) => (
                      <Card key={`inc-${idx}-${b.name}`} className="rounded-xl overflow-hidden border-[oklch(0.68_0.25_25_/_30%)] shadow-[0_0_10px_oklch(0.68_0.25_25_/_10%)] bg-card">
                        <div className="p-3">
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-sm font-medium text-foreground truncate mr-2">{b.name}</span>
                            <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-[oklch(0.68_0.25_25_/_15%)] neon-red">+{b.netChange}</span>
                          </div>
                          <div className="flex items-center gap-3 text-xs text-muted-foreground">
                            <span>{b.startVacant} → {b.endVacant}</span>
                            <span className="neon-red">{b.startPct}% → {b.endPct}%</span>
                          </div>
                          <div className="text-[10px] text-muted-foreground mt-1">Peak: {b.peakVacant} | Low: {b.lowVacant} | {b.totalUnits} units</div>
                        </div>
                      </Card>
                    ))}
                  </div>
                </div>
              )}

              {/* Recently Leased */}
              {weeklySummary.topDecreases.length > 0 && (
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-widest neon-green flex items-center gap-1 mb-2">
                    <ArrowDownRight className="w-3 h-3" /> Recently Leased This Week
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-3">
                    {weeklySummary.topDecreases.map((b, idx) => (
                      <Card key={`dec-${idx}-${b.name}`} className="rounded-xl overflow-hidden border-[oklch(0.82_0.22_145_/_30%)] shadow-[0_0_10px_oklch(0.82_0.22_145_/_10%)] bg-card">
                        <div className="p-3">
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-sm font-medium text-foreground truncate mr-2">{b.name}</span>
                            <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-[oklch(0.82_0.22_145_/_15%)] neon-green">{b.netChange}</span>
                          </div>
                          <div className="flex items-center gap-3 text-xs text-muted-foreground">
                            <span>{b.startVacant} → {b.endVacant}</span>
                            <span className="neon-green">{b.startPct}% → {b.endPct}%</span>
                          </div>
                          <div className="text-[10px] text-muted-foreground mt-1">Peak: {b.peakVacant} | Low: {b.lowVacant} | {b.totalUnits} units</div>
                        </div>
                      </Card>
                    ))}
                  </div>
                </div>
              )}

              {/* Day-by-Day Changes Log */}
              {weeklySummary.dailyChanges.length > 0 && (
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground mb-2">Day-by-Day Changes</p>
                  <Card className="neon-card rounded-xl overflow-hidden">
                    <CardContent className="p-0">
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow className="bg-[oklch(0.85_0.18_192_/_5%)] border-b border-[oklch(0.85_0.18_192_/_15%)]">
                              <TableHead className="text-[oklch(0.85_0.18_192)] font-semibold">Date</TableHead>
                              <TableHead className="text-[oklch(0.85_0.18_192)] font-semibold">Building</TableHead>
                              <TableHead className="text-right text-[oklch(0.85_0.18_192)] font-semibold">Previous</TableHead>
                              <TableHead className="text-right text-[oklch(0.85_0.18_192)] font-semibold">New</TableHead>
                              <TableHead className="text-right text-[oklch(0.85_0.18_192)] font-semibold">Change</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {weeklySummary.dailyChanges.flatMap((day) =>
                              day.changes.map((c, idx) => (
                                <TableRow key={`${day.date}-${c.building}`} className="border-b border-border/50">
                                  {idx === 0 ? (
                                    <TableCell rowSpan={day.changes.length} className="font-medium text-foreground align-top whitespace-nowrap">
                                      {new Date(day.date + 'T00:00:00').toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}
                                    </TableCell>
                                  ) : null}
                                  <TableCell className="text-foreground">{c.building}</TableCell>
                                  <TableCell className="text-right text-muted-foreground">{c.prevVacant}</TableCell>
                                  <TableCell className="text-right font-medium text-foreground">{c.newVacant}</TableCell>
                                  <TableCell className={`text-right font-bold ${c.change > 0 ? 'neon-red' : 'neon-green'}`}>
                                    {c.change > 0 ? '+' : ''}{c.change}
                                  </TableCell>
                                </TableRow>
                              ))
                            )}
                          </TableBody>
                        </Table>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}

              {/* Unchanged buildings count */}
              {weeklySummary.buildingTrends.filter(b => b.netChange === 0).length > 0 && (
                <div className="flex items-center gap-2 text-xs text-muted-foreground px-1">
                  <Minus className="w-3.5 h-3.5" />
                  <span>{weeklySummary.buildingTrends.filter(b => b.netChange === 0).length} building{weeklySummary.buildingTrends.filter(b => b.netChange === 0).length !== 1 ? 's' : ''} unchanged over the week</span>
                </div>
              )}
            </div>
          )}
        </section>

        {/* ── At-Risk Properties ── */}
        {atRiskBuildings.length > 0 && (
          <section>
            <h2 className="text-xs font-bold uppercase tracking-widest mb-4 flex items-center gap-2">
              <span className="neon-red">At-Risk Properties</span>
              <Badge className="bg-[oklch(0.68_0.25_25_/_15%)] text-[oklch(0.68_0.25_25)] border border-[oklch(0.68_0.25_25_/_30%)] text-xs">Vacancy &gt; 4%</Badge>
            </h2>
            <Card className="neon-card-magenta rounded-xl overflow-hidden border-[oklch(0.68_0.25_25_/_25%)] shadow-[0_0_15px_oklch(0.68_0.25_25_/_10%)]">
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-[oklch(0.68_0.25_25_/_8%)] border-b border-[oklch(0.68_0.25_25_/_20%)]">
                        <TableHead className="text-[oklch(0.68_0.25_25)] font-semibold cursor-pointer select-none hover:text-[oklch(0.78_0.25_25)] transition-colors" onClick={() => toggleAtRiskSort("name")}>
                          Building <SortIcon field="name" sort={atRiskSort} />
                        </TableHead>
                        <TableHead className="text-center text-[oklch(0.68_0.25_25)] font-semibold cursor-pointer select-none hover:text-[oklch(0.78_0.25_25)] transition-colors" onClick={() => toggleAtRiskSort("vacancyPct")}>
                          Vacancy % <SortIcon field="vacancyPct" sort={atRiskSort} />
                        </TableHead>
                        <TableHead className="text-center text-[oklch(0.68_0.25_25)] font-semibold cursor-pointer select-none hover:text-[oklch(0.78_0.25_25)] transition-colors" onClick={() => toggleAtRiskSort("totalVacant")}>
                          Vacant Units <SortIcon field="totalVacant" sort={atRiskSort} />
                        </TableHead>
                        <TableHead className="text-center text-[oklch(0.68_0.25_25)] font-semibold cursor-pointer select-none hover:text-[oklch(0.78_0.25_25)] transition-colors" onClick={() => toggleAtRiskSort("totalUnits")}>
                          Total Units <SortIcon field="totalUnits" sort={atRiskSort} />
                        </TableHead>
                        <TableHead className="text-center text-[oklch(0.78_0.20_55)] font-semibold cursor-pointer select-none hover:text-[oklch(0.88_0.20_55)] transition-colors" onClick={() => toggleAtRiskSort("vacUnleased")}>
                          Unleased <SortIcon field="vacUnleased" sort={atRiskSort} />
                        </TableHead>
                        <TableHead className="text-center text-[oklch(0.82_0.22_145)] font-semibold cursor-pointer select-none hover:text-[oklch(0.92_0.22_145)] transition-colors" onClick={() => toggleAtRiskSort("vacPreleased")}>
                          Preleased <SortIcon field="vacPreleased" sort={atRiskSort} />
                        </TableHead>
                        <TableHead className="text-center text-[oklch(0.68_0.22_290)] font-semibold cursor-pointer select-none hover:text-[oklch(0.78_0.22_290)] transition-colors" onClick={() => toggleAtRiskSort("onNotice")}>
                          Notice <SortIcon field="onNotice" sort={atRiskSort} />
                        </TableHead>
                        <TableHead className="text-center text-[oklch(0.72_0.25_330)] font-semibold cursor-pointer select-none hover:text-[oklch(0.82_0.25_330)] transition-colors" onClick={() => toggleAtRiskSort("eviction")}>
                          Eviction <SortIcon field="eviction" sort={atRiskSort} />
                        </TableHead>
                        <TableHead className="text-center text-[oklch(0.68_0.25_25)] font-semibold">Trend</TableHead>
                        <TableHead className="text-center text-[oklch(0.85_0.12_85)] font-semibold">Change</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {atRiskBuildings.map((b: { name: string; totalVacant: number; vacUnleased: number; vacPreleased: number; onNotice: number; eviction: number; totalUnits: number; vacancyPct: number; atRisk: boolean }) => (
                        <TableRow key={`vac-${b.name}`} data-building-name={b.name} className="border-b border-[oklch(0.68_0.25_25_/_10%)] hover:bg-[oklch(0.68_0.25_25_/_5%)] transition-colors">
                          <TableCell className="font-medium text-foreground">
                            <div className="flex items-center gap-2">
                              <AlertTriangle className="w-3.5 h-3.5 neon-red" />
                              {b.name}
                            </div>
                          </TableCell>
                          <TableCell className="text-center">
                            <span className="font-black text-lg neon-red">{b.vacancyPct}%</span>
                          </TableCell>
                          <TableCell className="text-center">
                            <span className="font-bold text-lg neon-orange">{b.totalVacant}</span>
                          </TableCell>
                          <TableCell className="text-center text-muted-foreground font-medium">{b.totalUnits || "—"}</TableCell>
                          <TableCell className="text-center font-medium neon-orange">{b.vacUnleased || "—"}</TableCell>
                          <TableCell className="text-center font-medium neon-green">{b.vacPreleased || "—"}</TableCell>
                          <TableCell className="text-center font-medium neon-purple">{b.onNotice || "—"}</TableCell>
                          <TableCell className="text-center font-medium neon-magenta">{b.eviction || "—"}</TableCell>
                          <TableCell className="text-center">
                            {(() => {
                              const vals = buildingSparklines.get(b.name) || [];
                              const dates = buildingSparklineDates.get(b.name) || [];
                              if (vals.length < 2) return <Sparkline data={vals} width={80} height={24} />;
                              const trend = describeTrend(b.name, vals, dates);
                              return (
                                <Popover>
                                  <PopoverTrigger asChild>
                                    <button className="cursor-pointer rounded hover:ring-1 hover:ring-white/20 transition-all" title="Click for trend details">
                                      <Sparkline data={vals} width={80} height={24} />
                                    </button>
                                  </PopoverTrigger>
                                  <PopoverContent side="left" className="w-72 p-3 text-xs">
                                    <p className={`font-bold text-sm mb-1 ${trend.color}`}>{trend.headline}</p>
                                    <p className="text-muted-foreground leading-relaxed">{trend.body}</p>
                                  </PopoverContent>
                                </Popover>
                              );
                            })()}
                          </TableCell>
                          <TableCell className="text-center text-lg">
                            {dailyChangeMap.has(b.name) ? (
                              <span className="flex items-center justify-center gap-1">
                                {dailyChangeMap.get(b.name)! < 0 ? (
                                  <><span role="img" aria-label="leased">👍</span> <span className="text-sm font-bold neon-green">{dailyChangeMap.get(b.name)}</span></>
                                ) : (
                                  <><span role="img" aria-label="vacant">👎</span> <span className="text-sm font-bold neon-red">+{dailyChangeMap.get(b.name)}</span></>
                                )}
                              </span>
                            ) : (
                              <span className="text-muted-foreground text-sm">—</span>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </section>
        )}

        {/* ── Building Vacancy ── */}
        <section>
          <h2 className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-4">
            Vacancy by Building
          </h2>
          <Card className="neon-card rounded-xl overflow-hidden">
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-[oklch(0.85_0.18_192_/_5%)] border-b border-[oklch(0.85_0.18_192_/_15%)]">
                      <TableHead className="text-[oklch(0.85_0.18_192)] font-semibold">Building</TableHead>
                      <TableHead className="text-center text-[oklch(0.85_0.18_192)] font-semibold">Vac %</TableHead>
                      <TableHead className="text-center text-[oklch(0.85_0.18_192)] font-semibold">Total Units</TableHead>
                      <TableHead className="text-right text-[oklch(0.85_0.18_192)] font-semibold">Total Vacant</TableHead>
                      <TableHead className="text-right text-[oklch(0.78_0.20_55)] font-semibold">Unleased</TableHead>
                      <TableHead className="text-right text-[oklch(0.82_0.22_145)] font-semibold">Preleased</TableHead>
                      <TableHead className="text-right text-[oklch(0.68_0.22_290)] font-semibold">On Notice</TableHead>
                      <TableHead className="text-right text-[oklch(0.72_0.25_330)] font-semibold">Eviction</TableHead>
                      <TableHead className="text-center text-[oklch(0.85_0.18_192)] font-semibold">Trend</TableHead>
                      <TableHead className="text-center text-[oklch(0.85_0.12_85)] font-semibold">Change</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {buildingVacancy.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={10} className="text-center text-muted-foreground py-8">
                          No building vacancy data available
                        </TableCell>
                      </TableRow>
                    ) : (
                      buildingVacancy.map((b: { name: string; totalVacant: number; vacUnleased: number; vacPreleased: number; onNotice: number; eviction: number; totalUnits: number; vacancyPct: number; atRisk: boolean }) => (
                        <TableRow key={`risk-${b.name}`} data-building-name={b.name} className={`border-b border-border/50 hover:bg-[oklch(0.85_0.18_192_/_3%)] transition-colors ${b.atRisk ? "bg-[oklch(0.68_0.25_25_/_3%)]" : ""}`}>
                          <TableCell className="font-medium text-foreground">
                            <div className="flex items-center gap-2">
                              <Building2 className={`w-3.5 h-3.5 ${b.atRisk ? "neon-red" : "text-muted-foreground"}`} />
                              {b.name}
                              {b.atRisk && <Badge className="bg-[oklch(0.68_0.25_25_/_15%)] text-[oklch(0.68_0.25_25)] border border-[oklch(0.68_0.25_25_/_30%)] text-[10px] px-1.5 py-0">AT RISK</Badge>}
                            </div>
                          </TableCell>
                          <TableCell className="text-center">
                            <span className={`font-bold ${b.vacancyPct > 4 ? "neon-red" : b.vacancyPct > 2 ? "neon-orange" : "neon-green"}`}>
                              {b.vacancyPct}%
                            </span>
                          </TableCell>
                          <TableCell className="text-center text-muted-foreground">{b.totalUnits || "—"}</TableCell>
                          <TableCell className="text-right">
                            <span className={`font-bold text-lg ${b.totalVacant > 5 ? "neon-red" : b.totalVacant > 2 ? "neon-orange" : "neon-green"}`}>
                              {b.totalVacant}
                            </span>
                          </TableCell>
                          <TableCell className="text-right font-medium neon-orange">{b.vacUnleased || "—"}</TableCell>
                          <TableCell className="text-right font-medium neon-green">{b.vacPreleased || "—"}</TableCell>
                          <TableCell className="text-right font-medium neon-purple">{b.onNotice || "—"}</TableCell>
                          <TableCell className="text-right font-medium neon-magenta">{b.eviction || "—"}</TableCell>
                          <TableCell className="text-center">
                            {(() => {
                              const vals = buildingSparklines.get(b.name) || [];
                              const dates = buildingSparklineDates.get(b.name) || [];
                              if (vals.length < 2) return <Sparkline data={vals} width={80} height={24} />;
                              const trend = describeTrend(b.name, vals, dates);
                              return (
                                <Popover>
                                  <PopoverTrigger asChild>
                                    <button className="cursor-pointer rounded hover:ring-1 hover:ring-white/20 transition-all" title="Click for trend details">
                                      <Sparkline data={vals} width={80} height={24} />
                                    </button>
                                  </PopoverTrigger>
                                  <PopoverContent side="left" className="w-72 p-3 text-xs">
                                    <p className={`font-bold text-sm mb-1 ${trend.color}`}>{trend.headline}</p>
                                    <p className="text-muted-foreground leading-relaxed">{trend.body}</p>
                                  </PopoverContent>
                                </Popover>
                              );
                            })()}
                          </TableCell>
                          <TableCell className="text-center text-lg">
                            {dailyChangeMap.has(b.name) ? (
                              <span className="flex items-center justify-center gap-1">
                                {dailyChangeMap.get(b.name)! < 0 ? (
                                  <><span role="img" aria-label="leased">👍</span> <span className="text-sm font-bold neon-green">{dailyChangeMap.get(b.name)}</span></>
                                ) : (
                                  <><span role="img" aria-label="vacant">👎</span> <span className="text-sm font-bold neon-red">+{dailyChangeMap.get(b.name)}</span></>
                                )}
                              </span>
                            ) : (
                              <span className="text-muted-foreground text-sm">—</span>
                            )}
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* ── Unit Tables ── */}
        <section>
          <h2 className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-4">
            Unit Details
          </h2>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <div className="mb-3">
              <div className="relative">
                <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  value={unitSearchQuery}
                  onChange={(event) => setUnitSearchQuery(event.target.value)}
                  placeholder="Search unit, building, or manager…"
                  aria-label="Search all unit details"
                  className="h-11 rounded-xl border-[oklch(0.85_0.18_192_/_30%)] bg-[oklch(0.85_0.18_192_/_5%)] pl-10 pr-10 text-sm shadow-sm"
                />
                {unitSearchQuery && (
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="absolute right-1 top-1/2 h-9 w-9 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                    onClick={() => setUnitSearchQuery("")}
                    aria-label="Clear unit search"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                )}
              </div>
              <div className="mt-1.5 flex items-center justify-between px-1 text-[11px] text-muted-foreground">
                <span>Searches all Unit Details tabs</span>
                {unitSearchQuery && <span className="font-medium text-foreground">{visibleUnitCount} matches</span>}
              </div>
            </div>

            <div className="relative mb-4">
              <div className="-mx-1 overflow-x-auto overscroll-x-contain px-1 pb-1 [scrollbar-width:thin]">
                <TabsList className="h-auto min-w-max justify-start gap-1 bg-secondary/50 border border-border p-1">
                <TabsTrigger value="unleased" className="shrink-0 min-h-10 px-2 sm:px-3 flex items-center gap-1.5 whitespace-nowrap text-xs sm:text-sm font-semibold transition-all data-[state=active]:bg-[oklch(0.78_0.16_205)] data-[state=active]:text-[oklch(0.16_0.03_240)] data-[state=active]:font-extrabold data-[state=active]:shadow-[0_2px_12px_oklch(0.78_0.16_205_/_40%)]">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>Vacant / Unleased</span>
                  <Badge variant="secondary" className="ml-0.5 text-[10px] sm:text-xs bg-[oklch(0.78_0.20_55_/_15%)] text-[oklch(0.78_0.20_55)]">{vacantUnleased.length}</Badge>
                </TabsTrigger>
                <TabsTrigger value="preleased" className="shrink-0 min-h-10 px-2 sm:px-3 flex items-center gap-1.5 whitespace-nowrap text-xs sm:text-sm font-semibold transition-all data-[state=active]:bg-[oklch(0.75_0.18_145)] data-[state=active]:text-[oklch(0.16_0.03_145)] data-[state=active]:font-extrabold data-[state=active]:shadow-[0_2px_12px_oklch(0.75_0.18_145_/_40%)]">
                  <TrendingUp className="w-3.5 h-3.5" />
                  <span>Vacant / Preleased</span>
                  <Badge variant="secondary" className="ml-0.5 text-[10px] sm:text-xs bg-[oklch(0.82_0.22_145_/_15%)] text-[oklch(0.82_0.22_145)]">{vacantPreleased.length}</Badge>
                </TabsTrigger>
                <TabsTrigger value="notice" className="shrink-0 min-h-10 px-2 sm:px-3 flex items-center gap-1.5 whitespace-nowrap text-xs sm:text-sm font-semibold transition-all data-[state=active]:bg-[oklch(0.70_0.18_290)] data-[state=active]:text-[oklch(0.16_0.03_290)] data-[state=active]:font-extrabold data-[state=active]:shadow-[0_2px_12px_oklch(0.70_0.18_290_/_40%)]">
                  <Clock className="w-3.5 h-3.5" />
                  <span>On Notice</span>
                  <Badge variant="secondary" className="ml-0.5 text-[10px] sm:text-xs bg-[oklch(0.68_0.22_290_/_15%)] text-[oklch(0.68_0.22_290)]">{onNotice.length}</Badge>
                </TabsTrigger>
                <TabsTrigger value="eviction" className="shrink-0 min-h-10 px-2 sm:px-3 flex items-center gap-1.5 whitespace-nowrap text-xs sm:text-sm font-semibold transition-all data-[state=active]:bg-[oklch(0.68_0.20_330)] data-[state=active]:text-[oklch(0.16_0.03_330)] data-[state=active]:font-extrabold data-[state=active]:shadow-[0_2px_12px_oklch(0.68_0.20_330_/_40%)]">
                  <Gavel className="w-3.5 h-3.5" />
                  <span>Evictions</span>
                  <Badge variant="secondary" className="ml-0.5 text-[10px] sm:text-xs bg-[oklch(0.72_0.25_330_/_15%)] text-[oklch(0.72_0.25_330)]">{evictions.length}</Badge>
                </TabsTrigger>
                <TabsTrigger value="collections" className="shrink-0 min-h-10 px-2 sm:px-3 flex items-center gap-1.5 whitespace-nowrap text-xs sm:text-sm font-semibold transition-all data-[state=active]:bg-[oklch(0.78_0.17_85)] data-[state=active]:text-[oklch(0.18_0.03_85)] data-[state=active]:font-extrabold data-[state=active]:shadow-[0_2px_12px_oklch(0.78_0.17_85_/_40%)]">
                  <DollarSign className="w-3.5 h-3.5" />
                  <span>Collections</span>
                </TabsTrigger>
                </TabsList>
              </div>
              <div aria-hidden="true" className="pointer-events-none absolute inset-y-0 right-0 w-12 bg-gradient-to-l from-background via-background/90 to-transparent" />
              <div aria-hidden="true" className="pointer-events-none absolute right-1 top-1/2 -translate-y-1/2 rounded-full border border-border/60 bg-background/90 p-1 shadow-sm">
                <ChevronRight className="h-3.5 w-3.5 text-muted-foreground" />
              </div>
            </div>

            {/* Vacant / Unleased */}
            <TabsContent value="unleased">
              <Card className="neon-card rounded-xl overflow-hidden">
                <CardContent className="p-0">
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-[oklch(0.85_0.18_192_/_5%)] border-b border-[oklch(0.85_0.18_192_/_15%)]">
                          <TableHead className="text-[oklch(0.85_0.18_192)] font-semibold">Date / By</TableHead>
                          <TableHead className="text-[oklch(0.85_0.18_192)] font-semibold">Building</TableHead>
                          <TableHead className="text-[oklch(0.85_0.18_192)] font-semibold">Unit</TableHead>
                          <TableHead className="text-[oklch(0.85_0.18_192)] font-semibold">Move Out</TableHead>
                          <TableHead className="text-right text-[oklch(0.85_0.18_192)] font-semibold">Days</TableHead>
                          <TableHead className="text-right text-[oklch(0.85_0.18_192)] font-semibold">Beds</TableHead>
                          <TableHead className="text-right text-[oklch(0.85_0.18_192)] font-semibold">Ask Rent</TableHead>
                          <TableHead className="text-right text-[oklch(0.85_0.18_192)] font-semibold">% Ready</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredVacantUnleased.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={8} className="text-center text-muted-foreground py-8">
                              {unitSearchQuery ? "No vacant/unleased units match your search" : "No vacant/unleased units"}
                            </TableCell>
                          </TableRow>
                        ) : (
                          filteredVacantUnleased.map((unit: { dateBy: string; building: string; unit: string; moveOut: string; days: number; beds: number; askRent: number; percentReady: number }, i: number) => (
                            <TableRow key={i} className={`border-b border-border/50 transition-colors ${!unit.askRent ? "bg-[oklch(0.85_0.18_85_/_8%)] border-l-2 border-l-[oklch(0.78_0.20_85)] hover:bg-[oklch(0.85_0.18_85_/_14%)]" : "hover:bg-[oklch(0.85_0.18_192_/_3%)]"}`}>
                              <TableCell className="text-xs text-muted-foreground whitespace-nowrap">
                                {unit.dateBy}
                              </TableCell>
                              <TableCell className="font-medium text-foreground">{unit.building}</TableCell>
                              <TableCell className="text-foreground">{unit.unit}</TableCell>
                              <TableCell className="whitespace-nowrap text-foreground">{unit.moveOut}</TableCell>
                              <TableCell className="text-right">
                                <span className={`font-bold ${unit.days > 60 ? "neon-red" : unit.days > 30 ? "neon-orange" : unit.days > 14 ? "neon-yellow" : "neon-green"}`}>
                                  {unit.days || "—"}
                                </span>
                              </TableCell>
                              <TableCell className="text-right text-foreground">{unit.beds || "—"}</TableCell>
                              <TableCell className="text-right font-medium neon-cyan">
                                {(unit.askRent != null && unit.askRent !== undefined) ? (unit.askRent > 0 ? formatCurrency(unit.askRent) : (
                                  <span className="inline-flex items-center gap-1 justify-end">
                                    <span className="text-[oklch(0.65_0.18_85)] text-xs italic font-medium">Not set</span>
                                    <Tooltip>
                                      <TooltipTrigger asChild>
                                        <Info className="w-3.5 h-3.5 text-[oklch(0.65_0.18_85)] cursor-help shrink-0" />
                                      </TooltipTrigger>
                                      <TooltipContent side="left" className="max-w-[260px] text-xs leading-relaxed">
                                        <p className="font-semibold mb-1">Ask Rent not set in PropertyMax.ai</p>
                                        <p>To fix: log in to PropertyMax.ai → navigate to the unit → open the unit detail page → enter the asking rent in the <strong>Ask Rent</strong> field and save.</p>
                                      </TooltipContent>
                                    </Tooltip>
                                  </span>
                                )) : "—"}
                              </TableCell>
                              <TableCell className="text-right">
                                {unit.percentReady ? (
                                  <span className={`font-medium ${unit.percentReady >= 80 ? "neon-green" : unit.percentReady >= 50 ? "neon-yellow" : "neon-orange"}`}>
                                    {unit.percentReady}%
                                  </span>
                                ) : "—"}
                              </TableCell>
                            </TableRow>
                          ))
                        )}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Vacant / Preleased */}
            <TabsContent value="preleased">
              <Card className="neon-card neon-card-green rounded-xl overflow-hidden">
                <CardContent className="p-0">
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-[oklch(0.82_0.22_145_/_5%)] border-b border-[oklch(0.82_0.22_145_/_15%)]">
                          <TableHead className="text-[oklch(0.82_0.22_145)] font-semibold">Date / By</TableHead>
                          <TableHead className="text-[oklch(0.82_0.22_145)] font-semibold">Building</TableHead>
                          <TableHead className="text-[oklch(0.82_0.22_145)] font-semibold">Unit</TableHead>
                          <TableHead className="text-[oklch(0.82_0.22_145)] font-semibold">Move Out</TableHead>
                          <TableHead className="text-[oklch(0.82_0.22_145)] font-semibold">Move In</TableHead>
                          <TableHead className="text-right text-[oklch(0.82_0.22_145)] font-semibold">Days</TableHead>
                          <TableHead className="text-right text-[oklch(0.82_0.22_145)] font-semibold">Beds</TableHead>
                          <TableHead className="text-right text-[oklch(0.82_0.22_145)] font-semibold">Ask Rent</TableHead>
                          <TableHead className="text-right text-[oklch(0.82_0.22_145)] font-semibold">% Ready</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredVacantPreleased.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={9} className="text-center text-muted-foreground py-8">
                              {unitSearchQuery ? "No vacant/preleased units match your search" : "No vacant/preleased units"}
                            </TableCell>
                          </TableRow>
                        ) : (
                          filteredVacantPreleased.map((unit: { dateBy: string; building: string; unit: string; moveOut: string; moveIn: string; days: number; beds: number; askRent: number; percentReady: number }, i: number) => (
                            <TableRow key={i} className={`border-b border-border/50 transition-colors ${!unit.askRent ? "bg-[oklch(0.85_0.18_85_/_8%)] border-l-2 border-l-[oklch(0.78_0.20_85)] hover:bg-[oklch(0.85_0.18_85_/_14%)]" : "hover:bg-[oklch(0.82_0.22_145_/_3%)]"}`}>
                              <TableCell className="text-xs text-muted-foreground whitespace-nowrap">
                                {unit.dateBy}
                              </TableCell>
                              <TableCell className="font-medium text-foreground">{unit.building}</TableCell>
                              <TableCell className="text-foreground">{unit.unit}</TableCell>
                              <TableCell className="whitespace-nowrap text-foreground">{unit.moveOut}</TableCell>
                              <TableCell className="whitespace-nowrap neon-green">{unit.moveIn || "—"}</TableCell>
                              <TableCell className="text-right">
                                <span className={`font-bold ${unit.days > 60 ? "neon-red" : unit.days > 30 ? "neon-orange" : unit.days > 14 ? "neon-yellow" : "neon-green"}`}>
                                  {unit.days || "—"}
                                </span>
                              </TableCell>
                              <TableCell className="text-right text-foreground">{unit.beds || "—"}</TableCell>
                              <TableCell className="text-right font-medium neon-cyan">
                                {(unit.askRent != null && unit.askRent !== undefined) ? (unit.askRent > 0 ? formatCurrency(unit.askRent) : (
                                  <span className="inline-flex items-center gap-1 justify-end">
                                    <span className="text-[oklch(0.65_0.18_85)] text-xs italic font-medium">Not set</span>
                                    <Tooltip>
                                      <TooltipTrigger asChild>
                                        <Info className="w-3.5 h-3.5 text-[oklch(0.65_0.18_85)] cursor-help shrink-0" />
                                      </TooltipTrigger>
                                      <TooltipContent side="left" className="max-w-[260px] text-xs leading-relaxed">
                                        <p className="font-semibold mb-1">Ask Rent not set in PropertyMax.ai</p>
                                        <p>To fix: log in to PropertyMax.ai → navigate to the unit → open the unit detail page → enter the asking rent in the <strong>Ask Rent</strong> field and save.</p>
                                      </TooltipContent>
                                    </Tooltip>
                                  </span>
                                )) : "—"}
                              </TableCell>
                              <TableCell className="text-right">
                                {unit.percentReady ? (
                                  <span className={`font-medium ${unit.percentReady >= 80 ? "neon-green" : unit.percentReady >= 50 ? "neon-yellow" : "neon-orange"}`}>
                                    {unit.percentReady}%
                                  </span>
                                ) : "—"}
                              </TableCell>
                            </TableRow>
                          ))
                        )}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* On Notice */}
            <TabsContent value="notice">
              <Card className="neon-card neon-card-magenta rounded-xl overflow-hidden">
                <CardContent className="p-0">
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-[oklch(0.68_0.22_290_/_5%)] border-b border-[oklch(0.68_0.22_290_/_15%)]">
                          <TableHead className="text-[oklch(0.68_0.22_290)] font-semibold">Building</TableHead>
                          <TableHead className="text-[oklch(0.68_0.22_290)] font-semibold">Unit</TableHead>
                          <TableHead className="text-[oklch(0.68_0.22_290)] font-semibold">Leased</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredOnNotice.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={3} className="text-center text-muted-foreground py-8">
                              {unitSearchQuery ? "No units on notice match your search" : "No units on notice"}
                            </TableCell>
                          </TableRow>
                        ) : (
                          filteredOnNotice.map((unit: { building: string; unit: string; leased: string }, i: number) => (
                            <TableRow key={i} className="border-b border-border/50 hover:bg-[oklch(0.68_0.22_290_/_3%)] transition-colors">
                              <TableCell className="font-medium text-foreground">{unit.building}</TableCell>
                              <TableCell className="text-foreground">{unit.unit}</TableCell>
                              <TableCell>
                                {unit.leased === "Y" ? (
                                  <Badge className="bg-[oklch(0.82_0.22_145_/_15%)] text-[oklch(0.82_0.22_145)] border border-[oklch(0.82_0.22_145_/_30%)]">
                                    Leased
                                  </Badge>
                                ) : (
                                  <Badge className="bg-[oklch(0.68_0.25_25_/_15%)] text-[oklch(0.68_0.25_25)] border border-[oklch(0.68_0.25_25_/_30%)]">
                                    Not Leased
                                  </Badge>
                                )}
                              </TableCell>
                            </TableRow>
                          ))
                        )}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Evictions */}
            <TabsContent value="eviction">
              <Card className="neon-card neon-card-magenta rounded-xl overflow-hidden">
                <CardContent className="p-0">
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-[oklch(0.72_0.25_330_/_5%)] border-b border-[oklch(0.72_0.25_330_/_15%)]">
                          <TableHead className="text-[oklch(0.72_0.25_330)] font-semibold">Building</TableHead>
                          <TableHead className="text-[oklch(0.72_0.25_330)] font-semibold">Unit</TableHead>
                          <TableHead className="text-[oklch(0.72_0.25_330)] font-semibold">Dates</TableHead>
                          <TableHead className="text-right text-[oklch(0.72_0.25_330)] font-semibold">Amount Owed</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredEvictions.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={4} className="text-center text-muted-foreground py-8">
                              {unitSearchQuery ? "No active evictions match your search" : "No active evictions"}
                            </TableCell>
                          </TableRow>
                        ) : (
                          filteredEvictions.map((unit: { building: string; unit: string; dates: string; amountOwed: number }, i: number) => (
                            <TableRow key={i} className="border-b border-border/50 hover:bg-[oklch(0.72_0.25_330_/_3%)] transition-colors">
                              <TableCell className="font-medium text-foreground">{unit.building}</TableCell>
                              <TableCell className="text-foreground">{unit.unit}</TableCell>
                              <TableCell className="text-muted-foreground">{unit.dates || "—"}</TableCell>
                              <TableCell className="text-right font-bold neon-red">
                                {(unit.amountOwed != null && unit.amountOwed !== undefined) ? formatCurrency(unit.amountOwed) : "Not listed"}
                              </TableCell>
                            </TableRow>
                          ))
                        )}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Collections Intelligence: FLOW tab data */}
            <TabsContent value="collections">
              <CollectionsPanel />
            </TabsContent>
          </Tabs>
        </section>

        {/* ── PIN Dialog Overlay ── */}
        {showPinDialog && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm">
            <Card className="w-full max-w-sm mx-4 neon-card rounded-2xl border-[oklch(0.85_0.12_85_/_25%)] shadow-[0_0_30px_oklch(0.85_0.12_85_/_15%)] bg-card">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-[oklch(0.85_0.12_85_/_10%)]">
                      <ShieldCheck className="w-5 h-5 text-[oklch(0.85_0.12_85)]" />
                    </div>
                    <div>
                      <h3 className="text-lg font-bold text-foreground">Admin Access</h3>
                      <p className="text-xs text-muted-foreground">Enter PIN to unlock financial data</p>
                    </div>
                  </div>
                  <button
                    onClick={() => { setShowPinDialog(false); setPinValue(""); setPinError(false); }}
                    className="text-muted-foreground hover:text-foreground transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
                <div className="space-y-4">
                  <div>
                    <input
                      ref={pinInputRef}
                      type="password"
                      inputMode="numeric"
                      maxLength={10}
                      value={pinValue}
                      onChange={(e) => { setPinValue(e.target.value); setPinError(false); }}
                      onKeyDown={(e) => { if (e.key === "Enter") handlePinSubmit(); }}
                      placeholder="Enter PIN"
                      className={`w-full px-4 py-3 text-center text-2xl font-bold tracking-[0.5em] rounded-xl bg-[oklch(0.15_0.02_260)] border-2 transition-all focus:outline-none ${
                        pinError
                          ? "border-[oklch(0.68_0.25_25)] text-[oklch(0.68_0.25_25)] shake-animation"
                          : "border-[oklch(0.85_0.12_85_/_30%)] text-foreground focus:border-[oklch(0.85_0.12_85_/_60%)] focus:shadow-[0_0_15px_oklch(0.85_0.12_85_/_15%)]"
                      }`}
                    />
                    {pinError && (
                      <p className="text-xs text-[oklch(0.68_0.25_25)] mt-2 text-center font-medium">Incorrect PIN. Please try again.</p>
                    )}
                  </div>
                  <Button
                    onClick={handlePinSubmit}
                    disabled={pinValue.length === 0 || verifyPinMutation.isPending}
                    className="w-full bg-[oklch(0.85_0.12_85_/_20%)] text-[oklch(0.85_0.12_85)] border border-[oklch(0.85_0.12_85_/_30%)] hover:bg-[oklch(0.85_0.12_85_/_30%)] font-bold py-3 rounded-xl transition-all"
                  >
                    {verifyPinMutation.isPending ? (
                      <Loader2 className="w-4 h-4 animate-spin mr-2" />
                    ) : (
                      <Unlock className="w-4 h-4 mr-2" />
                    )}
                    Unlock
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* ── Email Preview (Admin Only) ── */}
        {isAdmin && storedPin && (
          <section>
            <h2 className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-4">
              Email Report Preview
            </h2>
            <div className="flex gap-3">
              <button
                onClick={() => setPreviewType("daily")}
                className="flex items-center gap-2 px-4 py-3 rounded-xl border border-[oklch(0.72_0.25_330_/_30%)] bg-[oklch(0.72_0.25_330_/_8%)] text-[oklch(0.72_0.25_330)] hover:bg-[oklch(0.72_0.25_330_/_15%)] transition-all text-sm font-bold"
              >
                <Eye className="w-4 h-4" />
                Preview Daily Report
              </button>
              <button
                onClick={() => setPreviewType("weekly")}
                className="flex items-center gap-2 px-4 py-3 rounded-xl border border-[oklch(0.82_0.22_145_/_30%)] bg-[oklch(0.82_0.22_145_/_8%)] text-[oklch(0.82_0.22_145)] hover:bg-[oklch(0.82_0.22_145_/_15%)] transition-all text-sm font-bold"
              >
                <CalendarDays className="w-4 h-4" />
                Preview Weekly Summary
              </button>
            </div>
          </section>
        )}

        {/* ── Email Recipients Management (Admin Only) ── */}
        {isAdmin && storedPin && (
          <EmailRecipientsManager adminPin={storedPin} />
        )}

        {/* ── Unit Count Overrides (Admin Only) ── */}
        {isAdmin && storedPin && (
          <UnitCountOverrideManager adminPin={storedPin} />
        )}

        {/* ── Historical Marc's Net Cash (Admin Only) ── */}
        {isAdmin && storedPin && (
          <section>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xs font-bold uppercase tracking-widest text-muted-foreground">
                Historical Marc's Net Cash — Complete Months
              </h2>
              <div className="flex items-center gap-2">
                {/* Test Connection button */}
                <button
                  onClick={() => { setConnStatus(null); testConnectionMutation.mutate({ pin: storedPin }); }}
                  disabled={testConnectionMutation.isPending}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[oklch(0.55_0.2_250_/_40%)] bg-[oklch(0.55_0.2_250_/_10%)] text-[oklch(0.7_0.18_250)] hover:bg-[oklch(0.55_0.2_250_/_20%)] transition-all text-xs font-bold disabled:opacity-50"
                >
                  {testConnectionMutation.isPending ? (
                    <Loader2 className="w-3 h-3 animate-spin" />
                  ) : (
                    <Wifi className="w-3 h-3" />
                  )}
                  Test Connection
                </button>
                {/* Status indicator */}
                {connStatus !== null && (
                  <span className={`flex items-center gap-1 text-xs font-semibold ${
                    connStatus.success ? "text-green-400" : "text-red-400"
                  }`}>
                    {connStatus.success
                      ? <><CheckCircle2 className="w-3 h-3" /> OK ({connStatus.latencyMs}ms)</>
                      : <><XCircle className="w-3 h-3" /> Failed</>}
                  </span>
                )}
                {/* Clear Cache button */}
                <button
                  onClick={() => clearHistoricalCacheMutation.mutate({ pin: storedPin })}
                  disabled={clearHistoricalCacheMutation.isPending}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[oklch(0.68_0.25_25_/_30%)] bg-[oklch(0.68_0.25_25_/_8%)] text-[oklch(0.68_0.25_25)] hover:bg-[oklch(0.68_0.25_25_/_15%)] transition-all text-xs font-bold disabled:opacity-50"
                >
                  {clearHistoricalCacheMutation.isPending ? (
                    <Loader2 className="w-3 h-3 animate-spin" />
                  ) : (
                    <RefreshCw className="w-3 h-3" />
                  )}
                  Clear & Re-fetch Cache
                </button>
              </div>
            </div>
            <Card className="neon-card rounded-xl">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-lg text-foreground">
                      {currentHistMonth?.label ?? "—"}
                    </CardTitle>
                    {currentHistMonth && (
                      <p className="text-2xl font-black mt-1 neon-cyan">
                        Grand Total: {formatCurrency(currentHistMonth.grandTotal)}
                      </p>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => setHistoryIndex((i) => i + 1)}
                      disabled={!canGoPrev}
                      className="border-border hover:bg-secondary"
                    >
                      <ChevronLeft className="w-4 h-4" />
                    </Button>
                    <span className="text-sm text-muted-foreground min-w-[80px] text-center">
                      {historyIndex + 1} / {historicalMonths.length}
                    </span>
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => setHistoryIndex((i) => i - 1)}
                      disabled={!canGoNext}
                      className="border-border hover:bg-secondary"
                    >
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                {/* Month selector pills */}
                <div className="flex flex-wrap gap-2 mt-3">
                  {historicalMonths.map((m: { label: string; monthName: string; year: number }, idx: number) => (
                    <button
                      key={m.label}
                      onClick={() => setHistoryIndex(idx)}
                      className={`px-3 py-1 rounded-full text-xs font-semibold transition-all ${
                        idx === historyIndex
                          ? "bg-[oklch(0.85_0.18_192_/_20%)] text-[oklch(0.85_0.18_192)] border border-[oklch(0.85_0.18_192_/_40%)] shadow-[0_0_8px_oklch(0.85_0.18_192_/_20%)]"
                          : "bg-secondary text-muted-foreground border border-transparent hover:bg-[oklch(0.85_0.18_192_/_8%)] hover:text-[oklch(0.85_0.18_192_/_70%)]"
                      }`}
                    >
                      {m.monthName.slice(0, 3)} {m.year}
                    </button>
                  ))}
                </div>
              </CardHeader>

              {currentHistMonth && (
                <CardContent>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                    {currentHistMonth.regions.map((region: { region: number; regionName: string; total: number; buildings: { name: string; value: number }[] }, idx: number) => {
                      const neonTexts = ["neon-cyan", "neon-green", "neon-magenta", "neon-yellow"];
                      return (
                        <div key={region.region} className="space-y-2">
                          <div className="flex items-center justify-between pb-2 border-b border-border/50">
                            <h4 className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
                              {region.regionName}
                            </h4>
                            <span className={`text-sm font-black ${neonTexts[idx % 4]}`}>
                              {formatCurrency(region.total)}
                            </span>
                          </div>
                          <div className="space-y-1">
                            {region.buildings.map((b: { name: string; value: number }) => (
                              <div key={`reg-${b.name}`} className="flex items-center justify-between text-xs">
                                <span className="text-muted-foreground truncate mr-2">{b.name}</span>
                                <span className={`font-medium tabular-nums ${b.value < 0 ? "neon-red" : "text-foreground"}`}>
                                  {formatCurrency(b.value)}
                                </span>
                              </div>
                            ))}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              )}
            </Card>
          </section>
        )}

        {/* Footer */}
        <footer className="text-center text-xs text-muted-foreground pb-6">
          Data sourced from propertymax.ai · Auto-refreshes every 30 minutes
        </footer>
      </div>

      {/* ── Email Preview Modal ── */}
      {previewType !== null && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4"
          onClick={(e) => { if (e.target === e.currentTarget) setPreviewType(null); }}
        >
          <div className="relative w-full max-w-4xl max-h-[90vh] flex flex-col rounded-2xl overflow-hidden border border-[oklch(0.72_0.25_330_/_30%)] shadow-[0_0_40px_oklch(0.72_0.25_330_/_15%)]">
            {/* Modal header */}
            <div className="flex items-center justify-between px-5 py-3 bg-[oklch(0.10_0.02_260)] border-b border-[oklch(0.72_0.25_330_/_20%)] shrink-0">
              <div className="flex items-center gap-2">
                {previewType === "daily" ? (
                  <><Mail className="w-4 h-4 text-[oklch(0.72_0.25_330)]" />
                  <span className="text-sm font-bold text-[oklch(0.72_0.25_330)]">Daily Vacancy Report Preview</span></>
                ) : (
                  <><CalendarDays className="w-4 h-4 text-[oklch(0.82_0.22_145)]" />
                  <span className="text-sm font-bold text-[oklch(0.82_0.22_145)]">Weekly Summary Preview</span></>
                )}
                <span className="text-xs text-muted-foreground ml-1">— exactly as recipients will see it</span>
              </div>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setPreviewType(previewType === "daily" ? "weekly" : "daily")}
                  className="text-xs text-muted-foreground hover:text-foreground transition-colors border border-border/40 rounded-lg px-3 py-1.5 hover:border-border"
                >
                  Switch to {previewType === "daily" ? "Weekly" : "Daily"}
                </button>
                <button
                  onClick={() => setPreviewType(null)}
                  className="text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1 text-sm"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
            {/* Modal body — iframe for isolated rendering */}
            <div className="flex-1 overflow-auto bg-[#0a0b14]">
              {isPreviewLoading ? (
                <div className="flex items-center justify-center h-64">
                  <Loader2 className="w-8 h-8 animate-spin text-[oklch(0.72_0.25_330)]" />
                  <span className="ml-3 text-muted-foreground">Loading preview...</span>
                </div>
              ) : activePreviewHtml ? (
                <iframe
                  srcDoc={activePreviewHtml}
                  className="w-full border-0"
                  style={{ height: "75vh" }}
                  title="Email Preview"
                  sandbox="allow-same-origin"
                />
              ) : (
                <div className="flex items-center justify-center h-64">
                  <span className="text-muted-foreground text-sm">Failed to load preview. Try again.</span>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
