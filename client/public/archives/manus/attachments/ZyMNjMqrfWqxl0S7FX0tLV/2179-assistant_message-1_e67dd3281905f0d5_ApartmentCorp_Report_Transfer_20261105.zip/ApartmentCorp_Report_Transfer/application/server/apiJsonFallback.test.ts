import { describe, expect, it, vi } from "vitest";
import { sendApiJsonNotFound } from "./_core/apiJsonFallback";

describe("sendApiJsonNotFound", () => {
  it("returns a tRPC-compatible JSON error envelope instead of SPA HTML", () => {
    const json = vi.fn();
    const status = vi.fn(() => ({ json }));
    const req = { originalUrl: "/api/trpc/missing.procedure" } as never;
    const res = { status } as never;

    sendApiJsonNotFound(req, res);

    expect(status).toHaveBeenCalledWith(404);
    expect(json).toHaveBeenCalledWith({
      error: {
        json: {
          message: "API route not found. Please retry the dashboard request.",
          code: -32004,
          data: {
            code: "NOT_FOUND",
            httpStatus: 404,
            path: "/api/trpc/missing.procedure",
          },
        },
      },
    });
  });
});
