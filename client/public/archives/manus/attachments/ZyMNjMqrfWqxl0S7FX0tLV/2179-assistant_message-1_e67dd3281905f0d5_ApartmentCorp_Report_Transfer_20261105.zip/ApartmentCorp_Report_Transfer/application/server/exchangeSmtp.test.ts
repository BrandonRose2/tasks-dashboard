import nodemailer from "nodemailer";
import { describe, expect, it, vi } from "vitest";
import {
  EXCHANGE_SMTP_SENDER,
  getExchangeSmtpAccessToken,
  getExchangeSmtpConfig,
} from "./emailService";

const validEnv: NodeJS.ProcessEnv = {
  EXCHANGE_TENANT_ID: "tenant-id",
  EXCHANGE_CLIENT_ID: "client-id",
  EXCHANGE_CLIENT_SECRET: "client-secret",
  EXCHANGE_SMTP_SENDER: EXCHANGE_SMTP_SENDER,
};

describe("Exchange app-only SMTP transport", () => {
  it("requires all app-only credentials and locks the sender to Ethan", () => {
    expect(getExchangeSmtpConfig(validEnv)).toEqual({
      tenantId: "tenant-id",
      clientId: "client-id",
      clientSecret: "client-secret",
      sender: EXCHANGE_SMTP_SENDER,
    });
    expect(() => getExchangeSmtpConfig({ ...validEnv, EXCHANGE_CLIENT_SECRET: "" }))
      .toThrow("Exchange OAuth credentials are not configured");
    expect(() => getExchangeSmtpConfig({ ...validEnv, EXCHANGE_SMTP_SENDER: "other@apartmentcorp.com" }))
      .toThrow(`Exchange SMTP sender must be ${EXCHANGE_SMTP_SENDER}`);
  });

  it("requests a client-credentials SMTP token from Ethan's tenant without Gmail settings", async () => {
    const request = vi.fn().mockResolvedValue(new Response(JSON.stringify({ access_token: "exchange-token" }), {
      status: 200,
      headers: { "content-type": "application/json" },
    }));

    await expect(getExchangeSmtpAccessToken(validEnv, request)).resolves.toBe("exchange-token");
    expect(request).toHaveBeenCalledOnce();
    const [url, init] = request.mock.calls[0] as [string, RequestInit];
    expect(url).toBe("https://login.microsoftonline.com/tenant-id/oauth2/v2.0/token");
    expect(init.method).toBe("POST");
    expect(init.headers).toEqual({ "Content-Type": "application/x-www-form-urlencoded" });
    expect(String(init.body)).toContain("scope=https%3A%2F%2Foutlook.office365.com%2F.default");
    expect(String(init.body)).toContain("grant_type=client_credentials");
  });

  it("fails closed when Entra cannot issue an Exchange token", async () => {
    const request = vi.fn().mockResolvedValue(new Response(JSON.stringify({ error_description: "Mailbox binding missing" }), {
      status: 401,
      headers: { "content-type": "application/json" },
    }));

    await expect(getExchangeSmtpAccessToken(validEnv, request))
      .rejects.toThrow("Exchange OAuth token request failed (401): Mailbox binding missing");
  });

  it.skipIf(process.env.EXCHANGE_TOKEN_LIVE_VERIFY !== "true")("validates the stored Entra credentials by retrieving a token only", async () => {
    const token = await getExchangeSmtpAccessToken();
    expect(token).toEqual(expect.any(String));
    expect(token.length).toBeGreaterThan(100);
  }, 20_000);

  it.skipIf(process.env.EXCHANGE_SMTP_LIVE_VERIFY !== "true")("authenticates to Exchange SMTP without sending a message", async () => {
    const accessToken = await getExchangeSmtpAccessToken();
    const transporter = nodemailer.createTransport({
      host: "smtp.office365.com",
      port: 587,
      secure: false,
      requireTLS: true,
      auth: { type: "OAuth2", user: EXCHANGE_SMTP_SENDER, accessToken },
    });
    await expect(transporter.verify()).resolves.toBe(true);
  }, 30_000);
});
