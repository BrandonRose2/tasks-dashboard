import { describe, expect, it } from "vitest";
import { buildDailyVacancyHtml } from "./emailService";

describe("full Daily Vacancy email presentation", () => {
  it("renders the complete report in light mode with a bottom Collections deep link", () => {
    const data: Parameters<typeof buildDailyVacancyHtml>[0] = {
      stats: { totalVacant: 1, vacUnleased: 1, vacPreleased: 0, onNotice: 0, eviction: 0 },
      buildingVacancy: [
        {
          name: "Example Property",
          totalVacant: 1,
          vacUnleased: 1,
          vacPreleased: 0,
          onNotice: 0,
          eviction: 0,
          totalUnits: 10,
          vacancyPct: 10,
          atRisk: true,
        },
      ],
      dailyChanges: [{ building: "Example Property", yesterdayVacant: 0, todayVacant: 1, change: 1 }],
      vacantUnleased: [
        {
          dateBy: "Today",
          building: "Example Property",
          unit: "101",
          moveOut: "Today",
          alertDays: "",
          days: 1,
          beds: 1,
          askRent: 1000,
          percentReady: 100,
        },
      ],
      vacantPreleased: [],
      onNotice: [],
      evictions: [],
      historicalMonths: [],
      lastUpdated: new Date(),
    };
    const html = buildDailyVacancyHtml(data);

    expect(html).toContain("VACANCY REPORT");
    expect(html).toContain("Vacant / Unleased Unit Detail Rows (1)");
    expect(html).toContain("Fresh PropertyMax Vacancy snapshot:");
    expect(html).toContain("fresh PropertyMax Vacancy snapshot");
    expect(html).toContain("background-color:#f5f7fa");
    expect(html).toContain('href="https://vacancyreport.manus.space"');
    expect(html).toContain("View Collections →");
    expect(html).toContain('href="https://vacancyreport.manus.space?tab=collections"');
    expect(html).not.toContain("railway_daily_collections_preview.html");
    expect(html).not.toContain("vacancyapp-42vudntx.manus.space");
    expect(html).not.toContain("background-color:#0a0b14");
    expect(html).toContain('role="presentation"');
    expect(html).toContain("mso-line-height-rule:exactly");
    expect(html).not.toContain("background:linear-gradient");
    expect(html).not.toMatch(/#[0-9a-fA-F]{8}\b/);
    expect(html).not.toContain("Net Rent Collected");
    expect(html).not.toContain("👎");
    expect(html).not.toContain("👍");
    expect(html).not.toContain("New vacancies shown in");
    expect(html).not.toMatch(/#(?:15803d|dc2626|c2410c|7c3aed|0369a1|ff4041)\b/i);
    for (const accent of ["#1e73be", "#b96a14", "#198754", "#7851a9", "#c63c4a"]) {
      expect(html).toContain(`border-top:4px solid ${accent}`);
    }
    expect(html).toContain("background:#fff7f7");
    expect(html).toContain("border:1px solid #efcfd3");
  });
});
