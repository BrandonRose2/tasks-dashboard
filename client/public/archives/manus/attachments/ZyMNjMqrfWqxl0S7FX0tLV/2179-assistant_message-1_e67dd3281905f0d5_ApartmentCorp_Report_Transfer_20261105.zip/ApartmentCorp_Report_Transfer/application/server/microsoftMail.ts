import { createCipheriv, createDecipheriv, createHash, randomBytes } from "crypto";
import { getMicrosoftMailConnection, upsertMicrosoftMailConnection } from "./db";

export const MICROSOFT_MAIL_SENDER = "ethan@apartmentcorp.com";
const GRAPH_SCOPES = ["openid", "profile", "offline_access", "User.Read", "Mail.Send"];

type TokenResponse = {
  access_token?: unknown;
  refresh_token?: unknown;
  expires_in?: unknown;
  error?: unknown;
  error_description?: unknown;
};

type MicrosoftMailConfig = {
  tenantId: string;
  clientId: string;
  clientSecret: string;
  redirectUri: string;
};

export type GraphMailMessage = {
  to: string | string[];
  cc?: string | string[];
  subject: string;
  html: string;
};

function required(value: string | undefined, name: string): string {
  const normalized = value?.trim();
  if (!normalized) throw new Error(`${name} is not configured.`);
  return normalized;
}

export function getMicrosoftMailConfig(env: NodeJS.ProcessEnv = process.env): MicrosoftMailConfig {
  return {
    tenantId: required(env.EXCHANGE_TENANT_ID, "EXCHANGE_TENANT_ID"),
    clientId: required(env.EXCHANGE_CLIENT_ID, "EXCHANGE_CLIENT_ID"),
    clientSecret: required(env.EXCHANGE_CLIENT_SECRET, "EXCHANGE_CLIENT_SECRET"),
    redirectUri: required(env.MICROSOFT_OAUTH_REDIRECT_URI, "MICROSOFT_OAUTH_REDIRECT_URI"),
  };
}

function encryptionKey(env: NodeJS.ProcessEnv = process.env): Buffer {
  return createHash("sha256").update(required(env.JWT_SECRET, "JWT_SECRET")).digest();
}

export function encryptMicrosoftRefreshToken(token: string, env: NodeJS.ProcessEnv = process.env): string {
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", encryptionKey(env), iv);
  const ciphertext = Buffer.concat([cipher.update(token, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return [iv, tag, ciphertext].map(part => part.toString("base64url")).join(".");
}

export function decryptMicrosoftRefreshToken(value: string, env: NodeJS.ProcessEnv = process.env): string {
  const [ivValue, tagValue, ciphertextValue] = value.split(".");
  if (!ivValue || !tagValue || !ciphertextValue) throw new Error("Stored Microsoft OAuth token is malformed.");
  const decipher = createDecipheriv("aes-256-gcm", encryptionKey(env), Buffer.from(ivValue, "base64url"));
  decipher.setAuthTag(Buffer.from(tagValue, "base64url"));
  return Buffer.concat([
    decipher.update(Buffer.from(ciphertextValue, "base64url")),
    decipher.final(),
  ]).toString("utf8");
}

function authorizeBase(tenantId: string) {
  return `https://login.microsoftonline.com/${encodeURIComponent(tenantId)}/oauth2/v2.0`;
}

export function buildMicrosoftAuthorizationUrl(state: string, env: NodeJS.ProcessEnv = process.env): string {
  const config = getMicrosoftMailConfig(env);
  const params = new URLSearchParams({
    client_id: config.clientId,
    response_type: "code",
    redirect_uri: config.redirectUri,
    response_mode: "query",
    scope: GRAPH_SCOPES.join(" "),
    state,
    prompt: "select_account",
  });
  return `${authorizeBase(config.tenantId)}/authorize?${params.toString()}`;
}

async function requestToken(body: URLSearchParams, env: NodeJS.ProcessEnv = process.env, request: typeof fetch = fetch): Promise<TokenResponse> {
  const { tenantId } = getMicrosoftMailConfig(env);
  const response = await request(`${authorizeBase(tenantId)}/token`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body,
  });
  const payload = await response.json().catch(() => null) as TokenResponse | null;
  if (!response.ok || !payload || typeof payload.access_token !== "string") {
    const detail = payload && typeof payload.error_description === "string" ? `: ${payload.error_description}` : "";
    throw new Error(`Microsoft OAuth token request failed (${response.status})${detail}`);
  }
  return payload;
}

async function verifyEthanMailbox(accessToken: string, request: typeof fetch = fetch): Promise<void> {
  const response = await request("https://graph.microsoft.com/v1.0/me?$select=mail,userPrincipalName", {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  const profile = await response.json().catch(() => null) as { mail?: unknown; userPrincipalName?: unknown } | null;
  const email = typeof profile?.mail === "string" && profile.mail
    ? profile.mail
    : typeof profile?.userPrincipalName === "string" ? profile.userPrincipalName : "";
  if (!response.ok || email.trim().toLowerCase() !== MICROSOFT_MAIL_SENDER) {
    throw new Error(`Microsoft authorization must use ${MICROSOFT_MAIL_SENDER}.`);
  }
}

export async function connectMicrosoftMailbox(
  authorizationCode: string,
  env: NodeJS.ProcessEnv = process.env,
  request: typeof fetch = fetch,
): Promise<void> {
  const config = getMicrosoftMailConfig(env);
  const payload = await requestToken(new URLSearchParams({
    client_id: config.clientId,
    client_secret: config.clientSecret,
    grant_type: "authorization_code",
    code: authorizationCode,
    redirect_uri: config.redirectUri,
    scope: GRAPH_SCOPES.join(" "),
  }), env, request);
  if (typeof payload.refresh_token !== "string" || !payload.refresh_token) {
    throw new Error("Microsoft did not return a refresh token. Reauthorize and approve offline access.");
  }
  await verifyEthanMailbox(payload.access_token as string, request);
  await upsertMicrosoftMailConnection({
    accountEmail: MICROSOFT_MAIL_SENDER,
    refreshTokenCiphertext: encryptMicrosoftRefreshToken(payload.refresh_token, env),
    refreshTokenExpiresAt: null,
  });
}

export async function getMicrosoftDelegatedAccessToken(
  env: NodeJS.ProcessEnv = process.env,
  request: typeof fetch = fetch,
): Promise<string> {
  const connection = await getMicrosoftMailConnection(MICROSOFT_MAIL_SENDER);
  if (!connection) throw new Error("Microsoft mail is not connected. Ethan must complete the one-time authorization.");
  const config = getMicrosoftMailConfig(env);
  const refreshToken = decryptMicrosoftRefreshToken(connection.refreshTokenCiphertext, env);
  const payload = await requestToken(new URLSearchParams({
    client_id: config.clientId,
    client_secret: config.clientSecret,
    grant_type: "refresh_token",
    refresh_token: refreshToken,
    scope: GRAPH_SCOPES.join(" "),
  }), env, request);
  if (typeof payload.refresh_token === "string" && payload.refresh_token) {
    await upsertMicrosoftMailConnection({
      accountEmail: MICROSOFT_MAIL_SENDER,
      refreshTokenCiphertext: encryptMicrosoftRefreshToken(payload.refresh_token, env),
      refreshTokenExpiresAt: null,
    });
  }
  return payload.access_token as string;
}

export async function sendMicrosoftGraphMail(
  message: GraphMailMessage,
  env: NodeJS.ProcessEnv = process.env,
  request: typeof fetch = fetch,
): Promise<void> {
  const accessToken = await getMicrosoftDelegatedAccessToken(env, request);
  const recipients = (Array.isArray(message.to) ? message.to : message.to.split(","))
    .map(address => address.trim())
    .filter(Boolean)
    .map(address => ({ emailAddress: { address } }));
  if (recipients.length === 0) throw new Error("At least one recipient is required.");
  const ccRecipients = (message.cc ? (Array.isArray(message.cc) ? message.cc : message.cc.split(",")) : [])
    .map(address => address.trim())
    .filter(Boolean)
    .map(address => ({ emailAddress: { address } }));
  const response = await request("https://graph.microsoft.com/v1.0/me/sendMail", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      message: {
        subject: message.subject,
        body: { contentType: "HTML", content: message.html },
        toRecipients: recipients,
        ...(ccRecipients.length > 0 ? { ccRecipients } : {}),
      },
      saveToSentItems: true,
    }),
  });
  if (!response.ok) {
    const detail = await response.text().catch(() => "");
    throw new Error(`Microsoft Graph sendMail failed (${response.status})${detail ? `: ${detail.slice(0, 300)}` : ""}`);
  }
}
