import { randomBytes, timingSafeEqual } from "crypto";
import { parse as parseCookie } from "cookie";
import type { Express, Request, Response } from "express";
import { buildMicrosoftAuthorizationUrl, connectMicrosoftMailbox } from "./microsoftMail";
import { ENV } from "./_core/env";

const STATE_COOKIE = "microsoft_mail_oauth_state";
const STATE_TTL_MS = 10 * 60 * 1000;

function stateMatches(actual: string | undefined, expected: string): boolean {
  if (!actual) return false;
  const actualBuffer = Buffer.from(actual);
  const expectedBuffer = Buffer.from(expected);
  return actualBuffer.length === expectedBuffer.length && timingSafeEqual(actualBuffer, expectedBuffer);
}

function oauthCookieOptions() {
  return {
    httpOnly: true,
    secure: ENV.isProduction,
    sameSite: "lax" as const,
    path: "/api/microsoft-oauth",
    maxAge: STATE_TTL_MS,
  };
}

function finish(res: Response, title: string, body: string, status = 200) {
  res.status(status).type("html").send(`<!doctype html><html><head><meta charset="utf-8"><title>${title}</title></head><body style="font-family:Segoe UI,Arial,sans-serif;background:#f5f7fa;color:#172b4d;padding:48px"><main style="max-width:560px;margin:auto;background:#fff;border:1px solid #dde3ea;border-radius:12px;padding:28px"><h1 style="margin-top:0">${title}</h1><p>${body}</p></main></body></html>`);
}

export function registerMicrosoftOAuthRoutes(app: Express) {
  app.get("/api/microsoft-oauth/start", (req: Request, res: Response) => {
    try {
      const state = randomBytes(32).toString("base64url");
      res.cookie(STATE_COOKIE, state, oauthCookieOptions());
      res.redirect(302, buildMicrosoftAuthorizationUrl(state));
    } catch (error) {
      console.error("[Microsoft OAuth] Unable to start authorization", error);
      finish(res, "Microsoft authorization unavailable", "The report sender configuration is incomplete. No email was sent.", 500);
    }
  });

  app.get("/api/microsoft-oauth/callback", async (req: Request, res: Response) => {
    const code = typeof req.query.code === "string" ? req.query.code : undefined;
    const state = typeof req.query.state === "string" ? req.query.state : undefined;
    const cookieState = parseCookie(req.headers.cookie ?? "")[STATE_COOKIE];
    res.clearCookie(STATE_COOKIE, oauthCookieOptions());

    if (!code || !state || !stateMatches(cookieState, state)) {
      finish(res, "Microsoft authorization could not be verified", "Please return to the report connection page and try again. No email was sent.", 400);
      return;
    }

    try {
      await connectMicrosoftMailbox(code);
      finish(res, "Microsoft report sender connected", "Ethan’s Microsoft 365 mailbox is now authorized for the report service. The service will still validate the token before any report is sent.");
    } catch (error) {
      console.error("[Microsoft OAuth] Callback failed", error);
      finish(res, "Microsoft authorization was not completed", "The mailbox was not connected. This can happen if the tenant blocks user consent or the account is not Ethan’s mailbox. No email was sent.", 400);
    }
  });
}
