import { describe, expect, it } from "vitest";
import { parseStrictMonthlyNetCashHtml as parse } from "./monthlyNetCashParser";

// Synthetic FLOW structure only: no private property names, values, or captured HTML.
const HEADER = '<th colspan="2"></th><th>★ Alpha</th><th></th><th>Beta</th><th></th>';
function cashRow(label = "Net Cash Flow", alpha = "<strong>123.45</strong>", beta = "<strong>-23.45</strong>"): string {
  return `<tr><td colspan="2"><strong>${label}</strong></td><td>${alpha}</td><td></td><td>${beta}</td><td></td></tr>`;
}
function table(rows = cashRow(), header = HEADER): string {
  return `<table><thead><tr>${header}</tr></thead><tbody>${rows}</tbody></table>`;
}
// Current rollups have a separate cell rather than a colspan label, plus a global summary.
function rollup(label: string): string {
  return `<tr><td>${label}</td><td><strong>999999.99</strong></td><td>888888.88</td><td></td><td>777777.77</td><td></td></tr>`;
}
const EXPECTED = {
  region: 1, regionName: "Region 1", total: 100,
  buildings: [{ name: "Alpha", value: 123.45 }, { name: "Beta", value: -23.45 }],
};

describe("strict monthly canonical cash-row selection", () => {
  it.each([false, true])("prefers canonical building cash to Marc/Todd global rollups regardless of order (rollups first: %s)", first => {
    const otherRows = rollup("Marc's Net Cash Flow") + rollup("Todd's Net Cash Flow");
    expect(parse(table(first ? otherRows + cashRow() : cashRow() + otherRows), 1)).toEqual(EXPECTED);
  });

  it("ignores duplicate legacy rollups and malformed summary tables when one canonical row exists", () => {
    const summaries = `<table>${rollup("Marc's Net Cash Flow")}${rollup("Marc’s Net Cash")}${rollup("Todd's Net Cash Flow")}</table>`;
    expect(parse(summaries + table(), 1)).toEqual(EXPECTED);
  });

  it.each([
    table(cashRow() + cashRow()),
    table() + table(),
    table(cashRow() + cashRow() + cashRow("Marc's Net Cash")),
  ])("rejects duplicate canonical rows, including across tables, without falling back", html => {
    expect(() => parse(html, 1)).toThrow("exactly one cash row");
  });

  it.each(["Marc's Net Cash", "Marc’s Net Cash", "Marc's Net Cash Flow", "Marc’s Net Cash Flow"])(
    "accepts unique legacy fallback %s only when canonical is absent", label => {
      expect(parse(table(cashRow(label) + rollup("Todd's Net Cash Flow")), 1)).toEqual(EXPECTED);
    },
  );

  it.each([
    table(cashRow("Marc's Net Cash") + cashRow("Marc's Net Cash")),
    table(cashRow("Marc's Net Cash") + cashRow("Marc’s Net Cash Flow")),
    table(cashRow("Marc's Net Cash")) + table(cashRow("Marc’s Net Cash")),
  ])("rejects duplicate legacy fallback rows", html => {
    expect(() => parse(html, 1)).toThrow("exactly one cash row");
  });

  it.each(["Todd's Net Cash Flow", "Net Cash Flow Summary", "Marc's Net Cash Flow Total", "Prefix Net Cash Flow"])(
    "never treats nonexact label %s as canonical or legacy cash", label => {
      expect(() => parse(table(cashRow(label)), 1)).toThrow("exactly one cash row");
    },
  );

  it("normalizes label whitespace without broadening to summary prefixes", () => {
    expect(parse(table(cashRow("\u00a0Net\n Cash   Flow\u00a0")), 1)).toEqual(EXPECTED);
  });

  it("rejects an invalid canonical row rather than using a valid legacy row", () => {
    expect(() => parse(table(cashRow("Net Cash Flow", "<strong>N/A</strong>") + cashRow("Marc's Net Cash")), 1))
      .toThrow("invalid cash amount");
  });
});

describe("strict monthly physical columns and authoritative per-cell cash", () => {
  it.each([[1, 9, 19], [2, 9, 19], [3, 12, 25], [4, 11, 23]])(
    "preserves the captured layout shape for region %i (%i buildings, %i physical cells)", (region, count, physicalCells) => {
      const names = Array.from({ length: count }, (_, index) => `Synthetic ${index + 1}`);
      const values = names.map((_, index) => index === 0 ? 0 : index % 2 ? -index : index);
      const header = '<th colspan="2"></th>' + names.map(name => `<th>★ ${name}</th><th></th>`).join("");
      const row = '<tr><td colspan="2"><strong>Net Cash Flow</strong></td>' + values.map(value =>
        `<td><span style="color:green">500.00</span><br><span style="color:red">-100.00</span><br><strong style="color:black">${value.toFixed(2)}</strong><br></td><td></td>`,
      ).join("") + "</tr>";
      expect((row.match(/<td\b/g) ?? []).length).toBe(physicalCells);
      expect(parse(table(row + rollup("Marc's Net Cash Flow") + rollup("Todd's Net Cash Flow"), header), region))
        .toEqual({ region, regionName: `Region ${region}`, buildings: names.map((name, index) => ({ name, value: values[index] })),
          total: values.reduce((sum, value) => sum + value, 0) });
    },
  );

  it("preserves label colspan and wider blank spacers without borrowing components from another cell", () => {
    const header = '<th colspan="2"></th><th>★ Alpha</th><th colspan="2"></th><th>Beta</th><th></th>';
    const row = cashRow("Net Cash Flow", '<span style="color:green">150.00</span><br><span style="color:red">-26.55</span><br><strong>123.45</strong><br>')
      .replace('<td></td>', '<td colspan="2"></td>');
    expect(parse(table(row, header), 1)).toEqual(EXPECTED);
  });

  it("keeps signed cash, negative zero, plain zero, accounting amounts and encoded HTML", () => {
    const result = parse(JSON.stringify(table(cashRow("Net Cash Flow", "<strong>-0.00</strong>", "0.00"))), 1);
    expect(Object.is(result.buildings[0].value, -0)).toBe(true);
    expect(Object.is(result.buildings[1].value, 0)).toBe(true);
    expect(result.total).toBe(0);
    expect(parse(table(cashRow("Net Cash Flow", "($1,234.56)", "$234.56")), 1).total).toBe(-1000);
  });

  it.each(["", "N/A", "NaN", "Infinity", "123junk", "1,23.45", "123.456", "--1", "0.00 pending", "(-1.00)", "9".repeat(400)])(
    "rejects invalid authoritative source cash %j even with a valid legacy fallback", cash => {
      expect(() => parse(table(cashRow("Net Cash Flow", `<strong>${cash}</strong>`) + cashRow("Marc's Net Cash")), 1)).toThrow();
    },
  );

  it.each([
    "<strong>123.45</strong><strong>100</strong>",
    "<strong>123.45</strong><br>N/A",
    "<strong>123.45</strong><br>123junk",
    "<strong></strong><br>123.45",
  ])("rejects ambiguous strong values or invalid components %j", cash => {
    expect(() => parse(table(cashRow("Net Cash Flow", cash)), 1)).toThrow();
  });

  it.each([
    table(cashRow("Net Cash Flow", "")),
    table(cashRow().replace('<td><strong>-23.45</strong></td><td></td>', "")),
    table(cashRow().replace('<td></td>', '<td><strong>999.00</strong></td>')),
    table(cashRow().replace('<td><strong>123.45</strong></td>', '<td colspan="2"><strong>123.45</strong></td>')),
    table(cashRow(), HEADER.replace('<th>Beta</th>', '<th>Alpha</th>')),
    table(cashRow(), HEADER.replace('<th>Beta</th>', '<th>Total</th>')),
    table(cashRow(), HEADER.replace('<th>Beta</th>', '<th colspan="2">Beta</th>')),
    table(cashRow().replace('<td><strong>123.45</strong></td>', '<td rowspan="2"><strong>123.45</strong></td>')),
    table(cashRow().replace('<td><strong>123.45</strong></td>', '<td><table><tr><td><strong>123.45</strong></td></tr></table></td>')),
    table().replace(/<thead>[\s\S]*?<\/thead>/, ""),
    table().replace('</thead>', `<tr>${HEADER}</tr></thead>`),
  ])("retains rejection of missing, shifted, partial or ambiguous building columns", html => {
    expect(() => parse(html, 1)).toThrow();
  });
});
