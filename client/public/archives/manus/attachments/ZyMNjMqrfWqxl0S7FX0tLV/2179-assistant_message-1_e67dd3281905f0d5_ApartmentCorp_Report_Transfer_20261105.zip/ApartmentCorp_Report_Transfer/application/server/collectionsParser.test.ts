import { describe, expect, it } from "vitest";
import { parseCollectionsHtml } from "./scraper";

describe("FLOW collections parser", () => {
  it("ignores spacer cells so values remain aligned to their building headers", () => {
    const html = `
      <table>
        <thead><tr><th colspan="2"></th><th>Alpha</th><th></th><th>Beta</th><th></th></tr></thead>
        <tbody>
          <tr><td colspan="2">Vouchers [Current / Goal]</td><td>[4 / 0]</td><td></td><td>[2 / 0]</td><td></td></tr>
          <tr><td colspan="2">Rent Billed</td><td>100.00</td><td></td><td>200.00</td><td></td></tr>
          <tr><td colspan="2">Utility Reimbursement Received</td><td>10.00</td><td></td><td>20.00</td><td></td></tr>
          <tr><td colspan="2">Rent Collected (Manager)</td><td>80.00</td><td></td><td>190.00</td><td></td></tr>
        </tbody>
      </table>`;

    expect(parseCollectionsHtml(html, 1)).toEqual([
      expect.objectContaining({ buildingName: "Alpha", rentBilled: 100, rentCollected: 80, utilityReimbursement: 10, vouchersCount: 4, collectionPct: 80 }),
      expect.objectContaining({ buildingName: "Beta", rentBilled: 200, rentCollected: 190, utilityReimbursement: 20, vouchersCount: 2, collectionPct: 95 }),
    ]);
  });
});
