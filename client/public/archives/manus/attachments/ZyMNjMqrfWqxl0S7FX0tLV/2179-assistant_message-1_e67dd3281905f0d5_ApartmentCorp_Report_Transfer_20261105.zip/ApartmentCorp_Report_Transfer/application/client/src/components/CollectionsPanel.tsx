import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { COLLECTION_VARIANCE_TOLERANCE, getCollectionVariance } from "@shared/collectionVariance";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Loader2,
  TrendingUp,
  TrendingDown,
  Minus,
  DollarSign,
  Search,
  RefreshCw,
  AlertTriangle,
  CheckCircle2,
  BarChart3,
  Building2,
  Ticket,
  Zap,
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
  X,
} from "lucide-react";

// ─── Types ────────────────────────────────────────────────────────────────────

interface CollectionRow {
  buildingName: string;
  regionId: number;
  rentBilled: number;
  rentCollected: number;
  utilityReimbursement: number;
  vouchersCount: number;
  collectionPct: number;
  snapshotDate: string;
  rentCollectedChangePct: number | null;
  prevRentCollected: number | null;
  prevSnapshotDate: string | null;
}

interface CollectionsSnapshot {
  snapshotDate: string;
  buildings: CollectionRow[];
  totalRentBilled: number;
  totalRentCollected: number;
  overallCollectionPct: number;
}

interface HistoryPoint {
  snapshotDate: string;
  rentBilled: number;
  rentCollected: number;
  collectionPct: number;
  utilityReimbursement: number;
  vouchersCount: number;
}

type SortMode = "billed-desc" | "rate-asc" | "rate-desc" | "name-asc" | "region-asc";

// ─── Helpers ──────────────────────────────────────────────────────────────────

function fmt(n: number) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(n);
}

function pctColor(pct: number) {
  if (pct >= 90) return "text-[oklch(0.82_0.22_145)]";
  if (pct >= 75) return "text-[oklch(0.85_0.18_85)]";
  return "text-[oklch(0.72_0.25_30)]";
}

function pctBg(pct: number) {
  if (pct >= 90) return "bg-[oklch(0.82_0.22_145_/_12%)] border-[oklch(0.82_0.22_145_/_25%)]";
  if (pct >= 75) return "bg-[oklch(0.85_0.18_85_/_12%)] border-[oklch(0.85_0.18_85_/_25%)]";
  return "bg-[oklch(0.72_0.25_30_/_12%)] border-[oklch(0.72_0.25_30_/_25%)]";
}

function VarianceCell({ expectedRent, collected, compact = false, showEmoji = true }: { expectedRent: number; collected: number; compact?: boolean; showEmoji?: boolean }) {
  const variance = getCollectionVariance(expectedRent, collected);
  if (variance.status === "no_expected_rent") return <span className="text-muted-foreground">—</span>;
  const isShortfall = variance.status === "shortfall";
  const color = isShortfall
    ? "text-[oklch(0.72_0.25_30)]"
    : "text-[oklch(0.82_0.22_145)]";
  const emoji = isShortfall ? "🚨" : "👌🏼";
  const signed = `${variance.variance > 0 ? "+" : variance.variance < 0 ? "-" : ""}${fmt(Math.abs(variance.variance))}`;

  if (compact) return <span className={`font-mono font-semibold whitespace-nowrap ${color}`}>{showEmoji ? `${emoji} ` : ""}{signed}</span>;

  return (
    <span className={`font-mono font-semibold whitespace-nowrap ${color}`}>{showEmoji ? `${emoji} ` : ""}{signed}</span>
  );
}

function sortBuildings(buildings: CollectionRow[], mode: SortMode): CollectionRow[] {
  const arr = [...buildings];
  switch (mode) {
    case "rate-asc":
      return arr.sort((a, b) => {
        // Put $0 billed at the end
        if (a.rentBilled === 0 && b.rentBilled === 0) return 0;
        if (a.rentBilled === 0) return 1;
        if (b.rentBilled === 0) return -1;
        return a.collectionPct - b.collectionPct;
      });
    case "rate-desc":
      return arr.sort((a, b) => {
        if (a.rentBilled === 0 && b.rentBilled === 0) return 0;
        if (a.rentBilled === 0) return 1;
        if (b.rentBilled === 0) return -1;
        return b.collectionPct - a.collectionPct;
      });
    case "name-asc":
      return arr.sort((a, b) => a.buildingName.localeCompare(b.buildingName));
    case "region-asc":
      return arr.sort((a, b) => a.regionId - b.regionId || a.buildingName.localeCompare(b.buildingName));
    case "billed-desc":
    default:
      return arr.sort((a, b) => b.rentBilled - a.rentBilled);
  }
}

// ─── Gauge ────────────────────────────────────────────────────────────────────

function CollectionGauge({ pct }: { pct: number }) {
  const color = pct >= 90 ? "oklch(0.82 0.22 145)" : pct >= 75 ? "oklch(0.85 0.18 85)" : "oklch(0.72 0.25 30)";
  const radius = 20;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (Math.min(pct, 100) / 100) * circumference;
  return (
    <div className="relative inline-flex items-center justify-center">
      <svg width="56" height="56" viewBox="0 0 56 56">
        <circle cx="28" cy="28" r={radius} fill="none" stroke="oklch(0.3 0.05 240 / 40%)" strokeWidth="5" />
        <circle
          cx="28" cy="28" r={radius} fill="none"
          stroke={color} strokeWidth="5"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          strokeLinecap="round"
          transform="rotate(-90 28 28)"
          style={{ transition: "stroke-dashoffset 0.6s ease" }}
        />
      </svg>
      <span className="absolute text-[10px] font-bold" style={{ color }}>{pct.toFixed(0)}%</span>
    </div>
  );
}

// ─── Change Indicator ─────────────────────────────────────────────────────────

function ChangeIndicator({ pct }: { pct: number | null }) {
  if (pct === null) return <span className="text-muted-foreground text-xs">—</span>;
  if (Math.abs(pct) < 0.1) return <span className="flex items-center gap-0.5 text-xs text-muted-foreground"><Minus className="w-3 h-3" /> 0%</span>;
  if (pct > 0) return (
    <span className="flex items-center gap-0.5 text-xs text-[oklch(0.82_0.22_145)] font-semibold">
      <TrendingUp className="w-3 h-3" /> +{pct.toFixed(1)}%
    </span>
  );
  return (
    <span className="flex items-center gap-0.5 text-xs text-[oklch(0.72_0.25_30)] font-semibold">
      <TrendingDown className="w-3 h-3" /> {pct.toFixed(1)}%
    </span>
  );
}

// ─── Mini Sparkline SVG ───────────────────────────────────────────────────────

function MiniSparkline({ data, width = 80, height = 28 }: { data: number[]; width?: number; height?: number }) {
  if (data.length < 2) return null;
  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 1;
  const pts = data.map((v, i) => {
    const x = (i / (data.length - 1)) * width;
    const y = height - ((v - min) / range) * (height - 4) - 2;
    return `${x},${y}`;
  });
  const last = data[data.length - 1];
  const color = last >= 90 ? "oklch(0.82 0.22 145)" : last >= 75 ? "oklch(0.85 0.18 85)" : "oklch(0.72 0.25 30)";
  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} className="overflow-visible">
      <polyline
        points={pts.join(" ")}
        fill="none"
        stroke={color}
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
        opacity="0.8"
      />
    </svg>
  );
}

// ─── History Modal ────────────────────────────────────────────────────────────

function HistoryModal({ building, onClose }: { building: CollectionRow; onClose: () => void }) {
  const { data: history, isLoading } = trpc.collections.getHistory.useQuery(
    { buildingName: building.buildingName },
    { enabled: true }
  );

  const chartData = history ?? [];
  const hasData = chartData.length > 0;
  const currentVariance = getCollectionVariance(building.rentBilled, building.rentCollected);

  // SVG line chart dimensions
  const W = 560;
  const H = 160;
  const PAD = { top: 16, right: 16, bottom: 32, left: 48 };
  const innerW = W - PAD.left - PAD.right;
  const innerH = H - PAD.top - PAD.bottom;

  const pcts = chartData.map(d => d.collectionPct);
  const minPct = Math.max(0, Math.min(...pcts) - 5);
  const maxPct = Math.min(100, Math.max(...pcts) + 5);
  const pctRange = maxPct - minPct || 1;

  function xPos(i: number) {
    return PAD.left + (i / Math.max(chartData.length - 1, 1)) * innerW;
  }
  function yPos(pct: number) {
    return PAD.top + innerH - ((pct - minPct) / pctRange) * innerH;
  }

  const linePts = chartData.map((d, i) => `${xPos(i)},${yPos(d.collectionPct)}`).join(" ");

  // Reference lines
  const y90 = yPos(90);
  const y75 = yPos(75);

  return (
    <Dialog open onOpenChange={() => onClose()}>
      <DialogContent className="w-[calc(100vw-1.25rem)] sm:w-[calc(100vw-2rem)] max-w-2xl max-h-[calc(100dvh-1.25rem)] sm:max-h-[calc(100dvh-2rem)] flex flex-col bg-card border border-border/40 rounded-xl sm:rounded-2xl shadow-2xl p-0 overflow-hidden" showCloseButton={false}>
        <DialogHeader className="shrink-0 px-4 sm:px-6 pt-[calc(1rem+env(safe-area-inset-top))] sm:pt-5 pb-0">
          <div className="flex items-start justify-between">
            <div className="min-w-0 pr-3">
              <DialogTitle className="text-base sm:text-lg font-bold text-foreground break-words">{building.buildingName}</DialogTitle>
              <div className="text-xs text-muted-foreground mt-0.5">Region {building.regionId} · Collection Rate History</div>
            </div>
            <Button variant="ghost" size="icon" className="shrink-0 h-9 w-9 -mt-1 -mr-1 text-muted-foreground hover:text-foreground" onClick={onClose} aria-label="Close collection history">
              <X className="w-4 h-4" />
            </Button>
          </div>
        </DialogHeader>

        <div className="min-h-0 overflow-y-auto px-4 sm:px-6 pb-[calc(1rem+env(safe-area-inset-bottom))] sm:pb-6 pt-3 sm:pt-4 space-y-5">
          {/* Current snapshot summary */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 sm:gap-3">
            <div className={`rounded-xl border p-2.5 sm:p-3 ${pctBg(building.collectionPct)}`}>
              <div className="text-[9px] sm:text-[10px] text-muted-foreground uppercase tracking-wider mb-1">Current Rate</div>
              <div className={`text-xl sm:text-2xl font-bold ${pctColor(building.collectionPct)}`}>{building.collectionPct.toFixed(1)}%</div>
            </div>
            <div className="rounded-xl border border-border/30 bg-card p-2.5 sm:p-3">
              <div className="text-[9px] sm:text-[10px] text-muted-foreground uppercase tracking-wider mb-1">Expected Rent</div>
              <div className="text-base sm:text-lg font-bold text-foreground whitespace-nowrap">{fmt(building.rentBilled)}</div>
            </div>
            <div className="rounded-xl border border-border/30 bg-card p-2.5 sm:p-3">
              <div className="text-[9px] sm:text-[10px] text-muted-foreground uppercase tracking-wider mb-1">Collected</div>
              <div className={`text-base sm:text-lg font-bold whitespace-nowrap ${pctColor(building.collectionPct)}`}>{fmt(building.rentCollected)}</div>
            </div>
            <div className={`rounded-xl border p-2.5 sm:p-3 ${currentVariance.status === "shortfall" ? "border-[oklch(0.72_0.25_30_/_25%)] bg-[oklch(0.72_0.25_30_/_8%)]" : currentVariance.status === "over_collected" ? "border-[oklch(0.68_0.22_290_/_25%)] bg-[oklch(0.68_0.22_290_/_8%)]" : "border-[oklch(0.82_0.22_145_/_25%)] bg-[oklch(0.82_0.22_145_/_8%)]"}`}>
              <div className="text-[9px] sm:text-[10px] text-muted-foreground uppercase tracking-wider mb-1">Variance</div>
              <VarianceCell expectedRent={building.rentBilled} collected={building.rentCollected} compact />
            </div>
          </div>

          {/* Chart */}
          {isLoading ? (
            <div className="flex items-center justify-center py-10">
              <Loader2 className="w-6 h-6 animate-spin text-[oklch(0.85_0.18_192)] mr-2" />
              <span className="text-sm text-muted-foreground">Loading history…</span>
            </div>
          ) : !hasData ? (
            <div className="text-center py-10 text-muted-foreground text-sm">No historical data available yet.</div>
          ) : (
            <div>
              <div className="text-xs text-muted-foreground mb-2 font-medium">Collection Rate Over Time</div>
              <div className="rounded-xl border border-border/20 bg-[oklch(0.12_0.02_240_/_50%)] p-2 sm:p-3 overflow-x-auto">
                <div className="sm:hidden mb-2 text-[10px] text-muted-foreground">Swipe horizontally to inspect the trend chart.</div>
                <svg width="100%" viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="xMidYMid meet" style={{ minWidth: "320px" }}>
                  {/* Reference lines */}
                  {maxPct >= 90 && minPct <= 90 && (
                    <>
                      <line x1={PAD.left} y1={y90} x2={W - PAD.right} y2={y90} stroke="oklch(0.82 0.22 145 / 30%)" strokeDasharray="4 3" strokeWidth="1" />
                      <text x={PAD.left - 4} y={y90 + 4} textAnchor="end" fontSize="9" fill="oklch(0.82 0.22 145 / 70%)">90%</text>
                    </>
                  )}
                  {maxPct >= 75 && minPct <= 75 && (
                    <>
                      <line x1={PAD.left} y1={y75} x2={W - PAD.right} y2={y75} stroke="oklch(0.85 0.18 85 / 30%)" strokeDasharray="4 3" strokeWidth="1" />
                      <text x={PAD.left - 4} y={y75 + 4} textAnchor="end" fontSize="9" fill="oklch(0.85 0.18 85 / 70%)">75%</text>
                    </>
                  )}

                  {/* Y-axis labels */}
                  {[minPct, (minPct + maxPct) / 2, maxPct].map((v, i) => (
                    <text key={i} x={PAD.left - 6} y={yPos(v) + 4} textAnchor="end" fontSize="9" fill="oklch(0.6 0.05 240)">
                      {v.toFixed(0)}%
                    </text>
                  ))}

                  {/* Area fill */}
                  <polygon
                    points={`${xPos(0)},${PAD.top + innerH} ${linePts} ${xPos(chartData.length - 1)},${PAD.top + innerH}`}
                    fill="oklch(0.85 0.18 192 / 8%)"
                  />

                  {/* Line */}
                  <polyline
                    points={linePts}
                    fill="none"
                    stroke="oklch(0.85 0.18 192)"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />

                  {/* Data points */}
                  {chartData.map((d, i) => {
                    const cx = xPos(i);
                    const cy = yPos(d.collectionPct);
                    const dotColor = d.collectionPct >= 90 ? "oklch(0.82 0.22 145)" : d.collectionPct >= 75 ? "oklch(0.85 0.18 85)" : "oklch(0.72 0.25 30)";
                    return (
                      <g key={i}>
                        <circle cx={cx} cy={cy} r="4" fill={dotColor} stroke="oklch(0.15 0.02 240)" strokeWidth="1.5" />
                        {/* X-axis label */}
                        <text
                          x={cx} y={H - 4}
                          textAnchor="middle"
                          fontSize="8"
                          fill="oklch(0.55 0.05 240)"
                          transform={chartData.length > 6 ? `rotate(-30 ${cx} ${H - 4})` : undefined}
                        >
                          {new Date(d.snapshotDate + "T12:00:00").toLocaleDateString("en-US", { month: "short", day: "numeric" })}
                        </text>
                        {/* Tooltip value above dot */}
                        <text x={cx} y={cy - 8} textAnchor="middle" fontSize="8" fill={dotColor} fontWeight="600">
                          {d.collectionPct.toFixed(0)}%
                        </text>
                      </g>
                    );
                  })}
                </svg>
              </div>

              {/* Phone history list: all metrics visible without horizontal scrolling */}
              <div className="mt-4 space-y-2 sm:hidden">
                {[...chartData].reverse().map((d, i, arr) => {
                  const prev = arr[i + 1];
                  const delta = prev && prev.collectionPct > 0
                    ? d.collectionPct - prev.collectionPct
                    : null;
                  return (
                    <div key={d.snapshotDate} className="rounded-xl border border-border/20 bg-card p-3">
                      <div className="flex items-center justify-between gap-3">
                        <span className="text-xs font-semibold text-foreground">
                          {new Date(d.snapshotDate + "T12:00:00").toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
                        </span>
                        <span className={`text-sm font-bold ${pctColor(d.collectionPct)}`}>{d.collectionPct.toFixed(1)}%</span>
                      </div>
                      <div className="grid grid-cols-3 gap-2 mt-2 pt-2 border-t border-border/15">
                        <div>
                          <div className="text-[9px] uppercase tracking-wider text-muted-foreground">Expected</div>
                          <div className="mt-0.5 text-[11px] font-mono font-semibold text-foreground whitespace-nowrap">{fmt(d.rentBilled)}</div>
                        </div>
                        <div>
                          <div className="text-[9px] uppercase tracking-wider text-muted-foreground">Collected</div>
                          <div className={`mt-0.5 text-[11px] font-mono font-bold whitespace-nowrap ${pctColor(d.collectionPct)}`}>{fmt(d.rentCollected)}</div>
                        </div>
                        <div>
                          <div className="text-[9px] uppercase tracking-wider text-muted-foreground">Variance</div>
                          <div className="mt-0.5 text-[11px]"><VarianceCell expectedRent={d.rentBilled} collected={d.rentCollected} compact /></div>
                        </div>
                      </div>
                      {delta !== null && (
                        <div className="mt-2 flex items-center justify-between text-[10px]">
                          <span className="text-muted-foreground">Rate change vs. prior snapshot</span>
                          {delta > 0.05 ? (
                            <span className="flex items-center gap-0.5 text-[oklch(0.82_0.22_145)] font-semibold"><ArrowUp className="w-3 h-3" />+{delta.toFixed(1)}pp</span>
                          ) : delta < -0.05 ? (
                            <span className="flex items-center gap-0.5 text-[oklch(0.72_0.25_30)] font-semibold"><ArrowDown className="w-3 h-3" />{delta.toFixed(1)}pp</span>
                          ) : (
                            <span className="text-muted-foreground">No change</span>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Desktop and unfolded-fold history table */}
              <div className="mt-4 rounded-xl border border-border/20 overflow-x-auto hidden sm:block">
                <Table className="min-w-[560px]">
                  <TableHeader>
                    <TableRow className="bg-[oklch(0.85_0.18_192_/_5%)] border-b border-border/30">
                      <TableHead className="text-[10px] uppercase tracking-wider text-muted-foreground">Date</TableHead>
                      <TableHead className="text-[10px] uppercase tracking-wider text-muted-foreground text-right">Expected</TableHead>
                      <TableHead className="text-[10px] uppercase tracking-wider text-muted-foreground text-right">Collected</TableHead>
                      <TableHead className="text-[10px] uppercase tracking-wider text-muted-foreground text-right">Variance</TableHead>
                      <TableHead className="text-[10px] uppercase tracking-wider text-muted-foreground text-center">Rate</TableHead>
                      <TableHead className="text-[10px] uppercase tracking-wider text-muted-foreground text-center">Δ</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {[...chartData].reverse().map((d, i, arr) => {
                      const prev = arr[i + 1];
                      const delta = prev && prev.collectionPct > 0
                        ? d.collectionPct - prev.collectionPct
                        : null;
                      return (
                        <TableRow key={d.snapshotDate} className="border-b border-border/10 hover:bg-[oklch(0.85_0.18_192_/_3%)]">
                          <TableCell className="text-xs text-muted-foreground py-2">
                            {new Date(d.snapshotDate + "T12:00:00").toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
                          </TableCell>
                          <TableCell className="text-xs text-right font-mono py-2">{fmt(d.rentBilled)}</TableCell>
                          <TableCell className={`text-xs text-right font-mono font-bold py-2 ${pctColor(d.collectionPct)}`}>{fmt(d.rentCollected)}</TableCell>
                          <TableCell className="text-xs text-right py-2"><VarianceCell expectedRent={d.rentBilled} collected={d.rentCollected} compact /></TableCell>
                          <TableCell className="text-center py-2">
                            <span className={`text-xs font-bold ${pctColor(d.collectionPct)}`}>{d.collectionPct.toFixed(1)}%</span>
                          </TableCell>
                          <TableCell className="text-center py-2">
                            {delta === null ? (
                              <span className="text-muted-foreground text-xs">—</span>
                            ) : delta > 0.05 ? (
                              <span className="flex items-center justify-center gap-0.5 text-xs text-[oklch(0.82_0.22_145)] font-semibold">
                                <ArrowUp className="w-3 h-3" />+{delta.toFixed(1)}pp
                              </span>
                            ) : delta < -0.05 ? (
                              <span className="flex items-center justify-center gap-0.5 text-xs text-[oklch(0.72_0.25_30)] font-semibold">
                                <ArrowDown className="w-3 h-3" />{delta.toFixed(1)}pp
                              </span>
                            ) : (
                              <span className="text-muted-foreground text-xs">—</span>
                            )}
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ─── Summary Cards ────────────────────────────────────────────────────────────

function SummaryCards({ snapshot }: { snapshot: CollectionsSnapshot }) {
  const flagged = snapshot.buildings.filter(b => b.collectionPct < 75 && b.rentBilled > 0).length;
  const strong = snapshot.buildings.filter(b => b.collectionPct >= 90 && b.rentBilled > 0).length;
    const totalVouchers = snapshot.buildings.reduce((s, b) => s + b.vouchersCount, 0);
  const totalUtility = snapshot.buildings.reduce((s, b) => s + b.utilityReimbursement, 0);
  const totalVariance = getCollectionVariance(snapshot.totalRentBilled, snapshot.totalRentCollected);
  return (
    <div className="grid grid-cols-1 min-[375px]:grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 mb-6">
      <Card className="neon-card rounded-xl border-[oklch(0.85_0.18_192_/_20%)] bg-[oklch(0.85_0.18_192_/_5%)]">
        <CardContent className="p-4">
          <div className="flex items-center gap-2 mb-1">
            <DollarSign className="w-4 h-4 text-[oklch(0.85_0.18_192)]" />
            <span className="text-xs text-muted-foreground uppercase tracking-wider">Expected Rent</span>
          </div>
          <div className="text-xl font-bold text-[oklch(0.85_0.18_192)]">{fmt(snapshot.totalRentBilled)}</div>
          <div className="text-xs text-muted-foreground mt-0.5">{snapshot.buildings.filter(b => b.rentBilled > 0).length} buildings</div>
        </CardContent>
      </Card>

      <Card className={`neon-card rounded-xl border ${pctBg(snapshot.overallCollectionPct)}`}>
        <CardContent className="p-4">
          <div className="flex items-center gap-2 mb-1">
            <CheckCircle2 className="w-4 h-4 text-[oklch(0.82_0.22_145)]" />
            <span className="text-xs text-muted-foreground uppercase tracking-wider">Total Collected</span>
          </div>
          <div className={`text-xl font-bold ${pctColor(snapshot.overallCollectionPct)}`}>{fmt(snapshot.totalRentCollected)}</div>
          <div className={`text-xs font-semibold mt-0.5 ${pctColor(snapshot.overallCollectionPct)}`}>{snapshot.overallCollectionPct.toFixed(1)}% collection rate</div>
        </CardContent>
      </Card>


      <Card className={`neon-card rounded-xl border ${totalVariance.status === "shortfall" ? "border-[oklch(0.72_0.25_30_/_25%)] bg-[oklch(0.72_0.25_30_/_8%)]" : totalVariance.status === "over_collected" ? "border-[oklch(0.68_0.22_290_/_25%)] bg-[oklch(0.68_0.22_290_/_8%)]" : "border-[oklch(0.82_0.22_145_/_25%)] bg-[oklch(0.82_0.22_145_/_8%)]"}`}>
        <CardContent className="p-4">
          <div className="flex items-center gap-2 mb-1">
            <TrendingUp className="w-4 h-4 text-[oklch(0.85_0.18_192)]" />
            <span className="text-xs text-muted-foreground uppercase tracking-wider">Variance vs Expected</span>
          </div>
          <div className="mt-1"><VarianceCell expectedRent={snapshot.totalRentBilled} collected={snapshot.totalRentCollected} compact /></div>
          <div className="text-xs text-muted-foreground mt-1">Variance tolerance: ±{fmt(COLLECTION_VARIANCE_TOLERANCE)}</div>
        </CardContent>
      </Card>
      <Card className={`neon-card rounded-xl border ${flagged > 0 ? "border-[oklch(0.72_0.25_30_/_25%)] bg-[oklch(0.72_0.25_30_/_5%)]" : "border-[oklch(0.82_0.22_145_/_20%)] bg-[oklch(0.82_0.22_145_/_5%)]"}`}>
        <CardContent className="p-4">
          <div className="flex items-center gap-2 mb-1">
            {flagged > 0 ? <AlertTriangle className="w-4 h-4 text-[oklch(0.72_0.25_30)]" /> : <CheckCircle2 className="w-4 h-4 text-[oklch(0.82_0.22_145)]" />}
            <span className="text-xs text-muted-foreground uppercase tracking-wider">At-Risk (&lt;75%)</span>
          </div>
          <div className={`text-xl font-bold ${flagged > 0 ? "text-[oklch(0.72_0.25_30)]" : "text-[oklch(0.82_0.22_145)]"}`}>{flagged}</div>
          <div className="text-xs text-muted-foreground mt-0.5">{strong} buildings ≥ 90%</div>
        </CardContent>
      </Card>

      <Card className="neon-card rounded-xl border-[oklch(0.68_0.22_290_/_20%)] bg-[oklch(0.68_0.22_290_/_5%)]">
        <CardContent className="p-4">
          <div className="flex items-center gap-2 mb-1">
            <Ticket className="w-4 h-4 text-[oklch(0.68_0.22_290)]" />
            <span className="text-xs text-muted-foreground uppercase tracking-wider">Vouchers / Utility</span>
          </div>
          <div className="text-xl font-bold text-[oklch(0.68_0.22_290)]">{totalVouchers}</div>
          <div className="text-xs text-muted-foreground mt-0.5">Utility reimb: {fmt(totalUtility)}</div>
        </CardContent>
      </Card>
    </div>
  );
}

// ─── Building Cards Grid ──────────────────────────────────────────────────────

function BuildingCards({
  buildings,
  sortMode,
  onCardClick,
}: {
  buildings: CollectionRow[];
  sortMode: SortMode;
  onCardClick: (b: CollectionRow) => void;
}) {
  const sorted = sortBuildings(buildings, sortMode);
  return (
    <div className="grid grid-cols-1 min-[480px]:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
      {sorted.map((b, i) => (
        <Card
          key={`${b.buildingName}-${i}`}
          className={`neon-card relative overflow-hidden rounded-xl border transition-all hover:scale-[1.02] hover:shadow-lg cursor-pointer ${pctBg(b.collectionPct)}`}
          onClick={() => onCardClick(b)}
          title="Click to view historical trend"
        >
          {b.rentBilled > 0 && (() => {
            const variance = getCollectionVariance(b.rentBilled, b.rentCollected);
            const isMaterialShortfall = variance.status === "shortfall";
            return (
              <span
                aria-label={isMaterialShortfall ? "Material collection shortfall" : "Collection variance within tolerance or positive"}
                className="pointer-events-none absolute right-3 top-2 z-10 text-xl leading-none drop-shadow-sm"
                title={isMaterialShortfall ? `Variance is below the $${COLLECTION_VARIANCE_TOLERANCE.toLocaleString()} tolerance` : "Variance is within tolerance or positive"}
              >
                {isMaterialShortfall ? "🚨" : "⭐"}
              </span>
            );
          })()}
          <CardContent className="p-4">
            <div className="flex items-start justify-between mb-3">
              <div className="flex-1 min-w-0">
                <div className="font-semibold text-sm text-foreground truncate">{b.buildingName}</div>
                <div className="text-xs text-muted-foreground">Region {b.regionId}</div>
              </div>
              <CollectionGauge pct={b.collectionPct} />
            </div>

            <div className="space-y-1.5">
              <div className="flex justify-between items-center">
                <span className="text-xs text-muted-foreground">Expected Rent</span>
                <span className="text-xs font-mono font-semibold text-foreground">{fmt(b.rentBilled)}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-xs text-muted-foreground">Collected</span>
                <span className={`text-xs font-mono font-bold ${pctColor(b.collectionPct)}`}>{fmt(b.rentCollected)}</span>
              </div>
              {b.rentBilled > 0 && (
                <div className="flex justify-between items-center">
                  <span className="text-xs text-muted-foreground">Variance</span>
                  <VarianceCell expectedRent={b.rentBilled} collected={b.rentCollected} compact showEmoji={false} />
                </div>
              )}
              {b.utilityReimbursement > 0 && (
                <div className="flex justify-between items-center">
                  <span className="text-xs text-muted-foreground">Utility Reimb.</span>
                  <span className="text-xs font-mono text-muted-foreground">{fmt(b.utilityReimbursement)}</span>
                </div>
              )}
              {b.vouchersCount > 0 && (
                <div className="flex justify-between items-center">
                  <span className="text-xs text-muted-foreground">Vouchers</span>
                  <Badge variant="outline" className="text-[10px] h-4 px-1.5 border-[oklch(0.68_0.22_290_/_30%)] text-[oklch(0.68_0.22_290)]">{b.vouchersCount}</Badge>
                </div>
              )}
            </div>

            {/* Progress bar */}
            <div className="mt-3">
              <div className="h-1.5 rounded-full bg-[oklch(0.3_0.05_240_/_30%)] overflow-hidden">
                <div
                  className="h-full rounded-full transition-all duration-700"
                  style={{
                    width: `${Math.min(b.collectionPct, 100)}%`,
                    background: b.collectionPct >= 90
                      ? "oklch(0.82 0.22 145)"
                      : b.collectionPct >= 75
                      ? "oklch(0.85 0.18 85)"
                      : "oklch(0.72 0.25 30)",
                  }}
                />
              </div>
            </div>

            {/* Change vs prior */}
            {b.rentCollectedChangePct !== null && (
              <div className="mt-2 pt-2 border-t border-border/30 flex items-center justify-between">
                <span className="text-[10px] text-muted-foreground">vs {b.prevSnapshotDate}</span>
                <ChangeIndicator pct={b.rentCollectedChangePct} />
              </div>
            )}

            {/* Click hint */}
            <div className="mt-2 text-[10px] text-muted-foreground/50 text-center">Click to view history</div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

// ─── Table View ───────────────────────────────────────────────────────────────

function BuildingTable({
  buildings,
  sortMode,
  onRowClick,
}: {
  buildings: CollectionRow[];
  sortMode: SortMode;
  onRowClick: (b: CollectionRow) => void;
}) {
  const sorted = sortBuildings(buildings, sortMode);
  return (
    <div className="overflow-x-auto rounded-xl border border-border/30">
      <Table>
        <TableHeader>
          <TableRow className="bg-[oklch(0.85_0.18_192_/_5%)] border-b border-border/30">
            <TableHead className="text-[oklch(0.85_0.18_192)] font-semibold text-xs uppercase tracking-wider">Building</TableHead>
            <TableHead className="text-[oklch(0.85_0.18_192)] font-semibold text-xs uppercase tracking-wider text-right">Expected Rent</TableHead>
            <TableHead className="text-[oklch(0.85_0.18_192)] font-semibold text-xs uppercase tracking-wider text-right">Collected</TableHead>
            <TableHead className="text-[oklch(0.85_0.18_192)] font-semibold text-xs uppercase tracking-wider text-right">Variance</TableHead>
            <TableHead className="text-[oklch(0.85_0.18_192)] font-semibold text-xs uppercase tracking-wider text-center">Rate</TableHead>
            <TableHead className="text-[oklch(0.85_0.18_192)] font-semibold text-xs uppercase tracking-wider text-right">Utility</TableHead>
            <TableHead className="text-[oklch(0.85_0.18_192)] font-semibold text-xs uppercase tracking-wider text-center">Vouchers</TableHead>
            <TableHead className="text-[oklch(0.85_0.18_192)] font-semibold text-xs uppercase tracking-wider text-center">vs Prior</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {sorted.map((b, i) => (
            <TableRow
              key={`${b.buildingName}-${i}`}
              className="border-b border-border/20 hover:bg-[oklch(0.85_0.18_192_/_5%)] transition-colors cursor-pointer"
              onClick={() => onRowClick(b)}
              title="Click to view historical trend"
            >
              <TableCell className="font-medium text-sm">
                <div>{b.buildingName}</div>
                <div className="text-[10px] text-muted-foreground">Region {b.regionId}</div>
              </TableCell>
              <TableCell className="text-right font-mono text-sm">{fmt(b.rentBilled)}</TableCell>
              <TableCell className={`text-right font-mono text-sm font-bold ${pctColor(b.collectionPct)}`}>{fmt(b.rentCollected)}</TableCell>
              <TableCell className="text-right text-sm"><VarianceCell expectedRent={b.rentBilled} collected={b.rentCollected} /></TableCell>
              <TableCell className="text-center">
                <div className="flex items-center justify-center gap-1.5">
                  <div className="w-16 h-1.5 rounded-full bg-[oklch(0.3_0.05_240_/_30%)] overflow-hidden">
                    <div
                      className="h-full rounded-full"
                      style={{
                        width: `${Math.min(b.collectionPct, 100)}%`,
                        background: b.collectionPct >= 90 ? "oklch(0.82 0.22 145)" : b.collectionPct >= 75 ? "oklch(0.85 0.18 85)" : "oklch(0.72 0.25 30)",
                      }}
                    />
                  </div>
                  <span className={`text-xs font-bold ${pctColor(b.collectionPct)}`}>{b.collectionPct.toFixed(1)}%</span>
                </div>
              </TableCell>
              <TableCell className="text-right text-sm text-muted-foreground font-mono">{b.utilityReimbursement > 0 ? fmt(b.utilityReimbursement) : "—"}</TableCell>
              <TableCell className="text-center">
                {b.vouchersCount > 0
                  ? <Badge variant="outline" className="text-[10px] border-[oklch(0.68_0.22_290_/_30%)] text-[oklch(0.68_0.22_290)]">{b.vouchersCount}</Badge>
                  : <span className="text-muted-foreground text-xs">—</span>}
              </TableCell>
              <TableCell className="text-center"><ChangeIndicator pct={b.rentCollectedChangePct} /></TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}

// ─── Sort Button ──────────────────────────────────────────────────────────────

function SortButton({ mode, current, label, onClick }: { mode: SortMode; current: SortMode; label: string; onClick: () => void }) {
  const active = mode === current;
  return (
    <button
      onClick={onClick}
      className={`min-h-9 flex items-center gap-1 text-xs px-2.5 py-1 rounded-lg border transition-all ${
        active
          ? "bg-[oklch(0.85_0.18_85_/_20%)] border-[oklch(0.85_0.18_85_/_40%)] text-[oklch(0.85_0.18_85)] font-semibold"
          : "border-border/30 text-muted-foreground hover:text-foreground hover:border-border/60"
      }`}
    >
      {mode === "rate-asc" && <ArrowUp className="w-3 h-3" />}
      {mode === "rate-desc" && <ArrowDown className="w-3 h-3" />}
      {mode === "billed-desc" && <ArrowUpDown className="w-3 h-3" />}
      {mode === "name-asc" && <ArrowUpDown className="w-3 h-3" />}
      {mode === "region-asc" && <Building2 className="w-3 h-3" />}
      {label}
    </button>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────

export default function CollectionsPanel() {
  const [viewMode, setViewMode] = useState<"cards" | "table">("cards");
  const [searchQuery, setSearchQuery] = useState("");
  const [sortMode, setSortMode] = useState<SortMode>("billed-desc");
  const [selectedBuilding, setSelectedBuilding] = useState<CollectionRow | null>(null);

  const { data: dates, isLoading: datesLoading, refetch: refetchDates } = trpc.collections.getDates.useQuery();
  const { data: latestDate } = trpc.collections.getLatestDate.useQuery();

  const [selectedDate, setSelectedDate] = useState<string>("");
  const { data: currentSnapshotData, isLoading: currentSnapshotLoading, refetch: refetchCurrent } = trpc.collections.getSnapshot.useQuery(
    undefined,
    { staleTime: 60 * 1000, refetchInterval: 60 * 1000, refetchOnWindowFocus: true }
  );
  const effectiveDate = selectedDate || currentSnapshotData?.snapshotDate || latestDate || "";

  const { data: historicalRows, isLoading: historicalRowsLoading, refetch: refetchHistorical } = trpc.collections.getForDate.useQuery(
    { date: selectedDate, buildingQuery: "" },
    { enabled: !!selectedDate }
  );

  const [refreshPin, setRefreshPin] = useState("");
  const [showPinInput, setShowPinInput] = useState(false);
  const refreshMutation = trpc.collections.refresh.useMutation({
    onSuccess: () => {
      void Promise.all([refetchCurrent(), refetchHistorical(), refetchDates()]);
      setShowPinInput(false);
      setRefreshPin("");
    },
    onError: () => setShowPinInput(true),
  });

  function handleRefresh() {
    if (!refreshPin) { setShowPinInput(true); return; }
    refreshMutation.mutate({ pin: refreshPin });
  }

  const snapshot: CollectionsSnapshot | null = useMemo(() => {
    const rows = selectedDate
      ? (historicalRows ?? [])
      : (currentSnapshotData?.buildings ?? []).map((building) => ({
          ...building,
          rentCollectedChangePct: null,
          prevRentCollected: null,
          prevSnapshotDate: null,
        }));
    if (!rows || rows.length === 0) return null;
    const totalRentBilled = rows.reduce((s, r) => s + r.rentBilled, 0);
    const totalRentCollected = rows.reduce((s, r) => s + r.rentCollected, 0);
    const overallCollectionPct = totalRentBilled > 0
      ? Math.round((totalRentCollected / totalRentBilled) * 1000) / 10
      : 0;
    return {
      snapshotDate: effectiveDate,
      buildings: rows as CollectionRow[],
      totalRentBilled,
      totalRentCollected,
      overallCollectionPct,
    };
  }, [selectedDate, historicalRows, currentSnapshotData, effectiveDate]);

  const filteredBuildings = useMemo(() => {
    if (!snapshot) return [];
    if (!searchQuery.trim()) return snapshot.buildings;
    const q = searchQuery.toLowerCase();
    return snapshot.buildings.filter(b => b.buildingName.toLowerCase().includes(q));
  }, [snapshot, searchQuery]);

  const isLoading = datesLoading || currentSnapshotLoading || (Boolean(selectedDate) && historicalRowsLoading);

  if (isLoading && !snapshot) {
    return (
      <div className="flex items-center justify-center py-16">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin text-[oklch(0.85_0.18_192)] mx-auto mb-3" />
          <p className="text-muted-foreground text-sm">Loading collections data…</p>
        </div>
      </div>
    );
  }

  const noData = !snapshot || snapshot.buildings.length === 0;

  return (
    <div className="space-y-4">
      {/* ── Header Controls ── */}
      <div className="flex flex-col items-stretch gap-3 sm:flex-row sm:flex-wrap sm:items-center">
        {/* Date Picker */}
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <BarChart3 className="w-4 h-4 text-[oklch(0.85_0.18_192)]" />
          <Select value={effectiveDate} onValueChange={setSelectedDate}>
            <SelectTrigger className="w-full sm:w-40 h-10 sm:h-8 text-xs border-[oklch(0.85_0.18_192_/_25%)] bg-[oklch(0.85_0.18_192_/_5%)] text-foreground">
              <SelectValue placeholder="Select date…" />
            </SelectTrigger>
            <SelectContent>
              {(dates ?? []).map(d => (
                <SelectItem key={d} value={d} className="text-xs">
                  {new Date(d + "T12:00:00").toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Building Search */}
        <div className="relative w-full sm:flex-1 sm:min-w-[180px] sm:max-w-xs">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
          <Input
            placeholder="Search buildings…"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="pl-8 h-10 sm:h-8 text-xs border-[oklch(0.85_0.18_192_/_25%)] bg-[oklch(0.85_0.18_192_/_5%)]"
          />
        </div>

        {/* Sort Controls */}
        <div className="flex w-full flex-wrap items-center gap-1.5 sm:w-auto">
          <span className="text-xs text-muted-foreground mr-0.5">Sort:</span>
          <SortButton mode="rate-asc" current={sortMode} label="Rate ↑" onClick={() => setSortMode("rate-asc")} />
          <SortButton mode="rate-desc" current={sortMode} label="Rate ↓" onClick={() => setSortMode("rate-desc")} />
          <SortButton mode="billed-desc" current={sortMode} label="Billed" onClick={() => setSortMode("billed-desc")} />
          <SortButton mode="name-asc" current={sortMode} label="A–Z" onClick={() => setSortMode("name-asc")} />
          <SortButton mode="region-asc" current={sortMode} label="Region 1–4" onClick={() => setSortMode("region-asc")} />
        </div>

        {/* View Toggle */}
        <div className="flex w-full items-center gap-1 sm:ml-auto sm:w-auto">
          <Button
            variant="ghost"
            size="sm"
            className={`h-10 sm:h-8 flex-1 sm:flex-none px-3 text-xs ${viewMode === "cards" ? "bg-[oklch(0.85_0.18_192_/_15%)] text-[oklch(0.85_0.18_192)]" : "text-muted-foreground"}`}
            onClick={() => setViewMode("cards")}
          >
            <Building2 className="w-3.5 h-3.5 mr-1" /> Cards
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className={`h-10 sm:h-8 flex-1 sm:flex-none px-3 text-xs ${viewMode === "table" ? "bg-[oklch(0.85_0.18_192_/_15%)] text-[oklch(0.85_0.18_192)]" : "text-muted-foreground"}`}
            onClick={() => setViewMode("table")}
          >
            <BarChart3 className="w-3.5 h-3.5 mr-1" /> Table
          </Button>
        </div>
      </div>

      {/* ── No Data State ── */}
      {noData && (
        <Card className="neon-card rounded-xl border-[oklch(0.85_0.18_85_/_25%)] bg-[oklch(0.85_0.18_85_/_5%)]">
          <CardContent className="py-12 text-center">
            <Zap className="w-10 h-10 text-[oklch(0.85_0.18_85)] mx-auto mb-3 opacity-60" />
            <p className="text-foreground font-semibold mb-1">No collections data yet</p>
            <p className="text-muted-foreground text-sm mb-4">Fetch the latest data from PropertyMax.ai to populate this panel.</p>
            {showPinInput && (
              <div className="flex items-center gap-2 mb-3 justify-center">
                <Input
                  type="password"
                  placeholder="Admin PIN"
                  value={refreshPin}
                  onChange={e => setRefreshPin(e.target.value)}
                  onKeyDown={e => e.key === "Enter" && handleRefresh()}
                  className="w-32 h-8 text-xs text-center border-[oklch(0.85_0.18_85_/_30%)]"
                  autoFocus
                />
              </div>
            )}
            <Button
              size="sm"
              className="bg-[oklch(0.85_0.18_85_/_20%)] hover:bg-[oklch(0.85_0.18_85_/_30%)] text-[oklch(0.85_0.18_85)] border border-[oklch(0.85_0.18_85_/_30%)]"
              onClick={handleRefresh}
              disabled={refreshMutation.isPending}
            >
              {refreshMutation.isPending ? <Loader2 className="w-3.5 h-3.5 animate-spin mr-1.5" /> : <RefreshCw className="w-3.5 h-3.5 mr-1.5" />}
              Load Collections Data
            </Button>
          </CardContent>
        </Card>
      )}

      {/* ── Summary Cards ── */}
      {snapshot && <SummaryCards snapshot={snapshot} />}

      {/* ── Date + Filter Info ── */}
      {snapshot && (
        <div className="flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between text-xs text-muted-foreground px-1">
          <span>
            Showing data for{" "}
            <span className="text-foreground font-semibold">
              {new Date(effectiveDate + "T12:00:00").toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric", year: "numeric" })}
            </span>
            {searchQuery && (
              <> · <span className="text-[oklch(0.85_0.18_192)]">{filteredBuildings.length} buildings matching "{searchQuery}"</span></>
            )}
          </span>
          <span>{snapshot.buildings.length} buildings total{!selectedDate && " · FLOW refreshes every minute"}</span>
        </div>
      )}

      {/* ── Building Cards or Table ── */}
      {snapshot && filteredBuildings.length > 0 && (
        viewMode === "cards"
          ? <BuildingCards buildings={filteredBuildings} sortMode={sortMode} onCardClick={setSelectedBuilding} />
          : <BuildingTable buildings={filteredBuildings} sortMode={sortMode} onRowClick={setSelectedBuilding} />
      )}

      {/* ── No Match State ── */}
      {snapshot && filteredBuildings.length === 0 && searchQuery && (
        <div className="text-center py-8 text-muted-foreground text-sm">
          No buildings match "<span className="text-foreground">{searchQuery}</span>"
        </div>
      )}

      {/* ── History Modal ── */}
      {selectedBuilding && (
        <HistoryModal building={selectedBuilding} onClose={() => setSelectedBuilding(null)} />
      )}
    </div>
  );
}
