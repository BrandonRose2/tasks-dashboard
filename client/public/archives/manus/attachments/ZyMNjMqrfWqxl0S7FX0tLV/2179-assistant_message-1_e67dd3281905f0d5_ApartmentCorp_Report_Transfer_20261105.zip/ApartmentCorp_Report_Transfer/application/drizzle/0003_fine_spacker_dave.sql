CREATE TABLE `email_recipients` (
	`id` int AUTO_INCREMENT NOT NULL,
	`email` varchar(320) NOT NULL,
	`name` varchar(255),
	`receiveDailyVacancy` int NOT NULL DEFAULT 1,
	`receiveMonthlyNetCash` int NOT NULL DEFAULT 0,
	`isActive` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `email_recipients_id` PRIMARY KEY(`id`),
	CONSTRAINT `email_recipients_email_unique` UNIQUE(`email`)
);
