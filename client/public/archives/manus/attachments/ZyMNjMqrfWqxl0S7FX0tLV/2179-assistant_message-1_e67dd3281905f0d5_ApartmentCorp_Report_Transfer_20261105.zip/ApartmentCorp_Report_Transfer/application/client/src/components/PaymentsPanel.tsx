import { useMemo, useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Loader2, TrendingUp, TrendingDown, Minus, DollarSign, AlertTriangle, Calendar, ArrowUp, ArrowDown } from "lucide-react";
import { trpc } from "@/lib/trpc";

// ─── Types ────────────────────────────────────────────────────────────────────

interface ComparisonRow {
  buildingName: string;
  regionId: number;
  todayRent: number;
  todayCash: number;
  prevRent: number;
  prevCash: number;
  rentChangePct: number;
  cashChangePct: number;
  rentFlagged: boolean;
  cashFlagged: boolean;
}

interface PaymentsComparisonData {
  today: string;
  yesterday: string;
  comparison: ComparisonRow[];
}

interface PaymentsSnapshotData {
  snapshotDate: string;
  buildings: { buildingName: string; regionId: number; regionName: string; netRentCollected: number; netCashFlow: number }[];
  totalNetRentCollected: number;
  totalNetCashFlow: number;
}

interface PaymentsPanelProps {
  comparison: PaymentsComparisonData | null | undefined;
  snapshot: PaymentsSnapshotData | null | undefined;
  isLoading: boolean;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

const REGION_NAMES: Record<number, string> = {
  1: "Region 1",
  2: "Region 2",
  3: "Region 3",
  4: "Region 4",
};

function fmt(val: number): string {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(val);
}

function fmtPct(pct: number): string {
  const sign = pct > 0 ? "+" : "";
  return `${sign}${pct.toFixed(1)}%`;
}

function fmtDate(dateStr: string): string {
  try {
    const [y, m, d] = dateStr.split("-").map(Number);
    return new Date(y, m - 1, d).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
  } catch {
    return dateStr;
  }
}

function ChangeBadge({ pct, flagged, hasData }: { pct: number; flagged: boolean; hasData: boolean }) {
  if (!hasData) {
    return (
      <span className="flex items-center gap-1 text-muted-foreground/50 text-xs italic">
        <Minus className="w-3 h-3" /> —
      </span>
    );
  }
  if (pct === 0) {
    return (
      <span className="flex items-center gap-1 text-muted-foreground text-xs">
        <Minus className="w-3 h-3" /> 0.0%
      </span>
    );
  }
  const isPos = pct > 0;
  const Icon = isPos ? ArrowUp : ArrowDown;
  const colorClass = isPos
    ? "text-[oklch(0.75_0.20_145)]"
    : flagged
    ? "text-[oklch(0.55_0.18_240)]"
    : "text-[oklch(0.65_0.22_25)]";

  return (
    <span className={`flex items-center gap-1 text-xs font-semibold ${colorClass}`}>
      {flagged && <span title="Change exceeds ±5%">🚨</span>}
      <Icon className="w-3 h-3" />
      {fmtPct(pct)}
    </span>
  );
}

// ─── Summary Cards ────────────────────────────────────────────────────────────

function SummaryCard({
  label,
  value,
  prevValue,
  changePct,
  flagged,
  hasComparison,
}: {
  label: string;
  value: number;
  prevValue: number;
  changePct: number;
  flagged: boolean;
  hasComparison: boolean;
}) {
  const isPos = changePct > 0;
  const Icon = changePct === 0 ? Minus : isPos ? TrendingUp : TrendingDown;
  const trendColor = changePct === 0
    ? "text-muted-foreground"
    : isPos
    ? "text-[oklch(0.75_0.20_145)]"
    : flagged
    ? "text-[oklch(0.55_0.18_240)]"
    : "text-[oklch(0.65_0.22_25)]";

  return (
    <Card className="border-0 bg-[oklch(0.12_0.02_260)] rounded-xl overflow-hidden">
      <div className="h-0.5 w-full bg-gradient-to-r from-[oklch(0.85_0.18_192_/_60%)] to-transparent" />
      <CardContent className="p-4">
        <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1">{label}</p>
        <p className="text-2xl font-black text-card-foreground">{fmt(value)}</p>
        {hasComparison ? (
          <div className={`flex items-center gap-1.5 mt-1 ${trendColor}`}>
            {flagged && <span title="Change exceeds ±5%">🚨</span>}
            <Icon className="w-3.5 h-3.5" />
            <span className="text-xs font-semibold">{fmtPct(changePct)} vs selected date</span>
          </div>
        ) : (
          <p className="text-xs text-muted-foreground/50 italic mt-1">Select a comparison date</p>
        )}
        {hasComparison && prevValue !== 0 && (
          <p className="text-xs text-muted-foreground mt-0.5">Prev: {fmt(prevValue)}</p>
        )}
      </CardContent>
    </Card>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────

export default function PaymentsPanel({ comparison: defaultComparison, snapshot, isLoading: defaultLoading }: PaymentsPanelProps) {
  // Fetch available dates
  const { data: availableDates } = trpc.payments.getDates.useQuery(undefined, {
    staleTime: 5 * 60 * 1000,
  });

  // Date picker state
  const [viewDate, setViewDate] = useState<string>("");
  const [compareDate, setCompareDate] = useState<string>("");

  // Seed viewDate from latest available date once loaded
  useEffect(() => {
    if (availableDates && availableDates.length > 0 && !viewDate) {
      setViewDate(availableDates[0]);
      if (availableDates.length > 1) setCompareDate(availableDates[1]);
    }
  }, [availableDates, viewDate]);

  // Custom comparison query (only when both dates are selected and different from defaults)
  const useCustomComparison = !!(viewDate && compareDate && viewDate !== compareDate);
  const { data: customComparison, isLoading: customLoading } = trpc.payments.getComparison.useQuery(
    { date: viewDate, compareDate },
    {
      enabled: useCustomComparison,
      staleTime: 5 * 60 * 1000,
    }
  );

  // Determine which data to show
  const activeComparison: PaymentsComparisonData | null | undefined = useCustomComparison
    ? (customComparison as PaymentsComparisonData | null | undefined)
    : defaultComparison;

  const isLoading = defaultLoading || (useCustomComparison && customLoading);

  // Group comparison rows by region
  const byRegion = useMemo(() => {
    const source = activeComparison?.comparison ?? snapshot?.buildings?.map(b => ({
      buildingName: b.buildingName,
      regionId: b.regionId,
      todayRent: b.netRentCollected,
      todayCash: b.netCashFlow,
      prevRent: 0,
      prevCash: 0,
      rentChangePct: 0,
      cashChangePct: 0,
      rentFlagged: false,
      cashFlagged: false,
    })) ?? [];

    const map = new Map<number, ComparisonRow[]>();
    for (const row of source) {
      if (!map.has(row.regionId)) map.set(row.regionId, []);
      map.get(row.regionId)!.push(row as ComparisonRow);
    }
    return [1, 2, 3, 4]
      .filter((r) => map.has(r))
      .map((r) => ({ regionId: r, rows: map.get(r)! }));
  }, [activeComparison, snapshot]);

  // Aggregate totals
  const totals = useMemo(() => {
    const source = activeComparison?.comparison ?? [];
    const totalRent = source.reduce((s, r) => s + r.todayRent, 0);
    const totalCash = source.reduce((s, r) => s + r.todayCash, 0);
    const prevRent = source.reduce((s, r) => s + r.prevRent, 0);
    const prevCash = source.reduce((s, r) => s + r.prevCash, 0);
    const rentChangePct = prevRent !== 0 ? ((totalRent - prevRent) / Math.abs(prevRent)) * 100 : 0;
    const cashChangePct = prevCash !== 0 ? ((totalCash - prevCash) / Math.abs(prevCash)) * 100 : 0;
    return {
      totalRent: totalRent || snapshot?.totalNetRentCollected || 0,
      totalCash: totalCash || snapshot?.totalNetCashFlow || 0,
      prevRent,
      prevCash,
      rentChangePct: Math.round(rentChangePct * 10) / 10,
      cashChangePct: Math.round(cashChangePct * 10) / 10,
      rentFlagged: Math.abs(rentChangePct) >= 5,
      cashFlagged: Math.abs(cashChangePct) >= 5,
    };
  }, [activeComparison, snapshot]);

  const flaggedCount = useMemo(() => {
    return (activeComparison?.comparison ?? []).filter(r => r.rentFlagged || r.cashFlagged).length;
  }, [activeComparison]);

  const hasComparison = !!activeComparison && activeComparison.comparison.length > 0 && (
    activeComparison.comparison.some(r => r.prevRent !== 0 || r.prevCash !== 0)
  );
  const hasData = byRegion.length > 0;

  if (isLoading && !hasData) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-8 h-8 animate-spin text-[oklch(0.85_0.18_192)]" />
        <span className="ml-3 text-muted-foreground">Loading payment data…</span>
      </div>
    );
  }

  if (!hasData) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center">
        <DollarSign className="w-12 h-12 text-muted-foreground mb-4 opacity-40" />
        <p className="text-muted-foreground font-medium">No payment data available yet.</p>
        <p className="text-sm text-muted-foreground mt-1">Data will appear once the first scrape completes.</p>
      </div>
    );
  }

  const dates = availableDates ?? [];

  return (
    <div className="space-y-6">
      {/* ── Date Picker Controls ── */}
      <Card className="border border-[oklch(0.85_0.18_192_/_15%)] bg-[oklch(0.10_0.02_260)] rounded-xl">
        <CardContent className="p-4">
          <div className="flex flex-wrap items-center gap-4">
            <div className="flex items-center gap-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
              <Calendar className="w-3.5 h-3.5" />
              Date Range
            </div>
            <div className="flex items-center gap-2 flex-1 min-w-0">
              <div className="flex flex-col gap-1 flex-1 min-w-[140px]">
                <label className="text-xs text-muted-foreground">View Date</label>
                <Select value={viewDate} onValueChange={setViewDate}>
                  <SelectTrigger className="h-8 text-xs bg-[oklch(0.12_0.02_260)] border-[oklch(0.85_0.18_192_/_20%)]">
                    <SelectValue placeholder="Select date…" />
                  </SelectTrigger>
                  <SelectContent>
                    {dates.map(d => (
                      <SelectItem key={d} value={d} className="text-xs">{fmtDate(d)}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex flex-col gap-1 flex-1 min-w-[140px]">
                <label className="text-xs text-muted-foreground">Compare To</label>
                <Select value={compareDate} onValueChange={setCompareDate}>
                  <SelectTrigger className="h-8 text-xs bg-[oklch(0.12_0.02_260)] border-[oklch(0.85_0.18_192_/_20%)]">
                    <SelectValue placeholder="No comparison" />
                  </SelectTrigger>
                  <SelectContent>
                    {dates.filter(d => d !== viewDate).map(d => (
                      <SelectItem key={d} value={d} className="text-xs">{fmtDate(d)}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            {/* Active comparison info */}
            {activeComparison && (
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <Badge variant="outline" className="font-mono text-xs">{fmtDate(activeComparison.today)}</Badge>
                <span>vs</span>
                <Badge variant="outline" className="font-mono text-xs">{fmtDate(activeComparison.yesterday)}</Badge>
                {flaggedCount > 0 && (
                  <Badge className="bg-[oklch(0.65_0.22_25_/_20%)] text-[oklch(0.72_0.20_35)] border border-[oklch(0.65_0.22_25_/_40%)]">
                    🚨 {flaggedCount} flagged
                  </Badge>
                )}
              </div>
            )}
            {customLoading && (
              <Loader2 className="w-4 h-4 animate-spin text-[oklch(0.85_0.18_192)] shrink-0" />
            )}
          </div>
        </CardContent>
      </Card>

      {/* ── Summary Totals ── */}
      <div className="grid grid-cols-1 gap-4">
        <SummaryCard
          label="Total Net Rent Collected"
          value={totals.totalRent}
          prevValue={totals.prevRent}
          changePct={totals.rentChangePct}
          flagged={totals.rentFlagged}
          hasComparison={hasComparison}
        />

      </div>

      {/* ── Per-Region Tables ── */}
      {byRegion.map(({ regionId, rows }) => {
        const regionRent = rows.reduce((s, r) => s + r.todayRent, 0);
        const regionCash = rows.reduce((s, r) => s + r.todayCash, 0);
        const regionFlagged = rows.filter(r => r.rentFlagged || r.cashFlagged).length;

        return (
          <Card key={regionId} className="border border-[oklch(0.85_0.18_192_/_15%)] bg-[oklch(0.10_0.02_260)] rounded-xl overflow-hidden">
            <CardHeader className="pb-2 pt-4 px-4 bg-[oklch(0.85_0.18_192_/_5%)] border-b border-[oklch(0.85_0.18_192_/_10%)]">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-bold text-[oklch(0.85_0.18_192)]">
                  {REGION_NAMES[regionId] ?? `Region ${regionId}`}
                </CardTitle>
                <div className="flex items-center gap-3 text-xs text-muted-foreground">
                  {regionFlagged > 0 && (
                    <span className="text-[oklch(0.70_0.18_240)]">🚨 {regionFlagged} flagged</span>
                  )}
                  <span>Rent: <span className="text-card-foreground font-semibold">{fmt(regionRent)}</span></span>
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow className="bg-[oklch(0.85_0.18_192_/_3%)] border-b border-[oklch(0.85_0.18_192_/_10%)]">
                    <TableHead className="text-[oklch(0.85_0.18_192)] font-semibold text-xs pl-4">Building</TableHead>
                    <TableHead className="text-right text-[oklch(0.85_0.18_192)] font-semibold text-xs">Net Rent Collected</TableHead>
                    <TableHead className="text-right text-[oklch(0.85_0.18_192)] font-semibold text-xs">% Change / Prev Day</TableHead>

                  </TableRow>
                </TableHeader>
                <TableBody>
                  {rows.map((row, idx) => {
                    const isAnyFlagged = row.rentFlagged || row.cashFlagged;
                    return (
                      <TableRow
                        key={`pay-${idx}-${row.buildingName}`}
                        className={`border-b border-border/30 transition-colors ${
                          isAnyFlagged
                            ? "bg-[oklch(0.55_0.18_240_/_8%)] hover:bg-[oklch(0.55_0.18_240_/_12%)]"
                            : "hover:bg-white/3"
                        }`}
                      >
                        <TableCell className="font-medium text-card-foreground text-sm pl-4 py-2.5">
                          {isAnyFlagged && <span className="mr-1.5">🚨</span>}
                          {row.buildingName}
                        </TableCell>
                        <TableCell className="text-right font-mono text-sm text-card-foreground py-2.5">
                          {fmt(row.todayRent)}
                        </TableCell>
                        <TableCell className="text-right py-2.5">
                          <div className="flex flex-col items-end gap-0.5">
                            <ChangeBadge pct={row.rentChangePct} flagged={row.rentFlagged} hasData={hasComparison && row.prevRent !== 0} />
                            {hasComparison && row.prevRent !== 0 && (
                              <span className={`text-xs font-mono ${row.rentFlagged ? "text-[oklch(0.55_0.18_240)]" : "text-muted-foreground/70"}`}>
                                {fmt(row.prevRent)}
                              </span>
                            )}
                          </div>
                        </TableCell>

                      </TableRow>
                    );
                  })}
                  {/* Region subtotal row */}
                  <TableRow className="bg-[oklch(0.85_0.18_192_/_5%)] border-t border-[oklch(0.85_0.18_192_/_20%)]">
                    <TableCell className="font-bold text-[oklch(0.85_0.18_192)] text-xs uppercase tracking-wide pl-4 py-2">
                      Region Total
                    </TableCell>
                    <TableCell className="text-right font-bold font-mono text-sm text-[oklch(0.85_0.18_192)] py-2">
                      {fmt(regionRent)}
                    </TableCell>
                    <TableCell />
                  </TableRow>
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        );
      })}

      {/* ── Grand Total ── */}
      <Card className="border border-[oklch(0.85_0.12_85_/_30%)] bg-[oklch(0.12_0.02_260)] rounded-xl overflow-hidden">
        <div className="h-0.5 w-full bg-gradient-to-r from-[oklch(0.85_0.12_85)] via-[oklch(0.85_0.18_192)] to-transparent" />
        <CardContent className="p-4">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-0.5">Portfolio Total</p>
              <p className="text-xs text-muted-foreground">All {byRegion.reduce((s, r) => s + r.rows.length, 0)} buildings</p>
            </div>
            <div className="flex gap-8">
              <div className="text-right">
                <p className="text-xs text-muted-foreground mb-0.5">Net Rent Collected</p>
                <p className="text-xl font-black text-card-foreground">{fmt(totals.totalRent)}</p>
              </div>

            </div>
          </div>
        </CardContent>
      </Card>

      {/* ── No comparison note ── */}
      {!hasComparison && hasData && dates.length < 2 && (
        <div className="flex items-center gap-2 text-xs text-muted-foreground bg-[oklch(0.12_0.02_260)] rounded-lg border border-white/5 p-3">
          <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
          <span>Day-over-day comparison will appear once data has been collected for at least 2 days.</span>
        </div>
      )}
    </div>
  );
}
