ALTER TABLE `daily_vacancy_jobs` ADD `collections_approved` boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE `daily_vacancy_send_ledger` ADD `report_type` enum('vacancy','collections','collections_test') DEFAULT 'vacancy' NOT NULL;--> statement-breakpoint
ALTER TABLE `daily_vacancy_send_ledger` ADD CONSTRAINT `daily_vacancy_job_report_date_unique` UNIQUE(`job_id`,`report_type`,`local_date`);--> statement-breakpoint
ALTER TABLE `daily_vacancy_send_ledger` DROP INDEX `daily_vacancy_job_date_unique`;
