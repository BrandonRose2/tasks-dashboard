import nodemailer from "nodemailer";
import { describe, expect, it } from "vitest";

describe("replacement Gmail credentials", () => {
  it.skipIf(process.env.GMAIL_CREDENTIAL_LIVE_VERIFY !== "true")(
    "authenticates the selected Gmail account without sending mail",
    async () => {
      const user = process.env.GMAIL_USER?.trim().toLowerCase();
      const password = process.env.GMAIL_APP_PASSWORD?.replace(/\s/g, "");
      expect(user, "GMAIL_USER must be the newly selected account").toBe("apartmentcorp44@gmail.com");
      expect(Boolean(password && /^[a-zA-Z]{16}$/.test(password)), "A 16-letter Gmail App Password is required").toBe(true);
      const transporter = nodemailer.createTransport({
        host: "smtp.gmail.com",
        port: 587,
        secure: false,
        requireTLS: true,
        auth: { user, pass: password },
        connectionTimeout: 15000,
        greetingTimeout: 15000,
        socketTimeout: 20000,
      });
      try {
        expect(await transporter.verify()).toBe(true);
      } finally {
        transporter.close();
      }
    },
    45000,
  );
});
