import { describe, expect, it } from "vitest";
import { hasVacancyUnitDetailCoverage, type DashboardData } from "./scraper";

const railwayBuildingOnlyDashboard: DashboardData = {
  stats: { totalVacant: 115, vacUnleased: 63, vacPreleased: 52, onNotice: 29, eviction: 62 },
  buildingVacancy: [
    { name: "Example", totalVacant: 115, vacUnleased: 63, vacPreleased: 52, onNotice: 29, eviction: 62, totalUnits: 1000, vacancyPct: 11.5, atRisk: true },
  ],
  dailyChanges: [],
  vacantUnleased: [],
  vacantPreleased: [],
  onNotice: [],
  evictions: [],
  historicalMonths: [],
  lastUpdated: new Date("2026-10-19T20:34:08.692Z"),
};

describe("Daily Vacancy source safety", () => {
  it("recognizes that Railway unit details are unavailable while retaining its reconciled building-level snapshot", () => {
    expect(hasVacancyUnitDetailCoverage(railwayBuildingOnlyDashboard)).toBe(false);
    expect(railwayBuildingOnlyDashboard.buildingVacancy.reduce((sum, row) => sum + row.totalVacant, 0)).toBe(
      railwayBuildingOnlyDashboard.stats.totalVacant,
    );
  });
});
