import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";
import ts from "typescript";
import { describe, expect, it } from "vitest";
const source = (path: string) => readFileSync(new URL(path, import.meta.url), "utf8");
const hash = (text: string) => createHash("sha256").update(text).digest("hex");
describe("Monthly restoration stays isolated", () => {
  it("preserves the original Monthly HTML function byte-for-byte apart from its export", () => {
    const text = source("./emailService.ts"); const ast = ts.createSourceFile("emailService.ts", text, ts.ScriptTarget.Latest, true);
    const fn = ast.statements.find(n => ts.isFunctionDeclaration(n) && n.name?.text === "buildMonthlyNetCashHtml")!;
    expect(hash(text.slice(fn.getStart(ast), fn.end).replace(/^export /, ""))).toBe("dc96c39c5af21f74974e5477a80a75320d982c2c9e9128b578a284cfc5d9faeb");
  });
  it.each([
    ["./auxiliaryEmailScheduled.ts", "2d9a58538da0342137e9cbfd8de5902f6996679bd09e6324b8d96171334abd5c"],
    ["./auxiliaryEmailSchedulePolicy.ts", "17f00107c63a065e747c97a940ead28e0ec8761c62605faa96f8598cd779a0e6"],
  ])("does not change %s", (path, expected) => expect(hash(source(path))).toBe(expected));
  it("adds only monthly schema tables without altering any existing table", () => {
    const before = JSON.parse(source("../drizzle/meta/0011_snapshot.json")); const after = JSON.parse(source("../drizzle/meta/0012_snapshot.json"));
    for (const [name, table] of Object.entries(before.tables)) expect(after.tables[name]).toEqual(table);
    expect(Object.keys(after.tables).filter(name => !before.tables[name]).sort()).toEqual(["monthly_email_deliveries", "monthly_email_jobs", "monthly_email_runs"]);
  });
  it("migration does not destroy data and alters only new monthly tables", () => {
    const sql = source("../drizzle/0012_monthly_net_cash_heartbeat.sql");
    expect(sql).not.toMatch(/DROP TABLE|DELETE FROM|TRUNCATE|UPDATE\s+`/i);
    expect([...sql.matchAll(/(?:CREATE|ALTER) TABLE `([^`]+)`/g)].every(match => match[1].startsWith("monthly_email_"))).toBe(true);
    expect(sql).toContain("UNIQUE(`job_id`,`period_key`)"); expect(sql).toContain("`activated_at` timestamp(3)");
  });
  it("monthly callback has no registration, recipient fallback, or body-controlled policy", () => {
    const text = source("./monthlyEmailScheduled.ts");
    expect(text).not.toMatch(/req\.body|createHeartbeatJob|updateHeartbeatJob|dailyVacancyJobs|auxiliaryEmailJobs|getMonthlyNetCashRecipients/);
    expect(text).toContain("sdk.authenticateRequest(req)");
    expect(text).toContain("getMonthlyEmailJobByTaskUid(uid)");
  });
});
