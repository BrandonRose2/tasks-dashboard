// Retired legacy Collections entry point. Importing or executing this file never sends email.
console.error("Legacy Collections sender retired; use sendManagedCollectionsTestToEthan(taskUid) only after explicit test authorization.");
process.exitCode = 1;
