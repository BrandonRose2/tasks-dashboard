import { describe, expect, it } from "vitest";
import { DAILY_VACANCY_TEST_RECIPIENT, sendDailyVacancyEmail } from "./emailService";

describe("Daily Vacancy recipient containment", () => {
  it("pins the only explicit test recipient to Ethan", () => {
    expect(DAILY_VACANCY_TEST_RECIPIENT).toBe("ethan@apartmentcorp.com");
  });

  it("rejects a non-approved test recipient before contacting PropertyMax or the email transport", async () => {
    await expect(sendDailyVacancyEmail("mam@22.bz")).resolves.toBe(false);
  });

  it("rejects a mixed recipient list before contacting PropertyMax or the email transport", async () => {
    await expect(sendDailyVacancyEmail("Brandon@ApartmentCorp.com, Ethan@ApartmentCorp.com")).resolves.toBe(false);
  });
});
