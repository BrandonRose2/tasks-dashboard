import { writeFile } from "node:fs/promises";
import { buildCurrentCollectionsHtml, buildDailyVacancyHtml } from "./server/emailService";
import { fetchRailwayCollectionsSnapshot, fetchRailwayVacancySnapshot } from "./server/railwayReports";

const [vacancy, collections] = await Promise.all([
  fetchRailwayVacancySnapshot(),
  fetchRailwayCollectionsSnapshot(),
]);

await writeFile("/home/ubuntu/railway_daily_vacancy_preview.html", buildDailyVacancyHtml(vacancy));
await writeFile("/home/ubuntu/railway_daily_collections_preview.html", buildCurrentCollectionsHtml(collections, []));

console.log(JSON.stringify({
  vacancy: {
    lastUpdated: vacancy.lastUpdated.toISOString(),
    totalVacant: vacancy.stats.totalVacant,
    vacUnleased: vacancy.stats.vacUnleased,
    vacPreleased: vacancy.stats.vacPreleased,
    onNotice: vacancy.stats.onNotice,
    eviction: vacancy.stats.eviction,
    buildingCount: vacancy.buildingVacancy.length,
  },
  collections: {
    snapshotDate: collections.snapshotDate,
    buildingCount: collections.buildings.length,
    totalRentBilled: collections.totalRentBilled,
    totalRentCollected: collections.totalRentCollected,
    overallCollectionPct: collections.overallCollectionPct,
  },
}, null, 2));
