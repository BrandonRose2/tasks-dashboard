import { describe, expect, it } from "vitest";
import { hasSessionInitializationError } from "./scraper";

describe("PropertyMax session recovery detection", () => {
  it("detects a ColdFusion SESSION.mybuildings error instead of treating it as an empty summary", () => {
    expect(hasSessionInitializationError("<html><title>ERROR</title>Element mybuildings is undefined in SESSION.</html>")).toBe(true);
  });

  it("detects a redirect back to the login form", () => {
    expect(hasSessionInitializationError('<input name="cfusername" /><input id="log" />')).toBe(true);
  });

  it("detects the ColdFusion empty-portfolio SQL error as a failed session bootstrap", () => {
    expect(hasSessionInitializationError("Error Executing Database Query: r.regionid IN ()"))
      .toBe(true);
  });

  it("does not reject normal PropertyMax summary data", () => {
    expect(hasSessionInitializationError("<table><thead><tr><th>Building</th></tr></thead></table>")).toBe(false);
  });
});
