import { useMemo } from "react";

interface SparklineProps {
  data: number[];
  width?: number;
  height?: number;
  color?: string;
  fillColor?: string;
  strokeWidth?: number;
}

export function Sparkline({
  data,
  width = 80,
  height = 24,
  color = "#00e5ff",
  fillColor,
  strokeWidth = 1.5,
}: SparklineProps) {
  const path = useMemo(() => {
    if (data.length < 2) return null;

    const min = Math.min(...data);
    const max = Math.max(...data);
    const range = max - min || 1;
    const padding = 2;
    const w = width - padding * 2;
    const h = height - padding * 2;

    const points = data.map((val, i) => ({
      x: padding + (i / (data.length - 1)) * w,
      y: padding + h - ((val - min) / range) * h,
    }));

    const linePath = points
      .map((p, i) => (i === 0 ? `M ${p.x} ${p.y}` : `L ${p.x} ${p.y}`))
      .join(" ");

    const fillPath = fillColor
      ? `${linePath} L ${points[points.length - 1].x} ${height} L ${points[0].x} ${height} Z`
      : null;

    return { linePath, fillPath, lastPoint: points[points.length - 1] };
  }, [data, width, height, fillColor]);

  if (!path) {
    return (
      <span className="text-[10px] text-muted-foreground italic">
        Collecting...
      </span>
    );
  }

  // Determine trend color
  const trend = data[data.length - 1] - data[0];
  const trendColor = trend > 0 ? "#ff4444" : trend < 0 ? "#00e676" : color;

  return (
    <svg
      width={width}
      height={height}
      viewBox={`0 0 ${width} ${height}`}
      className="inline-block"
    >
      {path.fillPath && (
        <path
          d={path.fillPath}
          fill={fillColor || `${trendColor}20`}
          opacity={0.3}
        />
      )}
      <path
        d={path.linePath}
        fill="none"
        stroke={trendColor}
        strokeWidth={strokeWidth}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle
        cx={path.lastPoint.x}
        cy={path.lastPoint.y}
        r={2}
        fill={trendColor}
      />
    </svg>
  );
}
