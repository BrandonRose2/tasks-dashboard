import { expect, it } from "vitest";
import { createGmailReportTransport } from "./gmailReportTransport";

// Opt-in only. Credentials must already be supplied securely in the environment.
// This test authenticates via SMTP verify(), never delivers a message.
it.skipIf(process.env.GMAIL_SMTP_LIVE_VERIFY !== "true")(
  "verifies selected Gmail SMTP without sending mail",
  async () => {
    const transporter = createGmailReportTransport();
    try {
      let verified: boolean;
      try {
        verified = await transporter.verify();
      } catch {
        // Avoid exposing arbitrary SMTP error payloads or credential values.
        throw new Error("Gmail SMTP verification failed; check relay credentials and network access securely.");
      }
      expect(verified).toBe(true);
    } finally {
      transporter.close();
    }
  },
  90_000,
);
