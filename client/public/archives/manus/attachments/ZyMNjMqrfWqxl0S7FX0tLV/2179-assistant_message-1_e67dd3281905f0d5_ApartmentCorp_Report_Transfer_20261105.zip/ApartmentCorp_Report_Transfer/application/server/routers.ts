import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { fetchDashboardData, invalidateCache, getVacancyHistory, getWeeklySummary, parseAndIngestRawData, getCachedData, getLastCompleteDashboardData, getPaymentsSnapshot, fetchAndSavePaymentsSnapshot, fetchHistoricalMonths, getCollectionsSnapshot, fetchAndSaveCollectionsSnapshot } from "./scraper";
import { sendMonthlyNetCashEmail, sendWeeklySummaryEmail, buildDailyVacancyHtml, buildWeeklySummaryHtml } from "./emailService";
import { getAllRecipients, addRecipient, updateRecipient, deleteRecipient, getAllUnitOverrides, upsertUnitOverride, deleteUnitOverride, getPaymentsForDateDb, getLatestPaymentsDate, getPaymentsDates, getCollectionsAtTimestamp, getCollectionsLookup, getCollectionsDates, getLatestCollectionsDate, getCollectionHistory } from "./db";
import { fetchFreshMonthlyNetCashReport, getCompletedMonthlyNetCashPeriod, getPreviousCompletedMonth } from "./monthlyNetCashReport";
import { z } from "zod";
import { ENV } from "./_core/env";

const ADMIN_PIN = process.env.ADMIN_PIN || "3060";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  vacancy: router({
    // Get full dashboard data (cached for 30 minutes)
    getDashboard: publicProcedure
      .input(z.object({ forceRefresh: z.boolean().optional() }).optional())
      .query(async ({ input }) => {
        try {
          const data = await fetchDashboardData(input?.forceRefresh ?? false);
          return { ...data, sourceStatus: { state: "live" as const } };
        } catch (error) {
          const lastComplete = getLastCompleteDashboardData();
          const message = "Live PropertyMax vacancy details are temporarily unavailable. Showing the last complete snapshot while the connection recovers.";
          if (lastComplete) {
            console.warn("[Dashboard] PropertyMax refresh failed; serving last complete snapshot:", error);
            return { ...lastComplete, sourceStatus: { state: "stale" as const, message } };
          }
          console.warn("[Dashboard] PropertyMax refresh failed before a complete snapshot was available:", error);
          return {
            stats: { totalVacant: 0, vacUnleased: 0, vacPreleased: 0, onNotice: 0, eviction: 0 },
            vacantUnleased: [], vacantPreleased: [], onNotice: [], evictions: [],
            buildingVacancy: [], dailyChanges: [], historicalMonths: [], lastUpdated: new Date(),
            sourceStatus: { state: "unavailable" as const, message },
          };
        }
      }),

    // Refresh cache manually
    refresh: publicProcedure.mutation(async () => {
      invalidateCache();
      try {
        const data = await fetchDashboardData(true);
        return { success: true, lastUpdated: data.lastUpdated };
      } catch (error) {
        return {
          success: false,
          message: "PropertyMax is temporarily unavailable. The dashboard will keep the last complete data visible.",
        };
      }
    }),

    // Send daily vacancy email manually (for testing)
    sendDailyEmail: publicProcedure
      .input(z.object({ recipient: z.string().email().optional() }).optional())
      .mutation(async ({ input }): Promise<{ success: boolean }> => {
        throw new Error("Manual daily distribution retired; use the approved managed callback or the authorized Ethan-only Collections test helper.");
      }),

    // Ingest raw HTML fetched by the browser from propertymax.ai
    // This bypasses the Node.js TLS issue by letting the browser do the HTTP fetch
    ingestFromBrowser: publicProcedure
      .input(z.object({
        orangebxupd: z.string(),
        summary1: z.string(),
        summary2: z.string(),
        summary3: z.string(),
        summary4: z.string(),
      }))
      .mutation(async ({ input }) => {
        const data = await parseAndIngestRawData(input);
        return { success: true, lastUpdated: data.lastUpdated };
      }),

    // Get cached dashboard data without triggering a server-side scrape
    getCached: publicProcedure.query(async () => {
      return getCachedData();
    }),

    // Get vacancy history for sparklines (last 30 days)
    getHistory: publicProcedure.query(async () => {
      return await getVacancyHistory();
    }),

    // Get weekly summary data (7-day trends)
    getWeeklySummary: publicProcedure.query(async () => {
      return await getWeeklySummary();
    }),

    // Get vacant unleased units for a specific building (for modal drill-down)
    getVacantUnitsByBuilding: publicProcedure
      .input(z.object({ buildingName: z.string() }))
      .query(async ({ input }) => {
        const data = await getCachedData();
        if (!data) return { units: [], buildingName: input.buildingName };
        const units = (data.vacantUnleased || []).filter(
          (u: { building: string }) => u.building === input.buildingName
        );
        return { units, buildingName: input.buildingName };
      }),

    // Send weekly summary email manually (for testing)
    sendWeeklyEmail: publicProcedure
      .input(z.object({ recipient: z.string().email().optional() }).optional())
      .mutation(async ({ input }) => {
        const summary = await getWeeklySummary();
        const sent = await sendWeeklySummaryEmail(summary, input?.recipient);
        return { success: sent };
      }),

    // Verify admin PIN for accessing restricted sections
    verifyPin: publicProcedure
      .input(z.object({ pin: z.string() }))
      .mutation(async ({ input }) => {
        const valid = input.pin === ADMIN_PIN;
        return { valid };
      }),

    // Preview daily vacancy email HTML (for admin preview)
    previewDailyEmail: publicProcedure
      .input(z.object({ pin: z.string() }))
      .query(async ({ input }) => {
        if (input.pin !== ADMIN_PIN) throw new Error("Invalid PIN");
        const data = await fetchDashboardData(false);
        const html = buildDailyVacancyHtml(data);
        return { html };
      }),

    // Preview weekly summary email HTML (for admin preview)
    previewWeeklyEmail: publicProcedure
      .input(z.object({ pin: z.string() }))
      .query(async ({ input }) => {
        if (input.pin !== ADMIN_PIN) throw new Error("Invalid PIN");
        const summary = await getWeeklySummary();
        const html = buildWeeklySummaryHtml(summary);
        return { html };
      }),

    // Clear historical cache and re-fetch all months (admin only)
    clearHistoricalCache: publicProcedure
      .input(z.object({ pin: z.string() }))
      .mutation(async ({ input }) => {
        if (input.pin !== ADMIN_PIN) throw new Error("Invalid PIN");
        const { getDb } = await import("./db");
        const { historicalCache } = await import("../drizzle/schema");
        const db = await getDb();
        if (db) {
          await db.delete(historicalCache);
          console.log("[Admin] Historical cache cleared");
        }
        // Trigger a fresh fetch (non-blocking)
        fetchHistoricalMonths(12).catch(err => console.warn("[Admin] Re-fetch failed:", err));
        return { success: true };
      }),

    // Test PropertyMax.ai connection health (admin only)
    testConnection: publicProcedure
      .input(z.object({ pin: z.string() }))
      .mutation(async ({ input }) => {
        if (input.pin !== ADMIN_PIN) throw new Error("Invalid PIN");
        const startTime = Date.now();
        try {
          const { fetchVacancyStats } = await import("./scraper");
          await fetchVacancyStats();
          const elapsed = Date.now() - startTime;
          return { success: true, message: "Connected successfully", latencyMs: elapsed };
        } catch (err: any) {
          const elapsed = Date.now() - startTime;
          return { success: false, message: err?.message ?? "Unknown error", latencyMs: elapsed };
        }
      }),

    // Send monthly net cash email manually (for testing)
    sendMonthlyEmail: publicProcedure
      .input(z.object({ year: z.number().int().min(2000).max(2100), month: z.number().int().min(1).max(12), recipient: z.string().email().optional() }).optional())
      .mutation(async ({ input }) => {
        const period = input
          ? getCompletedMonthlyNetCashPeriod(input.year, input.month)
          : getPreviousCompletedMonth();
        const { month } = await fetchFreshMonthlyNetCashReport(period);
        const sent = await sendMonthlyNetCashEmail(month, input?.recipient);
        return { success: sent };
      }),
  }),

  // Email recipient management (admin-only via PIN)
  recipients: router({
    list: publicProcedure.query(async () => {
      const recipients = await getAllRecipients();
      return recipients.map(r => ({
        id: r.id,
        email: r.email,
        name: r.name,
        receiveDailyVacancy: r.receiveDailyVacancy === 1,
        receiveMonthlyNetCash: r.receiveMonthlyNetCash === 1,
        scheduleGroup: r.scheduleGroup as "early" | "admin",
        isActive: r.isActive === 1,
        createdAt: r.createdAt,
      }));
    }),

    add: publicProcedure
      .input(z.object({
        pin: z.string(),
        email: z.string().email(),
        name: z.string().optional(),
        receiveDailyVacancy: z.boolean().default(true),
        receiveMonthlyNetCash: z.boolean().default(false),
        scheduleGroup: z.enum(["early", "admin"]).default("early"),
      }))
      .mutation(async ({ input }) => {
        if (input.pin !== ADMIN_PIN) throw new Error("Invalid PIN");
        await addRecipient({
          email: input.email,
          name: input.name,
          receiveDailyVacancy: input.receiveDailyVacancy,
          receiveMonthlyNetCash: input.receiveMonthlyNetCash,
          scheduleGroup: input.scheduleGroup,
        });
        return { success: true };
      }),

    update: publicProcedure
      .input(z.object({
        pin: z.string(),
        id: z.number(),
        name: z.string().optional(),
        receiveDailyVacancy: z.boolean().optional(),
        receiveMonthlyNetCash: z.boolean().optional(),
        scheduleGroup: z.enum(["early", "admin"]).optional(),
        isActive: z.boolean().optional(),
      }))
      .mutation(async ({ input }) => {
        if (input.pin !== ADMIN_PIN) throw new Error("Invalid PIN");
        await updateRecipient(input.id, {
          name: input.name,
          receiveDailyVacancy: input.receiveDailyVacancy,
          receiveMonthlyNetCash: input.receiveMonthlyNetCash,
          scheduleGroup: input.scheduleGroup,
          isActive: input.isActive,
        });
        return { success: true };
      }),

    remove: publicProcedure
      .input(z.object({
        pin: z.string(),
        id: z.number(),
      }))
      .mutation(async ({ input }) => {
        if (input.pin !== ADMIN_PIN) throw new Error("Invalid PIN");
        await deleteRecipient(input.id);
        return { success: true };
      }),

    // Send daily vacancy report immediately to a specific recipient's email
    sendNow: publicProcedure
      .input(z.object({
        pin: z.string(),
        email: z.string().email(),
      }))
      .mutation(async ({ input }): Promise<{ success: boolean }> => {
        if (input.pin !== ADMIN_PIN) throw new Error("Invalid PIN");
        throw new Error("Manual daily distribution retired; use the approved managed callback or the authorized Ethan-only Collections test helper.");
      }),
  }),

  // ─── Payments: Net Rent Collected + Net Cash Flow ──────────────────────────
  payments: router({
    // Get today's payments snapshot (from DB or fresh scrape)
    getSnapshot: publicProcedure
      .input(z.object({ forceRefresh: z.boolean().optional() }).optional())
      .query(async ({ input }) => {
        const snapshot = await getPaymentsSnapshot(input?.forceRefresh ?? false);
        return snapshot;
      }),

    // Get payments for a specific date (for comparison)
    getForDate: publicProcedure
      .input(z.object({ date: z.string() }))
      .query(async ({ input }) => {
        const rows = await getPaymentsForDateDb(input.date);
        return rows.map(r => ({
          buildingName: r.buildingName,
          regionId: r.regionId,
          netRentCollected: parseFloat(r.netRentCollected),
          netCashFlow: parseFloat(r.netCashFlow),
        }));
      }),

    // Get available snapshot dates
    getDates: publicProcedure.query(async () => {
      return getPaymentsDates();
    }),

    // Get latest snapshot date
    getLatestDate: publicProcedure.query(async () => {
      return getLatestPaymentsDate();
    }),

    // Get comparison between any two dates
    getComparison: publicProcedure
      .input(z.object({ date: z.string(), compareDate: z.string() }))
      .query(async ({ input }) => {
        const [todayRows, prevRows] = await Promise.all([
          getPaymentsForDateDb(input.date),
          getPaymentsForDateDb(input.compareDate),
        ]);
        if (todayRows.length === 0) return null;
        const prevMap = new Map<string, { netRentCollected: number; netCashFlow: number }>();
        for (const r of prevRows) {
          prevMap.set(r.buildingName, {
            netRentCollected: parseFloat(r.netRentCollected),
            netCashFlow: parseFloat(r.netCashFlow),
          });
        }
        const comparison = todayRows.map(r => {
          const prev = prevMap.get(r.buildingName);
          const todayRent = parseFloat(r.netRentCollected);
          const todayCash = parseFloat(r.netCashFlow);
          const prevRent = prev?.netRentCollected ?? 0;
          const prevCash = prev?.netCashFlow ?? 0;
          const rentChangePct = prevRent !== 0 ? ((todayRent - prevRent) / Math.abs(prevRent)) * 100 : 0;
          const cashChangePct = prevCash !== 0 ? ((todayCash - prevCash) / Math.abs(prevCash)) * 100 : 0;
          return {
            buildingName: r.buildingName,
            regionId: r.regionId,
            todayRent,
            todayCash,
            prevRent,
            prevCash,
            rentChangePct: Math.round(rentChangePct * 10) / 10,
            cashChangePct: Math.round(cashChangePct * 10) / 10,
            rentFlagged: Math.abs(rentChangePct) >= 5,
            cashFlagged: Math.abs(cashChangePct) >= 5,
          };
        });
        return { today: input.date, yesterday: input.compareDate, comparison };
      }),

    // Force refresh payments snapshot
    refresh: publicProcedure
      .input(z.object({ pin: z.string() }))
      .mutation(async ({ input }) => {
        if (input.pin !== ADMIN_PIN) throw new Error("Invalid PIN");
        const snapshot = await fetchAndSavePaymentsSnapshot();
        return { success: true, buildingCount: snapshot.buildings.length, snapshotDate: snapshot.snapshotDate };
      }),

    // Timestamp-based collections lookup
    getAtTimestamp: publicProcedure
      .input(z.object({
        timestamp: z.string().min(1, "Timestamp is required"),
        buildingQuery: z.string().min(1, "Building name or ID is required"),
      }))
      .query(async ({ input }) => {
        const results = await getCollectionsAtTimestamp(input.timestamp, input.buildingQuery);
        return results;
      }),

    // Get yesterday's payments for daily change comparison
    getYesterdayComparison: publicProcedure.query(async () => {
      const dates = await getPaymentsDates();
      if (dates.length < 2) return null;
      const today = dates[0];
      const yesterday = dates[1];
      const [todayRows, yesterdayRows] = await Promise.all([
        getPaymentsForDateDb(today),
        getPaymentsForDateDb(yesterday),
      ]);
      const yesterdayMap = new Map<string, { netRentCollected: number; netCashFlow: number }>();
      for (const r of yesterdayRows) {
        yesterdayMap.set(r.buildingName, {
          netRentCollected: parseFloat(r.netRentCollected),
          netCashFlow: parseFloat(r.netCashFlow),
        });
      }
      const comparison = todayRows.map(r => {
        const prev = yesterdayMap.get(r.buildingName);
        const todayRent = parseFloat(r.netRentCollected);
        const todayCash = parseFloat(r.netCashFlow);
        const prevRent = prev?.netRentCollected ?? 0;
        const prevCash = prev?.netCashFlow ?? 0;
        const rentChangePct = prevRent !== 0 ? ((todayRent - prevRent) / Math.abs(prevRent)) * 100 : 0;
        const cashChangePct = prevCash !== 0 ? ((todayCash - prevCash) / Math.abs(prevCash)) * 100 : 0;
        return {
          buildingName: r.buildingName,
          regionId: r.regionId,
          todayRent,
          todayCash,
          prevRent,
          prevCash,
          rentChangePct: Math.round(rentChangePct * 10) / 10,
          cashChangePct: Math.round(cashChangePct * 10) / 10,
          rentFlagged: Math.abs(rentChangePct) >= 5,
          cashFlagged: Math.abs(cashChangePct) >= 5,
        };
      });
      return { today, yesterday, comparison };
    }),
  }),

  // ─── Building Unit Count Overrides ─────────────────────────────────────────
  unitOverrides: router({
    list: publicProcedure
      .input(z.object({ pin: z.string() }))
      .query(async ({ input }) => {
        if (input.pin !== ADMIN_PIN) throw new Error("Invalid PIN");
        return getAllUnitOverrides();
      }),
    upsert: publicProcedure
      .input(z.object({
        pin: z.string(),
        buildingName: z.string().min(1),
        totalUnits: z.number().int().min(1),
      }))
      .mutation(async ({ input }) => {
        if (input.pin !== ADMIN_PIN) throw new Error("Invalid PIN");
        await upsertUnitOverride(input.buildingName, input.totalUnits);
        invalidateCache();
        return { success: true };
      }),
    delete: publicProcedure
      .input(z.object({
        pin: z.string(),
        id: z.number(),
      }))
      .mutation(async ({ input }) => {
        if (input.pin !== ADMIN_PIN) throw new Error("Invalid PIN");
        await deleteUnitOverride(input.id);
        invalidateCache();
        return { success: true };
      }),
  }),

  // ─── Collections (FLOW Tab) ────────────────────────────────────────────────
  collections: router({
    // Get today's collections snapshot (from DB or fresh scrape)
    getSnapshot: publicProcedure
      .input(z.object({ forceRefresh: z.boolean().optional() }).optional())
      .query(async ({ input }) => {
        return getCollectionsSnapshot(input?.forceRefresh ?? false);
      }),

    // Get collections for a specific date
    getForDate: publicProcedure
      .input(z.object({ date: z.string(), buildingQuery: z.string().optional() }))
      .query(async ({ input }) => {
        return getCollectionsLookup(input.date, input.buildingQuery ?? "");
      }),

    // Get all available snapshot dates
    getDates: publicProcedure.query(async () => {
      return getCollectionsDates();
    }),

    // Get latest snapshot date
    getLatestDate: publicProcedure.query(async () => {
      return getLatestCollectionsDate();
    }),

    // Get historical collection data for a specific building (for trend modal)
    getHistory: publicProcedure
      .input(z.object({ buildingName: z.string() }))
      .query(async ({ input }) => {
        return getCollectionHistory(input.buildingName);
      }),

    // Force refresh collections snapshot (admin only)
    refresh: publicProcedure
      .input(z.object({ pin: z.string() }))
      .mutation(async ({ input }) => {
        if (input.pin !== ADMIN_PIN) throw new Error("Invalid PIN");
        const snapshot = await fetchAndSaveCollectionsSnapshot();
        return { success: true, buildingCount: snapshot.buildings.length, snapshotDate: snapshot.snapshotDate };
      }),
  }),
});

export type AppRouter = typeof appRouter;
