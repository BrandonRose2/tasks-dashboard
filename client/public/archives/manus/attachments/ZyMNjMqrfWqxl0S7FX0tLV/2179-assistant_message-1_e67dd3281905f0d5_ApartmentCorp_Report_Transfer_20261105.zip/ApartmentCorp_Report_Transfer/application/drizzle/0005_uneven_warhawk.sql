CREATE TABLE `building_unit_overrides` (
	`id` int AUTO_INCREMENT NOT NULL,
	`buildingName` varchar(255) NOT NULL,
	`totalUnits` int NOT NULL,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `building_unit_overrides_id` PRIMARY KEY(`id`),
	CONSTRAINT `building_unit_overrides_buildingName_unique` UNIQUE(`buildingName`)
);
