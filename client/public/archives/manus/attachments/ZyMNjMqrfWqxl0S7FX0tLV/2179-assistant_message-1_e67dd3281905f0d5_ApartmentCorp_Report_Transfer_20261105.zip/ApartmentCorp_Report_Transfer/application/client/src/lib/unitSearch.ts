export type SearchableUnit = {
  building?: string | null;
  unit?: string | null;
  dateBy?: string | null;
  dates?: string | null;
  leased?: string | null;
};

/** Matches the fields a manager is most likely to know when looking up a unit. */
export function matchesUnitSearch(unit: SearchableUnit, rawQuery: string): boolean {
  const query = rawQuery.trim().toLocaleLowerCase();
  if (!query) return true;

  return [unit.building, unit.unit, unit.dateBy, unit.dates, unit.leased]
    .filter((value): value is string => typeof value === "string")
    .some((value) => value.toLocaleLowerCase().includes(query));
}
