import { describe, expect, it } from "vitest";

describe("Email recipients schema", () => {
  it("should define emailRecipients table in drizzle schema", async () => {
    const schema = await import("../drizzle/schema");
    expect(schema.emailRecipients).toBeDefined();
  });

  it("should export EmailRecipient and InsertEmailRecipient types", async () => {
    // Type-level check: if these don't exist, the import will fail
    const schema = await import("../drizzle/schema");
    expect(schema.emailRecipients).toBeDefined();
    // The table should have the expected columns
    const columns = Object.keys(schema.emailRecipients);
    expect(columns.length).toBeGreaterThan(0);
  });
});

describe("Email recipients DB helpers", () => {
  it("should export getAllRecipients function", async () => {
    const db = await import("./db");
    expect(typeof db.getAllRecipients).toBe("function");
  });

  it("should export getDailyVacancyRecipients function", async () => {
    const db = await import("./db");
    expect(typeof db.getDailyVacancyRecipients).toBe("function");
  });

  it("should export getMonthlyNetCashRecipients function", async () => {
    const db = await import("./db");
    expect(typeof db.getMonthlyNetCashRecipients).toBe("function");
  });

  it("should export addRecipient function", async () => {
    const db = await import("./db");
    expect(typeof db.addRecipient).toBe("function");
  });

  it("should export updateRecipient function", async () => {
    const db = await import("./db");
    expect(typeof db.updateRecipient).toBe("function");
  });

  it("should export deleteRecipient function", async () => {
    const db = await import("./db");
    expect(typeof db.deleteRecipient).toBe("function");
  });
});

describe("Scheduled Vacancy recipient containment", () => {
  it("uses the Admin-tab Daily Vacancy recipient list for scheduled reports", async () => {
    const fs = await import("fs");
    const source = fs.readFileSync(
      new URL("./emailService.ts", import.meta.url),
      "utf-8"
    );
    expect(source).toContain("getDailyVacancyRecipients");
    expect(source).toContain("isScheduledAdminDelivery");
  });

  it("does not retain the legacy multi-recipient Daily Vacancy fallback", async () => {
    const fs = await import("fs");
    const source = fs.readFileSync(
      new URL("./emailService.ts", import.meta.url),
      "utf-8"
    );
    expect(source).not.toContain("FALLBACK_DAILY_RECIPIENTS");
    expect(source).not.toContain("getDailyVacancyRecipients(scheduleGroup)");
  });

  it("keeps independent monthly recipient configuration available", async () => {
    const fs = await import("fs");
    const source = fs.readFileSync(
      new URL("./emailService.ts", import.meta.url),
      "utf-8"
    );
    expect(source).toContain("await getMonthlyNetCashRecipients()");
    expect(source).not.toContain("FALLBACK_MONTHLY_RECIPIENTS");
    const { MONTHLY_RECIPIENTS } = await import("./monthlyEmailSchedulePolicy");
    expect(MONTHLY_RECIPIENTS).toEqual(["ethan@apartmentcorp.com", "mam@22.bz"]);
  });

  it("removes the legacy in-process Daily Vacancy schedule", async () => {
    const fs = await import("fs");
    const scheduler = fs.readFileSync(
      new URL("./emailScheduler.ts", import.meta.url),
      "utf-8"
    );
    expect(scheduler).toContain("Daily Vacancy + Collections: single managed durable schedule");
    expect(scheduler).not.toContain("runEarlyDailyEmail");
    expect(scheduler).not.toContain("runAdminDailyEmail");
  });
});

describe("tRPC recipients router", () => {
  it("should define recipients router with CRUD procedures", async () => {
    const fs = await import("fs");
    const source = fs.readFileSync(
      new URL("./routers.ts", import.meta.url),
      "utf-8"
    );
    expect(source).toContain("recipients: router({");
    expect(source).toContain("list:");
    expect(source).toContain("add:");
    expect(source).toContain("update:");
    expect(source).toContain("remove:");
  });

  it("should require PIN for add/update/remove operations", async () => {
    const fs = await import("fs");
    const source = fs.readFileSync(
      new URL("./routers.ts", import.meta.url),
      "utf-8"
    );
    // All mutation procedures should check PIN
    const pinChecks = (source.match(/input\.pin !== ADMIN_PIN/g) || []).length;
    expect(pinChecks).toBeGreaterThanOrEqual(3); // add, update, remove
  });

  it("should validate email format on add", async () => {
    const fs = await import("fs");
    const source = fs.readFileSync(
      new URL("./routers.ts", import.meta.url),
      "utf-8"
    );
    expect(source).toContain("z.string().email()");
  });
});
