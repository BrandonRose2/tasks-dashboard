import { describe, expect, it } from "vitest";

describe("Email recipients configuration", () => {
  let source: string;

  const getSource = async () => {
    if (!source) {
      const fs = await import("fs");
      source = fs.readFileSync(
        new URL("./emailService.ts", import.meta.url),
        "utf-8"
      );
    }
    return source;
  };

  it("should use the Admin-tab Daily Vacancy recipient list for scheduled reports", async () => {
    const src = await getSource();
    expect(src).toContain("getDailyVacancyRecipients");
    expect(src).toContain("isScheduledAdminDelivery");
  });

  it("should not accept a legacy schedule-group recipient selector", async () => {
    const src = await getSource();
    expect(src).not.toContain('scheduleGroup?: "early" | "admin"');
  });

  it("should use database-driven recipients via getMonthlyNetCashRecipients", async () => {
    const src = await getSource();
    expect(src).toContain("getMonthlyNetCashRecipients");
    expect(src).toContain("await getMonthlyNetCashRecipients()");
  });

  it("should not retain a multi-recipient Daily Vacancy fallback", async () => {
    const src = await getSource();
    expect(src).not.toContain("FALLBACK_DAILY_RECIPIENTS");
  });

  it("should permit Ethan only for the explicitly labeled Test3 run", async () => {
    const src = await getSource();
    expect(src).toContain('testLabel?.trim() === "Test3"');
    expect(src).toContain("EXCHANGE_SMTP_SENDER");
  });

  it("does not retain a financial-report recipient fallback and schedules Monthly only to Ethan and Marc", async () => {
    const src = await getSource();
    expect(src).not.toContain("FALLBACK_MONTHLY_RECIPIENTS");
    const { MONTHLY_RECIPIENTS } = await import("./monthlyEmailSchedulePolicy");
    expect(MONTHLY_RECIPIENTS).toEqual(["ethan@apartmentcorp.com", "mam@22.bz"]);
  });

  it("should use the selected Gmail relay as From and retain Ethan as Reply-To", async () => {
    const src = await getSource();
    expect(src).toContain("FROM_EMAIL = GMAIL_REPORT_SENDER");
    expect(src).toContain('FROM_NAME = "Apartment Corp Reports"');
    expect(src).toContain("REPLY_TO = EXCHANGE_SMTP_SENDER");
    expect(src).toContain("FROM_EMAIL");
  });

  it("should still support recipientOverride for test emails", async () => {
    const src = await getSource();
    expect(src).toContain("recipientOverride?: string");
  });
});

describe("Vacancy Changes section in daily email", () => {
  let source: string;

  const getSource = async () => {
    if (!source) {
      const fs = await import("fs");
      source = fs.readFileSync(
        new URL("./emailService.ts", import.meta.url),
        "utf-8"
      );
    }
    return source;
  };

  it("should have Vacancy Changes section at the top of the email (before stats cards)", async () => {
    const src = await getSource();
    const changesIdx = src.indexOf("VACANCY CHANGES TODAY");
    const statsIdx = src.indexOf("Current Vacancy Overview");
    expect(changesIdx).toBeGreaterThan(-1);
    expect(statsIdx).toBeGreaterThan(-1);
    expect(changesIdx).toBeLessThan(statsIdx);
  });

  it("should include full building details in the changes section", async () => {
    const src = await getSource();
    // The changes section should look up building details
    expect(src).toContain('buildingVacancy.find');
    // Should show vacancy %, units, unleased, preleased, notice, eviction columns
    expect(src).toContain('bldg.vacancyPct');
    expect(src).toContain('bldg.totalUnits');
    expect(src).toContain('bldg.vacUnleased');
    expect(src).toContain('bldg.vacPreleased');
    expect(src).toContain('bldg.onNotice');
    expect(src).toContain('bldg.eviction');
  });

  it("should present vacancy changes with neutral numeric cues", async () => {
    const src = await getSource();
    expect(src).toContain('const changeColor = "#153a5b"');
    expect(src).toContain("Positive change indicates more vacant units");
  });

  it("should show a 'No Vacancy Changes' message when there are no changes", async () => {
    const src = await getSource();
    expect(src).toContain("No Vacancy Changes Today");
    expect(src).toContain("same vacancy count as yesterday");
  });

  it("should have removed the old Daily Changes section from lower in the email", async () => {
    const src = await getSource();
    // The old section had this exact heading
    expect(src).not.toContain('Daily Changes (vs. Previous Day)');
  });
});

describe("Email scheduler configuration", () => {
  let schedulerSource: string;

  const getSchedulerSource = async () => {
    if (!schedulerSource) {
      const fs = await import("fs");
      schedulerSource = fs.readFileSync(
        new URL("./emailScheduler.ts", import.meta.url),
        "utf-8"
      );
    }
    return schedulerSource;
  };

  it("should delegate Daily Vacancy scheduling to the managed durable schedule", async () => {
    const src = await getSchedulerSource();
    expect(src).toContain("Daily Vacancy + Collections: single managed durable schedule");
    expect(src).not.toContain("runAdminDailyEmail");
    expect(src).not.toContain("sendDailyVacancyEmail()");
  });

  it("should not retain the legacy early recipient group", async () => {
    const src = await getSchedulerSource();
    expect(src).not.toContain('"early"');
    expect(src).not.toContain("earlyDailyTimer");
  });

  it("should not retain an in-process Daily Vacancy timer", async () => {
    const src = await getSchedulerSource();
    expect(src).not.toContain("adminDailyTimer");
    expect(src).not.toContain("adminDailyInterval");
    expect(src).not.toContain("collectionsTimer");
  });

  it("restores Monthly through a separate external schedule, never an app timer or startup activation", async () => {
    const src = await getSchedulerSource();
    expect(src).not.toContain("MONTHLY_HOUR_UTC");
    expect(src).not.toContain("MONTHLY_DAY");
    expect(src).toContain("Monthly Net Cash Flow: standalone Heartbeat, 12th at 1 PM America/Los_Angeles");
    expect(src).toContain("No startup provisioning or activation");
    expect(src).not.toMatch(/setInterval|setTimeout|sendMonthlyNetCashEmail|createHeartbeat/);
  });

  it("does not pass a legacy schedule group to the in-process scheduler", async () => {
    const src = await getSchedulerSource();
    expect(src).not.toContain("scheduleGroup");
  });

  it("retires weekly and eviction timers for standalone Heartbeats", async () => {
    const src = await getSchedulerSource();
    expect(src).toContain("LEGACY_WEEKLY_TIMER_RETIRED = true");
    expect(src).toContain("LEGACY_EVICTION_TIMER_RETIRED = true");
    expect(src).not.toMatch(/setTimeout|setInterval|getMsUntilNext/);
    const fs = await import("fs");
    const policy = fs.readFileSync(new URL("./auxiliaryEmailSchedulePolicy.ts", import.meta.url), "utf8");
    expect(policy).toContain('cron: "0 0 13,14 * * 6"');
    expect(policy).toContain('cron: "0 0 13,14 1,15 * *"');
    expect(policy).toContain('AUXILIARY_SEND_HOUR = 9');
    expect(policy).toContain('"America/New_York"');
    const callback = fs.readFileSync(new URL("./auxiliaryEmailScheduled.ts", import.meta.url), "utf8");
    expect(callback).toContain("getWeeklySummary");
    expect(callback).toContain("prepareWeeklySummaryEmail");
    const entry = fs.readFileSync(new URL("./_core/index.ts", import.meta.url), "utf8");
    expect(entry).not.toMatch(/startEmailScheduler|ensureAuxiliary|activateAuxiliary/);
  });
});

describe("Weekly summary email", () => {
  let source: string;

  const getSource = async () => {
    if (!source) {
      const fs = await import("fs");
      source = fs.readFileSync(
        new URL("./emailService.ts", import.meta.url),
        "utf-8"
      );
    }
    return source;
  };

  it("should have buildWeeklySummaryHtml function", async () => {
    const src = await getSource();
    expect(src).toContain("buildWeeklySummaryHtml");
  });

  it("should have sendWeeklySummaryEmail function", async () => {
    const src = await getSource();
    expect(src).toContain("sendWeeklySummaryEmail");
  });

  it("should include week-at-a-glance overview section", async () => {
    const src = await getSource();
    expect(src).toContain("WEEK AT A GLANCE");
    expect(src).toContain("NET CHANGE");
    expect(src).toContain("BUILDINGS CHANGED");
  });

  it("should include new vacancies and recently leased sections", async () => {
    const src = await getSource();
    expect(src).toContain("NEW VACANCIES");
    expect(src).toContain("RECENTLY LEASED");
  });

  it("should include day-by-day changes log", async () => {
    const src = await getSource();
    expect(src).toContain("DAY-BY-DAY CHANGES");
  });

  it("should include current snapshot stats", async () => {
    const src = await getSource();
    expect(src).toContain("CURRENT SNAPSHOT");
    expect(src).toContain("TOTAL VACANT");
    expect(src).toContain("UNLEASED");
    expect(src).toContain("PRELEASED");
  });

  it("should support overrideRecipient for test sends", async () => {
    const src = await getSource();
    expect(src).toContain("overrideRecipient?: string");
  });

  it("should export buildWeeklySummaryHtml for testing", async () => {
    const src = await getSource();
    expect(src).toContain("buildWeeklySummaryHtml");
    const exportLine = src.match(/export\s*\{[^}]*buildWeeklySummaryHtml[^}]*\}/);
    expect(exportLine).toBeTruthy();
  });

  it("should use purple theme for weekly report", async () => {
    const src = await getSource();
    expect(src).toContain("#7c4dff");
    expect(src).toContain("WEEKLY REPORT");
    expect(src).toContain("WEEKLY SUMMARY");
  });
});

describe("DB recipients with scheduleGroup", () => {
  it("should support scheduleGroup parameter in getDailyVacancyRecipients", async () => {
    const fs = await import("fs");
    const src = fs.readFileSync(
      new URL("./db.ts", import.meta.url),
      "utf-8"
    );
    expect(src).toContain('scheduleGroup?: "early" | "admin"');
    expect(src).toContain("r.scheduleGroup === scheduleGroup");
  });

  it("should support scheduleGroup in addRecipient", async () => {
    const fs = await import("fs");
    const src = fs.readFileSync(
      new URL("./db.ts", import.meta.url),
      "utf-8"
    );
    expect(src).toContain('scheduleGroup: data.scheduleGroup || "early"');
  });

  it("should support scheduleGroup in updateRecipient", async () => {
    const fs = await import("fs");
    const src = fs.readFileSync(
      new URL("./db.ts", import.meta.url),
      "utf-8"
    );
    expect(src).toContain("data.scheduleGroup !== undefined");
    expect(src).toContain("updateSet.scheduleGroup = data.scheduleGroup");
  });
});

describe("At-Risk sort logic", () => {
  type SortField = "name" | "vacancyPct" | "totalVacant" | "totalUnits" | "vacUnleased" | "vacPreleased" | "onNotice" | "eviction";
  type SortDir = "asc" | "desc";

  interface BuildingVacancy {
    name: string;
    totalVacant: number;
    vacUnleased: number;
    vacPreleased: number;
    onNotice: number;
    eviction: number;
    totalUnits: number;
    vacancyPct: number;
    atRisk: boolean;
  }

  function sortBuildings(buildings: BuildingVacancy[], field: SortField, dir: SortDir): BuildingVacancy[] {
    const sorted = [...buildings];
    sorted.sort((a, b) => {
      const aVal = a[field as keyof BuildingVacancy];
      const bVal = b[field as keyof BuildingVacancy];
      if (typeof aVal === "string" && typeof bVal === "string") {
        return dir === "asc" ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
      }
      const aNum = Number(aVal) || 0;
      const bNum = Number(bVal) || 0;
      return dir === "asc" ? aNum - bNum : bNum - aNum;
    });
    return sorted;
  }

  const testBuildings: BuildingVacancy[] = [
    { name: "Arbor Crest", totalVacant: 23, vacUnleased: 14, vacPreleased: 9, onNotice: 0, eviction: 2, totalUnits: 120, vacancyPct: 19.2, atRisk: true },
    { name: "Howell Place", totalVacant: 9, vacUnleased: 2, vacPreleased: 7, onNotice: 0, eviction: 0, totalUnits: 48, vacancyPct: 18.8, atRisk: true },
    { name: "Thibodaux", totalVacant: 14, vacUnleased: 12, vacPreleased: 2, onNotice: 0, eviction: 0, totalUnits: 107, vacancyPct: 13.1, atRisk: true },
    { name: "Gates", totalVacant: 21, vacUnleased: 12, vacPreleased: 9, onNotice: 3, eviction: 0, totalUnits: 276, vacancyPct: 7.6, atRisk: true },
  ];

  it("should sort by vacancy % descending by default", () => {
    const sorted = sortBuildings(testBuildings, "vacancyPct", "desc");
    expect(sorted[0].name).toBe("Arbor Crest");
    expect(sorted[1].name).toBe("Howell Place");
    expect(sorted[sorted.length - 1].name).toBe("Gates");
  });

  it("should sort by vacancy % ascending", () => {
    const sorted = sortBuildings(testBuildings, "vacancyPct", "asc");
    expect(sorted[0].name).toBe("Gates");
    expect(sorted[sorted.length - 1].name).toBe("Arbor Crest");
  });

  it("should sort by building name alphabetically ascending", () => {
    const sorted = sortBuildings(testBuildings, "name", "asc");
    expect(sorted[0].name).toBe("Arbor Crest");
    expect(sorted[1].name).toBe("Gates");
    expect(sorted[2].name).toBe("Howell Place");
    expect(sorted[3].name).toBe("Thibodaux");
  });

  it("should sort by building name alphabetically descending", () => {
    const sorted = sortBuildings(testBuildings, "name", "desc");
    expect(sorted[0].name).toBe("Thibodaux");
    expect(sorted[sorted.length - 1].name).toBe("Arbor Crest");
  });

  it("should sort by total vacant units descending", () => {
    const sorted = sortBuildings(testBuildings, "totalVacant", "desc");
    expect(sorted[0].name).toBe("Arbor Crest"); // 23
    expect(sorted[1].name).toBe("Gates"); // 21
    expect(sorted[2].name).toBe("Thibodaux"); // 14
    expect(sorted[3].name).toBe("Howell Place"); // 9
  });

  it("should sort by total units descending", () => {
    const sorted = sortBuildings(testBuildings, "totalUnits", "desc");
    expect(sorted[0].name).toBe("Gates"); // 276
    expect(sorted[1].name).toBe("Arbor Crest"); // 120
  });

  it("should sort by unleased descending", () => {
    const sorted = sortBuildings(testBuildings, "vacUnleased", "desc");
    expect(sorted[0].name).toBe("Arbor Crest"); // 14
    expect(sorted[sorted.length - 1].name).toBe("Howell Place"); // 2
  });
});
