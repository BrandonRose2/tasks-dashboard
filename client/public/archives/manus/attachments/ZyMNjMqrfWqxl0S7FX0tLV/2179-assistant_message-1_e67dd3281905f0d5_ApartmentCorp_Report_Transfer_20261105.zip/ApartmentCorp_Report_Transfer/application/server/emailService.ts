import { fetchDashboardData, type DashboardData, type BuildingVacancy, type MarcsNetCash, type HistoricalMonth, type WeeklySummaryData, type CollectionsSnapshot } from "./scraper";
import { getDailyVacancyRecipients, getMonthlyNetCashRecipients, getPaymentsForDateDb, getPaymentsDates, getCollectionsLookup } from "./db";
import type { CollectionsLookupResult } from "./db";
import { COLLECTION_VARIANCE_TOLERANCE, getCollectionVariance } from "@shared/collectionVariance";
import { GMAIL_REPORT_SENDER, createGmailReportTransport } from "./gmailReportTransport";
import { assertApprovedScheduledRecipients } from "./dailyVacancySchedulePolicy";
import { replaceScopedReportRecipients } from "./scopedReportRecipients";
import { assertCompleteMonthlyNetCashReport } from "./monthlyNetCashReport";

// ─── Config ────────────────────────────────────────────────────────────────────

export const DAILY_VACANCY_TEST_RECIPIENT = "ethan@apartmentcorp.com";

// Legacy Exchange identity retained for compatibility and the existing Test3 allowlist.
// Exchange helpers below are inactive: report delivery uses only the selected Gmail relay.
export const EXCHANGE_SMTP_SENDER = "ethan@apartmentcorp.com";
const FROM_NAME = "Apartment Corp Reports";
const FROM_EMAIL = GMAIL_REPORT_SENDER;
const REPLY_TO = EXCHANGE_SMTP_SENDER;

// The active Manus-hosted dashboard is the durable report destination.
const REPORT_DASHBOARD_URL = "https://vacancyreport.manus.space";
function getDashboardUrl(): string {
  return REPORT_DASHBOARD_URL;
}

export type ExchangeSmtpConfig = {
  tenantId: string;
  clientId: string;
  clientSecret: string;
  sender: string;
};

/** Inactive legacy Exchange configuration API retained for existing imports/tests. */
export function getExchangeSmtpConfig(env: NodeJS.ProcessEnv = process.env): ExchangeSmtpConfig {
  const tenantId = env.EXCHANGE_TENANT_ID?.trim();
  const clientId = env.EXCHANGE_CLIENT_ID?.trim();
  const clientSecret = env.EXCHANGE_CLIENT_SECRET?.trim();
  const sender = env.EXCHANGE_SMTP_SENDER?.trim().toLowerCase() ?? EXCHANGE_SMTP_SENDER;

  if (!tenantId || !clientId || !clientSecret) {
    throw new Error("Exchange OAuth credentials are not configured. Set EXCHANGE_TENANT_ID, EXCHANGE_CLIENT_ID, and EXCHANGE_CLIENT_SECRET.");
  }
  if (sender !== EXCHANGE_SMTP_SENDER) {
    throw new Error(`Exchange SMTP sender must be ${EXCHANGE_SMTP_SENDER}.`);
  }
  return { tenantId, clientId, clientSecret, sender };
}

/** Inactive legacy app-only Exchange token API; never called by the report transport. */
export async function getExchangeSmtpAccessToken(
  env: NodeJS.ProcessEnv = process.env,
  request: typeof fetch = fetch,
): Promise<string> {
  const config = getExchangeSmtpConfig(env);
  const body = new URLSearchParams({
    client_id: config.clientId,
    client_secret: config.clientSecret,
    grant_type: "client_credentials",
    scope: "https://outlook.office365.com/.default",
  });
  const response = await request(`https://login.microsoftonline.com/${encodeURIComponent(config.tenantId)}/oauth2/v2.0/token`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body,
  });
  const payload = await response.json().catch(() => null) as { access_token?: unknown; error_description?: unknown } | null;
  if (!response.ok || !payload || typeof payload.access_token !== "string" || !payload.access_token) {
    const detail = payload && typeof payload.error_description === "string" ? `: ${payload.error_description}` : "";
    throw new Error(`Exchange OAuth token request failed (${response.status})${detail}`);
  }
  return payload.access_token;
}

/** Active Gmail-only SMTP relay; missing/invalid configuration blocks delivery. */
async function getTransporter(): Promise<ReturnType<typeof createGmailReportTransport> | null> {
  try {
    return createGmailReportTransport();
  } catch {
    // Do not log configuration values or arbitrary transport error payloads.
    console.warn("[Email] Gmail report relay is unavailable; check GMAIL_USER and GMAIL_APP_PASSWORD. Report delivery is blocked.");
    return null;
  }
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function formatCurrency(val: number): string {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 2,
  }).format(val);
}

function formatDate(d: Date): string {
  return d.toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" });
}

/** Applies the light-mode palette only to the full Daily Vacancy email. */
function toLightModeDailyVacancyEmail(html: string): string {
  const lightPalette: Array<[string, string]> = [
    ["#0a0b14", "#f5f7fa"], ["#0d1117", "#153a5b"], ["#111827", "#ffffff"],
    ["#e6edf3", "#172b4d"], ["#8b949e", "#667085"], ["#484f58", "#98a2b3"],
    ["#ffffff08", "#e8edf3"], ["#ffffff06", "#f3f5f7"],
    ["#00e5ff", "#153a5b"], ["#00e676", "#153a5b"], ["#ff9800", "#153a5b"],
    ["#ff4081", "#153a5b"], ["#ff4041", "#a67c00"], ["#b388ff", "#153a5b"], ["#c9a84c", "#a67c00"],
    ["#0369a1", "#153a5b"], ["#15803d", "#153a5b"], ["#c2410c", "#a67c00"],
    ["#dc2626", "#153a5b"], ["#7c3aed", "#153a5b"], ["#059669", "#153a5b"], ["#b45309", "#a67c00"],
  ];
  return lightPalette.reduce((result, [darkColor, lightColor]) => result.split(darkColor).join(lightColor), html);
}

/**
 * Outlook desktop does not reliably honor stylesheet classes, gradients, or
 * 8-digit hex alpha values. Daily Vacancy emails are therefore normalized to
 * table-first, explicit inline colors after the light-mode palette is applied.
 */
function toOutlookSafeDailyVacancyEmail(html: string): string {
  return html
    .replace(/background:linear-gradient\([^;]*\);?/g, "background:#edf4fb;")
    .replace(/#153a5b(?:08|12|15|18|20|30|40|60)\b/gi, "#eef2f6")
    .replace(/#a67c00(?:08|12|15|18|20|30|40|60)\b/gi, "#fbf6e8")
    .replace(/#([0-9a-fA-F]{6})[0-9a-fA-F]{2}\b/g, "#$1")
    .replace(/filter:[^;\"]*;?/g, "")
    .replace(/<table\s/g, '<table role="presentation" ')
    .replace(/<td style="([^"]*)"/g, '<td style="$1;mso-line-height-rule:exactly;"');
}

function dashboardButton(
  color: string,
  label: string = "View Live Dashboard",
  url: string = getDashboardUrl(),
  containerBackground: string = "#111827",
): string {
  return `
        <tr><td style="background:${containerBackground};padding:16px 32px;" align="center">
          <a href="${url}" target="_blank" class="btn-link" style="display:inline-block;background:${color};color:#0a0b14;font-size:14px;font-weight:800;text-decoration:none;padding:14px 36px;border-radius:8px;letter-spacing:0.5px;box-shadow:0 0 20px ${color}40;">${label} →</a>
        </td></tr>`;
}

function collectionsButton(): string {
  const url = `${getDashboardUrl()}?tab=collections`;
  return `
        <tr><td style="background:#111827;padding:0 32px 16px;" align="center">
          <a href="${url}" target="_blank" class="btn-link" style="display:inline-block;background:#c9a84c;color:#0a0b14;font-size:14px;font-weight:800;text-decoration:none;padding:14px 36px;border-radius:8px;letter-spacing:0.5px;box-shadow:0 0 20px #c9a84c40;">View Collections →</a>
        </td></tr>`;
}

// ─── Daily Vacancy Email ─────────────────────────────────────────────────────

// ─── Payments email section builder ─────────────────────────────────────────

type PaymentComparisonRow = {
  buildingName: string;
  regionId: number;
  todayRent: number;
  todayCash: number;
  prevRent: number;
  prevCash: number;
  rentChangePct: number;
  cashChangePct: number;
  rentFlagged: boolean;
  cashFlagged: boolean;
};

type PaymentsEmailData = {
  today: string;
  yesterday: string;
  comparison: PaymentComparisonRow[];
} | null;

function fmtCurrencyShort(val: number): string {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(val);
}

function buildPaymentsSectionHtml(payments: PaymentsEmailData): string {
  if (!payments || payments.comparison.length === 0) return "";

  const { today, yesterday, comparison } = payments;
  const flaggedRows = comparison.filter(r => r.rentFlagged || r.cashFlagged);
  const totalRent = comparison.reduce((s, r) => s + r.todayRent, 0);
  const totalCash = comparison.reduce((s, r) => s + r.todayCash, 0);
  const prevTotalRent = comparison.reduce((s, r) => s + r.prevRent, 0);
  const prevTotalCash = comparison.reduce((s, r) => s + r.prevCash, 0);
  const totalRentPct = prevTotalRent !== 0 ? ((totalRent - prevTotalRent) / Math.abs(prevTotalRent)) * 100 : 0;
  const totalCashPct = prevTotalCash !== 0 ? ((totalCash - prevTotalCash) / Math.abs(prevTotalCash)) * 100 : 0;
  const hasComparison = comparison.some(r => r.prevRent !== 0 || r.prevCash !== 0);

  // Group by region
  const regions = [1, 2, 3, 4];
  const byRegion = regions
    .map(rid => ({ rid, rows: comparison.filter(r => r.regionId === rid) }))
    .filter(g => g.rows.length > 0);

  const regionColors = ["#00e5ff", "#00e676", "#ff9800", "#b388ff"];

  const regionTables = byRegion.map(({ rid, rows }, idx) => {
    const color = regionColors[idx % 4];
    const regRent = rows.reduce((s, r) => s + r.todayRent, 0);
    const regCash = rows.reduce((s, r) => s + r.todayCash, 0);
    return `
    <tr><td style="background:#111827;padding:0 32px 16px;">
      <div style="border:1px solid ${color}20;border-radius:10px;overflow:hidden;">
        <div style="background:${color}08;padding:10px 16px;border-bottom:1px solid ${color}15;">
          <table width="100%"><tr>
            <td><span style="font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:${color};">Region ${rid}</span></td>
            <td align="right">
              <span style="font-size:12px;color:#8b949e;">Rent: </span><span style="font-size:13px;font-weight:700;color:${color};">${fmtCurrencyShort(regRent)}</span>
            </td>
          </tr></table>
        </div>
        <table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;table-layout:fixed;">
          <colgroup>
            <col style="width:44%;" />
            <col style="width:28%;" />
            <col style="width:28%;" />
          </colgroup>
          <tr style="background:${color}05;">
            <td style="padding:6px 12px;font-size:10px;font-weight:700;color:${color};">Building</td>
            <td align="right" style="padding:6px 8px;font-size:10px;font-weight:700;color:${color};white-space:nowrap;">Net Rent Collected</td>
            <td align="right" style="padding:6px 8px;font-size:10px;font-weight:700;color:${color};white-space:nowrap;">% Chg / Prev Day</td>

          </tr>
          ${rows.map((r, i) => {
            const isFlag = r.rentFlagged || r.cashFlagged;
            const bg = isFlag ? "#3b82f608" : i % 2 === 0 ? "#0d1117" : "#111827";
            const hasPrevRent = hasComparison && r.prevRent !== 0;
            const hasPrevCash = hasComparison && r.prevCash !== 0;
            const rentPctColor = !hasPrevRent ? "#4a5568" : r.rentChangePct > 0 ? "#00e676" : r.rentChangePct < 0 ? (r.rentFlagged ? "#3b82f6" : "#ff4081") : "#8b949e";
            const cashPctColor = !hasPrevCash ? "#4a5568" : r.cashChangePct > 0 ? "#00e676" : r.cashChangePct < 0 ? "#ff4081" : "#8b949e";
            const rentUpColor = "#00e676";
            const rentDownColor = r.rentFlagged ? "#3b82f6" : "#ff4081";
            const rentArrow = !hasPrevRent ? "" : r.rentChangePct > 0
              ? `<span style="color:${rentUpColor}">▲</span> `
              : r.rentChangePct < 0
              ? `<span style="color:${rentDownColor}">▼</span> `
              : "";
            const cashArrow = !hasPrevCash ? "" : r.cashChangePct > 0 ? "▲ " : r.cashChangePct < 0 ? "▼ " : "";
            const rentPctText = !hasPrevRent ? "—" : `${r.rentFlagged ? "🚨 " : ""}${rentArrow}${r.rentChangePct > 0 ? "+" : ""}${r.rentChangePct.toFixed(1)}%`;
            // rentPctColor already handles the number color; arrow color is inline above
            const cashPctText = !hasPrevCash ? "—" : `${r.cashFlagged ? "🚨 " : ""}${cashArrow}${r.cashChangePct > 0 ? "+" : ""}${r.cashChangePct.toFixed(1)}%`;
            return `
          <tr style="border-top:1px solid #ffffff06;background:${bg};">
            <td style="padding:6px 12px;font-size:12px;color:#e6edf3;word-break:break-word;">${isFlag ? "🚨 " : ""}${r.buildingName}</td>
            <td align="right" style="padding:6px 8px;font-size:12px;font-weight:600;color:#e6edf3;white-space:nowrap;">${fmtCurrencyShort(r.todayRent)}</td>
            <td align="right" style="padding:6px 8px;font-size:11px;font-weight:700;color:${rentPctColor};white-space:nowrap;">${rentPctText}${hasPrevRent ? `<br><span style="font-size:10px;font-weight:600;color:${r.rentFlagged ? '#3b82f6' : '#6b7280'};font-family:monospace;">${fmtCurrencyShort(r.prevRent)}</span>` : ''}</td>

          </tr>`;
          }).join("")}
        </table>
      </div>
    </td></tr>`;
  }).join("");

  const rentPctColor = totalRentPct > 0 ? "#00e676" : totalRentPct < 0 ? "#ff4081" : "#8b949e";
  const cashPctColor = totalCashPct > 0 ? "#00e676" : totalCashPct < 0 ? "#ff4081" : "#8b949e";
  const totalRentArrow = totalRentPct > 0
    ? `<span style="color:#00e676">▲</span> `
    : totalRentPct < 0
    ? `<span style="color:#ff4081">▼</span> `
    : "";

  return `
    <!-- Payments Section -->
    <tr><td style="background:#111827;padding:24px 32px 8px;">
      <table width="100%"><tr>
        <td>
          <p style="margin:0 0 4px;font-size:14px;font-weight:900;text-transform:uppercase;letter-spacing:2px;color:#00e676;">💰 PAYMENTS — NET RENT COLLECTED</p>
          <p style="margin:0;font-size:11px;color:#8b949e;">${hasComparison ? `Comparing ${today} vs ${yesterday}` : `Data for ${today}`}${flaggedRows.length > 0 ? ` · 🚨 ${flaggedRows.length} building${flaggedRows.length !== 1 ? "s" : ""} with &gt;±5% change` : ""}</p>
        </td>
        <td align="right" style="vertical-align:top;">
          <div style="display:inline-block;background:#00e67615;border:1px solid #00e67630;border-radius:8px;padding:8px 14px;text-align:right;">
            <p style="margin:0;font-size:10px;color:#8b949e;font-weight:700;">TOTAL RENT</p>
            <p style="margin:2px 0 0;font-size:18px;font-weight:900;color:#00e676;">${fmtCurrencyShort(totalRent)}</p>
            ${hasComparison ? `<p style="margin:2px 0 0;font-size:11px;font-weight:700;color:${rentPctColor};">${totalRentArrow}${totalRentPct > 0 ? "+" : ""}${totalRentPct.toFixed(1)}% vs prev</p>` : ""}
          </div>

        </td>
      </tr></table>
    </td></tr>
    ${regionTables}
  `;
}

function buildDailyVacancyHtml(data: DashboardData): string {
  const { stats, buildingVacancy, dailyChanges, vacantUnleased, vacantPreleased, onNotice, evictions } = data;
  const sourceTimestamp = data.lastUpdated;
  const sourceTimestampLabel = sourceTimestamp.toLocaleString("en-US", {
    weekday: "short", year: "numeric", month: "short", day: "numeric", hour: "numeric", minute: "2-digit", timeZoneName: "short",
  });
  const unitDetailRowsAvailable = vacantUnleased.length + vacantPreleased.length + onNotice.length + evictions.length > 0;
  const atRiskBuildings = buildingVacancy.filter((b: BuildingVacancy) => b.atRisk);
  const changesWithDiff = dailyChanges.filter((c) => c.change !== 0);

  return toOutlookSafeDailyVacancyEmail(toLightModeDailyVacancyEmail(`<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Daily Vacancy Report</title>
  <style>
    @media only screen and (max-width: 600px) {
      .email-outer { padding: 8px 0 !important; }
      .email-inner { width: 100% !important; max-width: 100% !important; }
      .email-pad { padding-left: 16px !important; padding-right: 16px !important; }
      .email-header { padding: 20px 16px !important; border-radius: 8px 8px 0 0 !important; }
      .email-header h1 { font-size: 17px !important; }
      .stat-row { display: block !important; width: 100% !important; }
      .stat-cell { display: inline-block !important; width: 48% !important; padding: 0 2px 8px !important; box-sizing: border-box !important; }
      .stat-cell:last-child { width: 100% !important; }
      .stat-val { font-size: 22px !important; }
      .data-table td, .data-table th { font-size: 10px !important; padding: 5px 3px !important; }
      .data-table .bldg-col { max-width: 90px !important; overflow: hidden !important; text-overflow: ellipsis !important; white-space: nowrap !important; }
      .btn-link { padding: 12px 20px !important; font-size: 13px !important; }
      .section-pad { padding: 0 16px 18px !important; }
    }
  </style>
</head>
<body style="margin:0;padding:0;background-color:#0a0b14;font-family:'Segoe UI',Roboto,Helvetica,Arial,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" class="email-outer" style="background-color:#0a0b14;padding:20px 0;">
    <tr><td align="center">
      <table width="900" cellpadding="0" cellspacing="0" class="email-inner" style="max-width:900px;width:100%;">

        <!-- Header -->
        <tr><td style="background:linear-gradient(135deg,#0d1117 0%,#111827 100%);border-radius:12px 12px 0 0;padding:28px 32px;border-bottom:2px solid #c9a84c;">
          <table width="100%"><tr>
            <td style="vertical-align:middle;">
              <img src="https://d2xsxph8kpxj0f.cloudfront.net/310519663449376037/42VuDntxHxNeoLPYMuqTxk/ApartmentCorpLOGO_0ca11dd4.png" alt="Apartment Corp" height="36" style="height:36px;width:auto;display:inline-block;vertical-align:middle;filter:sepia(1) saturate(3) brightness(1.2) hue-rotate(10deg);" />
            </td>
            <td style="vertical-align:middle;padding-left:16px;">
              <h1 style="margin:0;font-size:22px;color:#00e5ff;letter-spacing:1px;">VACANCY REPORT</h1>
              <p style="margin:4px 0 0;font-size:13px;color:#8b949e;">${formatDate(sourceTimestamp)}</p>
              <p style="margin:4px 0 0;font-size:11px;color:#64748b;">Fresh PropertyMax Vacancy snapshot: ${sourceTimestampLabel}</p>
            </td>
            <td align="right" style="vertical-align:top;">
              <span style="display:inline-block;background:#c9a84c20;color:#c9a84c;font-size:11px;padding:4px 10px;border-radius:20px;border:1px solid #c9a84c40;">DAILY REPORT</span>
            </td>
          </tr></table>
        </td></tr>

        <!-- VACANCY CHANGES ALERT (top of email) -->
        ${changesWithDiff.length > 0 ? `
        <tr><td style="background:#111827;padding:24px 32px 0;">
          <div style="background:linear-gradient(135deg,#c9a84c15 0%,#ff980015 100%);border:2px solid #c9a84c60;border-radius:12px;padding:20px;">
            <table width="100%"><tr>
              <td><p style="margin:0 0 4px;font-size:14px;font-weight:900;text-transform:uppercase;letter-spacing:2px;color:#c9a84c;">⚡ VACANCY CHANGES TODAY</p>
              <p style="margin:0 0 16px;font-size:11px;color:#8b949e;">Buildings with vacancy changes since yesterday</p></td>
              <td align="right" style="vertical-align:top;"><span style="display:inline-block;background:#c9a84c20;color:#c9a84c;font-size:22px;font-weight:900;padding:6px 14px;border-radius:10px;border:1px solid #c9a84c40;">${changesWithDiff.length}</span></td>
            </tr></table>
            <table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;">
              <tr style="border-bottom:2px solid #c9a84c30;">
                <td style="padding:10px 6px;font-size:11px;font-weight:800;color:#c9a84c;">Building</td>
                <td align="center" style="padding:10px 4px;font-size:11px;font-weight:800;color:#c9a84c;">Yesterday</td>
                <td align="center" style="padding:10px 4px;font-size:11px;font-weight:800;color:#c9a84c;">Today</td>
                <td align="center" style="padding:10px 4px;font-size:11px;font-weight:800;color:#c9a84c;">Change</td>
                <td align="center" style="padding:10px 4px;font-size:11px;font-weight:800;color:#c9a84c;">Vac %</td>
                <td align="center" style="padding:10px 4px;font-size:11px;font-weight:800;color:#c9a84c;">Units</td>
                <td align="center" style="padding:10px 4px;font-size:11px;font-weight:800;color:#c9a84c;">Unlsd</td>
                <td align="center" style="padding:10px 4px;font-size:11px;font-weight:800;color:#c9a84c;">Prelsd</td>
                <td align="center" style="padding:10px 4px;font-size:11px;font-weight:800;color:#c9a84c;">Notice</td>
                <td align="center" style="padding:10px 4px;font-size:11px;font-weight:800;color:#c9a84c;min-width:52px;">Evictions</td>
              </tr>
              ${changesWithDiff.map(c => {
                const bldg = buildingVacancy.find((b: BuildingVacancy) => b.name === c.building);
                const changeColor = "#153a5b";
                const changeBg = "#ffffff";
                const pctColor = bldg && bldg.vacancyPct > 4 ? "#ff4081" : bldg && bldg.vacancyPct > 2 ? "#ff9800" : "#00e676";
                return `
              <tr style="border-top:1px solid #ffffff08;background:${changeBg};">
                <td style="padding:9px 6px;font-size:13px;color:#e6edf3;font-weight:600;">${c.building}</td>
                <td align="center" style="padding:9px 4px;font-size:13px;color:#8b949e;">${c.yesterdayVacant}</td>
                <td align="center" style="padding:9px 4px;font-size:14px;color:#e6edf3;font-weight:700;">${c.todayVacant}</td>
                <td align="center" style="padding:9px 4px;font-size:14px;font-weight:900;color:${changeColor};">${c.change > 0 ? "+" : ""}${c.change}</td>
                <td align="center" style="padding:9px 4px;font-size:13px;font-weight:700;color:${pctColor};">${bldg ? bldg.vacancyPct + "%" : "—"}</td>
                <td align="center" style="padding:9px 4px;font-size:12px;color:#8b949e;">${bldg ? bldg.totalUnits : "—"}</td>
                <td align="center" style="padding:9px 4px;font-size:12px;color:#ff9800;">${bldg ? (bldg.vacUnleased || "—") : "—"}</td>
                <td align="center" style="padding:9px 4px;font-size:12px;color:#00e676;">${bldg ? (bldg.vacPreleased || "—") : "—"}</td>
                <td align="center" style="padding:9px 4px;font-size:12px;color:#b388ff;">${bldg ? (bldg.onNotice || "—") : "—"}</td>
                <td align="center" style="padding:9px 4px;font-size:12px;color:#ff4081;">${bldg ? (bldg.eviction || "—") : "—"}</td>
              </tr>`;
              }).join("")}
            </table>
            <p style="margin:12px 0 0;font-size:10px;color:#8b949e;text-align:center;">Positive change indicates more vacant units; negative change indicates fewer.</p>
          </div>
        </td></tr>` : `
        <tr><td style="background:#111827;padding:24px 32px 0;">
          <div style="background:#00e67612;border:1px solid #00e67630;border-radius:12px;padding:16px 20px;text-align:center;">
            <p style="margin:0;font-size:13px;font-weight:700;color:#00e676;">✓ No Vacancy Changes Today</p>
            <p style="margin:4px 0 0;font-size:11px;color:#8b949e;">All buildings have the same vacancy count as yesterday</p>
          </div>
        </td></tr>`}

        <!-- Stats Cards -->
        <tr><td style="background:#111827;padding:24px 32px;">
          <p style="margin:0 0 12px;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:2px;color:#8b949e;">Current Vacancy Overview</p>
          <table width="100%" cellpadding="0" cellspacing="0">
            <tr class="stat-row">
              ${[
                { label: "Total Vacant", value: stats.totalVacant, accent: "#1e73be", surface: "#f4f8fc" },
                { label: "Unleased", value: stats.vacUnleased, accent: "#b96a14", surface: "#fdf8f2" },
                { label: "Preleased", value: stats.vacPreleased, accent: "#198754", surface: "#f3faf6" },
                { label: "On Notice", value: stats.onNotice, accent: "#7851a9", surface: "#f7f4fb" },
                { label: "Evictions", value: stats.eviction, accent: "#c63c4a", surface: "#fdf4f5" },
              ].map(s => `
              <td width="20%" class="stat-cell" style="padding:0 4px;">
                <div style="background:${s.surface};border:1px solid #dde3ea;border-top:4px solid ${s.accent};border-radius:8px;padding:10px 6px 12px;text-align:center;">
                  <p style="margin:0;font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;color:#667085;white-space:nowrap;">${s.label}</p>
                  <p class="stat-val" style="margin:4px 0 0;font-size:26px;font-weight:900;color:${s.accent};">${s.value}</p>
                </div>
              </td>`).join("")}
            </tr>
          </table>
        </td></tr>

        <!-- At-Risk Properties -->
        ${atRiskBuildings.length > 0 ? `
        <tr><td style="background:#111827;padding:0 32px 24px;">
          <div style="background:#fff7f7;border:1px solid #efcfd3;border-radius:10px;padding:20px;">
            <table width="100%"><tr>
              <td><p style="margin:0 0 12px;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:2px;color:#c63c4a;">⚠ At-Risk Properties (Vacancy &gt; 4%)</p></td>
              <td align="right"><span style="font-size:20px;font-weight:900;color:#c63c4a;">${atRiskBuildings.length}</span></td>
            </tr></table>
            <table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;">
              <tr style="border-bottom:1px solid #efcfd3;">
                <td style="padding:8px 6px;font-size:11px;font-weight:700;color:#172b4d;">Building</td>
                <td align="center" style="padding:8px 6px;font-size:11px;font-weight:700;color:#172b4d;">Vacancy %</td>
                <td align="center" style="padding:8px 6px;font-size:11px;font-weight:700;color:#172b4d;">Vacant</td>
                <td align="center" style="padding:8px 6px;font-size:11px;font-weight:700;color:#172b4d;">Total Units</td>
              </tr>
              ${atRiskBuildings.map((b: BuildingVacancy) => `
              <tr style="border-bottom:1px solid #f3e2e4;">
                <td style="padding:8px 6px;font-size:13px;color:#172b4d;font-weight:500;">${b.name}</td>
                <td align="center" style="padding:8px 6px;font-size:14px;font-weight:800;color:#c63c4a;">${b.vacancyPct}%</td>
                <td align="center" style="padding:8px 6px;font-size:13px;color:#172b4d;">${b.totalVacant}</td>
                <td align="center" style="padding:8px 6px;font-size:13px;color:#667085;">${b.totalUnits || "—"}</td>
              </tr>`).join("")}
            </table>
          </div>
        </td></tr>` : ""}

        <!-- Building Vacancy Table -->
        <tr><td class="section-pad" style="background:#111827;padding:0 32px 24px;">
          <p style="margin:0 0 12px;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:2px;color:#8b949e;">Vacancy by Building</p>
          <div style="border:1px solid #00e5ff20;border-radius:10px;overflow:hidden;">
            <table width="100%" cellpadding="0" cellspacing="0" class="data-table" style="border-collapse:collapse;">
              <tr style="background:#00e5ff08;">
                <td style="padding:10px 8px;font-size:11px;font-weight:700;color:#00e5ff;">Building</td>
                <td align="center" style="padding:10px 4px;font-size:11px;font-weight:700;color:#00e5ff;">Vac %</td>
                <td align="center" style="padding:10px 4px;font-size:11px;font-weight:700;color:#00e5ff;">Total</td>
                <td align="center" style="padding:10px 4px;font-size:11px;font-weight:700;color:#ff9800;">Unlsd</td>
                <td align="center" style="padding:10px 4px;font-size:11px;font-weight:700;color:#00e676;">Prelsd</td>
                <td align="center" style="padding:10px 4px;font-size:11px;font-weight:700;color:#b388ff;">Notice</td>
                <td align="center" style="padding:10px 4px;font-size:11px;font-weight:700;color:#ff4081;min-width:52px;">Evictions</td>
              </tr>
              ${buildingVacancy.map((b: BuildingVacancy) => {
                const pctColor = b.vacancyPct > 4 ? "#ff4081" : b.vacancyPct > 2 ? "#ff9800" : "#00e676";
                return `
              <tr style="border-top:1px solid #ffffff06;">
                <td style="padding:7px 8px;font-size:12px;color:#e6edf3;">${b.name}</td>
                <td align="center" style="padding:7px 4px;font-size:12px;font-weight:700;color:${pctColor};">${b.vacancyPct}%</td>
                <td align="center" style="padding:7px 4px;font-size:13px;font-weight:800;color:${b.totalVacant > 5 ? "#ff4081" : b.totalVacant > 2 ? "#ff9800" : "#00e676"};">${b.totalVacant}</td>
                <td align="center" style="padding:7px 4px;font-size:12px;color:#ff9800;">${b.vacUnleased || "—"}</td>
                <td align="center" style="padding:7px 4px;font-size:12px;color:#00e676;">${b.vacPreleased || "—"}</td>
                <td align="center" style="padding:7px 4px;font-size:12px;color:#b388ff;">${b.onNotice || "—"}</td>
                <td align="center" style="padding:7px 4px;font-size:12px;color:#ff4081;">${b.eviction || "—"}</td>
              </tr>`;
              }).join("")}
            </table>
          </div>
        </td></tr>

        <!-- Daily Changes section moved to top of email as "Vacancy Changes Today" -->

        ${!unitDetailRowsAvailable ? `
        <tr><td style="background:#111827;padding:0 32px 24px;">
          <div style="background:#eff6ff;border:1px solid #bfdbfe;border-radius:10px;padding:14px 16px;color:#1e3a5f;font-size:12px;line-height:18px;">
            <strong>Current unit-detail rows are not available from the PropertyMax Vacancy snapshot.</strong><br>
            The building-level totals above remain authoritative: ${stats.vacUnleased} unleased, ${stats.vacPreleased} preleased, ${stats.onNotice} on notice, and ${stats.eviction} evictions. Older unit data is intentionally not substituted.
          </div>
        </td></tr>` : ""}

        <!-- Vacant Unleased Units -->
        ${unitDetailRowsAvailable ? `<tr><td style="background:#111827;padding:0 32px 24px;">
          <p style="margin:0 0 12px;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:2px;color:#ff9800;">Vacant / Unleased Unit Detail Rows (${vacantUnleased.length})</p>
          <div style="border:1px solid #ff980020;border-radius:10px;overflow:hidden;">
            <table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;">
              <tr style="background:#ff980008;">
                <td style="padding:8px 6px;font-size:10px;font-weight:700;color:#ff9800;">Building</td>
                <td style="padding:8px 4px;font-size:10px;font-weight:700;color:#ff9800;">Unit</td>
                <td style="padding:8px 4px;font-size:10px;font-weight:700;color:#ff9800;">Move Out</td>
                <td align="center" style="padding:8px 4px;font-size:10px;font-weight:700;color:#ff9800;">Days</td>
                <td align="right" style="padding:8px 6px;font-size:10px;font-weight:700;color:#ff9800;">Ask Rent</td>
                <td align="right" style="padding:8px 6px;font-size:10px;font-weight:700;color:#ff9800;">% Ready</td>
              </tr>
              ${vacantUnleased.slice(0, 50).map(u => {
                const daysColor = u.days > 60 ? "#ff4081" : u.days > 30 ? "#ff9800" : "#00e676";
                return `
              <tr style="border-top:1px solid #ffffff06;">
                <td style="padding:5px 6px;font-size:11px;color:#e6edf3;">${u.building}</td>
                <td style="padding:5px 4px;font-size:11px;color:#8b949e;">${u.unit}</td>
                <td style="padding:5px 4px;font-size:11px;color:#8b949e;">${u.moveOut}</td>
                <td align="center" style="padding:5px 4px;font-size:12px;font-weight:700;color:${daysColor};">${u.days || "—"}</td>
                <td align="right" style="padding:5px 6px;font-size:11px;color:#00e5ff;">${u.askRent ? formatCurrency(u.askRent) : "—"}</td>
                <td align="right" style="padding:5px 6px;font-size:11px;color:${u.percentReady >= 80 ? "#00e676" : u.percentReady >= 50 ? "#ff9800" : "#ff4081"};">${u.percentReady ? u.percentReady + "%" : "—"}</td>
              </tr>`;
              }).join("")}
              ${vacantUnleased.length > 50 ? `<tr><td colspan="6" style="padding:8px;text-align:center;font-size:11px;color:#8b949e;">... and ${vacantUnleased.length - 50} more units</td></tr>` : ""}
            </table>
          </div>
        </td></tr>` : ""}

        <!-- Vacant Preleased Units -->
        ${vacantPreleased.length > 0 ? `
        <tr><td style="background:#111827;padding:0 32px 24px;">
          <p style="margin:0 0 12px;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:2px;color:#00e676;">Vacant / Preleased Units (${vacantPreleased.length})</p>
          <div style="border:1px solid #00e67620;border-radius:10px;overflow:hidden;">
            <table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;">
              <tr style="background:#00e67608;">
                <td style="padding:8px 6px;font-size:10px;font-weight:700;color:#00e676;">Building</td>
                <td style="padding:8px 4px;font-size:10px;font-weight:700;color:#00e676;">Unit</td>
                <td style="padding:8px 4px;font-size:10px;font-weight:700;color:#00e676;">Move Out</td>
                <td style="padding:8px 4px;font-size:10px;font-weight:700;color:#00e676;">Move In</td>
                <td align="center" style="padding:8px 4px;font-size:10px;font-weight:700;color:#00e676;">Days</td>
                <td align="right" style="padding:8px 6px;font-size:10px;font-weight:700;color:#00e676;">Ask Rent</td>
              </tr>
              ${vacantPreleased.slice(0, 50).map(u => {
                const daysColor = u.days > 60 ? "#ff4081" : u.days > 30 ? "#ff9800" : "#00e676";
                return `
              <tr style="border-top:1px solid #ffffff06;">
                <td style="padding:5px 6px;font-size:11px;color:#e6edf3;">${u.building}</td>
                <td style="padding:5px 4px;font-size:11px;color:#8b949e;">${u.unit}</td>
                <td style="padding:5px 4px;font-size:11px;color:#8b949e;">${u.moveOut}</td>
                <td style="padding:5px 4px;font-size:11px;color:#00e676;">${u.moveIn}</td>
                <td align="center" style="padding:5px 4px;font-size:12px;font-weight:700;color:${daysColor};">${u.days || "—"}</td>
                <td align="right" style="padding:5px 6px;font-size:11px;color:#00e5ff;">${u.askRent ? formatCurrency(u.askRent) : "—"}</td>
              </tr>`;
              }).join("")}
              ${vacantPreleased.length > 50 ? `<tr><td colspan="6" style="padding:8px;text-align:center;font-size:11px;color:#8b949e;">... and ${vacantPreleased.length - 50} more units</td></tr>` : ""}
            </table>
          </div>
        </td></tr>` : ""}

        <!-- On Notice -->
        ${onNotice.length > 0 ? `<tr><td style="background:#111827;padding:0 32px 24px;">
          <p style="margin:0 0 12px;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:2px;color:#b388ff;">Units On Notice (${onNotice.length})</p>
          <div style="border:1px solid #b388ff20;border-radius:10px;overflow:hidden;">
            <table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;">
              <tr style="background:#b388ff08;">
                <td style="padding:8px 6px;font-size:10px;font-weight:700;color:#b388ff;">Building</td>
                <td style="padding:8px 4px;font-size:10px;font-weight:700;color:#b388ff;">Unit</td>
                <td align="center" style="padding:8px 4px;font-size:10px;font-weight:700;color:#b388ff;">Leased</td>
              </tr>
              ${onNotice.map(u => `
              <tr style="border-top:1px solid #ffffff06;">
                <td style="padding:5px 6px;font-size:11px;color:#e6edf3;">${u.building}</td>
                <td style="padding:5px 4px;font-size:11px;color:#8b949e;">${u.unit}</td>
                <td align="center" style="padding:5px 4px;font-size:11px;color:${u.leased === "Y" ? "#00e676" : "#ff4081"};">${u.leased === "Y" ? "✓ Leased" : "✗ Not Leased"}</td>
              </tr>`).join("")}
            </table>
          </div>
        </td></tr>` : ""}

        <!-- Evictions -->
        ${evictions.length > 0 ? `
        <tr><td style="background:#111827;padding:0 32px 24px;">
          <p style="margin:0 0 12px;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:2px;color:#ff4081;">Evictions (${evictions.length})</p>
          <div style="border:1px solid #ff408120;border-radius:10px;overflow:hidden;">
            <table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;">
              <tr style="background:#ff408108;">
                <td style="padding:8px 6px;font-size:10px;font-weight:700;color:#ff4081;">Building</td>
                <td style="padding:8px 4px;font-size:10px;font-weight:700;color:#ff4081;">Unit</td>
                <td style="padding:8px 4px;font-size:10px;font-weight:700;color:#ff4081;">Dates</td>
                <td align="right" style="padding:8px 6px;font-size:10px;font-weight:700;color:#ff4081;">Amount Owed</td>
              </tr>
              ${evictions.map(u => `
              <tr style="border-top:1px solid #ffffff06;">
                <td style="padding:5px 6px;font-size:11px;color:#e6edf3;">${u.building}</td>
                <td style="padding:5px 4px;font-size:11px;color:#8b949e;">${u.unit}</td>
                <td style="padding:5px 4px;font-size:11px;color:#8b949e;">${u.dates || "—"}</td>
                <td align="right" style="padding:5px 6px;font-size:12px;font-weight:700;color:#ff4081;">${u.amountOwed ? formatCurrency(u.amountOwed) : "—"}</td>
              </tr>`).join("")}
            </table>
          </div>
        </td></tr>` : ""}

        <!-- BOTTOM Dashboard Button -->
        ${dashboardButton("#00e5ff")}
        ${collectionsButton()}

        <!-- Footer -->
        <tr><td style="background:#0d1117;border-radius:0 0 12px 12px;padding:20px 32px;border-top:1px solid #ffffff08;">
          <p style="margin:0;font-size:11px;color:#484f58;text-align:center;">
            Daily Vacancy report sourced exclusively from the fresh PropertyMax Vacancy snapshot · ${sourceTimestampLabel}
          </p>
        </td></tr>

      </table>
    </td></tr>
  </table>
</body>
</html>`));
}

// ─── Monthly Net Cash Flow Email ─────────────────────────────────────────────

function buildMonthlyNetCashHtml(month: HistoricalMonth): string {
  const now = new Date();

  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Monthly Net Cash Flow Report</title>
  <style>
    @media only screen and (max-width: 600px) {
      .email-outer { padding: 8px 0 !important; }
      .email-inner { width: 100% !important; max-width: 100% !important; }
      .email-pad { padding-left: 16px !important; padding-right: 16px !important; }
      .email-header { padding: 20px 16px !important; border-radius: 8px 8px 0 0 !important; }
      .email-header h1 { font-size: 17px !important; }
      .region-cell { display: block !important; width: 100% !important; padding: 0 0 16px !important; }
      .data-table td, .data-table th { font-size: 10px !important; padding: 5px 3px !important; }
      .btn-link { padding: 12px 20px !important; font-size: 13px !important; }
      .section-pad { padding: 0 16px 18px !important; }
    }
  </style>
</head>
<body style="margin:0;padding:0;background-color:#0a0b14;font-family:'Segoe UI',Roboto,Helvetica,Arial,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" class="email-outer" style="background-color:#0a0b14;padding:20px 0;">
    <tr><td align="center">
      <table width="900" cellpadding="0" cellspacing="0" class="email-inner" style="max-width:900px;width:100%;">

        <!-- Header -->
        <tr><td style="background:linear-gradient(135deg,#0d1117 0%,#111827 100%);border-radius:12px 12px 0 0;padding:28px 32px;border-bottom:2px solid #c9a84c;">
          <table width="100%"><tr>
            <td style="vertical-align:middle;">
              <img src="https://d2xsxph8kpxj0f.cloudfront.net/310519663449376037/42VuDntxHxNeoLPYMuqTxk/ApartmentCorpLOGO_0ca11dd4.png" alt="Apartment Corp" height="36" style="height:36px;width:auto;display:inline-block;vertical-align:middle;filter:sepia(1) saturate(3) brightness(1.2) hue-rotate(10deg);" />
            </td>
            <td style="vertical-align:middle;padding-left:16px;">
              <h1 style="margin:0;font-size:22px;color:#00e676;letter-spacing:1px;">MARC'S NET CASH FLOW</h1>
              <p style="margin:4px 0 0;font-size:13px;color:#8b949e;">${month.label}</p>
            </td>
            <td align="right" style="vertical-align:top;">
              <span style="display:inline-block;background:#c9a84c20;color:#c9a84c;font-size:11px;padding:4px 10px;border-radius:20px;border:1px solid #c9a84c40;">MONTHLY REPORT</span>
            </td>
          </tr></table>
        </td></tr>

        <!-- TOP Dashboard Button -->
        ${dashboardButton("#00e676", "View Live Dashboard")}

        <!-- Grand Total -->
        <tr><td style="background:#111827;padding:28px 32px;">
          <div style="text-align:center;background:linear-gradient(135deg,#00e67610,#00e5ff10);border:1px solid #00e67630;border-radius:12px;padding:24px;">
            <p style="margin:0;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:2px;color:#8b949e;">Grand Total — All Regions</p>
            <p style="margin:8px 0 0;font-size:36px;font-weight:900;color:#00e676;">${formatCurrency(month.grandTotal)}</p>
          </div>
        </td></tr>

        <!-- Region Breakdowns -->
        ${month.regions.map((region: MarcsNetCash, idx: number) => {
          const colors = ["#00e5ff", "#00e676", "#ff4081", "#ffea00"];
          const color = colors[idx % 4];
          return `
        <tr><td style="background:#111827;padding:0 32px 20px;">
          <div style="border:1px solid ${color}20;border-radius:10px;overflow:hidden;">
            <div style="background:${color}08;padding:12px 16px;border-bottom:1px solid ${color}15;">
              <table width="100%"><tr>
                <td><span style="font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:${color};">${region.regionName}</span></td>
                <td align="right"><span style="font-size:16px;font-weight:900;color:${color};">${formatCurrency(region.total)}</span></td>
              </tr></table>
            </div>
            <table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;">
              ${region.buildings.map(b => `
              <tr style="border-top:1px solid #ffffff06;">
                <td style="padding:6px 16px;font-size:12px;color:#e6edf3;">${b.name}</td>
                <td align="right" style="padding:6px 16px;font-size:12px;font-weight:600;color:${b.value < 0 ? "#ff4081" : "#e6edf3"};">${formatCurrency(b.value)}</td>
              </tr>`).join("")}
            </table>
          </div>
        </td></tr>`;
        }).join("")}

        <!-- BOTTOM Dashboard Button -->
        ${dashboardButton("#00e676", "View Live Dashboard")}

        <!-- Footer -->
        <tr><td style="background:#0d1117;border-radius:0 0 12px 12px;padding:20px 32px;border-top:1px solid #ffffff08;">
          <p style="margin:0;font-size:11px;color:#484f58;text-align:center;">
            Data sourced from vacancy.apartmentcorp.com · Generated ${now.toLocaleString("en-US")}
          </p>
        </td></tr>

      </table>
    </td></tr>
  </table>
</body>
</html>`;
}

export type PreparedMonthlyNetCashEmail = {
  message: { from: string; replyTo: string; to: string; subject: string; html: string };
};

/** No source, DB, transport, or network access. Scheduled callers enforce their exact approved To list. */
export function prepareMonthlyNetCashEmail(month: HistoricalMonth, recipients: string[]): PreparedMonthlyNetCashEmail {
  assertCompleteMonthlyNetCashReport(month);
  if (!Array.isArray(recipients) || recipients.length === 0
    || recipients.some(address => typeof address !== "string" || address !== address.trim()
      || !/^[A-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Z0-9](?:[A-Z0-9-]*[A-Z0-9])?(?:\.[A-Z0-9](?:[A-Z0-9-]*[A-Z0-9])?)+$/i.test(address))
    || new Set(recipients.map(address => address.toLowerCase())).size !== recipients.length) {
    throw new Error("Monthly Net Cash requires a nonempty, valid, unique To recipient list");
  }
  return {
    message: {
      from: '"Apartment Corp Reports" <apartmentcorp44@gmail.com>',
      replyTo: "ethan@apartmentcorp.com",
      to: recipients.join(", "),
      subject: `💰 Marc's Net Cash Flow — ${month.label} | Grand Total: ${formatCurrency(month.grandTotal)}`,
      html: buildMonthlyNetCashHtml(month),
    },
  };
}

// ─── Send Functions ──────────────────────────────────────────────────────────

export function buildDailyVacancySubject(lastUpdated: Date, totalVacant: number, testLabel?: string): string {
  const labelPrefix = testLabel?.trim() ? `[${testLabel.trim()}] ` : "";
  return `${labelPrefix}⚡ Daily Vacancy Report — ${lastUpdated.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })} | ${totalVacant} Vacant Units`;
}

export type ScheduledDailyVacancyReceipt = {
  messageId: string; accepted: string[]; rejected: string[]; response: string;
};

/** Configuration and identical HTML rendering happen before the durable sending boundary. No network I/O. */
export async function prepareScheduledDailyVacancy(data: DashboardData, recipients: string[]) {
  assertApprovedScheduledRecipients(recipients);
  const transporter = await getTransporter();
  if (!transporter) throw new Error("Scheduled Daily Vacancy relay unavailable");
  const message = {
    from: `"${FROM_NAME}" <${FROM_EMAIL}>`, replyTo: REPLY_TO,
    to: recipients.join(", "),
    subject: buildDailyVacancySubject(data.lastUpdated, data.stats.totalVacant),
    html: buildDailyVacancyHtml(data),
  };
  return { transporter, message };
}

/** Invoke only after the ledger's sending state is durably confirmed. No fetch or recipient fallback. */
export async function sendPreparedScheduledDailyVacancy(
  prepared: Awaited<ReturnType<typeof prepareScheduledDailyVacancy>>,
): Promise<ScheduledDailyVacancyReceipt> {
  assertApprovedScheduledRecipients(prepared.message.to.split(", "));
  const receipt = await prepared.transporter.sendMail({
    from: `"${FROM_NAME}" <${FROM_EMAIL}>`, replyTo: REPLY_TO,
    to: prepared.message.to, subject: prepared.message.subject, html: prepared.message.html,
  });
  const address = (value: string | { address: string }) => typeof value === "string" ? value : value.address;
  return {
    messageId: receipt.messageId,
    accepted: (receipt.accepted ?? []).map(address), rejected: (receipt.rejected ?? []).map(address),
    response: receipt.response ?? "",
  };
}

export async function sendDailyVacancyEmail(recipientOverride?: string, testLabel?: string): Promise<boolean> {
  const requestedRecipients = recipientOverride
    ? recipientOverride.split(",").map(email => email.trim().toLowerCase()).filter(Boolean)
    : (await getDailyVacancyRecipients()).map(email => email.trim().toLowerCase()).filter(Boolean);
  const isScheduledAdminDelivery = !recipientOverride
    && !testLabel
    && requestedRecipients.length > 0;
  const isApprovedEthanTest = requestedRecipients.length === 1
    && requestedRecipients[0] === EXCHANGE_SMTP_SENDER
    && testLabel?.trim() === "Test3";
  if (!isScheduledAdminDelivery && !isApprovedEthanTest) {
    console.error("[Email] Daily vacancy report not sent: recipient is not in the Admin-tab schedule list or the approved Ethan Test3 allowlist");
    return false;
  }

  const transporter = await getTransporter();
  if (!transporter) {
    console.warn("[Email] Cannot send daily vacancy email: transporter not configured");
    return false;
  }

  try {
    const data = await fetchDashboardData(true);
    const html = buildDailyVacancyHtml(data);
    const subject = buildDailyVacancySubject(data.lastUpdated, data.stats.totalVacant, testLabel);
    const toAddress = requestedRecipients.join(", ");
    await transporter.sendMail({
      from: `"${FROM_NAME}" <${FROM_EMAIL}>`,
      replyTo: REPLY_TO,
      to: toAddress,
      subject,
      html,
    });
    console.log(`[Email] Fresh PropertyMax Daily Vacancy report sent successfully to ${toAddress}`);
    return true;
  } catch (err) {
    console.error("[Email] Failed to send daily vacancy report:", err);
    return false;
  }
}

export async function sendMonthlyNetCashEmail(month: HistoricalMonth, recipientOverride?: string): Promise<boolean> {
  try {
    const recipients = recipientOverride === undefined
      ? await getMonthlyNetCashRecipients()
      : recipientOverride.split(",").map(address => address.trim());
    const prepared = prepareMonthlyNetCashEmail(month, recipients);
    const transporter = await getTransporter();
    if (!transporter) {
      console.warn("[Email] Cannot send monthly net cash email: transporter not configured");
      return false;
    }
    await transporter.sendMail(prepared.message);
    console.log(`[Email] Monthly net cash report for ${month.label} sent successfully to ${prepared.message.to}`);
    return true;
  } catch (err) {
    console.error("[Email] Failed to send monthly net cash report:", err);
    return false;
  }
}

// ─── Weekly Summary Email ────────────────────────────────────────────────────

function buildWeeklySummaryHtml(summary: WeeklySummaryData, payments?: PaymentsEmailData): string {
  const now = new Date();
  const { weekStart, weekEnd, totalNetChange, startTotalVacant, endTotalVacant, totalBuildingsChanged, topIncreases, topDecreases, dailyChanges, buildingTrends, currentStats, currentAtRisk } = summary;

  const formatPeriodDate = (d: string) => {
    const dt = new Date(d + 'T00:00:00');
    return dt.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  const netChangeColor = totalNetChange > 0 ? '#ff6b6b' : totalNetChange < 0 ? '#00e676' : '#8b949e';
  const netChangeSign = totalNetChange > 0 ? '+' : '';

  // Build top movers rows
  const buildMoverRows = (movers: typeof topIncreases, isIncrease: boolean) => {
    if (movers.length === 0) return '';
    const color = isIncrease ? '#ff6b6b' : '#00e676';
    const label = isIncrease ? 'NEW VACANCIES' : 'RECENTLY LEASED';
    const arrow = isIncrease ? '▲' : '▼';
    return `
      <tr><td style="background:#111827;padding:20px 32px 0;">
        <p style="margin:0 0 12px;font-size:11px;font-weight:800;letter-spacing:2px;color:${color};text-transform:uppercase;">${arrow} ${label}</p>
        <table width="100%" cellpadding="0" cellspacing="0" style="border:1px solid ${color}40;border-radius:8px;overflow:hidden;">
          <tr style="background:${color}15;">
            <td style="padding:8px 12px;font-size:11px;font-weight:700;color:${color};border-bottom:1px solid ${color}30;">Building</td>
            <td style="padding:8px 12px;font-size:11px;font-weight:700;color:${color};border-bottom:1px solid ${color}30;text-align:center;">Change</td>
            <td style="padding:8px 12px;font-size:11px;font-weight:700;color:${color};border-bottom:1px solid ${color}30;text-align:center;">Start → End</td>
            <td style="padding:8px 12px;font-size:11px;font-weight:700;color:${color};border-bottom:1px solid ${color}30;text-align:center;">Vacancy %</td>
            <td style="padding:8px 12px;font-size:11px;font-weight:700;color:${color};border-bottom:1px solid ${color}30;text-align:center;">Peak/Low</td>
          </tr>
          ${movers.map((b, i) => `
          <tr style="background:${i % 2 === 0 ? '#0d1117' : '#111827'};">
            <td style="padding:8px 12px;font-size:13px;color:#e6edf3;font-weight:600;">${b.name}</td>
            <td style="padding:8px 12px;font-size:14px;color:${color};font-weight:900;text-align:center;">${isIncrease ? '+' : ''}${b.netChange}</td>
            <td style="padding:8px 12px;font-size:12px;color:#8b949e;text-align:center;">${b.startVacant} → ${b.endVacant}</td>
            <td style="padding:8px 12px;font-size:12px;color:${color};text-align:center;">${b.startPct}% → ${b.endPct}%</td>
            <td style="padding:8px 12px;font-size:11px;color:#8b949e;text-align:center;">↑${b.peakVacant} ↓${b.lowVacant}</td>
          </tr>`).join('')}
        </table>
      </td></tr>`;
  };

  // Build day-by-day changelog
  const buildDailyLog = () => {
    if (dailyChanges.length === 0) return '';
    const rows = dailyChanges.flatMap(day =>
      day.changes.map((c, idx) => {
        const dateCell = idx === 0 ? `<td rowspan="${day.changes.length}" style="padding:8px 12px;font-size:12px;color:#e6edf3;font-weight:600;vertical-align:top;border-bottom:1px solid #21262d;white-space:nowrap;">${new Date(day.date + 'T00:00:00').toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}</td>` : '';
        const changeColor = c.change > 0 ? '#ff6b6b' : '#00e676';
        return `<tr style="border-bottom:1px solid #21262d;">
          ${dateCell}
          <td style="padding:6px 12px;font-size:12px;color:#e6edf3;">${c.building}</td>
          <td style="padding:6px 12px;font-size:12px;color:#8b949e;text-align:center;">${c.prevVacant}</td>
          <td style="padding:6px 12px;font-size:12px;color:#e6edf3;text-align:center;font-weight:600;">${c.newVacant}</td>
          <td style="padding:6px 12px;font-size:13px;color:${changeColor};text-align:center;font-weight:800;">${c.change > 0 ? '+' : ''}${c.change}</td>
        </tr>`;
      })
    ).join('');

    return `
      <tr><td style="background:#111827;padding:20px 32px 0;">
        <p style="margin:0 0 12px;font-size:11px;font-weight:800;letter-spacing:2px;color:#00e5ff;text-transform:uppercase;">DAY-BY-DAY CHANGES</p>
        <table width="100%" cellpadding="0" cellspacing="0" style="border:1px solid #00e5ff30;border-radius:8px;overflow:hidden;">
          <tr style="background:#00e5ff10;">
            <td style="padding:8px 12px;font-size:11px;font-weight:700;color:#00e5ff;border-bottom:1px solid #00e5ff30;">Date</td>
            <td style="padding:8px 12px;font-size:11px;font-weight:700;color:#00e5ff;border-bottom:1px solid #00e5ff30;">Building</td>
            <td style="padding:8px 12px;font-size:11px;font-weight:700;color:#00e5ff;border-bottom:1px solid #00e5ff30;text-align:center;">Prev</td>
            <td style="padding:8px 12px;font-size:11px;font-weight:700;color:#00e5ff;border-bottom:1px solid #00e5ff30;text-align:center;">New</td>
            <td style="padding:8px 12px;font-size:11px;font-weight:700;color:#00e5ff;border-bottom:1px solid #00e5ff30;text-align:center;">Change</td>
          </tr>
          ${rows}
        </table>
      </td></tr>`;
  };

  // Current snapshot stats
  const statsSection = currentStats ? `
    <tr><td style="background:#111827;padding:20px 32px 0;">
      <p style="margin:0 0 12px;font-size:11px;font-weight:800;letter-spacing:2px;color:#c9a84c;text-transform:uppercase;">CURRENT SNAPSHOT</p>
      <table width="100%" cellpadding="0" cellspacing="0">
        <tr>
          <td style="width:20%;padding:8px;text-align:center;background:#c9a84c15;border-radius:8px;">
            <p style="margin:0;font-size:10px;color:#c9a84c;font-weight:700;letter-spacing:1px;">TOTAL VACANT</p>
            <p style="margin:4px 0 0;font-size:22px;font-weight:900;color:#00e5ff;">${currentStats.totalVacant}</p>
          </td>
          <td style="width:5%;"></td>
          <td style="width:20%;padding:8px;text-align:center;background:#ff980015;border-radius:8px;">
            <p style="margin:0;font-size:10px;color:#ff9800;font-weight:700;letter-spacing:1px;">UNLEASED</p>
            <p style="margin:4px 0 0;font-size:22px;font-weight:900;color:#ff9800;">${currentStats.vacUnleased}</p>
          </td>
          <td style="width:5%;"></td>
          <td style="width:20%;padding:8px;text-align:center;background:#00e67615;border-radius:8px;">
            <p style="margin:0;font-size:10px;color:#00e676;font-weight:700;letter-spacing:1px;">PRELEASED</p>
            <p style="margin:4px 0 0;font-size:22px;font-weight:900;color:#00e676;">${currentStats.vacPreleased}</p>
          </td>
          <td style="width:5%;"></td>
          <td style="width:20%;padding:8px;text-align:center;background:#7c4dff15;border-radius:8px;">
            <p style="margin:0;font-size:10px;color:#7c4dff;font-weight:700;letter-spacing:1px;">NOTICE</p>
            <p style="margin:4px 0 0;font-size:22px;font-weight:900;color:#7c4dff;">${currentStats.onNotice}</p>
          </td>
        </tr>
      </table>
    </td></tr>` : '';

  const unchangedCount = buildingTrends.filter(b => b.netChange === 0).length;

  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Weekly Vacancy Summary</title>
  <style>
    @media only screen and (max-width: 600px) {
      .email-outer { padding: 8px 0 !important; }
      .email-inner { width: 100% !important; max-width: 100% !important; }
      .email-pad { padding-left: 16px !important; padding-right: 16px !important; }
      .email-header { padding: 20px 16px !important; border-radius: 8px 8px 0 0 !important; }
      .email-header h1 { font-size: 17px !important; }
      .stat-row { display: block !important; width: 100% !important; }
      .stat-cell { display: inline-block !important; width: 48% !important; padding: 0 2px 8px !important; box-sizing: border-box !important; }
      .stat-cell:last-child { width: 100% !important; }
      .stat-val { font-size: 22px !important; }
      .data-table td, .data-table th { font-size: 10px !important; padding: 5px 3px !important; }
      .data-table .bldg-col { max-width: 90px !important; overflow: hidden !important; text-overflow: ellipsis !important; white-space: nowrap !important; }
      .btn-link { padding: 12px 20px !important; font-size: 13px !important; }
      .section-pad { padding: 0 16px 18px !important; }
    }
  </style>
</head>
<body style="margin:0;padding:0;background-color:#0a0b14;font-family:'Segoe UI',Roboto,Helvetica,Arial,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" class="email-outer" style="background-color:#0a0b14;padding:20px 0;">
    <tr><td align="center">
      <table width="900" cellpadding="0" cellspacing="0" class="email-inner" style="max-width:900px;width:100%;">

        <!-- Header -->
        <tr><td style="background:linear-gradient(135deg,#0d1117 0%,#111827 100%);border-radius:12px 12px 0 0;padding:28px 32px;border-bottom:2px solid #7c4dff;">
          <table width="100%"><tr>
            <td style="vertical-align:middle;">
              <img src="https://d2xsxph8kpxj0f.cloudfront.net/310519663449376037/42VuDntxHxNeoLPYMuqTxk/ApartmentCorpLOGO_0ca11dd4.png" alt="Apartment Corp" height="36" style="height:36px;width:auto;display:inline-block;vertical-align:middle;filter:sepia(1) saturate(3) brightness(1.2) hue-rotate(10deg);" />
            </td>
            <td style="vertical-align:middle;padding-left:16px;">
              <h1 style="margin:0;font-size:22px;color:#7c4dff;letter-spacing:1px;">WEEKLY SUMMARY</h1>
              <p style="margin:4px 0 0;font-size:13px;color:#8b949e;">${formatPeriodDate(weekStart)} — ${formatPeriodDate(weekEnd)}, ${new Date().getFullYear()}</p>
            </td>
            <td align="right" style="vertical-align:top;">
              <span style="display:inline-block;background:#7c4dff20;color:#7c4dff;font-size:11px;padding:4px 10px;border-radius:20px;border:1px solid #7c4dff40;">WEEKLY REPORT</span>
            </td>
          </tr></table>
        </td></tr>

        ${dashboardButton("#7c4dff")}

        <!-- Week Overview -->
        <tr><td style="background:#111827;padding:24px 32px 0;">
          <div style="background:linear-gradient(135deg,#7c4dff15 0%,#00e5ff15 100%);border:2px solid #7c4dff40;border-radius:12px;padding:20px;">
            <p style="margin:0 0 16px;font-size:13px;font-weight:800;letter-spacing:2px;color:#7c4dff;text-transform:uppercase;">⚡ WEEK AT A GLANCE</p>
            <table width="100%" cellpadding="0" cellspacing="0">
              <tr>
                <td style="width:25%;text-align:center;padding:8px;">
                  <p style="margin:0;font-size:10px;color:#8b949e;font-weight:700;letter-spacing:1px;">NET CHANGE</p>
                  <p style="margin:4px 0 0;font-size:28px;font-weight:900;color:${netChangeColor};">${netChangeSign}${totalNetChange}</p>
                </td>
                <td style="width:25%;text-align:center;padding:8px;">
                  <p style="margin:0;font-size:10px;color:#8b949e;font-weight:700;letter-spacing:1px;">START → END</p>
                  <p style="margin:4px 0 0;font-size:16px;font-weight:700;color:#e6edf3;">${startTotalVacant} → ${endTotalVacant}</p>
                </td>
                <td style="width:25%;text-align:center;padding:8px;">
                  <p style="margin:0;font-size:10px;color:#8b949e;font-weight:700;letter-spacing:1px;">BUILDINGS CHANGED</p>
                  <p style="margin:4px 0 0;font-size:28px;font-weight:900;color:#00e5ff;">${totalBuildingsChanged}</p>
                </td>
                <td style="width:25%;text-align:center;padding:8px;">
                  <p style="margin:0;font-size:10px;color:#8b949e;font-weight:700;letter-spacing:1px;">UNCHANGED</p>
                  <p style="margin:4px 0 0;font-size:28px;font-weight:900;color:#8b949e;">${unchangedCount}</p>
                </td>
              </tr>
            </table>
          </div>
        </td></tr>

        ${buildMoverRows(topIncreases, true)}
        ${buildMoverRows(topDecreases, false)}
        ${buildDailyLog()}
        ${statsSection}
        ${payments ? buildPaymentsSectionHtml(payments) : ""}

        <!-- Footer -->
        <tr><td style="background:#111827;padding:24px 32px;border-radius:0 0 12px 12px;border-top:1px solid #21262d;">
          <p style="margin:0;font-size:11px;color:#484f58;text-align:center;">ApartmentCorp Weekly Vacancy Summary • Generated ${formatDate(now)}</p>
        </td></tr>

      </table>
    </td></tr>
  </table>
</body>
</html>`;
}

/** Renders the unchanged weekly report and legacy saved-payments comparison; never invokes SMTP. */
export async function prepareWeeklySummaryEmail(summary: WeeklySummaryData, overrideRecipient?: string) {
  const transporter = await getTransporter();
  if (!transporter) throw new Error("Weekly relay unavailable");

  // Fetch payments data for weekly email — compare today vs 7 days ago (week-over-week)
  let paymentsData: PaymentsEmailData = null;
  try {
    const dates = await getPaymentsDates();
    if (dates.length >= 1) {
      const today = dates[0];
      // Find the snapshot closest to 7 days ago
      const todayMs = new Date(today).getTime();
      const sevenDaysAgoMs = todayMs - 7 * 24 * 60 * 60 * 1000;
      // Pick the date in dates[] whose distance from 7 days ago is smallest, but skip today
      const prevDate = dates.slice(1).reduce<string | null>((best, d) => {
        const dMs = new Date(d).getTime();
        if (!best) return d;
        const bestMs = new Date(best).getTime();
        return Math.abs(dMs - sevenDaysAgoMs) < Math.abs(bestMs - sevenDaysAgoMs) ? d : best;
      }, null);
      const [todayRows, prevRows] = await Promise.all([
        getPaymentsForDateDb(today),
        prevDate ? getPaymentsForDateDb(prevDate) : Promise.resolve([]),
      ]);
      if (todayRows.length > 0) {
        const prevMap = new Map<string, { netRentCollected: number; netCashFlow: number }>();
        for (const r of prevRows) {
          prevMap.set(r.buildingName, {
            netRentCollected: parseFloat(r.netRentCollected),
            netCashFlow: parseFloat(r.netCashFlow),
          });
        }
        const comparison: PaymentComparisonRow[] = todayRows.map(r => {
          const prev = prevMap.get(r.buildingName);
          const todayRent = parseFloat(r.netRentCollected);
          const todayCash = parseFloat(r.netCashFlow);
          const prevRent = prev?.netRentCollected ?? 0;
          const prevCash = prev?.netCashFlow ?? 0;
          const rentChangePct = prevRent !== 0 ? ((todayRent - prevRent) / Math.abs(prevRent)) * 100 : 0;
          const cashChangePct = prevCash !== 0 ? ((todayCash - prevCash) / Math.abs(prevCash)) * 100 : 0;
          return {
            buildingName: r.buildingName,
            regionId: r.regionId,
            todayRent,
            todayCash,
            prevRent,
            prevCash,
            rentChangePct: Math.round(rentChangePct * 10) / 10,
            cashChangePct: Math.round(cashChangePct * 10) / 10,
            rentFlagged: Math.abs(rentChangePct) >= 5,
            cashFlagged: Math.abs(cashChangePct) >= 5,
          };
        });
        paymentsData = { today, yesterday: prevDate ?? today, comparison };
      }
    }
  } catch {
    console.warn("[Email] Could not fetch payments data for weekly email.");
  }

  const html = buildWeeklySummaryHtml(summary, paymentsData);
  const subject = `📊 Weekly Vacancy Summary — ${summary.weekStart} to ${summary.weekEnd}`;

  // Scheduled vacancy reporting follows the Admin-tab active Daily Vacancy list.
  // Apply the weekly-only replacement to either the override or the saved list.
  const { to: toAddress } = replaceScopedReportRecipients(overrideRecipient || await getDailyVacancyRecipients());
  if (!toAddress) throw new Error("Weekly recipients unavailable");
  return { transporter, message: { from: `"${FROM_NAME}" <${FROM_EMAIL}>`, replyTo: REPLY_TO, to: toAddress, subject, html } };
}

export async function sendWeeklySummaryEmail(summary: WeeklySummaryData, overrideRecipient?: string): Promise<boolean> {
  try {
    const prepared = await prepareWeeklySummaryEmail(summary, overrideRecipient);
    await prepared.transporter.sendMail(prepared.message);
    console.log(`[Email] Weekly summary sent successfully to ${prepared.message.to}`);
    return true;
  } catch {
    console.error("[Email] Failed to send weekly summary.");
    return false;
  }
}

// Export template builders for testing/preview
export { buildDailyVacancyHtml, buildMonthlyNetCashHtml, buildWeeklySummaryHtml };

// ─── Bi-Weekly Eviction Missing Amount Owed Email ────────────────────────────

export interface EvictionManagerContact {
  property: string;           // Display name of the property
  managerName: string;
  managerEmail: string;
  regionalEmail: string;
  units: string[];            // Unit identifiers missing Amount Owed
}

function buildEvictionMissingAmountHtml(
  propertyName: string,
  managerFirstName: string,
  units: string[]
): string {
  const today = formatDate(new Date());
  const unitCount = units.length;
  const unitRows = units
    .map(u => `<tr><td style="padding:8px 12px;border-bottom:1px solid #f0f0f0;color:#444;">${u}</td></tr>`)
    .join("");

  return `<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"></head>
<body style="margin:0;padding:0;background:#f4f5f7;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f5f7;padding:32px 0;">
  <tr><td align="center">
    <table width="620" cellpadding="0" cellspacing="0" style="max-width:620px;width:100%;">
      <tr><td style="background:#1a1a2e;border-radius:10px 10px 0 0;padding:28px 32px;">
        <div style="color:#ffffff;font-size:20px;font-weight:700;margin-bottom:4px;">⚠️ Action Required: Missing Eviction Amounts</div>
        <div style="color:#a0aec0;font-size:13px;">${propertyName} &bull; ${today}</div>
      </td></tr>
      <tr><td style="background:#ffffff;padding:28px 32px;border-left:1px solid #e2e8f0;border-right:1px solid #e2e8f0;">
        <p style="margin:0 0 16px;color:#333;font-size:15px;line-height:1.6;">Hello ${managerFirstName},</p>
        <p style="margin:0 0 16px;color:#333;font-size:15px;line-height:1.6;">Marc wanted me to reach out and ask that you please input the following information into PropertyMax.ai at your earliest convenience.</p>
        <p style="margin:0 0 24px;color:#333;font-size:15px;line-height:1.6;">We are currently showing <strong>${unitCount} eviction unit${unitCount !== 1 ? "s" : ""} at ${propertyName}</strong> that ${unitCount !== 1 ? "do" : "does"} not have an <strong>Amount Owed</strong> entered in the system. This data is required for accurate eviction tracking and reporting across the portfolio.</p>
        <p style="margin:0 0 16px;color:#333;font-size:15px;line-height:1.6;">Please log in to PropertyMax.ai, navigate to each unit listed below, open the eviction record, and enter the correct Amount Owed:</p>
        <table width="100%" cellpadding="0" cellspacing="0" style="border:1px solid #e2e8f0;border-radius:6px;border-collapse:collapse;margin-bottom:24px;">
          <thead>
            <tr style="background:#f7f8fa;">
              <th style="padding:8px 12px;text-align:left;font-size:12px;color:#666;font-weight:600;text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid #e2e8f0;">Unit</th>
            </tr>
          </thead>
          <tbody>${unitRows}</tbody>
        </table>
        <p style="margin:0 0 16px;color:#333;font-size:15px;line-height:1.6;">If you have any questions or need assistance accessing the records, please don't hesitate to reach out.</p>
        <p style="margin:0;color:#333;font-size:15px;line-height:1.6;">Thank you,<br><strong>Brandon Rose</strong><br>Apartment Corp</p>
      </td></tr>
      <tr><td style="background:#f7f8fa;border:1px solid #e2e8f0;border-top:none;border-radius:0 0 10px 10px;padding:16px 32px;text-align:center;">
        <p style="margin:0;color:#999;font-size:12px;">Sent from the Vacancy Report Dashboard &bull; Apartment Corp &bull; ${today}</p>
      </td></tr>
    </table>
  </td></tr>
</table>
</body>
</html>`;
}

/** Identical per-manager message; preparation has no SMTP/network side effects. */
export function prepareEvictionMissingAmountEmail(c: EvictionManagerContact) {
  const transporter = createGmailReportTransport();
  const message = buildEvictionMissingAmountMessage(c);
  return { transporter, message };
}

function buildEvictionMissingAmountMessage(c: EvictionManagerContact) {
  const recipients = replaceScopedReportRecipients(c.managerEmail, [c.regionalEmail, "Brandon@ApartmentCorp.com", "mam@22.bz"]);
  return {
    from: `"${FROM_NAME}" <${FROM_EMAIL}>`, replyTo: REPLY_TO,
    to: recipients.to,
    cc: recipients.cc,
    subject: `Action Required: Missing Amount Owed — Eviction Records (${c.property})`,
    html: buildEvictionMissingAmountHtml(c.property, c.managerName.split(" ")[0], c.units),
  };
}

/**
 * Send bi-weekly eviction missing-amount emails.
 * One email per property, addressed to the on-site manager, CC'd to the
 * regional manager, Ethan, and Marc (deduped against the manager's To address).
 * Only sends if there are units missing Amount Owed.
 */
export async function sendEvictionMissingAmountEmails(
  contacts: EvictionManagerContact[]
): Promise<{ sent: number; skipped: number }> {
  const transporter = await getTransporter();
  if (!transporter) return { sent: 0, skipped: contacts.length };

  let sent = 0;
  let skipped = 0;

  for (const c of contacts) {
    if (!c.units.length) { skipped++; continue; }

    try {
      await transporter.sendMail(buildEvictionMissingAmountMessage(c));
      console.log(`[Email] Eviction missing-amount email sent to ${c.managerName} <${c.managerEmail}> for ${c.property}`);
      sent++;
    } catch (err) {
      console.error(`[Email] Failed to send eviction email for ${c.property}:`, err);
      skipped++;
    }
  }

  return { sent, skipped };
}

// ─── Daily Collections Report Email ──────────────────────────────────────────

export type DailyCollectionsBuilding = {
  buildingName: string;
  regionId: number;
  netRentCollected: number;
};

function collectionEmailKey(building: Pick<DailyCollectionsBuilding, "buildingName" | "regionId">): string {
  return `${building.regionId}:${building.buildingName.trim().toLocaleLowerCase()}`;
}

/**
 * Keeps the first record for each region/building pair. This is deliberately
 * applied at the email boundary as a safeguard so a repeated upstream record
 * can never double-count a property or render a duplicate row for recipients.
 */
export function dedupeDailyCollectionsBuildings(buildings: DailyCollectionsBuilding[]): DailyCollectionsBuilding[] {
  const unique = new Map<string, DailyCollectionsBuilding>();
  for (const building of buildings) {
    const key = collectionEmailKey(building);
    if (!unique.has(key)) unique.set(key, building);
  }
  return Array.from(unique.values());
}

export function getDailyCollectionsUniqueTotal(buildings: DailyCollectionsBuilding[]): number {
  return dedupeDailyCollectionsBuildings(buildings)
    .reduce((sum, building) => sum + building.netRentCollected, 0);
}

export function buildDailyCollectionsHtml(
  snapshot: { snapshotDate: string; buildings: DailyCollectionsBuilding[]; totalNetRentCollected: number },
  prevBuildings: DailyCollectionsBuilding[]
): string {
  const { snapshotDate } = snapshot;
  const buildings = dedupeDailyCollectionsBuildings(snapshot.buildings);
  const totalNetRentCollected = getDailyCollectionsUniqueTotal(snapshot.buildings);
  const dateLabel = new Date(snapshotDate + "T12:00:00").toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" });

  const prevMap = new Map<string, number>();
  for (const b of dedupeDailyCollectionsBuildings(prevBuildings)) {
    prevMap.set(collectionEmailKey(b), b.netRentCollected);
  }

  const sorted = [...buildings].sort((a, b) => a.regionId - b.regionId || a.buildingName.localeCompare(b.buildingName));

  const regionColors: Record<number, string> = { 1: "#3b82f6", 2: "#10b981", 3: "#f59e0b", 4: "#8b5cf6" };
  const regionNames: Record<number, string> = { 1: "Region 1", 2: "Region 2", 3: "Region 3", 4: "Region 4" };

  const byRegion = [1, 2, 3, 4].map(rid => ({
    rid,
    color: regionColors[rid] ?? "#64748b",
    name: regionNames[rid] ?? `Region ${rid}`,
    rows: sorted.filter(b => b.regionId === rid),
  })).filter(g => g.rows.length > 0);

  const fmt = (v: number) => new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", minimumFractionDigits: 2 }).format(v);

  const regionSections = byRegion.map(({ rid, color, name, rows }) => {
    const regionTotal = rows.reduce((s, b) => s + b.netRentCollected, 0);
    const rowsHtml = rows.map((b, i) => {
      const prev = prevMap.get(collectionEmailKey(b));
      const hasPrev = prev !== undefined && prev !== 0;
      const pct = hasPrev ? ((b.netRentCollected - prev!) / Math.abs(prev!)) * 100 : null;
      const flagged = pct !== null && Math.abs(pct) >= 5;
      const arrow = pct === null ? "" : pct > 0 ? "▲" : pct < 0 ? "▼" : "—";
      const arrowColor = pct === null ? "#94a3b8" : pct > 0 ? "#10b981" : "#ef4444";
      const changeCell = pct !== null
        ? `<span style="color:${arrowColor};font-weight:700;">${arrow} ${Math.abs(pct).toFixed(1)}%</span>${flagged ? ' <span style="color:#3b82f6;font-weight:900;">🚨</span>' : ""}`
        : `<span style="color:#94a3b8;">—</span>`;
      const prevCell = hasPrev ? `<span style="color:#94a3b8;font-size:11px;">${fmt(prev!)}</span>` : `<span style="color:#94a3b8;font-size:11px;">—</span>`;
      const bg = i % 2 === 0 ? "#ffffff" : "#f8fafc";
      return `<tr style="background:${bg};">
        <td style="padding:9px 14px;font-size:13px;color:#1e293b;font-weight:500;border-bottom:1px solid #e2e8f0;">${b.buildingName}</td>
        <td style="padding:9px 14px;font-size:13px;color:#1e293b;font-weight:700;text-align:right;border-bottom:1px solid #e2e8f0;">${fmt(b.netRentCollected)}</td>
        <td style="padding:9px 14px;font-size:12px;text-align:center;border-bottom:1px solid #e2e8f0;">${changeCell}</td>
        <td style="padding:9px 14px;text-align:right;border-bottom:1px solid #e2e8f0;">${prevCell}</td>
      </tr>`;
    }).join("");

    return `
    <div style="margin-bottom:24px;border:1px solid #e2e8f0;border-radius:10px;overflow:hidden;">
      <div style="background:${color};padding:10px 16px;">
        <table width="100%"><tr>
          <td><span style="font-size:13px;font-weight:700;color:#ffffff;text-transform:uppercase;letter-spacing:1px;">${name}</span></td>
          <td align="right"><span style="font-size:13px;font-weight:700;color:#ffffff;">${fmt(regionTotal)}</span></td>
        </tr></table>
      </div>
      <table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;">
        <thead>
          <tr style="background:#f1f5f9;">
            <th style="padding:8px 14px;text-align:left;font-size:11px;color:#64748b;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;border-bottom:2px solid #e2e8f0;">Building</th>
            <th style="padding:8px 14px;text-align:right;font-size:11px;color:#64748b;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;border-bottom:2px solid #e2e8f0;">Net Rent Collected</th>
            <th style="padding:8px 14px;text-align:center;font-size:11px;color:#64748b;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;border-bottom:2px solid #e2e8f0;">% Change</th>
            <th style="padding:8px 14px;text-align:right;font-size:11px;color:#64748b;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;border-bottom:2px solid #e2e8f0;">Prev Day</th>
          </tr>
        </thead>
        <tbody>${rowsHtml}</tbody>
      </table>
    </div>`;
  }).join("");

  const flaggedCount = sorted.filter(b => {
    const prev = prevMap.get(collectionEmailKey(b));
    if (!prev || prev === 0) return false;
    return Math.abs(((b.netRentCollected - prev) / Math.abs(prev)) * 100) >= 5;
  }).length;

  return `<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"></head>
<body style="margin:0;padding:0;background:#f1f5f9;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#f1f5f9;padding:32px 16px;">
  <tr><td align="center">
    <table width="700" cellpadding="0" cellspacing="0" style="max-width:700px;width:100%;">
      <tr><td style="background:#1e293b;border-radius:10px 10px 0 0;padding:28px 32px;">
        <div style="color:#ffffff;font-size:24px;font-weight:700;margin-bottom:4px;">💰 Daily Collections Report</div>
        <div style="color:#94a3b8;font-size:14px;">${dateLabel} &bull; All Buildings &bull; Net Rent Collected</div>
      </td></tr>
      <tr><td style="background:#0f172a;padding:16px 32px;">
        <table width="100%"><tr>
          <td>
            <div style="color:#94a3b8;font-size:11px;text-transform:uppercase;letter-spacing:1px;margin-bottom:4px;">Portfolio Total — Net Rent Collected</div>
            <div style="color:#10b981;font-size:28px;font-weight:800;">${fmt(totalNetRentCollected)}</div>
          </td>
          <td align="right">
            <div style="color:#94a3b8;font-size:11px;text-transform:uppercase;letter-spacing:1px;margin-bottom:4px;">Buildings Flagged (≥±5% change)</div>
            <div style="color:${flaggedCount > 0 ? "#3b82f6" : "#10b981"};font-size:28px;font-weight:800;">${flaggedCount}</div>
          </td>
        </tr></table>
      </td></tr>
      <tr><td style="background:#ffffff;padding:28px 32px;border:1px solid #e2e8f0;border-top:none;border-radius:0 0 10px 10px;">
        ${regionSections}
        <p style="margin:24px 0 0;color:#64748b;font-size:12px;text-align:center;">
          Data sourced from PropertyMax.ai &bull; Apartment Corp &bull; ${dateLabel}<br>
          🚨 = Net Rent Collected changed ≥ ±5% vs previous day
        </p>
      </td></tr>
    </table>
  </td></tr>
</table>
</body>
</html>`;
}

/**
 * Current-month Collections email sourced from PropertyMax.ai's FLOW-tab rows.
 * The snapshot is freshly retrieved immediately before each scheduled send.
 */
export function buildCurrentCollectionsHtml(
  snapshot: CollectionsSnapshot,
  comparisonRows: CollectionsLookupResult[]
): string {
  const rowByKey = new Map<string, CollectionsLookupResult>();
  for (const row of comparisonRows) {
    rowByKey.set(`${row.regionId}:${row.buildingName.trim().toLocaleLowerCase()}`, row);
  }

  const rows = snapshot.buildings.map((building) => {
    const key = `${building.regionId}:${building.buildingName.trim().toLocaleLowerCase()}`;
    const comparison = rowByKey.get(key);
    return {
      ...building,
      variance: getCollectionVariance(building.rentBilled, building.rentCollected),
      rentCollectedChangePct: comparison?.rentCollectedChangePct ?? null,
      prevRentCollected: comparison?.prevRentCollected ?? null,
    };
  });

  const totalBilled = rows.reduce((sum, row) => sum + row.rentBilled, 0);
  const totalCollected = rows.reduce((sum, row) => sum + row.rentCollected, 0);
  const totalVariance = getCollectionVariance(totalBilled, totalCollected);
  const overallRate = totalBilled > 0 ? (totalCollected / totalBilled) * 100 : 0;
  const fmt = (value: number) => formatCurrency(value);
  const signedCurrency = (value: number) => `${value > 0 ? "+" : value < 0 ? "-" : ""}${fmt(Math.abs(value))}`;
  const toleranceStatus = (variance: ReturnType<typeof getCollectionVariance>) => {
    if (variance.status === "within_tolerance") return { label: "Within ±$7,500", color: "#198754", background: "#f3faf6" };
    if (variance.status === "shortfall") return { label: "Shortfall > $7,500", color: "#c63c4a", background: "#fff7f7" };
    if (variance.status === "over_collected") return { label: "Over > $7,500", color: "#7851a9", background: "#f7f4fb" };
    return { label: "No expected rent", color: "#64748b", background: "#f8fafc" };
  };
  const totalTolerance = toleranceStatus(totalVariance);
  const dateLabel = new Date(`${snapshot.snapshotDate}T12:00:00`).toLocaleDateString("en-US", {
    weekday: "long", year: "numeric", month: "long", day: "numeric",
  });
  const rateColor = (rate: number) => rate >= 90 ? "#059669" : rate >= 75 ? "#b45309" : "#dc2626";
  const changeCell = (change: number | null) => {
    if (change === null) return `<span style="color:#64748b;">—</span>`;
    if (change > 0.05) return `<span style="color:#059669;font-weight:700;">▲ ${change.toFixed(1)}%</span>`;
    if (change < -0.05) return `<span style="color:#dc2626;font-weight:700;">▼ ${Math.abs(change).toFixed(1)}%</span>`;
    return `<span style="color:#64748b;">—</span>`;
  };

  const regionMeta: Record<number, { name: string; color: string; surface: string }> = {
    1: { name: "Region 1", color: "#1e73be", surface: "#f4f8fc" },
    2: { name: "Region 2", color: "#198754", surface: "#f3faf6" },
    3: { name: "Region 3", color: "#b96a14", surface: "#fdf8f2" },
    4: { name: "Region 4", color: "#7851a9", surface: "#f7f4fb" },
  };

  const sections = [1, 2, 3, 4].map((regionId) => {
    const regionRows = rows
      .filter((row) => row.regionId === regionId)
      .sort((a, b) => a.buildingName.localeCompare(b.buildingName));
    if (regionRows.length === 0) return "";

    const regionBilled = regionRows.reduce((sum, row) => sum + row.rentBilled, 0);
    const regionCollected = regionRows.reduce((sum, row) => sum + row.rentCollected, 0);
    const regionVariance = getCollectionVariance(regionBilled, regionCollected);
    const regionRate = regionBilled > 0 ? (regionCollected / regionBilled) * 100 : 0;
    const { name, color, surface } = regionMeta[regionId] ?? { name: `Region ${regionId}`, color: "#334155", surface: "#f8fafc" };

    const buildingRows = regionRows.map((row, index) => {
      const isMaterialShortfall = row.variance.variance < -COLLECTION_VARIANCE_TOLERANCE;
      const varianceEmoji = isMaterialShortfall ? "🚨" : "👌🏼";
      const varianceColor = isMaterialShortfall ? "#dc2626" : "#059669";
      return `<tr style="background:${index % 2 === 0 ? "#ffffff" : "#f8fafc"};">
        <td style="padding:9px 12px;font-size:12px;color:#1e293b;font-weight:600;border-bottom:1px solid #e2e8f0;">${row.buildingName}</td>
        <td align="right" style="padding:9px 10px;font-size:12px;color:#334155;border-bottom:1px solid #e2e8f0;">${fmt(row.rentBilled)}</td>
        <td align="right" style="padding:9px 10px;font-size:12px;color:#0f766e;font-weight:700;border-bottom:1px solid #e2e8f0;">${fmt(row.rentCollected)}</td>
        <td class="collections-variance" align="right" style="padding:7px 8px;font-size:12px;color:${varianceColor};font-weight:700;border-bottom:1px solid #e2e8f0;white-space:nowrap;">${varianceEmoji} ${signedCurrency(row.variance.variance)}</td>
        <td align="center" style="padding:9px 10px;font-size:12px;color:${rateColor(row.collectionPct)};font-weight:800;border-bottom:1px solid #e2e8f0;">${row.collectionPct.toFixed(1)}%</td>
        <td align="center" style="padding:9px 10px;font-size:12px;border-bottom:1px solid #e2e8f0;">${changeCell(row.rentCollectedChangePct)}</td>
      </tr>`;
    }).join("");

    return `<div style="margin:0 0 22px;border:1px solid #dde3ea;border-radius:10px;overflow:hidden;">
      <div style="background:${surface};border-top:4px solid ${color};padding:9px 16px 11px;color:#172b4d;">
        <table width="100%" cellpadding="0" cellspacing="0"><tr>
          <td style="font-size:14px;font-weight:800;color:${color};">${name}</td>
          <td align="right" style="font-size:12px;font-weight:700;color:#172b4d;">${fmt(regionCollected)} collected &middot; ${regionRate.toFixed(1)}%</td>
        </tr></table>
      </div>
      <table width="100%" cellpadding="0" cellspacing="0" class="collections-table" style="border-collapse:collapse;">
        <thead><tr style="background:#f1f5f9;">
          <th align="left" style="padding:8px 12px;font-size:10px;color:#64748b;letter-spacing:.4px;text-transform:uppercase;">Building</th>
          <th align="right" style="padding:8px 10px;font-size:10px;color:#64748b;letter-spacing:.4px;text-transform:uppercase;">Expected Rent</th>
          <th align="right" style="padding:8px 10px;font-size:10px;color:#64748b;letter-spacing:.4px;text-transform:uppercase;">Collected</th>
          <th align="right" style="padding:8px 10px;font-size:10px;color:#64748b;letter-spacing:.4px;text-transform:uppercase;">Variance</th>
          <th align="center" style="padding:8px 10px;font-size:10px;color:#64748b;letter-spacing:.4px;text-transform:uppercase;">Rate</th>
          <th align="center" style="padding:8px 10px;font-size:10px;color:#64748b;letter-spacing:.4px;text-transform:uppercase;">vs Prior</th>
        </tr></thead>
        <tbody>${buildingRows}</tbody>
      </table>
      <div style="padding:9px 12px;background:#f8fafc;border-top:1px solid #e2e8f0;font-size:11px;color:#475569;font-weight:700;text-align:right;">Expected ${fmt(regionBilled)} &nbsp;|&nbsp; Variance <span style="color:${regionVariance.variance < -COLLECTION_VARIANCE_TOLERANCE ? "#dc2626" : "#059669"};">${regionVariance.variance < -COLLECTION_VARIANCE_TOLERANCE ? "🚨" : "👌🏼"} ${signedCurrency(regionVariance.variance)}</span></div>
    </div>`;
  }).join("");

  return `<!DOCTYPE html>
<html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<style>
  @media only screen and (max-width:600px) {
    .collections-email-outer { padding:8px 0 !important; }
    .collections-email-inner { width:100% !important; max-width:100% !important; }
    .collections-header { padding:20px 16px !important; }
    .collections-body { padding:16px 8px 2px !important; }
    .collections-summary-row { display:block !important; }
    .collections-summary-cell { display:inline-block !important; width:50% !important; box-sizing:border-box !important; padding:0 6px 12px !important; vertical-align:top !important; }
    .collections-summary-cell:last-child { width:100% !important; }
    .collections-table th, .collections-table td { padding:6px 3px !important; font-size:9px !important; vertical-align:top !important; }
    .collections-table th:first-child, .collections-table td:first-child { width:19% !important; word-break:break-word !important; }
    .collections-table th:nth-child(2), .collections-table td:nth-child(2), .collections-table th:nth-child(3), .collections-table td:nth-child(3) { width:17% !important; }
    .collections-table th:nth-child(4), .collections-table td:nth-child(4) { width:21% !important; }
    .collections-table th:nth-child(5), .collections-table td:nth-child(5), .collections-table th:nth-child(6), .collections-table td:nth-child(6) { width:13% !important; }
    .collections-variance { white-space:nowrap !important; }
  }
</style></head>
<body style="margin:0;padding:0;background:#f5f7fa;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" class="collections-email-outer" style="padding:28px 12px;background:#f5f7fa;"><tr><td align="center">
    <table width="700" cellpadding="0" cellspacing="0" class="collections-email-inner" style="max-width:700px;width:100%;border-collapse:collapse;">
      <tr><td class="collections-header" style="background:#edf4fb;border-radius:12px 12px 0 0;padding:28px 30px;border-bottom:2px solid #c9a84c;">
        <div style="color:#153a5b;font-size:24px;font-weight:800;">Daily Collections Report</div>
        <div style="color:#667085;font-size:13px;margin-top:5px;">${dateLabel} &bull; Live PropertyMax FLOW Collections snapshot</div>
      </td></tr>
      <tr><td style="background:#ffffff;padding:18px 18px 6px;">
        <table width="100%" cellpadding="0" cellspacing="0"><tr class="collections-summary-row">
          <td width="25%" class="collections-summary-cell" style="padding:0 4px 12px 0;"><div style="background:#f4f8fc;border:1px solid #dde3ea;border-top:4px solid #1e73be;border-radius:8px;padding:10px 8px;text-align:center;"><div style="color:#667085;font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.6px;">Expected Rent</div><div style="color:#1e73be;font-size:18px;font-weight:800;margin-top:4px;">${fmt(totalBilled)}</div></div></td>
          <td width="25%" class="collections-summary-cell" style="padding:0 4px 12px;"><div style="background:#f3faf6;border:1px solid #dde3ea;border-top:4px solid #198754;border-radius:8px;padding:10px 8px;text-align:center;"><div style="color:#667085;font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.6px;">Total Collected</div><div style="color:#198754;font-size:18px;font-weight:800;margin-top:4px;">${fmt(totalCollected)}</div></div></td>
          <td width="25%" class="collections-summary-cell" style="padding:0 4px 12px;"><div style="background:${totalTolerance.background};border:1px solid #dde3ea;border-top:4px solid ${totalTolerance.color};border-radius:8px;padding:10px 8px;text-align:center;"><div style="color:#667085;font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.6px;">Variance</div><div style="color:${totalTolerance.color};font-size:18px;font-weight:800;margin-top:4px;">${signedCurrency(totalVariance.variance)}</div></div></td>
          <td width="25%" class="collections-summary-cell" style="padding:0 0 12px 4px;"><div style="background:#f7f4fb;border:1px solid #dde3ea;border-top:4px solid #7851a9;border-radius:8px;padding:10px 8px;text-align:center;"><div style="color:#667085;font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.6px;">Collection Rate</div><div style="color:#7851a9;font-size:18px;font-weight:800;margin-top:4px;">${overallRate.toFixed(1)}%</div></div></td>
        </tr></table>
      </td></tr>
      <tr><td class="collections-body" style="background:#ffffff;padding:8px 18px 4px;"><div style="margin:0 0 14px;padding:9px 12px;border:1px solid #efcfd3;border-radius:8px;background:#fff7f7;color:#c63c4a;font-size:11px;font-weight:800;text-align:center;">Variance tolerance: ±${fmt(COLLECTION_VARIANCE_TOLERANCE)} &nbsp;·&nbsp; 🚨 indicates a material shortfall</div>${sections}</td></tr>
       ${dashboardButton("#c9a84c", "Open Collections Dashboard", `${getDashboardUrl()}?tab=collections`, "#ffffff")}
      <tr><td style="background:#ffffff;border-radius:0 0 12px 12px;padding:12px 30px 24px;">
        <p style="margin:0;color:#64748b;font-size:11px;text-align:center;">Sourced exclusively from the PropertyMax FLOW Collections snapshot immediately before delivery.<br>Expected Rent = Rent Billed. Variance = Collected minus Expected Rent. “vs Prior” is shown only when an authoritative prior PropertyMax FLOW snapshot is available.</p>
      </td></tr>
    </table>
  </td></tr></table>
</body></html>`;
}

/**
 * A percentage change is meaningful in the daily email only when a snapshot
 * exists for the immediately preceding calendar day. Older historical data is
 * still retained for the dashboard trend view, but is not presented as “prior day.”
 */
export function getPriorDayCollectionComparisons(
  snapshotDate: string,
  rows: CollectionsLookupResult[]
): CollectionsLookupResult[] {
  const priorDay = new Date(`${snapshotDate}T12:00:00`);
  priorDay.setDate(priorDay.getDate() - 1);
  const priorDayString = priorDay.toISOString().slice(0, 10);

  return rows.map((row) => row.prevSnapshotDate === priorDayString
    ? row
    : { ...row, rentCollectedChangePct: null, prevRentCollected: null, prevSnapshotDate: null }
  );
}

export type PreparedManagedCollections = {
  transporter: ReturnType<typeof createGmailReportTransport>;
  message: { from: string; replyTo: string; to: string; subject: string; html: string };
  deliveryKind: "collections" | "collections_test";
};

function assertCollectionsDeliveryRecipients(recipients: string[], deliveryKind: PreparedManagedCollections["deliveryKind"]) {
  if (deliveryKind === "collections") return assertApprovedScheduledRecipients(recipients);
  if (deliveryKind !== "collections_test" || recipients.length !== 1 || recipients[0] !== DAILY_VACANCY_TEST_RECIPIENT) {
    throw new Error("Collections test recipient must be Ethan only");
  }
}

/** No network I/O: invoked only by the managed processor after its durable per-report claim and forced FLOW pull. */
export async function prepareManagedCollections(
  snapshot: CollectionsSnapshot, recipients: string[], deliveryKind: PreparedManagedCollections["deliveryKind"] = "collections",
): Promise<PreparedManagedCollections> {
  assertCollectionsDeliveryRecipients(recipients, deliveryKind);
  const transporter = createGmailReportTransport(); // strict getGmailReportConfig; never fallback
  return {
    transporter, deliveryKind,
    message: {
      from: `"${FROM_NAME}" <${FROM_EMAIL}>`, replyTo: REPLY_TO, to: recipients.join(", "),
      subject: `${deliveryKind === "collections_test" ? "[Test3] " : ""}💰 Daily Collections Report — ${snapshot.snapshotDate} | ${formatCurrency(snapshot.totalRentCollected)} Collected (${snapshot.overallCollectionPct.toFixed(1)}%)`,
      // Preserve the current renderer and prior-source semantics; no Railway or stale comparisons.
      html: buildCurrentCollectionsHtml(snapshot, []),
    },
  };
}

/** Low-level SMTP boundary: only after the processor confirms a durable sending CAS. */
export async function sendPreparedManagedCollections(prepared: PreparedManagedCollections): Promise<ScheduledDailyVacancyReceipt> {
  assertCollectionsDeliveryRecipients(prepared.message.to.split(", "), prepared.deliveryKind);
  const receipt = await prepared.transporter.sendMail({
    from: `"${FROM_NAME}" <${FROM_EMAIL}>`, replyTo: REPLY_TO,
    to: prepared.message.to, subject: prepared.message.subject, html: prepared.message.html,
  });
  const address = (value: string | { address: string }) => typeof value === "string" ? value : value.address;
  return {
    messageId: receipt.messageId,
    accepted: (receipt.accepted ?? []).map(address), rejected: (receipt.rejected ?? []).map(address),
    response: receipt.response ?? "",
  };
}

/** @deprecated Retired: use the managed callback or sendManagedCollectionsTestToEthan(taskUid). No SMTP, source fetch, or recipient fallback. */
export const LEGACY_COLLECTIONS_DISTRIBUTION_RETIRED = true;
export async function sendDailyCollectionsEmail(_recipientOverride?: string, _testLabel?: string): Promise<boolean> {
  return false;
}
