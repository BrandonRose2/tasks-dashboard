import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import type { CollectionsSnapshot, DashboardData, HistoricalMonth, WeeklySummaryData } from "./scraper";

const mocks = vi.hoisted(() => ({
  sendMail: vi.fn(),
  verify: vi.fn(),
  createTransport: vi.fn(),
  graphSend: vi.fn(() => { throw new Error("Graph must remain inactive"); }),
  graphToken: vi.fn(() => { throw new Error("Graph must remain inactive"); }),
  fetchDashboardData: vi.fn(),
  fetchRailwayCollectionsSnapshot: vi.fn(),
  getDailyVacancyRecipients: vi.fn(),
  getMonthlyNetCashRecipients: vi.fn(),
  getPaymentsDates: vi.fn(),
  getPaymentsForDateDb: vi.fn(),
  getCollectionsLookup: vi.fn(),
}));

// Mock SMTP at its boundary: every message is captured in memory, never sent.
vi.mock("nodemailer", () => ({ default: { createTransport: mocks.createTransport } }));
vi.mock("./microsoftMail", () => ({
  MICROSOFT_MAIL_SENDER: "ethan@apartmentcorp.com",
  sendMicrosoftGraphMail: mocks.graphSend,
  getMicrosoftDelegatedAccessToken: mocks.graphToken,
}));
vi.mock("./scraper", () => ({ fetchDashboardData: mocks.fetchDashboardData }));
vi.mock("./railwayReports", () => ({ fetchRailwayCollectionsSnapshot: mocks.fetchRailwayCollectionsSnapshot }));
vi.mock("./db", () => ({
  getDailyVacancyRecipients: mocks.getDailyVacancyRecipients,
  getMonthlyNetCashRecipients: mocks.getMonthlyNetCashRecipients,
  getPaymentsDates: mocks.getPaymentsDates,
  getPaymentsForDateDb: mocks.getPaymentsForDateDb,
  getCollectionsLookup: mocks.getCollectionsLookup,
}));

import {
  buildCurrentCollectionsHtml,
  buildDailyVacancyHtml,
  buildDailyVacancySubject,
  buildMonthlyNetCashHtml,
  buildWeeklySummaryHtml,
  sendDailyCollectionsEmail,
  prepareManagedCollections,
  sendPreparedManagedCollections,
  prepareScheduledDailyVacancy,
  sendPreparedScheduledDailyVacancy,
  sendDailyVacancyEmail,
  sendEvictionMissingAmountEmails,
  sendMonthlyNetCashEmail,
  sendWeeklySummaryEmail,
} from "./emailService";

const stats = { totalVacant: 2, vacUnleased: 2, vacPreleased: 0, onNotice: 0, eviction: 0 };
const dashboard: DashboardData = {
  stats,
  lastUpdated: new Date("2026-11-02T12:00:00Z"),
  vacantUnleased: [], vacantPreleased: [], onNotice: [], evictions: [],
  dailyChanges: [], historicalMonths: [],
  buildingVacancy: [{ name: "Synthetic Property", totalVacant: 2, vacUnleased: 2, vacPreleased: 0, onNotice: 0, eviction: 0, totalUnits: 100, vacancyPct: 2, atRisk: false }],
};
const month: HistoricalMonth = {
  year: 2026, month: 10, monthName: "October", label: "October 2026", grandTotal: 123,
  regions: [1, 2, 3, 4].map(region => ({ region, regionName: `Region ${region}`, total: region === 1 ? 123 : 0,
    buildings: [{ name: `Synthetic Property ${region}`, value: region === 1 ? 123 : 0 }] })),
};
const summary: WeeklySummaryData = {
  weekStart: "2026-10-26", weekEnd: "2026-11-02", totalBuildingsChanged: 0,
  totalNetChange: 0, startTotalVacant: 2, endTotalVacant: 2,
  buildingTrends: [], dailyChanges: [], topIncreases: [], topDecreases: [],
  currentStats: stats, currentAtRisk: [],
};
const collections: CollectionsSnapshot = {
  snapshotDate: "2026-11-02", totalRentBilled: 100, totalRentCollected: 90, overallCollectionPct: 90,
  buildings: [{ buildingName: "Synthetic Property", regionId: 1, regionName: "Region 1", rentBilled: 100, rentCollected: 90, utilityReimbursement: 0, vouchersCount: 0, collectionPct: 90 }],
};
const sender = {
  from: '"Apartment Corp Reports" <apartmentcorp44@gmail.com>',
  replyTo: "ethan@apartmentcorp.com",
};

beforeEach(() => {
  vi.clearAllMocks();
  vi.stubEnv("GMAIL_USER", "apartmentcorp44@gmail.com");
  vi.stubEnv("GMAIL_APP_PASSWORD", "abcd efgh ijkl mnop");
  vi.useFakeTimers();
  vi.setSystemTime(new Date("2026-11-02T12:00:00Z"));
  vi.spyOn(console, "log").mockImplementation(() => {});
  vi.spyOn(console, "warn").mockImplementation(() => {});
  vi.spyOn(console, "error").mockImplementation(() => {});
  vi.stubGlobal("fetch", vi.fn(() => { throw new Error("No network requests permitted"); }));
  mocks.createTransport.mockReturnValue({ sendMail: mocks.sendMail, verify: mocks.verify, close: vi.fn() });
  mocks.sendMail.mockResolvedValue({ messageId: "synthetic-only" });
  mocks.getDailyVacancyRecipients.mockResolvedValue(["Admin@One.test", "Second@Two.test"]);
  mocks.getMonthlyNetCashRecipients.mockResolvedValue(["monthly@one.test", "monthly@two.test"]);
  mocks.getPaymentsDates.mockResolvedValue([]);
  mocks.fetchDashboardData.mockResolvedValue(dashboard);
  mocks.fetchRailwayCollectionsSnapshot.mockResolvedValue(collections);
});

afterEach(() => {
  expect(mocks.graphSend).not.toHaveBeenCalled();
  expect(mocks.graphToken).not.toHaveBeenCalled();
  expect(fetch).not.toHaveBeenCalled();
  expect(mocks.verify).not.toHaveBeenCalled();
  vi.restoreAllMocks();
  vi.unstubAllEnvs();
  vi.unstubAllGlobals();
  vi.useRealTimers();
});

describe("Gmail report delivery wiring (mocked SMTP; no send)", () => {
  it("prepares the identical Daily Vacancy HTML without SMTP, then sends only the approved To list and returns receipt", async () => {
    const recipients = ["ethan@apartmentcorp.com", "mam@22.bz"];
    mocks.sendMail.mockResolvedValueOnce({ messageId: "mock-scheduled", accepted: recipients, rejected: [], response: "250 accepted" });
    const prepared = await prepareScheduledDailyVacancy(dashboard, recipients);
    expect(mocks.sendMail).not.toHaveBeenCalled();
    await expect(sendPreparedScheduledDailyVacancy(prepared)).resolves.toEqual({
      messageId: "mock-scheduled", accepted: recipients, rejected: [], response: "250 accepted",
    });
    expect(mocks.sendMail).toHaveBeenCalledWith({
      ...sender, to: "ethan@apartmentcorp.com, mam@22.bz",
      subject: buildDailyVacancySubject(dashboard.lastUpdated, stats.totalVacant),
      html: buildDailyVacancyHtml(dashboard),
    });
    const message = mocks.sendMail.mock.calls[0][0];
    expect(message).not.toHaveProperty("cc"); expect(message).not.toHaveProperty("bcc");
    expect(message.subject).not.toContain("Test3");
    expect(mocks.getDailyVacancyRecipients).not.toHaveBeenCalled();
    expect(mocks.fetchDashboardData).not.toHaveBeenCalled();
  });

  it("does not forward injected CC/BCC or sender fields from a prepared object", async () => {
    const prepared = await prepareScheduledDailyVacancy(dashboard, ["ethan@apartmentcorp.com", "mam@22.bz"]);
    Object.assign(prepared.message, { cc: "extra@invalid.test", bcc: "hidden@invalid.test", from: "other@invalid.test", replyTo: "other@invalid.test" });
    await sendPreparedScheduledDailyVacancy(prepared);
    const message = mocks.sendMail.mock.calls[0][0];
    expect(message).toMatchObject(sender);
    expect(message).not.toHaveProperty("cc"); expect(message).not.toHaveProperty("bcc");
  });

  it.each([
    ["ethan@apartmentcorp.com"], ["mam@22.bz", "other@invalid.test"],
    ["ethan@apartmentcorp.com", "mam@22.bz", "other@invalid.test"],
    ["ethan@apartmentcorp.com", "ethan@apartmentcorp.com"],
  ])("blocks unapproved scheduled recipient lists %j", async (...recipients) => {
    await expect(prepareScheduledDailyVacancy(dashboard, recipients)).rejects.toThrow("two approved");
    expect(mocks.createTransport).not.toHaveBeenCalled(); expect(mocks.sendMail).not.toHaveBeenCalled();
  });

  it("scheduled relay configuration failure happens during preparation without SMTP", async () => {
    vi.stubEnv("GMAIL_USER", "");
    await expect(prepareScheduledDailyVacancy(dashboard, ["ethan@apartmentcorp.com", "mam@22.bz"])).rejects.toThrow("relay unavailable");
    expect(mocks.sendMail).not.toHaveBeenCalled();
  });

  it("preserves the fresh Daily Vacancy source, Admin recipient policy, subject, HTML, and dashboard link", async () => {
    await expect(sendDailyVacancyEmail()).resolves.toBe(true);
    expect(mocks.fetchDashboardData).toHaveBeenCalledOnce();
    expect(mocks.fetchDashboardData).toHaveBeenCalledWith(true);
    expect(mocks.sendMail).toHaveBeenCalledOnce();
    expect(mocks.sendMail).toHaveBeenCalledWith({
      ...sender, to: "admin@one.test, second@two.test",
      subject: buildDailyVacancySubject(dashboard.lastUpdated, stats.totalVacant),
      html: buildDailyVacancyHtml(dashboard),
    });
    expect(mocks.sendMail.mock.calls[0][0].html).toContain('href="https://vacancyreport.manus.space"');
  });

  it("preserves the Ethan-only explicitly labeled Test3 exception", async () => {
    await expect(sendDailyVacancyEmail(" Ethan@ApartmentCorp.com ", "Test3")).resolves.toBe(true);
    expect(mocks.sendMail).toHaveBeenCalledOnce();
    expect(mocks.sendMail).toHaveBeenCalledWith({
      ...sender, to: "ethan@apartmentcorp.com",
      subject: buildDailyVacancySubject(dashboard.lastUpdated, stats.totalVacant, "Test3"),
      html: buildDailyVacancyHtml(dashboard),
    });
  });

  it("blocks unapproved overrides before constructing any transport", async () => {
    await expect(sendDailyVacancyEmail("someone@one.test", "Test3")).resolves.toBe(false);
    await expect(sendDailyVacancyEmail("ethan@apartmentcorp.com")).resolves.toBe(false);
    expect(mocks.createTransport).not.toHaveBeenCalled();
    expect(mocks.sendMail).not.toHaveBeenCalled();
  });

  it.each([
    { user: "", password: "abcdefghijklmnop" },
    { user: "other@gmail.com", password: "abcdefghijklmnop" },
    { user: "apartmentcorp44@gmail.com", password: "" },
    { user: "apartmentcorp44@gmail.com", password: "RegularPassword1" },
  ])("blocks delivery with invalid Gmail settings without Graph or other fallback: %j", async ({ user, password }) => {
    vi.stubEnv("GMAIL_USER", user);
    vi.stubEnv("GMAIL_APP_PASSWORD", password);
    await expect(sendDailyVacancyEmail()).resolves.toBe(false);
    expect(mocks.createTransport).not.toHaveBeenCalled();
    expect(mocks.sendMail).not.toHaveBeenCalled();
    expect(mocks.fetchDashboardData).not.toHaveBeenCalled();
  });

  it("preserves monthly database recipients, subject and exact HTML", async () => {
    await expect(sendMonthlyNetCashEmail(month)).resolves.toBe(true);
    expect(mocks.sendMail).toHaveBeenCalledOnce();
    expect(mocks.sendMail).toHaveBeenCalledWith({
      ...sender, to: "monthly@one.test, monthly@two.test",
      subject: "💰 Marc's Net Cash Flow — October 2026 | Grand Total: $123.00",
      html: buildMonthlyNetCashHtml(month),
    });
  });

  it("fails closed without monthly database recipients and retains explicit manual override", async () => {
    mocks.getMonthlyNetCashRecipients.mockResolvedValue([]);
    await expect(sendMonthlyNetCashEmail(month)).resolves.toBe(false);
    expect(mocks.sendMail).not.toHaveBeenCalled();
    await expect(sendMonthlyNetCashEmail(month, "override@one.test")).resolves.toBe(true);
    expect(mocks.sendMail.mock.calls[0][0].to).toBe("override@one.test");
  });

  it.each([undefined, "weekly@one.test"])("preserves weekly recipients, subject and exact HTML with override %s", async (override) => {
    await expect(sendWeeklySummaryEmail(summary, override)).resolves.toBe(true);
    expect(mocks.sendMail).toHaveBeenCalledOnce();
    expect(mocks.sendMail).toHaveBeenCalledWith({
      ...sender, to: override ?? "Admin@One.test, Second@Two.test",
      subject: "📊 Weekly Vacancy Summary — 2026-10-26 to 2026-11-02",
      html: buildWeeklySummaryHtml(summary),
    });
  });

  it("retires legacy Collections distribution and override calls without any transport or fetch", async () => {
    for (const args of [[], ["ethan@apartmentcorp.com", "Test3"], ["Brandon@ApartmentCorp.com"]]) {
      await expect(sendDailyCollectionsEmail(...args)).resolves.toBe(false);
    }
    expect(mocks.createTransport).not.toHaveBeenCalled(); expect(mocks.sendMail).not.toHaveBeenCalled();
    expect(mocks.fetchRailwayCollectionsSnapshot).not.toHaveBeenCalled();
  });

  it.each(["collections", "collections_test"] as const)("prepares unchanged current Collections HTML and exact policy for %s", async kind => {
    const recipients = kind === "collections_test" ? ["ethan@apartmentcorp.com"] : ["ethan@apartmentcorp.com", "mam@22.bz"];
    mocks.sendMail.mockResolvedValueOnce({ messageId: "mock-collections", accepted: recipients, rejected: [], response: "250 accepted" });
    const prepared = await prepareManagedCollections(collections, recipients, kind);
    expect(mocks.sendMail).not.toHaveBeenCalled();
    Object.assign(prepared.message, { cc: "extra@invalid.test", bcc: "hidden@invalid.test", from: "other@invalid.test" });
    await sendPreparedManagedCollections(prepared);
    expect(mocks.sendMail).toHaveBeenCalledWith({
      ...sender, to: recipients.join(", "),
      subject: `${kind === "collections_test" ? "[Test3] " : ""}💰 Daily Collections Report — 2026-11-02 | $90.00 Collected (90.0%)`,
      html: buildCurrentCollectionsHtml(collections, []),
    });
    const message = mocks.sendMail.mock.calls[0][0];
    expect(message).not.toHaveProperty("cc"); expect(message).not.toHaveProperty("bcc");
    expect(message.html).toContain('href="https://vacancyreport.manus.space?tab=collections"');
    expect(message.html).not.toMatch(/Railway|vacancyapp-42vudntx/);
    expect(mocks.fetchRailwayCollectionsSnapshot).not.toHaveBeenCalled();
  });

  it("rejects wrong Collections recipient or credentials before SMTP", async () => {
    await expect(prepareManagedCollections(collections, ["extra@invalid.test"], "collections_test")).rejects.toThrow("Ethan only");
    await expect(prepareManagedCollections(collections, ["ethan@apartmentcorp.com"])).rejects.toThrow("two approved");
    vi.stubEnv("GMAIL_USER", "other@gmail.com");
    await expect(prepareManagedCollections(collections, ["ethan@apartmentcorp.com"], "collections_test")).rejects.toThrow("GMAIL_USER must be");
    expect(mocks.sendMail).not.toHaveBeenCalled(); expect(mocks.createTransport).not.toHaveBeenCalled();
  });

  it("preserves eviction manager To, regional/admin CC, subject, HTML, and empty-unit skip behavior", async () => {
    const contact = { property: "Synthetic Property", managerName: "Sam Manager", managerEmail: "manager@one.test", regionalEmail: "regional@one.test", units: ["A101", "B202"] };
    await expect(sendEvictionMissingAmountEmails([contact, { ...contact, units: [] }])).resolves.toEqual({ sent: 1, skipped: 1 });
    expect(mocks.sendMail).toHaveBeenCalledOnce();
    const message = mocks.sendMail.mock.calls[0][0];
    expect(message).toEqual({
      ...sender, to: contact.managerEmail,
      cc: "regional@one.test, ethan@apartmentcorp.com, mam@22.bz",
      subject: "Action Required: Missing Amount Owed — Eviction Records (Synthetic Property)",
      html: expect.any(String),
    });
    expect(message.html).toContain("Hello Sam,");
    expect(message.html).toContain("2 eviction units at Synthetic Property");
    expect(message.html).toContain("A101");
    expect(message.html).toContain("B202");
    expect(message.html).toContain("PropertyMax.ai");
    expect(message.html).toContain("Brandon Rose");
  });
});
