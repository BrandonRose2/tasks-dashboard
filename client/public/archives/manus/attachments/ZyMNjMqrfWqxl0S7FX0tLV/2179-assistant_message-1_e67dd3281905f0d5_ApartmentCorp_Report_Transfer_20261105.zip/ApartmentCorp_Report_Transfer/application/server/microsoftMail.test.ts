import { describe, expect, it } from "vitest";
import {
  buildMicrosoftAuthorizationUrl,
  decryptMicrosoftRefreshToken,
  encryptMicrosoftRefreshToken,
  getMicrosoftDelegatedAccessToken,
  getMicrosoftMailConfig,
  MICROSOFT_MAIL_SENDER,
} from "./microsoftMail";

const env = {
  EXCHANGE_TENANT_ID: "tenant-id",
  EXCHANGE_CLIENT_ID: "client-id",
  EXCHANGE_CLIENT_SECRET: "client-secret",
  MICROSOFT_OAUTH_REDIRECT_URI: "https://example.test/api/microsoft-oauth/callback",
  JWT_SECRET: "test-jwt-secret",
} as NodeJS.ProcessEnv;

describe("delegated Microsoft mail configuration", () => {
  it("uses Ethan as the sole delegated sender", () => {
    expect(MICROSOFT_MAIL_SENDER).toBe("ethan@apartmentcorp.com");
  });

  it("builds a no-admin delegated authorization request with Mail.Send and offline access", () => {
    const url = new URL(buildMicrosoftAuthorizationUrl("csrf-state", env));
    expect(url.searchParams.get("response_type")).toBe("code");
    expect(url.searchParams.get("state")).toBe("csrf-state");
    expect(url.searchParams.get("scope")).toContain("Mail.Send");
    expect(url.searchParams.get("scope")).toContain("offline_access");
    expect(url.searchParams.get("redirect_uri")).toBe(env.MICROSOFT_OAUTH_REDIRECT_URI);
  });

  it("encrypts refresh tokens before storage and decrypts only with the server secret", () => {
    const encrypted = encryptMicrosoftRefreshToken("refresh-token-value", env);
    expect(encrypted).not.toContain("refresh-token-value");
    expect(decryptMicrosoftRefreshToken(encrypted, env)).toBe("refresh-token-value");
  });

  it("requires the redirect URI that is registered in Entra", () => {
    expect(() => getMicrosoftMailConfig({ ...env, MICROSOFT_OAUTH_REDIRECT_URI: "" })).toThrow("MICROSOFT_OAUTH_REDIRECT_URI");
  });

  it.skipIf(process.env.MICROSOFT_CLIENT_CREDENTIAL_LIVE_VERIFY !== "true")(
    "validates the clean Entra client credentials without contacting Graph mail or sending email",
    async () => {
      const config = getMicrosoftMailConfig();
      const response = await fetch(`https://login.microsoftonline.com/${encodeURIComponent(config.tenantId)}/oauth2/v2.0/token`, {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
          client_id: config.clientId,
          client_secret: config.clientSecret,
          grant_type: "client_credentials",
          scope: "https://graph.microsoft.com/.default",
        }),
      });
      const payload = await response.json() as { access_token?: string; error?: string };

      expect(response.ok, payload.error ?? "Microsoft token request failed").toBe(true);
      expect(typeof payload.access_token).toBe("string");
    },
    15_000,
  );

  it.skipIf(process.env.MICROSOFT_GRAPH_LIVE_VERIFY !== "true")(
    "refreshes Ethan's delegated token and validates his mailbox without sending mail",
    async () => {
      const accessToken = await getMicrosoftDelegatedAccessToken();
      const response = await fetch("https://graph.microsoft.com/v1.0/me?$select=mail,userPrincipalName", {
        headers: { Authorization: `Bearer ${accessToken}` },
      });
      const profile = await response.json() as { mail?: string; userPrincipalName?: string };

      expect(response.ok).toBe(true);
      expect((profile.mail ?? profile.userPrincipalName ?? "").toLowerCase()).toBe(MICROSOFT_MAIL_SENDER);
    },
    15_000,
  );
});
