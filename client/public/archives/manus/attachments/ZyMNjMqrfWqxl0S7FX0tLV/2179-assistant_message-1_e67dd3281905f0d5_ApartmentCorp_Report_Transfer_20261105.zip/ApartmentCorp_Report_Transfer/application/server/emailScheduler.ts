// Daily Vacancy + Collections: single managed durable schedule (unchanged).
export const LEGACY_DAILY_VACANCY_TIMER_RETIRED = true;
export const LEGACY_DAILY_COLLECTIONS_TIMER_RETIRED = true;
// Weekly summary: standalone Heartbeat, Saturdays 9 AM America/New_York.
export const LEGACY_WEEKLY_TIMER_RETIRED = true;
// Eviction reminders: standalone Heartbeat, 1st/15th 9 AM America/New_York.
export const LEGACY_EVICTION_TIMER_RETIRED = true;
// Monthly Net Cash Flow: standalone Heartbeat, 12th at 1 PM America/Los_Angeles.
// No startup provisioning or activation; explicit publish/bind/activate only.

/** Compatibility no-ops: all email timers are retired. */
export function startEmailScheduler(): void {}
export function stopEmailScheduler(): void {}
