import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import type { HistoricalMonth, MarcsNetCash } from "./scraper";
import type { TrpcContext } from "./_core/context";

const mocks = vi.hoisted(() => ({
  source: vi.fn(), undiciFetch: vi.fn(), monthlyRecipients: vi.fn(),
  sendMail: vi.fn(), createTransport: vi.fn(), getDb: vi.fn(),
}));
vi.mock("./scraper", async importOriginal => ({
  ...await importOriginal<typeof import("./scraper")>(),
  fetchAllRegionsMarcsNetCash: mocks.source,
}));
vi.mock("undici", () => ({ Agent: class {}, fetch: mocks.undiciFetch }));
vi.mock("./db", async importOriginal => ({
  ...await importOriginal<typeof import("./db")>(),
  getMonthlyNetCashRecipients: mocks.monthlyRecipients,
  getDb: mocks.getDb,
}));
vi.mock("nodemailer", () => ({ default: { createTransport: mocks.createTransport } }));

import {
  assertCompleteMonthlyNetCashReport, fetchFreshMonthlyNetCashReport,
  getCompletedMonthlyNetCashPeriod, getPreviousCompletedMonth,
} from "./monthlyNetCashReport";
import { parseStrictMonthlyNetCashHtml } from "./monthlyNetCashParser";
import { buildMonthlyNetCashHtml, prepareMonthlyNetCashEmail, sendMonthlyNetCashEmail } from "./emailService";
import { appRouter } from "./routers";
import { fetchMarcsNetCash } from "./scraper";

const NOW = new Date("2026-11-04T20:00:00Z");
const RECIPIENTS = ["ethan@apartmentcorp.com", "mam@22.bz"];
function completeRegions(values = [123.45, -23.45, 0, 12.34]): MarcsNetCash[] {
  return values.map((value, index) => ({
    region: index + 1, regionName: `Region ${index + 1}`, total: value,
    buildings: [{ name: `Synthetic ${index + 1}`, value }],
  }));
}
function completeMonth(regions = completeRegions()): HistoricalMonth {
  return {
    year: 2026, month: 10, monthName: "October", label: "October 2026", regions,
    grandTotal: regions.reduce((sum, region) => sum + region.total, 0),
  };
}
function flowHtml(alpha = "<strong>123.45</strong>", beta = "<strong>-23.45</strong>"): string {
  return `<table><thead><tr><th colspan="2"></th><th>★ Alpha</th><th></th><th>Beta</th><th></th></tr></thead>
    <tbody><tr><td colspan="2"><strong>Net Cash Flow</strong></td><td>${alpha}</td><td></td><td>${beta}</td><td></td></tr></tbody></table>`;
}
function caller() {
  return appRouter.createCaller({ user: null, req: {}, res: {} } as TrpcContext);
}

beforeEach(() => {
  vi.clearAllMocks();
  vi.useFakeTimers(); vi.setSystemTime(NOW);
  vi.stubEnv("GMAIL_USER", "apartmentcorp44@gmail.com");
  vi.stubEnv("GMAIL_APP_PASSWORD", "abcd efgh ijkl mnop");
  vi.stubEnv("PROPERTYMAX_USERNAME", "offline-fixture-user");
  vi.stubEnv("PROPERTYMAX_PASSWORD", "offline-fixture-password");
  vi.stubGlobal("fetch", vi.fn(() => { throw new Error("Live network forbidden in monthly tests"); }));
  mocks.getDb.mockImplementation(() => { throw new Error("DB/cache access forbidden in monthly source tests"); });
  mocks.monthlyRecipients.mockResolvedValue(RECIPIENTS);
  mocks.source.mockResolvedValue(completeRegions());
  mocks.createTransport.mockReturnValue({ sendMail: mocks.sendMail });
  mocks.sendMail.mockResolvedValue({ messageId: "offline-only" });
  mocks.undiciFetch.mockImplementation(async (url: string, options?: { method?: string }) => ({
    status: options?.method === "POST" ? 302 : 200,
    headers: {
      getSetCookie: () => ["CFID=offline; Path=/"],
      get: (name: string) => name === "location" ? "/app/" : null,
    },
    text: async () => url.includes("vacancy.cfc") ? flowHtml() : "<html>Offline fixture</html>",
  }));
  vi.spyOn(console, "log").mockImplementation(() => {});
  vi.spyOn(console, "warn").mockImplementation(() => {});
  vi.spyOn(console, "error").mockImplementation(() => {});
});
afterEach(() => {
  expect(fetch).not.toHaveBeenCalled();
  expect(mocks.getDb).not.toHaveBeenCalled();
  vi.restoreAllMocks(); vi.unstubAllEnvs(); vi.unstubAllGlobals(); vi.useRealTimers();
});

describe("monthly Pacific completed calendar month", () => {
  it("rolls January back to December of the prior year with calendar month 12", () => {
    expect(getPreviousCompletedMonth(new Date("2027-01-12T21:00:00Z"))).toEqual({
      year: 2026, month: 12, monthName: "December", label: "December 2026",
      periodKey: "2026-12", sourceDate: "2026-12-01",
    });
  });
  it.each([
    ["2027-01-01T07:59:59Z", "2026-11"], ["2027-01-01T08:00:00Z", "2026-12"],
    ["2026-06-01T06:59:59Z", "2026-04"], ["2026-06-01T07:00:00Z", "2026-05"],
    ["2024-03-01T07:59:59Z", "2024-01"], ["2024-03-01T08:00:00Z", "2024-02"],
    ["2024-02-29T23:59:59Z", "2024-01"],
  ])("selects the completed month at %s as %s", (now, periodKey) => {
    expect(getPreviousCompletedMonth(new Date(now)).periodKey).toBe(periodKey);
  });
  it("has a deterministic injectable now and rejects an invalid date", () => {
    expect(getPreviousCompletedMonth()).toEqual(getPreviousCompletedMonth(NOW));
    expect(() => getPreviousCompletedMonth(new Date(NaN))).toThrow("valid current date");
  });
  it.each([[2026, 0], [2026, 13], [2026, 1.5], [2026.5, 10], [1999, 12], [2101, 1], [NaN, 1]])(
    "rejects invalid explicit inputs %s/%s", (year, month) => {
      expect(() => getCompletedMonthlyNetCashPeriod(year, month)).toThrow("integer year");
    },
  );
  it.each([[2026, 11], [2026, 12], [2027, 1]])("rejects current/future %s/%s", (year, month) => {
    expect(() => getCompletedMonthlyNetCashPeriod(year, month)).toThrow("previous completed month");
  });
  it("rejects a UTC-previous month that is still open in Pacific", () => {
    expect(() => getCompletedMonthlyNetCashPeriod(2026, 12, new Date("2027-01-01T07:59:59Z"))).toThrow("previous completed");
    expect(getCompletedMonthlyNetCashPeriod(2026, 12, new Date("2027-01-01T08:00:00Z")).periodKey).toBe("2026-12");
  });
});

describe("strict monthly FLOW parser", () => {
  it("preserves colspan label and spacer indexes and signed authoritative building cash", () => {
    expect(parseStrictMonthlyNetCashHtml(flowHtml(), 1)).toEqual({
      region: 1, regionName: "Region 1", total: 100,
      buildings: [{ name: "Alpha", value: 123.45 }, { name: "Beta", value: -23.45 }],
    });
  });
  it.each([1, 2, 3, 4])("parses stored, previously captured FLOW sample for region %i with real cells", region => {
    const raw = readFileSync(new URL(`../payments_region${region}.html`, import.meta.url), "utf8");
    const parsed = parseStrictMonthlyNetCashHtml(raw, region);
    expect(parsed.region).toBe(region); expect(parsed.buildings.length).toBeGreaterThan(0);
    expect(parsed.total).toBe(parsed.buildings.reduce((sum, building) => sum + building.value, 0));
    expect(parsed.buildings.every(building => Number.isFinite(building.value))).toBe(true);
  });
  it("accepts complete allzero tables, plain cash, accounting negatives and encoded HTML", () => {
    expect(parseStrictMonthlyNetCashHtml(JSON.stringify(flowHtml("0.00", "$0.00")), 4).total).toBe(0);
    expect(parseStrictMonthlyNetCashHtml(flowHtml("($1,234.56)", "$234.56"), 2).total).toBe(-1000);
  });
  it("uses the one strong cash value without shifting component amounts to other buildings", () => {
    const parsed = parseStrictMonthlyNetCashHtml(flowHtml("150.00<br>-26.55<br><strong>123.45</strong><br>"), 3);
    expect(parsed.buildings.map(building => building.value)).toEqual([123.45, -23.45]);
    expect(parsed.total).toBe(100);
  });
  it.each(["", "N/A", "NaN", "Infinity", "123junk", "1,23.45", "123.456", "--1", "0.00 pending"])(
    "rejects missing/invalid numeric text %j instead of replacing with zero", value => {
      expect(() => parseStrictMonthlyNetCashHtml(flowHtml(`<strong>${value}</strong>`), 1)).toThrow();
    },
  );
  it.each([
    flowHtml("<strong>100</strong><strong>123.45</strong>"),
    flowHtml("<strong>123.45</strong><br>not cash"),
    flowHtml().replace("<td></td>", "<td><strong>999</strong></td>"),
    flowHtml().replace("<td><strong>-23.45</strong></td><td></td>", ""),
    flowHtml().replace("<th>Beta</th>", "<th>Alpha</th>"),
    flowHtml().replace("<th>Beta</th>", "<th>Total</th>"),
    flowHtml().replace("<td><strong>123.45</strong></td>", '<td colspan="2"><strong>123.45</strong></td>'),
    flowHtml() + flowHtml(), "<html><title>ERROR</title></html>",
    flowHtml().replace(/<thead>[\s\S]*?<\/thead>/, ""),
  ])("rejects ambiguous, shifted or partial tables", html => {
    expect(() => parseStrictMonthlyNetCashHtml(html, 1)).toThrow();
  });
  it.each(["Marc's Net Cash", "Marc’s Net Cash", "Marc's Net Cash Flow"])("retains legacy label %s", label => {
    expect(parseStrictMonthlyNetCashHtml(flowHtml().replace("Net Cash Flow", label), 1).total).toBe(100);
  });
  it("leaves default fetch parser behavior intact while strict calls reject missing rows (offline HTTP stub)", async () => {
    mocks.undiciFetch.mockImplementation(async (url: string, options?: { method?: string }) => ({
      status: options?.method === "POST" ? 302 : 200,
      headers: { getSetCookie: () => ["CFID=offline; Path=/"], get: () => "/app/" },
      text: async () => "<html>Source table missing</html>",
    }));
    await expect(fetchMarcsNetCash(1, "2026-10-01")).resolves.toEqual({ region: 1, regionName: "Region 1", total: 0, buildings: [] });
    await expect(fetchMarcsNetCash(1, "2026-10-01", { strict: true })).rejects.toThrow("exactly one cash row");
  });
  it("passes strict and the selected date to all four region fetches (offline HTTP stub)", async () => {
    const actual = await vi.importActual<typeof import("./scraper")>("./scraper");
    const result = await actual.fetchAllRegionsMarcsNetCash("2026-10-01", { strict: true });
    expect(result.map(region => region.region)).toEqual([1, 2, 3, 4]);
    const urls = mocks.undiciFetch.mock.calls.map(([url]) => new URL(url)).filter(url => url.pathname === "/vacancy.cfc");
    expect(urls.map(url => url.searchParams.get("regionid")).sort()).toEqual(["1", "2", "3", "4"]);
    expect(urls.every(url => url.searchParams.get("dt") === "2026-10-01")).toBe(true);
  });
});

describe("fresh monthly net cash source", () => {
  it("forces the selected live strict pull on every invocation; never reads or writes historical cache", async () => {
    const period = getPreviousCompletedMonth();
    const first = await fetchFreshMonthlyNetCashReport(period);
    const second = await fetchFreshMonthlyNetCashReport(period);
    expect(mocks.source).toHaveBeenCalledTimes(2);
    expect(mocks.source).toHaveBeenNthCalledWith(1, "2026-10-01", { strict: true });
    expect(first).toEqual({ month: completeMonth(), sourceUpdatedAt: NOW });
    expect(second.month).toEqual(first.month);
  });
  it("preserves negative and zero values and accepts allzero complete four-region source", async () => {
    mocks.source.mockResolvedValue(completeRegions([0, 0, 0, 0]));
    expect((await fetchFreshMonthlyNetCashReport(getPreviousCompletedMonth())).month.grandTotal).toBe(0);
  });
  it("rejects source failures without cache fallback or fabricated data", async () => {
    mocks.source.mockRejectedValue(new Error("Source unavailable"));
    await expect(fetchFreshMonthlyNetCashReport(getPreviousCompletedMonth())).rejects.toThrow("Source unavailable");
  });
  it.each([
    [], completeRegions().slice(0, 3),
    [...completeRegions().slice(0, 3), { ...completeRegions()[3], region: 3 }],
    [...completeRegions().slice(0, 3), { ...completeRegions()[3], region: 5 }],
    completeRegions().map((region, index) => index === 2 ? { ...region, buildings: [] } : region),
    completeRegions().map((region, index) => index === 2 ? { ...region, total: NaN } : region),
    completeRegions().map((region, index) => index === 2 ? { ...region, buildings: [{ name: "Bad", value: Infinity }] } : region),
    completeRegions().map((region, index) => index === 2 ? { ...region, total: 1 } : region),
    completeRegions().map((region, index) => index === 2 ? { ...region, buildings: [{ name: "Bad", value: undefined }] } : region),
  ].map(regions => ({ regions })))("rejects empty, partial, duplicate, nonfinite and nonreconciling source", async ({ regions }) => {
    mocks.source.mockResolvedValue(regions);
    await expect(fetchFreshMonthlyNetCashReport(getPreviousCompletedMonth())).rejects.toThrow();
  });
  it("rejects forged metadata or present/future periods before a source call", async () => {
    const period = getPreviousCompletedMonth();
    await expect(fetchFreshMonthlyNetCashReport({ ...period, sourceDate: "2026-11-01" })).rejects.toThrow("metadata");
    await expect(fetchFreshMonthlyNetCashReport({ ...period, month: 11 })).rejects.toThrow("previous completed");
    expect(mocks.source).not.toHaveBeenCalled();
  });
  it("checks rendering-level grand totals and labels against the canonical completed period", () => {
    expect(() => assertCompleteMonthlyNetCashReport({ ...completeMonth(), grandTotal: 999 })).toThrow("grand total");
    expect(() => assertCompleteMonthlyNetCashReport({ ...completeMonth(), label: "November 2026" })).toThrow("metadata");
    expect(() => assertCompleteMonthlyNetCashReport({ ...completeMonth(), grandTotal: Infinity })).toThrow("nonfinite");
    expect(() => assertCompleteMonthlyNetCashReport(completeMonth())).not.toThrow();
  });
});

describe("monthly email rendering and manual safety", () => {
  it("matches the prechange monthly HTML SHA256 byte for byte, including financial math and dark style", () => {
    const html = buildMonthlyNetCashHtml(completeMonth());
    expect(createHash("sha256").update(html).digest("hex")).toBe("c34cd500eaadcdbcf40173e4f99012b77687ae132d1af2aba54aed90003eca88");
    expect(html).toContain("-$23.45"); expect(html).toContain("$112.34");
  });
  it("prepares only a fixed-identity, legacy-subject message with no send, transport, DB or source access", () => {
    const result = prepareMonthlyNetCashEmail(completeMonth(), RECIPIENTS);
    expect(Object.keys(result)).toEqual(["message"]);
    expect(result.message).toEqual({
      from: '"Apartment Corp Reports" <apartmentcorp44@gmail.com>', replyTo: "ethan@apartmentcorp.com",
      to: "ethan@apartmentcorp.com, mam@22.bz",
      subject: "💰 Marc's Net Cash Flow — October 2026 | Grand Total: $112.34",
      html: buildMonthlyNetCashHtml(completeMonth()),
    });
    expect(result.message).not.toHaveProperty("cc"); expect(result.message).not.toHaveProperty("bcc");
    expect(mocks.createTransport).not.toHaveBeenCalled(); expect(mocks.sendMail).not.toHaveBeenCalled();
    expect(mocks.monthlyRecipients).not.toHaveBeenCalled(); expect(mocks.source).not.toHaveBeenCalled();
    expect(mocks.undiciFetch).not.toHaveBeenCalled();
  });
  it.each([[], [""], ["bad"], ["ethan@apartmentcorp.com\r\nBcc: x@example.com"], ["ethan@apartmentcorp.com, mam@22.bz"], ["mam@22.bz", "MAM@22.bz"]].map(recipients => ({ recipients })))(
    "rejects invalid, injected, empty or duplicate To lists $recipients", ({ recipients }) => {
      expect(() => prepareMonthlyNetCashEmail(completeMonth(), recipients)).toThrow("recipient list");
      expect(mocks.sendMail).not.toHaveBeenCalled();
    },
  );
  it("rejects invalid/current/partial report data before transport creation", async () => {
    await expect(sendMonthlyNetCashEmail({ ...completeMonth(), month: 0 })).resolves.toBe(false);
    await expect(sendMonthlyNetCashEmail({ ...completeMonth(), month: 11 })).resolves.toBe(false);
    await expect(sendMonthlyNetCashEmail(completeMonth(completeRegions().slice(0, 3)))).resolves.toBe(false);
    expect(mocks.createTransport).not.toHaveBeenCalled(); expect(mocks.sendMail).not.toHaveBeenCalled();
  });
  it("does not fall back to Brandon or anyone else when the monthly DB recipient list is empty", async () => {
    mocks.monthlyRecipients.mockResolvedValue([]);
    await expect(sendMonthlyNetCashEmail(completeMonth())).resolves.toBe(false);
    expect(mocks.createTransport).not.toHaveBeenCalled(); expect(mocks.sendMail).not.toHaveBeenCalled();
  });
  it("keeps the optional single-recipient manual signature without broadening recipients", async () => {
    await expect(sendMonthlyNetCashEmail(completeMonth(), "ethan@apartmentcorp.com")).resolves.toBe(true);
    expect(mocks.sendMail).toHaveBeenCalledWith(prepareMonthlyNetCashEmail(completeMonth(), [RECIPIENTS[0]]).message);
    expect(mocks.monthlyRecipients).not.toHaveBeenCalled();
  });
  it("fails closed for an explicitly empty override rather than falling back to the DB list", async () => {
    await expect(sendMonthlyNetCashEmail(completeMonth(), "")).resolves.toBe(false);
    expect(mocks.monthlyRecipients).not.toHaveBeenCalled(); expect(mocks.sendMail).not.toHaveBeenCalled();
  });
  it("uses December of the prior year for the no-input January manual route", async () => {
    vi.setSystemTime(new Date("2027-01-12T21:00:00Z"));
    await expect(caller().vacancy.sendMonthlyEmail()).resolves.toEqual({ success: true });
    expect(mocks.source).toHaveBeenCalledWith("2026-12-01", { strict: true });
    expect(mocks.sendMail.mock.calls[0][0].subject).toContain("December 2026");
  });
  it.each([{ year: 2026, month: 0 }, { year: 2026, month: 13 }, { year: 2026, month: 10.5 }, { year: 2026.5, month: 10 }, { year: 1999, month: 10 }, { year: 2026, month: 11 }, { year: 2027, month: 1 }])(
    "rejects invalid manual inputs %j before a source fetch or send", async input => {
      await expect(caller().vacancy.sendMonthlyEmail(input)).rejects.toThrow();
      expect(mocks.source).not.toHaveBeenCalled(); expect(mocks.sendMail).not.toHaveBeenCalled();
    },
  );
  it("uses selected completed month and optional manual recipient unchanged", async () => {
    await expect(caller().vacancy.sendMonthlyEmail({ year: 2024, month: 2, recipient: RECIPIENTS[0] })).resolves.toEqual({ success: true });
    expect(mocks.source).toHaveBeenCalledWith("2024-02-01", { strict: true });
    expect(mocks.sendMail.mock.calls[0][0].to).toBe(RECIPIENTS[0]);
    expect(mocks.sendMail.mock.calls[0][0].subject).toContain("February 2024");
  });
  it("does not send a monthly manual email if any source region is partial", async () => {
    mocks.source.mockResolvedValue(completeRegions().slice(0, 3));
    await expect(caller().vacancy.sendMonthlyEmail({ year: 2026, month: 10 })).rejects.toThrow("four regions");
    expect(mocks.sendMail).not.toHaveBeenCalled();
  });
});
