import { describe, expect, it } from "vitest";
import { buildCurrentCollectionsHtml, buildDailyCollectionsHtml, dedupeDailyCollectionsBuildings, getDailyCollectionsUniqueTotal, getPriorDayCollectionComparisons } from "./emailService";
import type { CollectionsSnapshot } from "./scraper";

describe("Daily Collections Report", () => {
  const arborCrest = { buildingName: "Arbor Crest", regionId: 1, netRentCollected: 112_870.24 };
  const bocaCiega = { buildingName: "Boca Ciega", regionId: 1, netRentCollected: 193_458 };

  it("keeps each building only once when an upstream snapshot repeats a record", () => {
    const unique = dedupeDailyCollectionsBuildings([
      arborCrest,
      { ...arborCrest },
      bocaCiega,
      { ...bocaCiega, buildingName: "  boca ciega  " },
    ]);

    expect(unique).toEqual([arborCrest, bocaCiega]);
    expect(getDailyCollectionsUniqueTotal([arborCrest, { ...arborCrest }, bocaCiega])).toBe(306_328.24);
  });

  it("renders one row per building and calculates the portfolio total from unique records", () => {
    const html = buildDailyCollectionsHtml(
      {
        snapshotDate: "2026-08-14",
        buildings: [arborCrest, { ...arborCrest }, bocaCiega, { ...bocaCiega }],
        totalNetRentCollected: 612_656.48,
      },
      [
        { ...arborCrest, netRentCollected: 84_037.34 },
        { ...arborCrest, netRentCollected: 84_037.34 },
        { ...bocaCiega, netRentCollected: 193_458 },
      ]
    );

    expect(html.match(/>Arbor Crest<\/td>/g)).toHaveLength(1);
    expect(html.match(/>Boca Ciega<\/td>/g)).toHaveLength(1);
    expect(html).toContain("$306,328.24");
    expect(html).not.toContain("$612,656.48");
  });

  it("renders expected rent, collected, variance, and tolerance status from fresh FLOW data", () => {
    const snapshot: CollectionsSnapshot = {
      snapshotDate: "2026-08-14",
      buildings: [
        { buildingName: "Arbor Crest", regionId: 1, regionName: "Region 1", rentBilled: 100_000, rentCollected: 80_000, utilityReimbursement: 0, vouchersCount: 4, collectionPct: 80 },
        { buildingName: "Boca Ciega", regionId: 1, regionName: "Region 1", rentBilled: 50_000, rentCollected: 50_000, utilityReimbursement: 0, vouchersCount: 0, collectionPct: 100 },
      ],
      totalRentBilled: 150_000,
      totalRentCollected: 130_000,
      overallCollectionPct: 86.7,
    };
    const html = buildCurrentCollectionsHtml(snapshot, [
      { buildingName: "Arbor Crest", regionId: 1, rentBilled: 100_000, rentCollected: 80_000, utilityReimbursement: 0, vouchersCount: 4, collectionPct: 80, snapshotDate: "2026-08-14", rentCollectedChangePct: 10, prevRentCollected: 72_727.27, prevSnapshotDate: "2026-08-13" },
      { buildingName: "Boca Ciega", regionId: 1, rentBilled: 50_000, rentCollected: 50_000, utilityReimbursement: 0, vouchersCount: 0, collectionPct: 100, snapshotDate: "2026-08-14", rentCollectedChangePct: 0, prevRentCollected: 50_000, prevSnapshotDate: "2026-08-13" },
    ]);

    expect(html).toContain("Live PropertyMax FLOW Collections snapshot");
    expect(html).toContain("$150,000.00");
    expect(html).toContain("$130,000.00");
    expect(html).toContain("-$20,000.00");
    expect(html).toContain("86.7%");
    expect(html).toContain("Expected Rent");
    expect(html).toContain("Variance");
    expect(html).toContain("🚨 -$20,000.00");
    expect(html).toContain("👌🏼 $0.00");
    expect(html).toContain("Variance tolerance: ±$7,500.00");
    expect(html).not.toContain("Net Rent Collected");
    expect(html).toContain("Sourced exclusively from the PropertyMax FLOW Collections snapshot");
    expect(html).toContain('href="https://vacancyreport.manus.space?tab=collections"');
    for (const accent of ["#1e73be", "#198754", "#c63c4a", "#7851a9"]) {
      expect(html).toContain(`border-top:4px solid ${accent}`);
    }
    expect(html).toContain("background:#fff7f7");
  });

  it("labels a material over-collection as positive variance", () => {
    const snapshot: CollectionsSnapshot = {
      snapshotDate: "2026-08-14",
      buildings: [
        { buildingName: "Arbor Crest", regionId: 1, regionName: "Region 1", rentBilled: 100_000, rentCollected: 110_000, utilityReimbursement: 0, vouchersCount: 0, collectionPct: 110 },
      ],
      totalRentBilled: 100_000,
      totalRentCollected: 110_000,
      overallCollectionPct: 110,
    };
    const html = buildCurrentCollectionsHtml(snapshot, []);

    expect(html).toContain("👌🏼 +$10,000.00");
    expect(html).not.toContain("-$10,000.00");
  });

  it("only presents a comparison as prior day when the snapshot is truly from the day before", () => {
    const base = {
      buildingName: "Arbor Crest", regionId: 1, rentBilled: 100_000, rentCollected: 80_000,
      utilityReimbursement: 0, vouchersCount: 0, collectionPct: 80, snapshotDate: "2026-08-14",
    };
    const [daily, historical] = getPriorDayCollectionComparisons("2026-08-14", [
      { ...base, rentCollectedChangePct: 8, prevRentCollected: 74_000, prevSnapshotDate: "2026-08-13" },
      { ...base, buildingName: "Boca Ciega", rentCollectedChangePct: 20, prevRentCollected: 66_667, prevSnapshotDate: "2026-08-05" },
    ]);

    expect(daily.rentCollectedChangePct).toBe(8);
    expect(historical.rentCollectedChangePct).toBeNull();
    expect(historical.prevSnapshotDate).toBeNull();
  });
});
