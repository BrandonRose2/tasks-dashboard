import type { Request, Response } from "express";

/**
 * Keeps SPA fallback HTML out of API clients during Vite/HMR transitions or a
 * malformed API route. This response deliberately follows the tRPC error JSON
 * envelope so tRPC clients can surface a normal query error.
 */
export function sendApiJsonNotFound(req: Request, res: Response): void {
  res.status(404).json({
    error: {
      json: {
        message: "API route not found. Please retry the dashboard request.",
        code: -32004,
        data: {
          code: "NOT_FOUND",
          httpStatus: 404,
          path: req.originalUrl,
        },
      },
    },
  });
}
