import { readFileSync } from "node:fs";
import * as cheerio from "cheerio";
import { afterAll, beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  getDb: vi.fn(async () => null),
  sourceFetch: vi.fn(async () => { throw new Error("Source requests are forbidden in parser tests"); }),
  mailTransport: vi.fn(() => { throw new Error("Email sending is forbidden in parser tests"); }),
}));
vi.mock("./db", () => ({
  getDb: mocks.getDb,
  getUnitOverridesMap: vi.fn(async () => ({})),
  getDailyVacancyRecipients: vi.fn(),
  getMonthlyNetCashRecipients: vi.fn(),
  getPaymentsForDateDb: vi.fn(),
  getPaymentsDates: vi.fn(),
  getCollectionsLookup: vi.fn(),
}));
vi.mock("undici", async importOriginal => ({
  ...await importOriginal<typeof import("undici")>(),
  fetch: mocks.sourceFetch,
}));
vi.mock("./gmailReportTransport", () => ({
  GMAIL_REPORT_SENDER: "unused@example.invalid",
  createGmailReportTransport: mocks.mailTransport,
}));

import { buildDailyVacancyHtml } from "./emailService";
import { invalidateCache, parseAndIngestRawData, parseSummaryHtml } from "./scraper";

// These are synthetic fixtures, not copies of private PropertyMax captures.
const unleasedHeaders = ["Date/By", "Building", "Unit", "%Rdy", "MovOut", "Alrt", "Days", "Beds", "$Ask"];
const preleasedHeaders = ["Date/By", "Building", "Unit", "%Rdy", "MovOut", "Alrt", "Days", "MovIn", "Beds", "$Ask"];
const values: Record<string, string> = {
  "Date/By": "11/4/26\n  Reviewer",
  Building: "<a>Example Property</a>",
  Unit: "A-101",
  "%Rdy": "50%",
  MovOut: "10/5/26",
  Alrt: "Ops Call Mgr",
  Days: "30",
  MovIn: "11/13/26",
  Beds: "3",
  "$Ask": "$1,272.00",
};
const expectedUnleased = {
  dateBy: "11/4/26 Reviewer",
  building: "Example Property",
  unit: "A-101",
  percentReady: 50,
  moveOut: "10/5/26",
  alertDays: "Ops Call Mgr",
  days: 30,
  beds: 3,
  askRent: 1272,
};
const emptySummary = { vacantUnleased: [], vacantPreleased: [], onNotice: [], evictions: [] };
function row(cells: string[]): string {
  return `<tr>${cells.map(cell => `<td>${cell}</td>`).join("")}</tr>`;
}
function table(headers: string[], cells: string[], extraRows = ""): string {
  return `<table><thead><tr>${headers.map(header => `<th>${header}</th>`).join("")}</tr></thead><tbody>${row(cells)}${extraRows}</tbody></table>`;
}
function vacancyTable(headers = unleasedHeaders, overrides: Record<string, string> = {}, extraRows = ""): string {
  return table(headers, headers.map(header => ({ ...values, ...overrides })[header] ?? ""), extraRows);
}
const onNoticeTable = table(["Building", "Unit", "Leased"], ["Example Notice", "N-1", "No"]);
const datesHtml = `<table><thead>
  <tr><td>Served</td><td>10/1/26</td></tr>
  <tr><td>Court</td><td>11/2/26</td></tr>
  <tr><td>Possession</td><td></td></tr>
</thead></table>`;
const evictionTable = table(["Building", "Unit", "Dates", "$Owed"], ["Example Eviction", "E-1", datesHtml, "$2,345.67"]);

beforeEach(() => {
  vi.clearAllMocks();
  invalidateCache();
  vi.stubGlobal("fetch", mocks.sourceFetch);
});
afterAll(() => vi.unstubAllGlobals());

describe("PropertyMax summary header mapping", () => {
  it("parses current unleased order with readiness before move-out, not last", () => {
    expect(parseSummaryHtml(vacancyTable())).toEqual({ ...emptySummary, vacantUnleased: [expectedUnleased] });
  });

  it("parses current preleased order without mistaking Days for Move In or Beds for rent", () => {
    expect(parseSummaryHtml(vacancyTable(preleasedHeaders))).toEqual({
      ...emptySummary,
      vacantPreleased: [{ ...expectedUnleased, moveIn: "11/13/26" }],
    });
  });

  it.each([false, true])("preserves legacy readiness-last order (preleased=%s)", preleased => {
    const headers = ["Date/By", "Building", "Unit", "MovOut", "Alrt", "Days", ...(preleased ? ["MovIn"] : []), "Beds", "$Ask", "%Rdy"];
    const summary = parseSummaryHtml(vacancyTable(headers));
    expect(preleased ? summary.vacantPreleased : summary.vacantUnleased).toEqual([
      preleased ? { ...expectedUnleased, moveIn: "11/13/26" } : expectedUnleased,
    ]);
  });

  it.each([false, true])("maps reordered columns while retaining blank and action columns (preleased=%s)", preleased => {
    const headers = ["Actions", "$Ask", "", "Beds", "Building", ...(preleased ? ["MovIn"] : []), "%Rdy", "Unit", "Days", "Date/By", "Alrt", "MovOut"];
    const summary = parseSummaryHtml(vacancyTable(headers, { Actions: "Edit" }));
    expect(preleased ? summary.vacantPreleased : summary.vacantUnleased).toEqual([
      preleased ? { ...expectedUnleased, moveIn: "11/13/26" } : expectedUnleased,
    ]);
  });

  it("retains a colspanned blank header's physical column indices", () => {
    const html = vacancyTable(["", "", ...unleasedHeaders]).replace("<th></th><th></th>", '<th colspan="2"></th>');
    expect(parseSummaryHtml(html).vacantUnleased).toEqual([expectedUnleased]);
  });

  it("normalizes full labels, mixed case, whitespace and punctuation", () => {
    const fullHeaders = [" Date / By ", " BUILDING ", "Unit", "% Ready", "Move Out", "Alert Days", "Days", "Move In", "Bedrooms", "Asking Rent"];
    expect(parseSummaryHtml(table(fullHeaders, preleasedHeaders.map(header => values[header]))).vacantPreleased).toEqual([
      { ...expectedUnleased, moveIn: "11/13/26" },
    ]);
    const moreFullHeaders = ["Date/By", "Building", "Unit", "Percent Ready", "Move-Out", "Alert", "Days", "Beds", "Ask Rent"];
    expect(parseSummaryHtml(table(moreFullHeaders, unleasedHeaders.map(header => values[header]))).vacantUnleased).toEqual([expectedUnleased]);
  });

  it.each([false, true])("preserves empty cells and existing numeric-zero defaults (preleased=%s)", preleased => {
    const summary = parseSummaryHtml(vacancyTable(preleased ? preleasedHeaders : unleasedHeaders, {
      MovOut: "", Alrt: "", Days: "", MovIn: "", Beds: "", "$Ask": "", "%Rdy": "",
    }));
    const expected = { ...expectedUnleased, moveOut: "", alertDays: "", days: 0, beds: 0, askRent: 0, percentReady: 0 };
    expect(preleased ? summary.vacantPreleased : summary.vacantUnleased).toEqual([
      preleased ? { ...expected, moveIn: "" } : expected,
    ]);
  });

  it("preserves zero percent readiness instead of using another column", () => {
    expect(parseSummaryHtml(vacancyTable(unleasedHeaders, { "%Rdy": "0%" })).vacantUnleased[0]).toEqual({
      ...expectedUnleased, percentReady: 0,
    });
  });

  it.each(["1272.00", "1,272.00", "$1,272.00", " $ 1,272.00 "])("parses asking currency %s without reading Beds", rent => {
    expect(parseSummaryHtml(vacancyTable(unleasedHeaders, { "$Ask": rent })).vacantUnleased[0].askRent).toBe(1272);
  });

  it("excludes nested tables even when their headers resemble unit-data tables", () => {
    const nestedFakeUnits = vacancyTable(unleasedHeaders, { Building: "Nested fake building" });
    const noteRows = `<tr><td colspan="9">${nestedFakeUnits}</td></tr>`;
    expect(parseSummaryHtml(vacancyTable(unleasedHeaders, {}, noteRows)).vacantUnleased).toEqual([expectedUnleased]);
  });

  it("does not inherit nested headers or classify standalone note tables", () => {
    const note = table(["Date", "By", "Notes", "Leased", "$Owed"], ["11/4/26", "Reviewer", "Synthetic note", "No", "$10"]);
    const nested = `<table><tbody><tr><td>${vacancyTable()}</td></tr></tbody></table>`;
    expect(parseSummaryHtml(note + nested)).toEqual(emptySummary);
  });

  it("excludes note-only colspanned rows, including rows with enough td elements", () => {
    const misleadingRow = `<tr><td colspan="2">Synthetic note</td>${Array(8).fill("<td>999</td>").join("")}</tr>`;
    const shortRow = `<tr><td colspan="9">Another synthetic note</td></tr>`;
    expect(parseSummaryHtml(vacancyTable(unleasedHeaders, {}, misleadingRow + shortRow)).vacantUnleased).toEqual([expectedUnleased]);
  });

  it("excludes nested note text from scalar unit fields", () => {
    const note = table(["Date", "By", "Notes"], ["11/4/26", "Reviewer", "Synthetic note"]);
    expect(parseSummaryHtml(vacancyTable(unleasedHeaders, {
      "Date/By": values["Date/By"] + note, Building: values.Building + note, "$Ask": values["$Ask"] + note,
    })).vacantUnleased).toEqual([expectedUnleased]);
  });

  it.each(["Date/By", "Building", "Unit", "%Rdy", "MovOut", "Alrt", "Days", "Beds", "$Ask"])(
    "fails safely when a recognized unit table lacks the %s header", missing => {
      expect(() => parseSummaryHtml(vacancyTable(unleasedHeaders.map(header => header === missing ? "Unknown" : header))))
        .toThrow(/PropertyMax vacantUnleased summary has missing headers/);
    },
  );

  it("fails safely on duplicate recognized headers", () => {
    expect(() => parseSummaryHtml(vacancyTable([...unleasedHeaders, "$Ask"]))).toThrow(/ambiguous headers/);
  });

  it("preserves on-notice building, unit and leased strings", () => {
    const note = `<tr><td colspan="3">Synthetic note</td></tr>`;
    expect(parseSummaryHtml(onNoticeTable.replace("</tbody>", `${note}</tbody>`)).onNotice).toEqual([
      { building: "Example Notice", unit: "N-1", leased: "No" },
    ]);
    expect(parseSummaryHtml(table(["Leased", "", "Unit", "Building"], ["Yes", "", "N-2", "Another Notice"])).onNotice).toEqual([
      { building: "Another Notice", unit: "N-2", leased: "Yes" },
    ]);
  });

  it("preserves flattened nested eviction dates and currency parsing", () => {
    expect(parseSummaryHtml(evictionTable).evictions).toEqual([
      { building: "Example Eviction", unit: "E-1", dates: "Served10/1/26 Court11/2/26 Possession", amountOwed: 2345.67 },
    ]);
    expect(parseSummaryHtml(table(["Amount Owed", "Dates", "Unit", "Building"], ["$2,345.67", datesHtml, "E-1", "Example Eviction"])).evictions)
      .toEqual(parseSummaryHtml(evictionTable).evictions);
  });

  it.each([
    table(["Building", "Leased"], ["Example Notice", "No"]),
    table(["Building", "Unit", "$Owed"], ["Example Eviction", "E-1", "$100"]),
  ])("fails safely on incomplete on-notice or eviction headers", html => {
    expect(() => parseSummaryHtml(html)).toThrow(/missing headers/);
  });

  it("decodes JSON-encoded ColdFusion HTML strings", () => {
    const html = vacancyTable() + vacancyTable(preleasedHeaders) + onNoticeTable + evictionTable;
    expect(parseSummaryHtml(`\n ${JSON.stringify(html)} \n`)).toEqual(parseSummaryHtml(html));
  });

  it("uses one exported parser in both fetch and ingestion paths", () => {
    const source = readFileSync(new URL("./scraper.ts", import.meta.url), "utf8");
    expect(source.match(/function parseSummaryHtml\(/g)).toHaveLength(1);
    expect(source).toMatch(/export async function fetchSummaryData[\s\S]*?return parseSummaryHtml\(raw\);/);
    for (const region of [1, 2, 3, 4]) expect(source).toContain(`parseSummaryHtml(payload.summary${region})`);
  });

  it("ingests all four region summaries through the shared parser with mocked DB and no source calls", async () => {
    const summaries = [vacancyTable(), JSON.stringify(vacancyTable(preleasedHeaders)), onNoticeTable, evictionTable];
    const dashboard = await parseAndIngestRawData({
      orangebxupd: [2, 1, 1, 1, 1].map(value => `<div class="panel"><h4>${value}</h4></div>`).join(""),
      summary1: summaries[0], summary2: summaries[1], summary3: summaries[2], summary4: summaries[3],
    });
    for (const key of Object.keys(emptySummary) as (keyof typeof emptySummary)[]) {
      expect(dashboard[key]).toEqual(summaries.flatMap<unknown>(summary => parseSummaryHtml(summary)[key]));
    }
    expect(dashboard.vacantUnleased).toEqual([expectedUnleased]);
    expect(dashboard.vacantPreleased).toEqual([{ ...expectedUnleased, moveIn: "11/13/26" }]);
    expect(mocks.getDb).toHaveBeenCalledTimes(2);
    expect(mocks.sourceFetch).not.toHaveBeenCalled();
    expect(mocks.mailTransport).not.toHaveBeenCalled();
  });

  it("does not persist an ingestion snapshot when a recognized summary is malformed", async () => {
    await expect(parseAndIngestRawData({
      orangebxupd: "", summary1: vacancyTable(unleasedHeaders.filter(header => header !== "$Ask")),
      summary2: "", summary3: "", summary4: "",
    })).rejects.toThrow(/missing headers: askRent/);
    expect(mocks.getDb).not.toHaveBeenCalled();
    expect(mocks.sourceFetch).not.toHaveBeenCalled();
  });

  it("renders corrected move-out date, asking rent and readiness in their existing email cells without sending", () => {
    const summary = parseSummaryHtml(vacancyTable() + vacancyTable(preleasedHeaders));
    const html = buildDailyVacancyHtml({
      ...summary,
      stats: { totalVacant: 2, vacUnleased: 1, vacPreleased: 1, onNotice: 0, eviction: 0 },
      buildingVacancy: [], dailyChanges: [], historicalMonths: [], lastUpdated: new Date("2026-11-04T12:00:00Z"),
    });
    const $ = cheerio.load(html);
    const unitRows = $("tr").filter((_, tr) => {
      const cells = $(tr).children("td");
      return cells.eq(0).text().trim() === "Example Property" && cells.eq(1).text().trim() === "A-101";
    });
    expect(unitRows).toHaveLength(2);
    expect(unitRows.first().children("td").map((_, td) => $(td).text().trim()).get()).toEqual([
      "Example Property", "A-101", "10/5/26", "30", "$1,272.00", "50%",
    ]);
    expect(unitRows.last().children("td").map((_, td) => $(td).text().trim()).get()).toEqual([
      "Example Property", "A-101", "10/5/26", "11/13/26", "30", "$1,272.00",
    ]);
    expect(mocks.mailTransport).not.toHaveBeenCalled();
    expect(mocks.sourceFetch).not.toHaveBeenCalled();
  });
});
