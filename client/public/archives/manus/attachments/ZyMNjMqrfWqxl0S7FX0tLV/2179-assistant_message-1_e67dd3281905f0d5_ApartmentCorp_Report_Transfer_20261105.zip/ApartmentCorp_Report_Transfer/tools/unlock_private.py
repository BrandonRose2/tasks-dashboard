"""Optional technician utility. Windows users can instead use an AES-capable ZIP app.
Requires pyzipper. No network calls, emails, schedule changes, or database writes.
The key file must be delivered separately from the transfer ZIP.
"""
from pathlib import Path, PurePosixPath
import argparse, re
import pyzipper

parser = argparse.ArgumentParser(description='Decrypt the private report archive to a NEW local folder.')
parser.add_argument('--key-file', required=True, type=Path)
parser.add_argument('--destination', required=True, type=Path)
args = parser.parse_args()
archive = Path(__file__).resolve().parent.parent / 'PRIVATE_DATA_AND_CREDENTIALS.zip'
key_text = args.key_file.read_text()
match = re.search(r'^Unlock key: (\S+)$', key_text, re.MULTILINE)
if not match:
    raise SystemExit('Unlock key not found; no extraction performed.')
if args.destination.exists():
    raise SystemExit('Destination must be a new, nonexistent folder; no overwrite allowed.')
with pyzipper.AESZipFile(archive) as z:
    z.setpassword(match.group(1).encode())
    names = z.namelist()
    for name in names:
        path = PurePosixPath(name)
        if path.is_absolute() or '..' in path.parts or '\\' in name:
            raise SystemExit('Unsafe archive path; extraction refused.')
    # Verify every entry before creating the extraction directory.
    decoded = {name: z.read(name) for name in names if not name.endswith('/')}
    args.destination.mkdir(parents=True, mode=0o700)
    for name, data in decoded.items():
        dest = args.destination / name
        dest.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        dest.write_bytes(data)
        dest.chmod(0o600)
print('Private archive extracted. Keep the destination private; no credential values were printed.')
