import type {
  BuildingCollectionData,
  BuildingVacancy,
  CollectionsSnapshot,
  DailyChange,
  DashboardData,
  VacancyStats,
} from "./scraper";

export const RAILWAY_REPORT_BASE_URL = "https://aptcorp-vacancy-report.up.railway.app";
const RAILWAY_TRPC_BASE_URL = `${RAILWAY_REPORT_BASE_URL}/api/trpc`;

type RailwayTrpcEnvelope<T> = {
  result?: {
    data?: {
      json?: T;
    };
  };
  error?: unknown;
};

type RailwayVacancyPayload = {
  stats: VacancyStats;
  vacantUnleased?: DashboardData["vacantUnleased"];
  vacantPreleased?: DashboardData["vacantPreleased"];
  onNotice?: DashboardData["onNotice"];
  evictions?: DashboardData["evictions"];
  buildingVacancy: BuildingVacancy[];
  dailyChanges?: DailyChange[];
  lastUpdated: string | Date;
};

function asFiniteNumber(value: unknown, label: string): number {
  const parsed = typeof value === "number" ? value : Number(value);
  if (!Number.isFinite(parsed)) throw new Error(`Railway ${label} is not a finite number`);
  return parsed;
}

function withinCent(left: number, right: number): boolean {
  return Math.abs(left - right) < 0.01;
}

async function fetchRailwayProcedure<T>(procedure: string, input: unknown): Promise<T> {
  const encodedInput = encodeURIComponent(JSON.stringify({ json: input }));
  const url = `${RAILWAY_TRPC_BASE_URL}/${procedure}?input=${encodedInput}`;
  const response = await fetch(url, {
    headers: { Accept: "application/json" },
    cache: "no-store",
  });

  if (!response.ok) {
    throw new Error(`Railway ${procedure} request failed with HTTP ${response.status}`);
  }

  const envelope = await response.json() as RailwayTrpcEnvelope<T>;
  const payload = envelope.result?.data?.json;
  if (!payload || envelope.error) {
    throw new Error(`Railway ${procedure} returned no usable snapshot`);
  }
  return payload;
}

/**
 * The Railway Vacancy dashboard is the authoritative source for the Daily
 * Vacancy email. The API's building totals must reconcile to the headline
 * total before it can be rendered or delivered.
 */
export async function fetchRailwayVacancySnapshot(): Promise<DashboardData> {
  const payload = await fetchRailwayProcedure<RailwayVacancyPayload>(
    "vacancy.getDashboard",
    { forceRefresh: false },
  );

  const stats: VacancyStats = {
    totalVacant: asFiniteNumber(payload.stats?.totalVacant, "vacancy total"),
    vacUnleased: asFiniteNumber(payload.stats?.vacUnleased, "unleased total"),
    vacPreleased: asFiniteNumber(payload.stats?.vacPreleased, "preleased total"),
    onNotice: asFiniteNumber(payload.stats?.onNotice, "on-notice total"),
    eviction: asFiniteNumber(payload.stats?.eviction, "eviction total"),
  };
  const buildingVacancy = Array.isArray(payload.buildingVacancy) ? payload.buildingVacancy : [];
  if (buildingVacancy.length === 0) throw new Error("Railway vacancy snapshot has no building rows");

  const buildingTotal = buildingVacancy.reduce((sum, building) => sum + asFiniteNumber(building.totalVacant, `${building.name} vacant total`), 0);
  if (buildingTotal !== stats.totalVacant) {
    throw new Error(`Railway vacancy snapshot does not reconcile: headline ${stats.totalVacant}, buildings ${buildingTotal}`);
  }
  if (stats.vacUnleased + stats.vacPreleased !== stats.totalVacant) {
    throw new Error("Railway vacancy headline totals do not reconcile to unleased plus preleased");
  }

  const lastUpdated = new Date(payload.lastUpdated);
  if (Number.isNaN(lastUpdated.getTime())) throw new Error("Railway vacancy snapshot has an invalid source timestamp");

  return {
    stats,
    buildingVacancy,
    dailyChanges: Array.isArray(payload.dailyChanges) ? payload.dailyChanges : [],
    vacantUnleased: Array.isArray(payload.vacantUnleased) ? payload.vacantUnleased : [],
    vacantPreleased: Array.isArray(payload.vacantPreleased) ? payload.vacantPreleased : [],
    onNotice: Array.isArray(payload.onNotice) ? payload.onNotice : [],
    evictions: Array.isArray(payload.evictions) ? payload.evictions : [],
    historicalMonths: [],
    lastUpdated,
    sourceStatus: {
      state: "live",
      message: "Authoritative Railway Vacancy dashboard snapshot",
    },
  };
}

/**
 * The Railway Collections tab is the authoritative source for the Daily
 * Collections email. Totals are checked against its individual building rows.
 */
export async function fetchRailwayCollectionsSnapshot(): Promise<CollectionsSnapshot> {
  const payload = await fetchRailwayProcedure<CollectionsSnapshot>("collections.getSnapshot", null);
  const buildings = Array.isArray(payload.buildings) ? payload.buildings as BuildingCollectionData[] : [];
  if (buildings.length === 0) throw new Error("Railway collections snapshot has no building rows");
  if (!/^\d{4}-\d{2}-\d{2}$/.test(payload.snapshotDate)) throw new Error("Railway collections snapshot has an invalid date");

  const totalRentBilled = asFiniteNumber(payload.totalRentBilled, "collections billed total");
  const totalRentCollected = asFiniteNumber(payload.totalRentCollected, "collections collected total");
  const calculatedBilled = buildings.reduce((sum, building) => sum + asFiniteNumber(building.rentBilled, `${building.buildingName} billed`), 0);
  const calculatedCollected = buildings.reduce((sum, building) => sum + asFiniteNumber(building.rentCollected, `${building.buildingName} collected`), 0);
  const calculatedRate = totalRentBilled > 0 ? (totalRentCollected / totalRentBilled) * 100 : 0;

  if (!withinCent(calculatedBilled, totalRentBilled) || !withinCent(calculatedCollected, totalRentCollected)) {
    throw new Error("Railway collections snapshot does not reconcile to building totals");
  }
  if (Math.abs(calculatedRate - asFiniteNumber(payload.overallCollectionPct, "collections rate")) > 0.11) {
    throw new Error("Railway collections snapshot rate does not reconcile to its totals");
  }

  return {
    snapshotDate: payload.snapshotDate,
    buildings,
    totalRentBilled,
    totalRentCollected,
    overallCollectionPct: Math.round(calculatedRate * 10) / 10,
  };
}
