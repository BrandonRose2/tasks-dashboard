import { eq, desc, lte, and, like, or, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, emailRecipients, type InsertEmailRecipient, buildingUnitOverrides, buildingPayments, buildingCollections, microsoftMailConnections } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ─── Email Recipient Helpers ─────────────────────────────────────────────────

export async function getAllRecipients() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(emailRecipients).orderBy(emailRecipients.createdAt);
}

export async function getDailyVacancyRecipients(scheduleGroup?: "early" | "admin") {
  const db = await getDb();
  if (!db) return [];
  const rows = await db.select().from(emailRecipients);
  return rows.filter(r => {
    if (r.receiveDailyVacancy !== 1 || r.isActive !== 1) return false;
    if (scheduleGroup) return r.scheduleGroup === scheduleGroup;
    return true;
  }).map(r => r.email);
}

export async function getMonthlyNetCashRecipients() {
  const db = await getDb();
  if (!db) return [];
  const rows = await db.select().from(emailRecipients);
  return rows.filter(r => r.receiveMonthlyNetCash === 1 && r.isActive === 1).map(r => r.email);
}

export async function addRecipient(data: { email: string; name?: string; receiveDailyVacancy?: boolean; receiveMonthlyNetCash?: boolean; scheduleGroup?: "early" | "admin" }) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const values: InsertEmailRecipient = {
    email: data.email,
    name: data.name || null,
    receiveDailyVacancy: data.receiveDailyVacancy !== false ? 1 : 0,
    receiveMonthlyNetCash: data.receiveMonthlyNetCash ? 1 : 0,
    scheduleGroup: data.scheduleGroup || "early",
    isActive: 1,
  };
  await db.insert(emailRecipients).values(values);
}

export async function updateRecipient(id: number, data: { name?: string; receiveDailyVacancy?: boolean; receiveMonthlyNetCash?: boolean; isActive?: boolean; scheduleGroup?: "early" | "admin" }) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const updateSet: Record<string, unknown> = {};
  if (data.name !== undefined) updateSet.name = data.name;
  if (data.receiveDailyVacancy !== undefined) updateSet.receiveDailyVacancy = data.receiveDailyVacancy ? 1 : 0;
  if (data.receiveMonthlyNetCash !== undefined) updateSet.receiveMonthlyNetCash = data.receiveMonthlyNetCash ? 1 : 0;
  if (data.isActive !== undefined) updateSet.isActive = data.isActive ? 1 : 0;
  if (data.scheduleGroup !== undefined) updateSet.scheduleGroup = data.scheduleGroup;
  if (Object.keys(updateSet).length === 0) return;
  await db.update(emailRecipients).set(updateSet).where(eq(emailRecipients.id, id));
}

export async function deleteRecipient(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(emailRecipients).where(eq(emailRecipients.id, id));
}

// ─── Delegated Microsoft Mail Connection ─────────────────────────────────────

export async function getMicrosoftMailConnection(accountEmail: string) {
  const db = await getDb();
  if (!db) return undefined;
  const normalizedEmail = accountEmail.trim().toLowerCase();
  const rows = await db.select()
    .from(microsoftMailConnections)
    .where(eq(microsoftMailConnections.accountEmail, normalizedEmail))
    .limit(1);
  return rows[0];
}

export async function upsertMicrosoftMailConnection(input: {
  accountEmail: string;
  refreshTokenCiphertext: string;
  refreshTokenExpiresAt?: Date | null;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const accountEmail = input.accountEmail.trim().toLowerCase();
  await db.insert(microsoftMailConnections).values({
    accountEmail,
    refreshTokenCiphertext: input.refreshTokenCiphertext,
    refreshTokenExpiresAt: input.refreshTokenExpiresAt ?? null,
  }).onDuplicateKeyUpdate({
    set: {
      refreshTokenCiphertext: input.refreshTokenCiphertext,
      refreshTokenExpiresAt: input.refreshTokenExpiresAt ?? null,
      updatedAt: new Date(),
    },
  });
}

// ─── Building Unit Override Helpers ─────────────────────────────────────────

export async function getAllUnitOverrides() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(buildingUnitOverrides).orderBy(buildingUnitOverrides.buildingName);
}

export async function getUnitOverridesMap(): Promise<Record<string, number>> {
  const rows = await getAllUnitOverrides();
  const map: Record<string, number> = {};
  for (const row of rows) {
    map[row.buildingName] = row.totalUnits;
  }
  return map;
}

export async function upsertUnitOverride(buildingName: string, totalUnits: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(buildingUnitOverrides)
    .values({ buildingName, totalUnits })
    .onDuplicateKeyUpdate({ set: { totalUnits } });
}

export async function deleteUnitOverride(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(buildingUnitOverrides).where(eq(buildingUnitOverrides.id, id));
}

// ─── Building Payments Helpers ─────────────────────────────────────────

export async function getPaymentsForDateDb(date: string) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(buildingPayments).where(eq(buildingPayments.snapshotDate, date));
}

export async function getLatestPaymentsDate(): Promise<string | null> {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select({ snapshotDate: buildingPayments.snapshotDate })
    .from(buildingPayments)
    .orderBy(desc(buildingPayments.snapshotDate))
    .limit(1);
  return rows.length > 0 ? rows[0].snapshotDate : null;
}

export async function getPaymentsDates(): Promise<string[]> {
  const db = await getDb();
  if (!db) return [];
  // Get distinct snapshot dates, most recent first
  const rows = await db.select({ snapshotDate: buildingPayments.snapshotDate })
    .from(buildingPayments)
    .orderBy(desc(buildingPayments.snapshotDate));
  const seen = new Set<string>();
  const dates: string[] = [];
  for (const r of rows) {
    if (!seen.has(r.snapshotDate)) { seen.add(r.snapshotDate); dates.push(r.snapshotDate); }
  }
  return dates;
}

// ─── Timestamp-based Collections Lookup ──────────────────────────────────────

export interface CollectionsAtTimestampResult {
  buildingName: string;
  regionId: number;
  netRentCollected: number;
  netCashFlow: number;
  snapshotDate: string;
  createdAt: Date;
  /** % change vs the snapshot immediately before this one for the same building */
  rentChangePct: number | null;
  prevNetRentCollected: number | null;
  prevSnapshotDate: string | null;
}

/**
 * Given an exact datetime string (e.g. "2026-08-03 23:50:01") and a building
 * query (partial name or building ID), returns the snapshot row(s) whose
 * createdAt is <= the requested timestamp, plus the % change vs the prior snapshot.
 */
export async function getCollectionsAtTimestamp(
  timestampStr: string,
  buildingQuery: string
): Promise<CollectionsAtTimestampResult[]> {
  const db = await getDb();
  if (!db) return [];

  // Find all rows for matching buildings at or before the requested timestamp
  const rows = await db
    .select()
    .from(buildingPayments)
    .where(
      and(
        lte(buildingPayments.createdAt, new Date(timestampStr)),
        or(
          like(buildingPayments.buildingName, `%${buildingQuery}%`),
          sql`LOWER(${buildingPayments.buildingName}) LIKE LOWER(${`%${buildingQuery}%`})`
        )
      )
    )
    .orderBy(desc(buildingPayments.createdAt));

  if (rows.length === 0) return [];

  // For each unique building, take the most recent row at/before the timestamp
  const latestByBuilding = new Map<string, typeof rows[0]>();
  for (const row of rows) {
    if (!latestByBuilding.has(row.buildingName)) {
      latestByBuilding.set(row.buildingName, row);
    }
  }

  const results: CollectionsAtTimestampResult[] = [];

  for (const [buildingName, row] of Array.from(latestByBuilding)) {
    const netRentCollected = parseFloat(row.netRentCollected);
    const netCashFlow = parseFloat(row.netCashFlow);

    // Find the prior snapshot for this building (the row just before this one)
    const priorRows = await db
      .select()
      .from(buildingPayments)
      .where(
        and(
          eq(buildingPayments.buildingName, buildingName),
          lte(buildingPayments.createdAt, new Date(new Date(row.createdAt).getTime() - 1))
        )
      )
      .orderBy(desc(buildingPayments.createdAt))
      .limit(1);

    let rentChangePct: number | null = null;
    let prevNetRentCollected: number | null = null;
    let prevSnapshotDate: string | null = null;

    if (priorRows.length > 0) {
      const prevRent = parseFloat(priorRows[0].netRentCollected);
      prevNetRentCollected = prevRent;
      prevSnapshotDate = priorRows[0].snapshotDate;
      if (prevRent !== 0) {
        rentChangePct = Math.round(((netRentCollected - prevRent) / Math.abs(prevRent)) * 1000) / 10;
      }
    }

    results.push({
      buildingName,
      regionId: row.regionId,
      netRentCollected,
      netCashFlow,
      snapshotDate: row.snapshotDate,
      createdAt: row.createdAt,
      rentChangePct,
      prevNetRentCollected,
      prevSnapshotDate,
    });
  }

  return results;
}

// ─── Building Collections Helpers ─────────────────────────────────────────────

export async function getCollectionsForDateDb(date: string) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(buildingCollections).where(eq(buildingCollections.snapshotDate, date));
}

export async function getCollectionsDates(): Promise<string[]> {
  const db = await getDb();
  if (!db) return [];
  const rows = await db.select({ snapshotDate: buildingCollections.snapshotDate })
    .from(buildingCollections)
    .orderBy(desc(buildingCollections.snapshotDate));
  const seen = new Set<string>();
  const dates: string[] = [];
  for (const r of rows) {
    if (!seen.has(r.snapshotDate)) { seen.add(r.snapshotDate); dates.push(r.snapshotDate); }
  }
  return dates;
}

export async function getLatestCollectionsDate(): Promise<string | null> {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select({ snapshotDate: buildingCollections.snapshotDate })
    .from(buildingCollections)
    .orderBy(desc(buildingCollections.snapshotDate))
    .limit(1);
  return rows.length > 0 ? rows[0].snapshotDate : null;
}

export interface CollectionsLookupResult {
  buildingName: string;
  regionId: number;
  rentBilled: number;
  rentCollected: number;
  utilityReimbursement: number;
  vouchersCount: number;
  collectionPct: number;
  snapshotDate: string;
  /** % change vs the prior snapshot for the same building */
  rentCollectedChangePct: number | null;
  prevRentCollected: number | null;
  prevSnapshotDate: string | null;
}

/**
 * Look up collections data for a specific date and optional building filter.
 * Returns all buildings if buildingQuery is empty.
 */
export async function getCollectionsLookup(
  date: string,
  buildingQuery: string
): Promise<CollectionsLookupResult[]> {
  const db = await getDb();
  if (!db) return [];

  const baseRows = buildingQuery.trim()
    ? await db.select().from(buildingCollections).where(
        and(
          eq(buildingCollections.snapshotDate, date),
          or(
            like(buildingCollections.buildingName, `%${buildingQuery}%`),
            sql`LOWER(${buildingCollections.buildingName}) LIKE LOWER(${`%${buildingQuery}%`})`
          )
        )
      )
    : await db.select().from(buildingCollections).where(eq(buildingCollections.snapshotDate, date));

  if (baseRows.length === 0) return [];

  // Get the previous snapshot date for comparison
  const allDates = await getCollectionsDates();
  const dateIdx = allDates.indexOf(date);
  const prevDate = dateIdx >= 0 && dateIdx < allDates.length - 1 ? allDates[dateIdx + 1] : null;

  let prevMap = new Map<string, number>();
  let prevDateStr: string | null = null;
  if (prevDate) {
    prevDateStr = prevDate;
    const prevRows = await db.select().from(buildingCollections).where(eq(buildingCollections.snapshotDate, prevDate));
    for (const r of prevRows) {
      prevMap.set(r.buildingName, parseFloat(r.rentCollected));
    }
  }

  return baseRows.map((r) => {
    const rentCollected = parseFloat(r.rentCollected);
    const prevRentCollected = prevMap.get(r.buildingName) ?? null;
    let rentCollectedChangePct: number | null = null;
    if (prevRentCollected !== null && prevRentCollected !== 0) {
      rentCollectedChangePct = Math.round(((rentCollected - prevRentCollected) / Math.abs(prevRentCollected)) * 1000) / 10;
    }
    return {
      buildingName: r.buildingName,
      regionId: r.regionId,
      rentBilled: parseFloat(r.rentBilled),
      rentCollected,
      utilityReimbursement: parseFloat(r.utilityReimbursement),
      vouchersCount: r.vouchersCount,
      collectionPct: parseFloat(r.collectionPct),
      snapshotDate: r.snapshotDate,
      rentCollectedChangePct,
      prevRentCollected,
      prevSnapshotDate: prevDateStr,
    };
  });
}

/**
 * Return all historical collection snapshots for a specific building,
 * ordered oldest → newest. Used for the trend modal chart.
 */
export async function getCollectionHistory(buildingName: string): Promise<{
  snapshotDate: string;
  rentBilled: number;
  rentCollected: number;
  collectionPct: number;
  utilityReimbursement: number;
  vouchersCount: number;
}[]> {
  const db = await getDb();
  if (!db) return [];
  const rows = await db
    .select()
    .from(buildingCollections)
    .where(eq(buildingCollections.buildingName, buildingName))
    .orderBy(buildingCollections.snapshotDate);
  return rows.map((r) => ({
    snapshotDate: r.snapshotDate,
    rentBilled: parseFloat(r.rentBilled),
    rentCollected: parseFloat(r.rentCollected),
    collectionPct: parseFloat(r.collectionPct),
    utilityReimbursement: parseFloat(r.utilityReimbursement),
    vouchersCount: r.vouchersCount,
  }));
}
