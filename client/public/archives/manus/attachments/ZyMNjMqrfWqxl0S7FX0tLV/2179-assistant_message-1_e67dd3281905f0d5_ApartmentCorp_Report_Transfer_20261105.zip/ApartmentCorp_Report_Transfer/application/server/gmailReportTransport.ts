import nodemailer from "nodemailer";

export const GMAIL_REPORT_SENDER = "apartmentcorp44@gmail.com";

export type GmailReportConfig = {
  user: string;
  appPassword: string;
};

/** Validate only the selected relay; never fall back to another account or provider. */
export function getGmailReportConfig(env: NodeJS.ProcessEnv = process.env): GmailReportConfig {
  const user = env.GMAIL_USER?.trim().toLowerCase();
  if (!user) {
    throw new Error("Gmail report relay is not configured. Set GMAIL_USER and GMAIL_APP_PASSWORD.");
  }
  if (user !== GMAIL_REPORT_SENDER) {
    throw new Error(`GMAIL_USER must be ${GMAIL_REPORT_SENDER}.`);
  }

  // Google displays App Passwords in space-separated groups. Do not accept a
  // regular account password or strip any other invalid characters.
  const appPassword = env.GMAIL_APP_PASSWORD?.replace(/ /g, "");
  if (!appPassword || !/^[A-Za-z]{16}$/.test(appPassword)) {
    throw new Error("GMAIL_APP_PASSWORD must be a Google App Password: 16 alphabetic characters, with optional display spaces. Do not use the regular Gmail password.");
  }
  return { user, appPassword };
}

/** Creates an SMTP client only; no connection, verification, or mail send occurs here. */
export function createGmailReportTransport(env: NodeJS.ProcessEnv = process.env) {
  const { user, appPassword } = getGmailReportConfig(env);
  return nodemailer.createTransport({
    host: "smtp.gmail.com",
    port: 587,
    secure: false,
    requireTLS: true,
    auth: { user, pass: appPassword },
    connectionTimeout: 15_000,
    greetingTimeout: 15_000,
    socketTimeout: 60_000,
    tls: { minVersion: "TLSv1.2", rejectUnauthorized: true },
    logger: false,
    debug: false,
  });
}
