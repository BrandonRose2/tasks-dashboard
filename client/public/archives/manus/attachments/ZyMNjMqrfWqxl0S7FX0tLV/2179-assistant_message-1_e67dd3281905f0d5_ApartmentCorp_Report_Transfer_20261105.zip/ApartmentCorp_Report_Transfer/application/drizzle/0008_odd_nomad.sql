CREATE TABLE `microsoft_mail_connections` (
	`id` int AUTO_INCREMENT NOT NULL,
	`accountEmail` varchar(320) NOT NULL,
	`refreshTokenCiphertext` text NOT NULL,
	`refreshTokenExpiresAt` timestamp,
	`connectedAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `microsoft_mail_connections_id` PRIMARY KEY(`id`),
	CONSTRAINT `microsoft_mail_connections_accountEmail_unique` UNIQUE(`accountEmail`)
);
