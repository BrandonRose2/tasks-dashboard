import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

describe("vacancy.verifyPin", () => {
  it("returns valid: true for the correct PIN", async () => {
    const ctx = createContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.vacancy.verifyPin({ pin: "3060" });
    expect(result).toEqual({ valid: true });
  });

  it("returns valid: false for an incorrect PIN", async () => {
    const ctx = createContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.vacancy.verifyPin({ pin: "0000" });
    expect(result).toEqual({ valid: false });
  });

  it("returns valid: false for an empty PIN", async () => {
    const ctx = createContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.vacancy.verifyPin({ pin: "" });
    expect(result).toEqual({ valid: false });
  });
});
