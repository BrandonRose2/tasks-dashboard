import { describe, expect, it } from "vitest";
import { COLLECTIONS_SNAPSHOT_TTL_MS, isCollectionsSnapshotFresh } from "./scraper";

describe("Collections snapshot freshness", () => {
  const now = new Date("2026-08-31T19:00:00.000Z").getTime();

  it("uses a one-minute current-data window for near-live FLOW alignment", () => {
    expect(COLLECTIONS_SNAPSHOT_TTL_MS).toBe(60 * 1000);
    expect(isCollectionsSnapshotFresh(new Date(now - 59 * 1000), now)).toBe(true);
    expect(isCollectionsSnapshotFresh(new Date(now - 60 * 1000), now)).toBe(false);
  });

  it("requires a refresh when no prior collection snapshot exists", () => {
    expect(isCollectionsSnapshotFresh(null, now)).toBe(false);
  });
});
