CREATE TABLE `monthly_email_deliveries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`run_id` int NOT NULL,
	`delivery_key` varchar(320) NOT NULL,
	`message` json NOT NULL,
	`state` enum('pending','sending','sent','unknown') NOT NULL DEFAULT 'pending',
	`attempt_token` varchar(36),
	`message_id` varchar(512),
	`smtp_receipt` json,
	`failure_code` varchar(64),
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `monthly_email_deliveries_id` PRIMARY KEY(`id`),
	CONSTRAINT `monthly_email_run_delivery_unique` UNIQUE(`run_id`,`delivery_key`)
);
--> statement-breakpoint
CREATE TABLE `monthly_email_jobs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`schedule_key` varchar(64) NOT NULL,
	`report_type` enum('monthly_net_cash_flow') NOT NULL,
	`schedule_cron_task_uid` varchar(65),
	`endpoint_path` varchar(128) NOT NULL,
	`enabled` boolean NOT NULL DEFAULT false,
	`timezone` varchar(64) NOT NULL DEFAULT 'America/Los_Angeles',
	`send_hour` int NOT NULL DEFAULT 13,
	`send_day` int NOT NULL DEFAULT 12,
	`recipient_to` json NOT NULL,
	`activated_at` timestamp(3),
	`first_send_date` varchar(10),
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `monthly_email_jobs_id` PRIMARY KEY(`id`),
	CONSTRAINT `monthly_email_jobs_schedule_key_unique` UNIQUE(`schedule_key`),
	CONSTRAINT `monthly_email_task_uid_unique` UNIQUE(`schedule_cron_task_uid`)
);
--> statement-breakpoint
CREATE TABLE `monthly_email_runs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`job_id` int NOT NULL,
	`period_key` varchar(7) NOT NULL,
	`state` enum('preparing','processing','ready','failed_before_send','complete','review') NOT NULL,
	`attempt_token` varchar(36) NOT NULL,
	`source_updated_at` timestamp,
	`plan_count` int,
	`outcome` varchar(64),
	`failure_code` varchar(64),
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `monthly_email_runs_id` PRIMARY KEY(`id`),
	CONSTRAINT `monthly_email_job_period_unique` UNIQUE(`job_id`,`period_key`)
);
--> statement-breakpoint
ALTER TABLE `monthly_email_deliveries` ADD CONSTRAINT `monthly_email_deliveries_run_id_monthly_email_runs_id_fk` FOREIGN KEY (`run_id`) REFERENCES `monthly_email_runs`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `monthly_email_runs` ADD CONSTRAINT `monthly_email_runs_job_id_monthly_email_jobs_id_fk` FOREIGN KEY (`job_id`) REFERENCES `monthly_email_jobs`(`id`) ON DELETE no action ON UPDATE no action;