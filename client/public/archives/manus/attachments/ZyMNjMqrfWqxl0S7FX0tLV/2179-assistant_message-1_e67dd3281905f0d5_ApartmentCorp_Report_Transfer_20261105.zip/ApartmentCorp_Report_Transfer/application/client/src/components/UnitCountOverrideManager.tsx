import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Building2, Pencil, Trash2, Plus, Check, X, Loader2 } from "lucide-react";
import { toast } from "sonner";

// Canonical list of buildings from the scraper's BUILDING_UNIT_COUNTS map
// (primary names only — no aliases)
const DEFAULT_BUILDINGS: { name: string; units: number }[] = [
  { name: "Boca Ciega", units: 109 },
  { name: "Jefferson Arms", units: 75 },
  { name: "Opa Locka", units: 65 },
  { name: "Macedonia Garden", units: 100 },
  { name: "Coral Village", units: 72 },
  { name: "Holiday Apartments", units: 115 },
  { name: "Cumberland Apartments", units: 68 },
  { name: "Village Green", units: 80 },
  { name: "Walnut Hill", units: 168 },
  { name: "River Pointe", units: 160 },
  { name: "Breckenridge Village", units: 66 },
  { name: "Lexington Arms", units: 61 },
  { name: "Grace Townhomes", units: 112 },
  { name: "Grove Park Terrace", units: 60 },
  { name: "La Promesa", units: 136 },
  { name: "New Wilmington Arms", units: 60 },
  { name: "Gates on Manhattan", units: 276 },
  { name: "Ruby Diamond", units: 73 },
  { name: "Star Homes", units: 48 },
  { name: "Thibodaux", units: 107 },
  { name: "Marrero 3", units: 173 },
  { name: "Arbor Crest", units: 120 },
  { name: "Windsor/Yorkshire", units: 134 },
  { name: "Windsor", units: 48 },
  { name: "Yorkshire", units: 86 },
  { name: "North Pointe", units: 27 },
  { name: "Granite Bayou", units: 60 },
  { name: "St. Charles Place", units: 121 },
  { name: "Pelican Bay", units: 152 },
  { name: "Howell Place", units: 48 },
  { name: "Pirates Bend", units: 48 },
  { name: "NWA", units: 162 },
  { name: "Anaheim", units: 80 },
  { name: "Fairfax", units: 46 },
  { name: "Urban 1 & 2", units: 60 },
  { name: "Midtown Manor", units: 32 },
  { name: "Pacific Pointe", units: 80 },
  { name: "Granite Ridge", units: 80 },
  { name: "Columbia Village", units: 80 },
  { name: "Forest View", units: 60 },
  { name: "Oak Hills", units: 80 },
  { name: "River Garden", units: 123 },
  { name: "Riverchase", units: 80 },
  { name: "Silver Springs Terrace", units: 100 },
  { name: "Thomasville Church Homes", units: 100 },
];

interface Props {
  adminPin: string;
}

type Override = {
  id: number;
  buildingName: string;
  totalUnits: number;
  updatedAt: Date;
};

export default function UnitCountOverrideManager({ adminPin }: Props) {
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editValue, setEditValue] = useState<string>("");
  const [addingName, setAddingName] = useState("");
  const [addingUnits, setAddingUnits] = useState("");
  const [showAddForm, setShowAddForm] = useState(false);
  const [deleteConfirmId, setDeleteConfirmId] = useState<number | null>(null);

  const utils = trpc.useUtils();

  const { data: overrides = [], isLoading } = trpc.unitOverrides.list.useQuery(
    { pin: adminPin },
    { enabled: !!adminPin }
  );

  const upsertMutation = trpc.unitOverrides.upsert.useMutation({
    onSuccess: () => {
      utils.unitOverrides.list.invalidate();
      setEditingId(null);
      setShowAddForm(false);
      setAddingName("");
      setAddingUnits("");
      toast.success("Unit count override saved. Dashboard will refresh on next load.");
    },
    onError: (err) => {
      toast.error(`Failed to save: ${err.message}`);
    },
  });

  const deleteMutation = trpc.unitOverrides.delete.useMutation({
    onSuccess: () => {
      utils.unitOverrides.list.invalidate();
      setDeleteConfirmId(null);
      toast.success("Override removed. Building will use the default unit count.");
    },
    onError: (err) => {
      toast.error(`Failed to delete: ${err.message}`);
    },
  });

  // Build a merged list: all defaults + any overrides not in defaults
  const overrideMap = new Map<string, Override>(
    overrides.map((o) => [o.buildingName, o as Override])
  );

  // Extra overrides that aren't in DEFAULT_BUILDINGS
  const extraOverrides = overrides.filter(
    (o) => !DEFAULT_BUILDINGS.some((d) => d.name === o.buildingName)
  );

  function startEdit(override: Override) {
    setEditingId(override.id);
    setEditValue(String(override.totalUnits));
  }

  function cancelEdit() {
    setEditingId(null);
    setEditValue("");
  }

  function saveEdit(buildingName: string) {
    const units = parseInt(editValue, 10);
    if (isNaN(units) || units < 1) {
      toast.error("Unit count must be a positive integer.");
      return;
    }
    upsertMutation.mutate({ pin: adminPin, buildingName, totalUnits: units });
  }

  function saveAdd() {
    const name = addingName.trim();
    const units = parseInt(addingUnits, 10);
    if (!name) {
      toast.error("Building name is required.");
      return;
    }
    if (isNaN(units) || units < 1) {
      toast.error("Unit count must be a positive integer.");
      return;
    }
    upsertMutation.mutate({ pin: adminPin, buildingName: name, totalUnits: units });
  }

  function setOverrideForDefault(buildingName: string, defaultUnits: number) {
    setAddingName(buildingName);
    setAddingUnits(String(defaultUnits));
    setShowAddForm(true);
  }

  return (
    <section>
      <h2 className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-4">
        Building Unit Count Overrides
      </h2>
      <Card className="neon-card rounded-xl">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Building2 className="w-5 h-5 neon-cyan" />
              <CardTitle className="text-lg text-foreground">Unit Count Overrides</CardTitle>
            </div>
            <Button
              size="sm"
              variant="outline"
              className="border-cyan-500/40 text-cyan-400 hover:bg-cyan-500/10"
              onClick={() => {
                setShowAddForm((v) => !v);
                setAddingName("");
                setAddingUnits("");
              }}
            >
              <Plus className="w-4 h-4 mr-1" />
              Add Override
            </Button>
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            Override the default total unit count for any building. Overrides take priority over
            hardcoded values and are used when computing vacancy percentages.
          </p>
        </CardHeader>
        <CardContent>
          {/* Add new override form */}
          {showAddForm && (
            <div className="mb-4 p-3 rounded-lg border border-cyan-500/30 bg-cyan-500/5">
              <p className="text-xs font-semibold text-cyan-400 mb-2">New Override</p>
              <div className="flex gap-2 flex-wrap">
                <input
                  className="flex-1 min-w-[180px] bg-background border border-border rounded px-2 py-1 text-sm text-foreground"
                  placeholder="Building name (exact match)"
                  value={addingName}
                  onChange={(e) => setAddingName(e.target.value)}
                />
                <input
                  className="w-24 bg-background border border-border rounded px-2 py-1 text-sm text-foreground"
                  type="number"
                  min={1}
                  placeholder="Units"
                  value={addingUnits}
                  onChange={(e) => setAddingUnits(e.target.value)}
                />
                <Button
                  size="sm"
                  className="bg-cyan-600 hover:bg-cyan-500 text-white"
                  onClick={saveAdd}
                  disabled={upsertMutation.isPending}
                >
                  {upsertMutation.isPending ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Check className="w-4 h-4" />
                  )}
                  Save
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => setShowAddForm(false)}
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </div>
          )}

          {/* Active overrides table */}
          {isLoading ? (
            <div className="flex items-center gap-2 text-muted-foreground py-4">
              <Loader2 className="w-4 h-4 animate-spin" />
              Loading overrides…
            </div>
          ) : overrides.length === 0 ? (
            <p className="text-sm text-muted-foreground py-2">
              No overrides set. All buildings use their default unit counts.
            </p>
          ) : (
            <div className="mb-6">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
                Active Overrides
              </p>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-muted-foreground">Building</TableHead>
                    <TableHead className="text-muted-foreground text-right">Units</TableHead>
                    <TableHead className="text-muted-foreground text-right">Updated</TableHead>
                    <TableHead className="text-muted-foreground text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {overrides.map((o) => (
                    <TableRow key={o.id}>
                      <TableCell className="font-medium text-foreground">{o.buildingName}</TableCell>
                      <TableCell className="text-right">
                        {editingId === o.id ? (
                          <input
                            className="w-20 bg-background border border-cyan-500/50 rounded px-2 py-0.5 text-sm text-foreground text-right"
                            type="number"
                            min={1}
                            value={editValue}
                            onChange={(e) => setEditValue(e.target.value)}
                            autoFocus
                          />
                        ) : (
                          <span className="neon-cyan font-bold">{o.totalUnits}</span>
                        )}
                      </TableCell>
                      <TableCell className="text-right text-xs text-muted-foreground">
                        {new Date(o.updatedAt).toLocaleDateString()}
                      </TableCell>
                      <TableCell className="text-right">
                        {editingId === o.id ? (
                          <div className="flex gap-1 justify-end">
                            <Button
                              size="sm"
                              variant="ghost"
                              className="text-green-400 hover:text-green-300 h-7 px-2"
                              onClick={() => saveEdit(o.buildingName)}
                              disabled={upsertMutation.isPending}
                            >
                              {upsertMutation.isPending ? (
                                <Loader2 className="w-3 h-3 animate-spin" />
                              ) : (
                                <Check className="w-3 h-3" />
                              )}
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              className="text-muted-foreground hover:text-foreground h-7 px-2"
                              onClick={cancelEdit}
                            >
                              <X className="w-3 h-3" />
                            </Button>
                          </div>
                        ) : deleteConfirmId === o.id ? (
                          <div className="flex gap-1 justify-end items-center">
                            <span className="text-xs text-red-400 mr-1">Remove?</span>
                            <Button
                              size="sm"
                              variant="ghost"
                              className="text-red-400 hover:text-red-300 h-7 px-2"
                              onClick={() =>
                                deleteMutation.mutate({ pin: adminPin, id: o.id })
                              }
                              disabled={deleteMutation.isPending}
                            >
                              {deleteMutation.isPending ? (
                                <Loader2 className="w-3 h-3 animate-spin" />
                              ) : (
                                <Check className="w-3 h-3" />
                              )}
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              className="text-muted-foreground hover:text-foreground h-7 px-2"
                              onClick={() => setDeleteConfirmId(null)}
                            >
                              <X className="w-3 h-3" />
                            </Button>
                          </div>
                        ) : (
                          <div className="flex gap-1 justify-end">
                            <Button
                              size="sm"
                              variant="ghost"
                              className="text-cyan-400 hover:text-cyan-300 h-7 px-2"
                              onClick={() => startEdit(o as Override)}
                            >
                              <Pencil className="w-3 h-3" />
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              className="text-red-400/70 hover:text-red-400 h-7 px-2"
                              onClick={() => setDeleteConfirmId(o.id)}
                            >
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}

          {/* Default buildings reference table */}
          <div>
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
              Default Unit Counts (click to override)
            </p>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-muted-foreground">Building</TableHead>
                    <TableHead className="text-muted-foreground text-right">Default Units</TableHead>
                    <TableHead className="text-muted-foreground text-right">Override</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {DEFAULT_BUILDINGS.map((b, idx) => {
                    const ov = overrideMap.get(b.name);
                    return (
                      <TableRow key={`unit-${idx}-${b.name}`} className={ov ? "bg-cyan-500/5" : ""}>
                        <TableCell className="text-foreground text-sm">{b.name}</TableCell>
                        <TableCell className="text-right text-sm text-muted-foreground">
                          {b.units}
                        </TableCell>
                        <TableCell className="text-right">
                          {ov ? (
                            <span className="text-sm font-bold neon-cyan">{ov.totalUnits}</span>
                          ) : (
                            <Button
                              size="sm"
                              variant="ghost"
                              className="text-xs text-muted-foreground hover:text-cyan-400 h-6 px-2"
                              onClick={() => setOverrideForDefault(b.name, b.units)}
                            >
                              <Pencil className="w-3 h-3 mr-1" />
                              Set
                            </Button>
                          )}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          </div>
        </CardContent>
      </Card>
    </section>
  );
}
