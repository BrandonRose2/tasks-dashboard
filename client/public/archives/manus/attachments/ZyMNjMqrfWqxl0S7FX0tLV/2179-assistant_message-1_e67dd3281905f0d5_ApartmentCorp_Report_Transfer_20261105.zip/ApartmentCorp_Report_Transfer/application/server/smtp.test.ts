import nodemailer from "nodemailer";
import { afterEach, describe, expect, it, vi } from "vitest";
import { createGmailReportTransport, getGmailReportConfig, GMAIL_REPORT_SENDER } from "./gmailReportTransport";

// Synthetic fixtures only; no runtime credentials or SMTP connections are used.
const validEnv: NodeJS.ProcessEnv = {
  GMAIL_USER: GMAIL_REPORT_SENDER,
  GMAIL_APP_PASSWORD: "abcd efgh ijkl mnop",
};

afterEach(() => vi.restoreAllMocks());

describe("selected Gmail report relay configuration (no send)", () => {
  it.each([
    {},
    { GMAIL_APP_PASSWORD: validEnv.GMAIL_APP_PASSWORD },
    { ...validEnv, GMAIL_USER: " " },
    { GMAIL_USER: GMAIL_REPORT_SENDER },
    { ...validEnv, GMAIL_APP_PASSWORD: " " },
  ])("fails closed when configuration is missing: %j", (env) => {
    const createTransport = vi.spyOn(nodemailer, "createTransport");
    expect(() => createGmailReportTransport(env)).toThrow(/GMAIL_USER|GMAIL_APP_PASSWORD/);
    expect(createTransport).not.toHaveBeenCalled();
  });

  it.each([
    "other@gmail.com",
    "apartmentcorp44@googlemail.com",
    "apartment.corp44@gmail.com",
    "apartmentcorp44+reports@gmail.com",
    "ethan@apartmentcorp.com",
  ])("rejects any other account, including aliases: %s", (user) => {
    expect(() => getGmailReportConfig({ ...validEnv, GMAIL_USER: user })).toThrow(`GMAIL_USER must be ${GMAIL_REPORT_SENDER}`);
  });

  it.each([
    "RegularPassword1",
    "ordinary-password",
    "abcdefghijklmnopq",
    "abcdefghijklmno",
    "abcd\tefgh ijkl mnop",
    "abcd\nefgh ijkl mnop",
    "abcd-efgh-ijkl-mnop",
  ])("rejects regular/malformed passwords: %s", (password) => {
    expect(() => getGmailReportConfig({ ...validEnv, GMAIL_APP_PASSWORD: password })).toThrow("Google App Password");
  });

  it("normalizes only account casing/outer whitespace and App Password display spaces", () => {
    expect(getGmailReportConfig({
      GMAIL_USER: "  ApartmentCorp44@Gmail.com  ",
      GMAIL_APP_PASSWORD: " abcd efgh ijkl mnop ",
    })).toEqual({ user: GMAIL_REPORT_SENDER, appPassword: "abcdefghijklmnop" });
    expect(getGmailReportConfig({ ...validEnv, GMAIL_APP_PASSWORD: "ABCDEFGHIJKLMNOP" }).appPassword).toBe("ABCDEFGHIJKLMNOP");
  });

  it("passes exact STARTTLS options to nodemailer without verifying or sending", () => {
    const smtpClient = { sendMail: vi.fn(), verify: vi.fn(), close: vi.fn() };
    const createTransport = vi.spyOn(nodemailer, "createTransport").mockReturnValue(smtpClient as unknown as ReturnType<typeof nodemailer.createTransport>);
    expect(createGmailReportTransport(validEnv)).toBe(smtpClient);
    expect(createTransport).toHaveBeenCalledOnce();
    expect(createTransport).toHaveBeenCalledWith({
      host: "smtp.gmail.com",
      port: 587,
      secure: false,
      requireTLS: true,
      auth: { user: GMAIL_REPORT_SENDER, pass: "abcdefghijklmnop" },
      connectionTimeout: 15_000,
      greetingTimeout: 15_000,
      socketTimeout: 60_000,
      tls: { minVersion: "TLSv1.2", rejectUnauthorized: true },
      logger: false,
      debug: false,
    });
    expect(smtpClient.sendMail).not.toHaveBeenCalled();
    expect(smtpClient.verify).not.toHaveBeenCalled();
  });

  it("never falls back to legacy credentials when Gmail settings are absent", () => {
    expect(() => getGmailReportConfig({
      EXCHANGE_TENANT_ID: "test-tenant",
      EXCHANGE_CLIENT_ID: "test-client",
      EXCHANGE_CLIENT_SECRET: "test-only",
      SMTP_USER: "legacy@gmail.com",
      SMTP_PASSWORD: "test-only",
    })).toThrow("Gmail report relay is not configured");
  });
});
