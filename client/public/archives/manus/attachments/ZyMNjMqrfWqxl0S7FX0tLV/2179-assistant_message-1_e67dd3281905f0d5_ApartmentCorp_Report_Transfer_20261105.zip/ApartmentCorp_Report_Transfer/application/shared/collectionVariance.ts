export const COLLECTION_VARIANCE_TOLERANCE = 7_500;

export type CollectionVarianceStatus = "within_tolerance" | "shortfall" | "over_collected" | "no_expected_rent";

export type CollectionVariance = {
  expectedRent: number;
  collected: number;
  variance: number;
  status: CollectionVarianceStatus;
  tolerance: number;
};

/**
 * Variance is collected minus expected rent. A positive value is over-collected;
 * a negative value is a shortfall. Amounts within the configured tolerance are
 * treated as on target.
 */
export function getCollectionVariance(expectedRent: number, collected: number): CollectionVariance {
  const variance = collected - expectedRent;
  if (expectedRent <= 0) {
    return { expectedRent, collected, variance, status: "no_expected_rent", tolerance: COLLECTION_VARIANCE_TOLERANCE };
  }
  if (Math.abs(variance) <= COLLECTION_VARIANCE_TOLERANCE) {
    return { expectedRent, collected, variance, status: "within_tolerance", tolerance: COLLECTION_VARIANCE_TOLERANCE };
  }
  return {
    expectedRent,
    collected,
    variance,
    status: variance < 0 ? "shortfall" : "over_collected",
    tolerance: COLLECTION_VARIANCE_TOLERANCE,
  };
}
