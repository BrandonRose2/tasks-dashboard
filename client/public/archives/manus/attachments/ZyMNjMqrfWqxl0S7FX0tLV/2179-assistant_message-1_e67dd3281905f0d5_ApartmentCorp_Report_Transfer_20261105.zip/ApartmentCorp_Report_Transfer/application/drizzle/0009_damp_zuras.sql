CREATE TABLE `daily_vacancy_jobs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`schedule_key` varchar(64) NOT NULL,
	`schedule_cron_task_uid` varchar(65),
	`enabled` boolean NOT NULL DEFAULT false,
	`timezone` varchar(64) NOT NULL DEFAULT 'America/Los_Angeles',
	`send_hour` int NOT NULL DEFAULT 13,
	`recipients` json NOT NULL,
	`activated_at` timestamp,
	`first_send_date` varchar(10),
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `daily_vacancy_jobs_id` PRIMARY KEY(`id`),
	CONSTRAINT `daily_vacancy_jobs_schedule_key_unique` UNIQUE(`schedule_key`),
	CONSTRAINT `daily_vacancy_task_uid_unique` UNIQUE(`schedule_cron_task_uid`)
);
--> statement-breakpoint
CREATE TABLE `daily_vacancy_send_ledger` (
	`id` int AUTO_INCREMENT NOT NULL,
	`job_id` int NOT NULL,
	`local_date` varchar(10) NOT NULL,
	`state` enum('preparing','sending','sent','failed_before_send','unknown') NOT NULL,
	`attempt_token` varchar(36) NOT NULL,
	`source_updated_at` timestamp,
	`message_id` varchar(512),
	`smtp_receipt` json,
	`failure_code` varchar(64),
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `daily_vacancy_send_ledger_id` PRIMARY KEY(`id`),
	CONSTRAINT `daily_vacancy_job_date_unique` UNIQUE(`job_id`,`local_date`)
);
--> statement-breakpoint
ALTER TABLE `daily_vacancy_send_ledger` ADD CONSTRAINT `daily_vacancy_send_ledger_job_id_daily_vacancy_jobs_id_fk` FOREIGN KEY (`job_id`) REFERENCES `daily_vacancy_jobs`(`id`) ON DELETE no action ON UPDATE no action;