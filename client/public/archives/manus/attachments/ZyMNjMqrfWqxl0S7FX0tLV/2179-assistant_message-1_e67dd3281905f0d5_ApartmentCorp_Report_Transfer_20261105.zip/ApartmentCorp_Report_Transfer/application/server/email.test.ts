import { describe, expect, it } from "vitest";
import { readFileSync } from "fs";
import { buildDailyVacancySubject } from "./emailService";

describe("report mail transport", () => {
  it("uses only the selected Gmail SMTP helper instead of Microsoft Graph", () => {
    const source = readFileSync(new URL("./emailService.ts", import.meta.url), "utf-8");
    expect(source).toContain('from "./gmailReportTransport"');
    expect(source).toContain("return createGmailReportTransport()");
    expect(source).not.toContain('from "./microsoftMail"');
    expect(source).not.toContain("sendMicrosoftGraphMail");
    expect(source).not.toContain("getMicrosoftDelegatedAccessToken");
  });

  it("uses a fresh local PropertyMax snapshot rather than Railway for Daily Vacancy delivery", () => {
    const source = readFileSync(new URL("./emailService.ts", import.meta.url), "utf-8");
    expect(source).toContain('fetchDashboardData(true)');
    expect(source).not.toContain('const data = await fetchRailwayVacancySnapshot()');
    expect(source).not.toContain("data.sourceStatus?.state");
    expect(source).toContain('https://vacancyreport.manus.space');
  });

  it("uses Admin-tab recipients for scheduled Daily Vacancy reports and permits only Ethan for Test3", () => {
    const source = readFileSync(new URL("./emailService.ts", import.meta.url), "utf-8");
    expect(source).toContain("await getDailyVacancyRecipients()");
    expect(source).toContain('EXCHANGE_SMTP_SENDER');
    expect(source).toContain('testLabel?.trim() === "Test3"');
  });

  it("labels an approved Test3 send without changing the scheduled report subject", () => {
    const date = new Date("2026-10-30T12:00:00.000Z");
    expect(buildDailyVacancySubject(date, 106, "Test3")).toContain("[Test3] ⚡ Daily Vacancy Report");
    expect(buildDailyVacancySubject(date, 106)).not.toContain("[Test3]");
  });
});
