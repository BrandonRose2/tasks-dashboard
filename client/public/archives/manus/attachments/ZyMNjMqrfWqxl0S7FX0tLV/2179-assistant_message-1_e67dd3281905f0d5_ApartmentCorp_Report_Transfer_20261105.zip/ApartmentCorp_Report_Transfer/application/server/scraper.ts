import { fetch as undiciFetch, Agent as UndiciAgent } from "undici";
import * as cheerio from "cheerio";
import { eq, desc } from "drizzle-orm";
import { vacancySnapshots, historicalCache } from "../drizzle/schema";
import { getDb, getUnitOverridesMap } from "./db";
import { parseStrictMonthlyNetCashHtml } from "./monthlyNetCashParser";

const BASE_URL = "https://propertymax.ai";
const LOGIN_PAGE_URL = `${BASE_URL}/app/vacancy/app/`;
const LOGIN_POST_URL = `${BASE_URL}/app/`;
const APP_URL = `${BASE_URL}/app/vacancy/app/`;
const FUNCTIONS_URL = `${BASE_URL}/vacancy.cfc`;

export type PropertyMaxCredentials = {
  username: string;
  password: string;
};

/** Reads the active PropertyMax account only from encrypted project runtime settings. */
export function getPropertyMaxCredentials(env: NodeJS.ProcessEnv = process.env): PropertyMaxCredentials {
  const username = env.PROPERTYMAX_USERNAME?.trim();
  const password = env.PROPERTYMAX_PASSWORD;
  if (!username || !password) {
    throw new Error("PropertyMax credentials are not configured. Set PROPERTYMAX_USERNAME and PROPERTYMAX_PASSWORD.");
  }
  return { username, password };
}

// Session cookie storage (in-memory, server lifetime)
let sessionCookieJar: Record<string, string> = {};
let lastAuthTime = 0;
const AUTH_EXPIRY_MS = 25 * 60 * 1000; // Re-auth every 25 minutes

// propertymax.ai: use undici Agent with TLS options for reliable connections
const pmAgent = new UndiciAgent({ connect: { rejectUnauthorized: false } });

// ─── Types ────────────────────────────────────────────────────────────────────

export interface VacancyStats {
  totalVacant: number;
  vacUnleased: number;
  vacPreleased: number;
  onNotice: number;
  eviction: number;
}

export interface VacantUnit {
  dateBy: string;
  building: string;
  unit: string;
  moveOut: string;
  alertDays: string;
  days: number;
  beds: number;
  askRent: number;
  percentReady: number;
}

export interface PreleasedUnit {
  dateBy: string;
  building: string;
  unit: string;
  moveOut: string;
  alertDays: string;
  days: number;
  moveIn: string;
  beds: number;
  askRent: number;
  percentReady: number;
}

export interface OnNoticeUnit {
  building: string;
  unit: string;
  leased: string;
}

export interface EvictionUnit {
  building: string;
  unit: string;
  dates: string;
  amountOwed: number;
}

export interface MarcsNetCash {
  region: number;
  regionName: string;
  total: number;
  buildings: { name: string; value: number }[];
}

export interface BuildingPaymentData {
  buildingName: string;
  regionId: number;
  regionName: string;
  netRentCollected: number;
  netCashFlow: number;
}

export interface PaymentsSnapshot {
  snapshotDate: string; // YYYY-MM-DD
  buildings: BuildingPaymentData[];
  totalNetRentCollected: number;
  totalNetCashFlow: number;
}

export interface HistoricalMonth {
  year: number;
  month: number;
  monthName: string;
  label: string;
  regions: MarcsNetCash[];
  grandTotal: number;
}

export interface BuildingVacancy {
  name: string;
  totalVacant: number;
  vacUnleased: number;
  vacPreleased: number;
  onNotice: number;
  eviction: number;
  totalUnits: number;
  vacancyPct: number;
  atRisk: boolean;
}

// ─── Building Unit Counts (from orgchart) ────────────────────────────────────

const BUILDING_UNIT_COUNTS: Record<string, number> = {
  // Region 1
  "Boca Ciega": 109,
  "Jefferson Arms": 75,
  "Opa Locka": 65,
  "135th Street": 65,
  "Opa Locka (135th Street)": 65,
  "Macedonia Garden": 100,
  "Macedonia": 100,
  "Coral Village": 72,
  "Holiday Apartments": 115,
  "Holiday": 115,
  "Cumberland Apartments": 68,
  "Cumberland": 68,
  "Village Green": 80,
  "Walnut Hill": 168,
  // Region 2
  "River Pointe": 160,
  "Breckenridge Village": 66,
  "Breckenridge": 66,
  "Lexington Arms": 61,
  "Lexington": 61,
  "Grace Townhomes": 112,
  "Grace": 112,
  "Grove Park Terrace": 60,
  "Grove Park": 60,
  "La Promesa": 136,
  "New Wilmington Arms": 60,
  "New Wilmington": 60,
  // Region 3
  "Gates on Manhattan": 276,
  "Gates": 276,
  "Ruby Diamond": 73,
  "Star Homes": 48,
  "Thibodaux": 107,
  "Colonial Estates": 107,
  "Marrero 3": 173,
  "Marrero": 173,
  "Arbor Crest": 120,
  "Windsor/Yorkshire": 134,
  "Windsor / Yorkshire": 134,
  "Windsor": 48,
  "Yorkshire": 86,
  "Yorkshire Village": 86,
  "North Pointe": 27,
  "Granite Bayou": 60,
  "St. Charles Place": 121,
  "St Charles Place": 121,
  "St. Charles": 121,
  "Pelican Bay": 152,
  "Howell Place": 48,
  "Pirates Bend": 48,
  // Region 4
  "NWA": 162,
  "Anaheim": 80,
  "Fairfax": 46,
  "Urban 1 & 2": 60,
  "Urban": 60,
  "Midtown Manor": 32,
  "Midtown": 32,
  "Pacific Pointe": 80,
  "Granite Ridge": 80,
  "Columbia Village": 80,
  "Columbia": 80,
  "Forest View": 60,
  "Oak Hills": 80,
  "River Garden": 123,
  "Riverchase": 80,
  // Region 5
  "Silver Springs Terrace": 100,
  "Silver Springs": 100,
  "Thomasville Church Homes": 100,
  "Thomasville": 100,
};

const AT_RISK_THRESHOLD = 4; // vacancy % above this is at-risk

function lookupTotalUnits(buildingName: string, overrides: Record<string, number> = {}): number {
  // DB overrides take highest priority — exact match first
  if (overrides[buildingName]) return overrides[buildingName];
  // DB overrides — partial match
  const lowerName = buildingName.toLowerCase();
  for (const [key, val] of Object.entries(overrides)) {
    if (lowerName.includes(key.toLowerCase()) || key.toLowerCase().includes(lowerName)) {
      return val;
    }
  }
  // Fallback to hardcoded map — exact match
  if (BUILDING_UNIT_COUNTS[buildingName]) return BUILDING_UNIT_COUNTS[buildingName];
  // Fallback to hardcoded map — partial match
  const lower = buildingName.toLowerCase();
  for (const [key, val] of Object.entries(BUILDING_UNIT_COUNTS)) {
    if (lower.includes(key.toLowerCase()) || key.toLowerCase().includes(lower)) {
      return val;
    }
  }
  return 0;
}

export interface DailyChange {
  building: string;
  todayVacant: number;
  yesterdayVacant: number;
  change: number;
}

export interface DashboardData {
  stats: VacancyStats;
  vacantUnleased: VacantUnit[];
  vacantPreleased: PreleasedUnit[];
  onNotice: OnNoticeUnit[];
  evictions: EvictionUnit[];
  buildingVacancy: BuildingVacancy[];
  dailyChanges: DailyChange[];
  historicalMonths: HistoricalMonth[];
  lastUpdated: Date;
  sourceStatus?: {
    state: "live" | "stale" | "unavailable";
    message?: string;
  };
}

/** A full vacancy report must not claim live totals while all matching detail rows are absent. */
export function hasVacancyUnitDetailCoverage(data: Pick<DashboardData, "stats" | "vacantUnleased" | "vacantPreleased" | "onNotice" | "evictions">): boolean {
  const expected = [data.stats.vacUnleased, data.stats.vacPreleased, data.stats.onNotice, data.stats.eviction];
  const actual = [data.vacantUnleased.length, data.vacantPreleased.length, data.onNotice.length, data.evictions.length];
  return expected.every((count, index) => count === 0 || actual[index] > 0);
}

// ─── Cookie Helpers ───────────────────────────────────────────────────────────

function parseCookies(setCookieHeaders: string | string[] | undefined): Record<string, string> {
  const jar: Record<string, string> = {};
  if (!setCookieHeaders) return jar;
  const headers = Array.isArray(setCookieHeaders) ? setCookieHeaders : [setCookieHeaders];
  for (const h of headers) {
    const [kv] = h.split(";");
    const eqIdx = kv.indexOf("=");
    if (eqIdx > 0) {
      const key = kv.substring(0, eqIdx).trim();
      const val = kv.substring(eqIdx + 1).trim();
      jar[key] = val;
    }
  }
  return jar;
}

function cookieJarToString(jar: Record<string, string>): string {
  return Object.entries(jar)
    .map(([k, v]) => `${k}=${v}`)
    .join("; ");
}

// ─── Auth ─────────────────────────────────────────────────────────────────────

let authInFlight: Promise<void> | null = null;

async function authenticate(): Promise<void> {
  const now = Date.now();
  if (Object.keys(sessionCookieJar).length > 0 && now - lastAuthTime < AUTH_EXPIRY_MS) {
    return; // Still valid
  }

  // Summary and collections calls can arrive together. ColdFusion associates
  // SESSION.mybuildings with one session, so overlapping logins can overwrite
  // the shared cookie jar and leave a valid-looking but uninitialized session.
  if (!authInFlight) {
    authInFlight = authenticateFreshWithRetry().finally(() => {
      authInFlight = null;
    });
  }
  return authInFlight;
}

async function authenticateFreshWithRetry(): Promise<void> {
  let lastError: unknown;
  for (let attempt = 1; attempt <= 2; attempt++) {
    try {
      await authenticateFresh();
      return;
    } catch (error) {
      lastError = error;
      sessionCookieJar = {};
      lastAuthTime = 0;
      if (attempt < 2) {
        console.warn("[Scraper] PropertyMax vacancy session bootstrap failed; retrying with a fresh session");
        await new Promise(resolve => setTimeout(resolve, 1500));
      }
    }
  }
  throw lastError instanceof Error ? lastError : new Error(String(lastError));
}

async function authenticateFresh(): Promise<void> {
  const now = Date.now();
  const credentials = getPropertyMaxCredentials();

  console.log("[Scraper] Authenticating with propertymax.ai...");

  // Step 1: GET login page to acquire initial CFID/CFTOKEN (use /app/ to get login form)
  const getResp = await undiciFetch(LOGIN_POST_URL, {
    headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" },
    redirect: "follow",
    // @ts-ignore undici dispatcher
    dispatcher: pmAgent,
  });

  // Use getSetCookie() to collect ALL Set-Cookie headers (undici supports this)
  const getRawCookies: string[] = (getResp.headers as any).getSetCookie?.() ?? [getResp.headers.get("set-cookie")].filter(Boolean);
  const initCookies = parseCookies(getRawCookies);
  sessionCookieJar = { ...initCookies };
  const loginPageHtml = await getResp.text();

  // Step 2: Extract CSRF token and CFID from the login page
  const csrfMatch = loginPageHtml.match(/name="csrftoken" value="([^"]+)"/);
  const loginValMatch = loginPageHtml.match(/name="login" value="([0-9]+)"/);
  const csrfToken = csrfMatch ? csrfMatch[1] : "";
  const loginVal = loginValMatch ? loginValMatch[1] : "1";

  // Step 3: POST login with correct field names for propertymax.ai
  const loginData = new URLSearchParams({
    cfusername: credentials.username,
    cfpassword: credentials.password,
    log: "1",
    login: loginVal,
    csrftoken: csrfToken,
  });

  // Step 3: POST to root / (form action is "/") with Referer header
  // Use redirect:"manual" so we can inspect the raw 302 Location header.
  // propertymax.ai (ColdFusion) redirects to /app/?CFID=...&CFTOKEN=... on success,
  // but the final followed page still shows the login form HTML — so checking page
  // content is unreliable. The 302 redirect itself is the reliable success signal.
  const postResp = await undiciFetch(`${BASE_URL}/`, {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
      Cookie: cookieJarToString(sessionCookieJar),
      Referer: LOGIN_POST_URL,
    },
    body: loginData.toString(),
    redirect: "manual",
    // @ts-ignore undici dispatcher
    dispatcher: pmAgent,
  });

  // Collect cookies from the POST response
  const postRawCookies: string[] = (postResp.headers as any).getSetCookie?.() ?? [postResp.headers.get("set-cookie")].filter(Boolean);
  const postCookies = parseCookies(postRawCookies);
  sessionCookieJar = { ...sessionCookieJar, ...postCookies };

  // Success check: server may return 302 redirect to /app/ OR 200 with user cookies (AC_ID set)
  const locationHeader = postResp.headers.get("location") ?? "";
  const isRedirectToApp = (postResp.status === 302 || postResp.status === 301) && locationHeader.includes("/app/");
  const hasUserCookie = postCookies["AC_ID"] !== undefined || postCookies["AC_ADMIN"] !== undefined;
  const isSuccess = isRedirectToApp || (postResp.status === 200 && hasUserCookie);
  // Consume body to avoid resource leak
  await postResp.text().catch(() => {});
  if (!isSuccess) {
    throw new Error(`Authentication failed: expected 302 redirect to /app/ or 200 with user cookies, got ${postResp.status} location=${locationHeader}`);
  }

  // Step 4a: Visit /app/ (main portal) to initialize the full ColdFusion session
  // This is required before getsummary works — visiting /app/ populates SESSION.mybuildings
  try {
    const appMainResp = await undiciFetch(`${BASE_URL}/app/`, {
      headers: {
        Cookie: cookieJarToString(sessionCookieJar),
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        Referer: BASE_URL,
      },
      redirect: "follow",
      // @ts-ignore undici dispatcher
      dispatcher: pmAgent,
    });
    const appMainCookies = parseCookies((appMainResp.headers as any).getSetCookie?.() ?? [appMainResp.headers.get("set-cookie")].filter(Boolean));
    sessionCookieJar = { ...sessionCookieJar, ...appMainCookies };
    await appMainResp.text(); // consume body
    console.log("[Scraper] Step 4a: visited /app/ to initialize session");
  } catch (e) {
    console.log("[Scraper] Warning: could not visit /app/ for session init:", e);
  }

  // Step 4b: Visit the vacancy app page to fully initialize SESSION.mybuildings
  try {
    const vacAppResp = await undiciFetch(APP_URL, {
      headers: {
        Cookie: cookieJarToString(sessionCookieJar),
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        Referer: `${BASE_URL}/app/`,
      },
      redirect: "follow",
      // @ts-ignore undici dispatcher
      dispatcher: pmAgent,
    });
    const vacAppCookies = parseCookies((vacAppResp.headers as any).getSetCookie?.() ?? [vacAppResp.headers.get("set-cookie")].filter(Boolean));
    sessionCookieJar = { ...sessionCookieJar, ...vacAppCookies };
    const vacancyAppHtml = await vacAppResp.text();
    if (hasSessionInitializationError(vacancyAppHtml)) {
      throw new Error("PropertyMax SESSION.mybuildings is not initialized for the vacancy application");
    }
    console.log("[Scraper] Step 4b: visited /app/vacancy/app/ to initialize SESSION.mybuildings");
  } catch (e) {
    throw new Error(`PropertyMax SESSION.mybuildings initialization failed: ${e instanceof Error ? e.message : String(e)}`);
  }

  lastAuthTime = now;
  console.log("[Scraper] Authentication successful");
}

async function fetchWithAuthRetry(url: string, params?: Record<string, string>, retries = 3): Promise<string> {
  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      return await fetchWithAuth(url, params);
    } catch (err: unknown) {
      const isRecoverableSessionError = err instanceof Error && (
        err.message.includes("ECONNRESET") ||
        err.message.includes("fetch failed") ||
        err.message.includes("SESSION.mybuildings")
      );
      if (isRecoverableSessionError && attempt < retries) {
        console.log(`[Scraper] Session/request error on attempt ${attempt}, retrying with a fresh session...`);
        // Force re-auth on next attempt
        sessionCookieJar = {};
        lastAuthTime = 0;
        await new Promise(r => setTimeout(r, 3000 * attempt));
        continue;
      }
      throw err;
    }
  }
  throw new Error('fetchWithAuthRetry exhausted all retries');
}

export function hasSessionInitializationError(data: string): boolean {
  const lower = data.toLocaleLowerCase();
  return lower.includes('name="cfusername"') ||
    lower.includes('id="log"') ||
    (lower.includes("mybuildings") && lower.includes("session")) ||
    lower.includes("error executing database query") ||
    lower.includes("portfolioregionids") ||
    lower.includes("r.regionid in ()");
}

async function fetchWithAuth(url: string, params?: Record<string, string>): Promise<string> {
  await authenticate();
  const fullUrl = params ? `${url}?${new URLSearchParams(params).toString()}` : url;

  const response = await undiciFetch(fullUrl, {
    headers: {
      Cookie: cookieJarToString(sessionCookieJar),
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
      Referer: APP_URL,
    },
    redirect: "follow",
    // @ts-ignore undici dispatcher
    dispatcher: pmAgent,
  });

  const responseCookies = parseCookies((response.headers as any).getSetCookie?.() ?? [response.headers.get("set-cookie")].filter(Boolean));
  if (Object.keys(responseCookies).length > 0) {
    sessionCookieJar = { ...sessionCookieJar, ...responseCookies };
  }
  const data = await response.text();

  // Detect login redirects and the ColdFusion error raised when a session has
  // cookies but has not initialized SESSION.mybuildings for the vacancy app.
  if (hasSessionInitializationError(data)) {
    console.log("[Scraper] Session is stale or incomplete, re-authenticating...");
    sessionCookieJar = {};
    lastAuthTime = 0;
    await authenticate();

    const retryResp = await undiciFetch(fullUrl, {
      headers: {
        Cookie: cookieJarToString(sessionCookieJar),
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        Referer: APP_URL,
      },
      redirect: "follow",
      // @ts-ignore undici dispatcher
      dispatcher: pmAgent,
    });
    const retryCookies = parseCookies((retryResp.headers as any).getSetCookie?.() ?? [retryResp.headers.get("set-cookie")].filter(Boolean));
    if (Object.keys(retryCookies).length > 0) {
      sessionCookieJar = { ...sessionCookieJar, ...retryCookies };
    }
    const retryData = await retryResp.text();
    if (hasSessionInitializationError(retryData)) {
      throw new Error("PropertyMax SESSION.mybuildings is not initialized after re-authentication");
    }
    return retryData;
  }

  return data;
}

// Decode JSON-encoded HTML from ColdFusion responses
function decodeHtml(raw: string): string {
  try {
    if (raw.trim().startsWith('"')) return JSON.parse(raw) as string;
  } catch {
    // not JSON
  }
  return raw;
}

// ─── Vacancy Stats ────────────────────────────────────────────────────────────

export async function fetchVacancyStats(): Promise<VacancyStats> {
  const raw = await fetchWithAuthRetry(FUNCTIONS_URL, { method: "orangebxupd" });
  const html = decodeHtml(raw);
  const $ = cheerio.load(html);

  // Structure: .panel-body contains h3 (label) and h4 (value)
  const values: number[] = [];
  $(".panel").each((_, panel) => {
    const h4 = $(panel).find("h4").first();
    const text = h4.text().trim().replace(/,/g, "");
    const num = parseInt(text, 10);
    if (!isNaN(num)) values.push(num);
  });

  return {
    totalVacant: values[0] ?? 0,
    vacUnleased: values[1] ?? 0,
    vacPreleased: values[2] ?? 0,
    onNotice: values[3] ?? 0,
    eviction: values[4] ?? 0,
  };
}

// ─── Building Vacancy Data ───────────────────────────────────────────────────

export async function fetchBuildingVacancy(overrides: Record<string, number> = {}): Promise<BuildingVacancy[]> {
  const raw = await fetchWithAuthRetry(FUNCTIONS_URL, { method: "orangebxupd" });
  const html = decodeHtml(raw);
  const $ = cheerio.load(html);

  const buildingsMap: Record<string, BuildingVacancy> = {};

  // Parse tooltip data from each panel
  const categoryMap: Record<string, keyof Omit<BuildingVacancy, "name">> = {
    "TOTAL VACANT": "totalVacant",
    "VACANT/UNLEASED": "vacUnleased",
    "VACANT/PRELEASED": "vacPreleased",
    "ON NOTICE": "onNotice",
    "EVICTION": "eviction",
  };

  $("div[title]").each((_, el) => {
    const tooltip = $(el).attr("title") || "";
    if (!tooltip) return;

    const $tip = cheerio.load(tooltip);
    const strong = $tip("strong").first().text().trim();
    const field = categoryMap[strong];
    if (!field) return;

    $tip("tr").each((_, row) => {
      const cells = $tip(row).find("td");
      if (cells.length >= 2) {
        const name = $tip(cells[0]).text().trim();
        const val = parseInt($tip(cells[1]).text().trim(), 10) || 0;
        if (!name) return;

        if (!buildingsMap[name]) {
          buildingsMap[name] = {
            name,
            totalVacant: 0,
            vacUnleased: 0,
            vacPreleased: 0,
            onNotice: 0,
            eviction: 0,
            totalUnits: 0,
            vacancyPct: 0,
            atRisk: false,
          };
        }
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (buildingsMap[name] as any)[field] = val;
      }
    });
  });

  // Add unit counts and vacancy %
  const result = Object.values(buildingsMap).map((b) => {
    const totalUnits = lookupTotalUnits(b.name, overrides);
    const vacancyPct = totalUnits > 0 ? Math.round((b.totalVacant / totalUnits) * 1000) / 10 : 0;
    return {
      ...b,
      totalUnits,
      vacancyPct,
      atRisk: vacancyPct > AT_RISK_THRESHOLD,
    };
  });

  // Sort by vacancy % descending
  return result.sort((a, b) => b.vacancyPct - a.vacancyPct);
}

// ─── Daily Snapshot & Change ─────────────────────────────────────────────────

function getTodayDateString(): string {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
}

function getYesterdayDateString(): string {
  const d = new Date();
  d.setDate(d.getDate() - 1);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

async function saveSnapshot(
  buildings: BuildingVacancy[],
  stats: VacancyStats
): Promise<void> {
  try {
    const db = await getDb();
    if (!db) return;

    const today = getTodayDateString();

    // Check if we already have a snapshot for today
    const existing = await db
      .select()
      .from(vacancySnapshots)
      .where(eq(vacancySnapshots.snapshotDate, today))
      .limit(1);

    if (existing.length > 0) {
      // Update existing snapshot
      await db
        .update(vacancySnapshots)
        .set({
          buildingData: JSON.stringify(buildings),
          totalVacant: stats.totalVacant,
          vacUnleased: stats.vacUnleased,
          vacPreleased: stats.vacPreleased,
          onNotice: stats.onNotice,
          eviction: stats.eviction,
        })
        .where(eq(vacancySnapshots.snapshotDate, today));
    } else {
      // Insert new snapshot
      await db.insert(vacancySnapshots).values({
        snapshotDate: today,
        buildingData: JSON.stringify(buildings),
        totalVacant: stats.totalVacant,
        vacUnleased: stats.vacUnleased,
        vacPreleased: stats.vacPreleased,
        onNotice: stats.onNotice,
        eviction: stats.eviction,
      });
    }
    console.log("[Scraper] Saved daily snapshot for", today);
  } catch (err) {
    console.warn("[Scraper] Failed to save snapshot:", err);
  }
}

async function getDailyChanges(todayBuildings: BuildingVacancy[]): Promise<DailyChange[]> {
  try {
    const db = await getDb();
    if (!db) return [];

    const yesterday = getYesterdayDateString();
    const rows = await db
      .select()
      .from(vacancySnapshots)
      .where(eq(vacancySnapshots.snapshotDate, yesterday))
      .limit(1);

    if (rows.length === 0) return [];

    const yesterdayData: BuildingVacancy[] = typeof rows[0].buildingData === "string"
      ? JSON.parse(rows[0].buildingData as string)
      : rows[0].buildingData as BuildingVacancy[];

    const yesterdayMap = new Map<string, number>();
    for (const b of yesterdayData) {
      yesterdayMap.set(b.name, b.totalVacant);
    }

    const changes: DailyChange[] = [];
    for (const b of todayBuildings) {
      const yVal = yesterdayMap.get(b.name) ?? 0;
      changes.push({
        building: b.name,
        todayVacant: b.totalVacant,
        yesterdayVacant: yVal,
        change: b.totalVacant - yVal,
      });
    }

    // Sort by absolute change descending
    changes.sort((a, b) => Math.abs(b.change) - Math.abs(a.change));
    return changes;
  } catch (err) {
    console.warn("[Scraper] Failed to get daily changes:", err);
    return [];
  }
}

// ─── Summary Tables ───────────────────────────────────────────────────────────

type SummaryData = {
  vacantUnleased: VacantUnit[];
  vacantPreleased: PreleasedUnit[];
  onNotice: OnNoticeUnit[];
  evictions: EvictionUnit[];
};

type SummaryField = keyof VacantUnit | keyof PreleasedUnit | keyof OnNoticeUnit | keyof EvictionUnit;

const SUMMARY_HEADER_FIELDS: Record<string, SummaryField> = {
  dateby: "dateBy",
  building: "building",
  unit: "unit",
  rdy: "percentReady",
  ready: "percentReady",
  percentready: "percentReady",
  movout: "moveOut",
  moveout: "moveOut",
  alrt: "alertDays",
  alert: "alertDays",
  alertdays: "alertDays",
  days: "days",
  movin: "moveIn",
  movein: "moveIn",
  beds: "beds",
  bedrooms: "beds",
  ask: "askRent",
  askrent: "askRent",
  askingrent: "askRent",
  leased: "leased",
  dates: "dates",
  owed: "amountOwed",
  amountowed: "amountOwed",
};

/** Parse only unit-data tables, using their own headers rather than a legacy column order. */
export function parseSummaryHtml(raw: string): SummaryData {
  const $ = cheerio.load(decodeHtml(raw));
  const result: SummaryData = { vacantUnleased: [], vacantPreleased: [], onNotice: [], evictions: [] };

  $("table").each((_, tableEl) => {
    // Notes and the eviction dates subtable are not independent unit-data tables.
    if ($(tableEl).parents("table").length > 0) return;
    const headerCells = $(tableEl).children("thead").children("tr").first().children("th, td");
    const columns: Partial<Record<SummaryField, number>> = {};
    let width = 0;
    let ambiguousHeaders = false;
    headerCells.each((_, cell) => {
      const label = $(cell).clone().find("table").remove().end().text().toLowerCase().replace(/[^a-z0-9]/g, "");
      const field = SUMMARY_HEADER_FIELDS[label];
      if (field) {
        if (columns[field] !== undefined) ambiguousHeaders = true;
        columns[field] = width;
      }
      // Blank/action headers still occupy columns (including colspanned spacers).
      width += Math.max(1, parseInt($(cell).attr("colspan") ?? "1", 10) || 1);
    });
    const has = (field: SummaryField) => columns[field] !== undefined;
    const vacancyFields: SummaryField[] = ["dateBy", "percentReady", "moveOut", "moveIn", "alertDays", "days", "beds", "askRent"];
    const isVacancy = has("moveOut") || has("moveIn") || vacancyFields.filter(has).length >= 3;
    // A note header mentioning rent/leased alone must never classify a table.
    if (!(has("building") || has("unit")) || !(isVacancy || has("leased") || has("amountOwed"))) return;

    const kind = isVacancy ? (has("moveIn") ? "vacantPreleased" : "vacantUnleased")
      : has("leased") ? "onNotice" : "evictions";
    const required: SummaryField[] = isVacancy
      ? ["dateBy", "building", "unit", "percentReady", "moveOut", "alertDays", "days", "beds", "askRent", ...(kind === "vacantPreleased" ? ["moveIn" as const] : [])]
      : kind === "onNotice" ? ["building", "unit", "leased"] : ["building", "unit", "dates", "amountOwed"];
    const missing = required.filter(field => !has(field));
    if (missing.length > 0 || ambiguousHeaders) {
      // Never turn an upstream header change into shifted but plausible unit values.
      throw new Error(`PropertyMax ${kind} summary has ${ambiguousHeaders ? "ambiguous headers" : `missing headers: ${missing.join(", ")}`}`);
    }

    $(tableEl).children("tbody").children("tr").each((_, row) => {
      const cells = $(row).children("td");
      // Note-only rows span the table; don't flatten them into unit columns.
      if (cells.length === 0 || cells.toArray().some(cell => (parseInt($(cell).attr("colspan") ?? "1", 10) || 1) > 1)) return;
      if (cells.length < width) return;
      const cellFor = (field: SummaryField) => cells.eq(columns[field]!);
      const text = (field: SummaryField) => cellFor(field).clone().find("table").remove().end().text().trim();
      const building = cellFor("building").clone().find("table").remove().end();
      const buildingName = building.find("a").text().trim() || building.text().trim();
      if (!buildingName) return;
      const identity = { building: buildingName, unit: text("unit") };
      const integer = (field: SummaryField) => parseInt(text(field), 10) || 0;
      const currency = (field: SummaryField) => parseFloat(text(field).replace(/[$,\s]/g, "")) || 0;

      if (isVacancy) {
        const unit: VacantUnit = {
          dateBy: text("dateBy").replace(/\s+/g, " "),
          ...identity,
          moveOut: text("moveOut"),
          alertDays: text("alertDays"),
          days: integer("days"),
          beds: integer("beds"),
          askRent: currency("askRent"),
          percentReady: integer("percentReady"),
        };
        if (kind === "vacantPreleased") result.vacantPreleased.push({ ...unit, moveIn: text("moveIn") });
        else result.vacantUnleased.push(unit);
      } else if (kind === "onNotice") {
        result.onNotice.push({ ...identity, leased: text("leased") });
      } else {
        result.evictions.push({
          ...identity,
          // Preserve the existing flattened Served/Court/Possession dates semantics.
          dates: cellFor("dates").text().trim().replace(/\s+/g, " "),
          amountOwed: currency("amountOwed"),
        });
      }
    });
  });
  return result;
}

export async function fetchSummaryData(regionId: number = 1): Promise<SummaryData> {
  const raw = await fetchWithAuthRetry(FUNCTIONS_URL, {
    method: "getsummary",
    regionid: String(regionId),
  });
  const html = decodeHtml(raw);
  if (html.includes('<title>ERROR</title>')) {
    console.warn(`[Scraper] fetchSummaryData(${regionId}) returned an ERROR page — SESSION may not be initialized`);
  }
  return parseSummaryHtml(raw);
}

// ─── Marc's Net Cash ──────────────────────────────────────────────────────────

const REGION_NAMES: Record<number, string> = {
  1: "Region 1",
  2: "Region 2",
  3: "Region 3",
  4: "Region 4",
};

export async function fetchMarcsNetCash(regionId: number, dt?: string, options?: { strict?: boolean }): Promise<MarcsNetCash> {
  const params: Record<string, string> = {
    method: "getpaymentsfromdatabase",
    regionid: String(regionId),
    dt: dt ?? `${new Date().getFullYear()}-${String(new Date().getMonth() + 1).padStart(2, "0")}-01`,
  };

  const raw = await fetchWithAuthRetry(FUNCTIONS_URL, params);
  if (options?.strict) return parseStrictMonthlyNetCashHtml(raw, regionId);
  const html = decodeHtml(raw);
  const $ = cheerio.load(html);

  // Find Net Cash Flow row (previously labelled "Marc's Net Cash" — now "Net Cash Flow" in the UI)
  let marcsRow: ReturnType<typeof $> | null = null;
  $("tr").each((_, row) => {
    const text = $(row).text();
    if ((text.includes("Net Cash Flow") || text.includes("Marc's Net Cash") || text.includes("Marc\u2019s Net Cash")) && !marcsRow) {
      marcsRow = $(row);
    }
  });

  if (!marcsRow) {
    return { region: regionId, regionName: REGION_NAMES[regionId] ?? `Region ${regionId}`, total: 0, buildings: [] };
  }

  // Get building names from the table header
  const table = $(marcsRow as ReturnType<typeof $>).closest("table");
  const headerCells: string[] = [];
  table.find("thead tr").first().find("th, td").each((_, th) => {
    const text = $(th).text().trim().replace(/★/g, "").trim();
    headerCells.push(text);
  });
  const buildingNames = headerCells.filter((h) => h.length > 0);

  // Extract strong (black text) values
  const strongValues: number[] = [];
  $(marcsRow as ReturnType<typeof $>).find("strong").each((_, el) => {
    const text = $(el).text().trim().replace(/,/g, "");
    if (text && !text.includes("Marc") && !text.includes("Cash") && !text.includes("Flow")) {
      const val = parseFloat(text);
      if (!isNaN(val)) strongValues.push(val);
    }
  });

  // If no strong values found, try plain td text values (some rows don't use <strong>)
  const finalValues = strongValues.length > 0 ? strongValues : (() => {
    const vals: number[] = [];
    (marcsRow as ReturnType<typeof $>).find("td").each((_, td) => {
      const text = $(td).text().trim().replace(/,/g, "").replace(/\$/g, "");
      if (!text || text.includes("Net") || text.includes("Cash") || text.includes("Flow") || text.includes("Marc")) return;
      const val = parseFloat(text);
      if (!isNaN(val)) vals.push(val);
    });
    return vals;
  })();

  const buildings = buildingNames.map((name, i) => ({
    name,
    value: finalValues[i] ?? 0,
  }));

  const total = finalValues.reduce((sum, v) => sum + v, 0);

  return {
    region: regionId,
    regionName: REGION_NAMES[regionId] ?? `Region ${regionId}`,
    total,
    buildings,
  };
}

export async function fetchAllRegionsMarcsNetCash(dt?: string, options?: { strict?: boolean }): Promise<MarcsNetCash[]> {
  const results = await Promise.all([
    fetchMarcsNetCash(1, dt, options),
    fetchMarcsNetCash(2, dt, options),
    fetchMarcsNetCash(3, dt, options),
    fetchMarcsNetCash(4, dt, options),
  ]);
  return results;
}

// ─── Historical Data ──────────────────────────────────────────────────────────

const MONTH_NAMES = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December",
];

function isCompleteMonth(year: number, month: number): boolean {
  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonth = now.getMonth() + 1;
  if (year < currentYear) return true;
  if (year === currentYear && month < currentMonth) return true;
  return false;
}

export async function fetchHistoricalMonths(monthsBack = 12): Promise<HistoricalMonth[]> {
  const now = new Date();
  const months: { year: number; month: number }[] = [];

  for (let i = 1; i <= monthsBack; i++) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const year = d.getFullYear();
    const month = d.getMonth() + 1;
    if (isCompleteMonth(year, month)) {
      months.push({ year, month });
    }
  }

  const results: HistoricalMonth[] = [];
  const db = await getDb();

  for (const { year, month } of months) {
    const monthKey = `${year}-${String(month).padStart(2, "0")}`;

    // Try DB cache first
    if (db) {
      try {
        const cached = await db.select().from(historicalCache).where(eq(historicalCache.monthKey, monthKey)).limit(1);
        if (cached.length > 0) {
          const data = typeof cached[0].data === "string" ? JSON.parse(cached[0].data as string) : cached[0].data as HistoricalMonth;
          results.push(data);
          continue;
        }
      } catch (err) {
        console.warn(`[Scraper] Cache read failed for ${monthKey}:`, err);
      }
    }

    // Not cached — fetch from source
    const dt = `${monthKey}-01`;
    try {
      const regions = await fetchAllRegionsMarcsNetCash(dt);
      const grandTotal = regions.reduce((sum, r) => sum + r.total, 0);
      const histMonth: HistoricalMonth = {
        year,
        month,
        monthName: MONTH_NAMES[month - 1],
        label: `${MONTH_NAMES[month - 1]} ${year}`,
        regions,
        grandTotal,
      };
      results.push(histMonth);

      // Save to DB cache
      if (db) {
        try {
          await db.insert(historicalCache).values({
            monthKey,
            data: JSON.stringify(histMonth),
          }).onDuplicateKeyUpdate({ set: { data: JSON.stringify(histMonth) } });
          console.log(`[Scraper] Cached historical data for ${monthKey}`);
        } catch (err) {
          console.warn(`[Scraper] Cache write failed for ${monthKey}:`, err);
        }
      }
    } catch (err) {
      console.warn(`[Scraper] Failed to fetch historical data for ${dt}:`, err);
    }
  }

  return results;
}

// ─── Full Dashboard ───────────────────────────────────────────────────────────

let cachedData: DashboardData | null = null;
let lastCompleteDashboardData: DashboardData | null = null;
let cacheTime = 0;
const CACHE_TTL_MS = 30 * 60 * 1000;
/** Keep the dashboard within one minute of live PropertyMax FLOW values. */
export const COLLECTIONS_SNAPSHOT_TTL_MS = 60 * 1000;

export function isCollectionsSnapshotFresh(createdAt: Date | null | undefined, now = Date.now()): boolean {
  if (!createdAt) return false;
  return now - new Date(createdAt).getTime() < COLLECTIONS_SNAPSHOT_TTL_MS;
}

export async function fetchDashboardData(forceRefresh = false): Promise<DashboardData> {
  const now = Date.now();
  if (!forceRefresh && cachedData && now - cacheTime < CACHE_TTL_MS) {
    if (hasVacancyUnitDetailCoverage(cachedData)) return cachedData;
    console.warn("[Scraper] Discarding cached dashboard data because unit-detail coverage is incomplete");
    cachedData = null;
    cacheTime = 0;
  }

  console.log("[Scraper] Fetching fresh dashboard data...");

  // Load DB unit count overrides (takes priority over hardcoded values)
  const unitOverrides = await getUnitOverridesMap().catch(() => ({} as Record<string, number>));

  // Pre-authenticate once before parallel fetches to avoid 6 simultaneous login attempts
  await authenticate();

  // Fetch stats, building vacancy, all 4 region summaries, AND payments in parallel
  const [stats, buildingVacancy, sum1, sum2, sum3, sum4] = await Promise.all([
    fetchVacancyStats(),
    fetchBuildingVacancy(unitOverrides),
    fetchSummaryData(1),
    fetchSummaryData(2),
    fetchSummaryData(3),
    fetchSummaryData(4),
  ]);

  const unitDetails = {
    stats,
    vacantUnleased: [...sum1.vacantUnleased, ...sum2.vacantUnleased, ...sum3.vacantUnleased, ...sum4.vacantUnleased],
    vacantPreleased: [...sum1.vacantPreleased, ...sum2.vacantPreleased, ...sum3.vacantPreleased, ...sum4.vacantPreleased],
    onNotice: [...sum1.onNotice, ...sum2.onNotice, ...sum3.onNotice, ...sum4.onNotice],
    evictions: [...sum1.evictions, ...sum2.evictions, ...sum3.evictions, ...sum4.evictions],
  };
  if (!hasVacancyUnitDetailCoverage(unitDetails)) {
    throw new Error("PropertyMax returned incomplete unit-detail data; refusing to cache or email an abbreviated Daily Vacancy Report");
  }

  // Save daily snapshot and compute daily changes
  await saveSnapshot(buildingVacancy, stats);
  const dailyChanges = await getDailyChanges(buildingVacancy);

  // Fetch and save payments snapshot in background (non-blocking — don't delay dashboard)
  fetchAndSavePaymentsSnapshot().catch((err) =>
    console.warn("[Scraper] Background payments fetch failed:", err)
  );

  // Return dashboard immediately with empty historical data, then fetch in background
  // First time: fetch historical (will be slow but cached for next time)
  // Subsequent: reads from DB cache (fast)
  const historicalMonths = await fetchHistoricalMonths(12);

  cachedData = {
    ...unitDetails,
    buildingVacancy,
    dailyChanges,
    historicalMonths,
    lastUpdated: new Date(),
  };
  lastCompleteDashboardData = cachedData;
  cacheTime = now;

  console.log("[Scraper] Dashboard data fetched successfully");
  return cachedData;
}

export function getCachedData(): DashboardData | null {
  return cachedData;
}

/** The most recent fully validated snapshot, retained across a failed live refresh. */
export function getLastCompleteDashboardData(): DashboardData | null {
  return lastCompleteDashboardData;
}

export function invalidateCache(): void {
  cachedData = null;
  cacheTime = 0;
  sessionCookieJar = {};
  lastAuthTime = 0;
}

// ─── Browser-Ingested Raw Data ────────────────────────────────────────────────
// Called when the browser fetches raw HTML from propertymax.ai and sends it here.
// We parse it with the existing cheerio parsers and update the in-memory cache.

export interface RawDataPayload {
  orangebxupd: string;           // method=orangebxupd (stats + building vacancy)
  summary1: string;              // method=getsummary&regionid=1
  summary2: string;              // method=getsummary&regionid=2
  summary3: string;              // method=getsummary&regionid=3
  summary4: string;              // method=getsummary&regionid=4
}

export async function parseAndIngestRawData(payload: RawDataPayload): Promise<DashboardData> {
  // Parse stats from orangebxupd HTML
  const statsHtml = decodeHtml(payload.orangebxupd);
  const $stats = cheerio.load(statsHtml);
  const statValues: number[] = [];
  $stats(".panel").each((_, panel) => {
    const h4 = $stats(panel).find("h4").first();
    const text = h4.text().trim().replace(/,/g, "");
    const num = parseInt(text, 10);
    if (!isNaN(num)) statValues.push(num);
  });
  const stats: VacancyStats = {
    totalVacant: statValues[0] ?? 0,
    vacUnleased: statValues[1] ?? 0,
    vacPreleased: statValues[2] ?? 0,
    onNotice: statValues[3] ?? 0,
    eviction: statValues[4] ?? 0,
  };

  // Parse building vacancy from orangebxupd HTML (same HTML, different parsing)
  const buildingsMap: Record<string, BuildingVacancy> = {};
  const categoryMap: Record<string, keyof Omit<BuildingVacancy, "name">> = {
    "TOTAL VACANT": "totalVacant",
    "VACANT/UNLEASED": "vacUnleased",
    "VACANT/PRELEASED": "vacPreleased",
    "ON NOTICE": "onNotice",
    "EVICTION": "eviction",
  };
  $stats("div[title]").each((_, el) => {
    const tooltip = $stats(el).attr("title") || "";
    if (!tooltip) return;
    const $tip = cheerio.load(tooltip);
    const strong = $tip("strong").first().text().trim();
    const field = categoryMap[strong];
    if (!field) return;
    $tip("tr").each((_, row) => {
      const cells = $tip(row).find("td");
      if (cells.length >= 2) {
        const name = $tip(cells[0]).text().trim();
        const val = parseInt($tip(cells[1]).text().trim(), 10) || 0;
        if (!name) return;
        if (!buildingsMap[name]) {
          buildingsMap[name] = { name, totalVacant: 0, vacUnleased: 0, vacPreleased: 0, onNotice: 0, eviction: 0, totalUnits: 0, vacancyPct: 0, atRisk: false };
        }
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (buildingsMap[name] as any)[field] = val;
      }
    });
  });
  const buildingVacancy: BuildingVacancy[] = Object.values(buildingsMap).map((b) => {
    const totalUnits = lookupTotalUnits(b.name);
    const vacancyPct = totalUnits > 0 ? Math.round((b.totalVacant / totalUnits) * 1000) / 10 : 0;
    return { ...b, totalUnits, vacancyPct, atRisk: vacancyPct > AT_RISK_THRESHOLD };
  }).sort((a, b) => b.vacancyPct - a.vacancyPct);

  const sum1 = parseSummaryHtml(payload.summary1);
  const sum2 = parseSummaryHtml(payload.summary2);
  const sum3 = parseSummaryHtml(payload.summary3);
  const sum4 = parseSummaryHtml(payload.summary4);

  // Save snapshot and compute daily changes
  await saveSnapshot(buildingVacancy, stats);
  const dailyChanges = await getDailyChanges(buildingVacancy);

  // Use existing historical months from cache or DB (don't re-fetch — no server-side access)
  const historicalMonths = cachedData?.historicalMonths ?? [];

  cachedData = {
    stats,
    vacantUnleased: [...sum1.vacantUnleased, ...sum2.vacantUnleased, ...sum3.vacantUnleased, ...sum4.vacantUnleased],
    vacantPreleased: [...sum1.vacantPreleased, ...sum2.vacantPreleased, ...sum3.vacantPreleased, ...sum4.vacantPreleased],
    onNotice: [...sum1.onNotice, ...sum2.onNotice, ...sum3.onNotice, ...sum4.onNotice],
    evictions: [...sum1.evictions, ...sum2.evictions, ...sum3.evictions, ...sum4.evictions],
    buildingVacancy,
    dailyChanges,
    historicalMonths,
    lastUpdated: new Date(),
  };
  cacheTime = Date.now();

  console.log("[Scraper] Ingested browser-fetched data successfully");
  return cachedData;
}

// ─── Weekly Summary ─────────────────────────────────────────────────────────

export interface WeeklyBuildingTrend {
  name: string;
  startVacant: number;
  endVacant: number;
  netChange: number;
  peakVacant: number;
  lowVacant: number;
  totalUnits: number;
  startPct: number;
  endPct: number;
  dailyValues: { date: string; vacant: number }[];
}

export interface WeeklyDailyChange {
  date: string;
  changes: { building: string; prevVacant: number; newVacant: number; change: number }[];
}

export interface WeeklySummaryData {
  weekStart: string; // YYYY-MM-DD
  weekEnd: string;
  totalBuildingsChanged: number;
  totalNetChange: number;
  startTotalVacant: number;
  endTotalVacant: number;
  buildingTrends: WeeklyBuildingTrend[];
  dailyChanges: WeeklyDailyChange[];
  topIncreases: WeeklyBuildingTrend[];
  topDecreases: WeeklyBuildingTrend[];
  currentStats: VacancyStats | null;
  currentAtRisk: BuildingVacancy[];
}

export async function getWeeklySummary(): Promise<WeeklySummaryData> {
  const db = await getDb();
  const snapshots: { snapshotDate: string; buildingData: BuildingVacancy[]; totalVacant: number; vacUnleased: number; vacPreleased: number; onNotice: number; eviction: number }[] = [];

  if (db) {
    const rows = await db
      .select()
      .from(vacancySnapshots)
      .orderBy(desc(vacancySnapshots.snapshotDate))
      .limit(8); // up to 8 to get 7 full days of changes

    for (const row of rows.reverse()) {
      const bData = typeof row.buildingData === "string"
        ? JSON.parse(row.buildingData as string)
        : (row.buildingData as BuildingVacancy[]);
      snapshots.push({
        snapshotDate: row.snapshotDate,
        buildingData: bData,
        totalVacant: row.totalVacant,
        vacUnleased: row.vacUnleased,
        vacPreleased: row.vacPreleased,
        onNotice: row.onNotice,
        eviction: row.eviction,
      });
    }
  }

  const weekEnd = snapshots.length > 0 ? snapshots[snapshots.length - 1].snapshotDate : getTodayDateString();
  const weekStart = snapshots.length > 0 ? snapshots[0].snapshotDate : getTodayDateString();

  // Build per-building trends across the week
  const buildingMap = new Map<string, { dailyValues: { date: string; vacant: number }[]; totalUnits: number }>();

  for (const snap of snapshots) {
    for (const b of snap.buildingData) {
      if (!buildingMap.has(b.name)) {
        buildingMap.set(b.name, { dailyValues: [], totalUnits: b.totalUnits });
      }
      buildingMap.get(b.name)!.dailyValues.push({ date: snap.snapshotDate, vacant: b.totalVacant });
    }
  }

  const buildingTrends: WeeklyBuildingTrend[] = [];
  for (const [name, data] of Array.from(buildingMap)) {
    const vals = data.dailyValues;
    if (vals.length === 0) continue;
    const startVacant = vals[0].vacant;
    const endVacant = vals[vals.length - 1].vacant;
    const peakVacant = Math.max(...vals.map((v: { date: string; vacant: number }) => v.vacant));
    const lowVacant = Math.min(...vals.map((v: { date: string; vacant: number }) => v.vacant));
    const totalUnits = data.totalUnits || lookupTotalUnits(name);
    buildingTrends.push({
      name,
      startVacant,
      endVacant,
      netChange: endVacant - startVacant,
      peakVacant,
      lowVacant,
      totalUnits,
      startPct: totalUnits > 0 ? Math.round((startVacant / totalUnits) * 1000) / 10 : 0,
      endPct: totalUnits > 0 ? Math.round((endVacant / totalUnits) * 1000) / 10 : 0,
      dailyValues: vals,
    });
  }

  // Compute daily changes (day-over-day)
  const dailyChanges: WeeklyDailyChange[] = [];
  for (let i = 1; i < snapshots.length; i++) {
    const prevSnap = snapshots[i - 1];
    const currSnap = snapshots[i];
    const prevMap = new Map<string, number>();
    for (const b of prevSnap.buildingData) prevMap.set(b.name, b.totalVacant);

    const changes: { building: string; prevVacant: number; newVacant: number; change: number }[] = [];
    for (const b of currSnap.buildingData) {
      const prev = prevMap.get(b.name) ?? 0;
      if (b.totalVacant !== prev) {
        changes.push({ building: b.name, prevVacant: prev, newVacant: b.totalVacant, change: b.totalVacant - prev });
      }
    }
    if (changes.length > 0) {
      changes.sort((a, b) => Math.abs(b.change) - Math.abs(a.change));
      dailyChanges.push({ date: currSnap.snapshotDate, changes });
    }
  }

  // Top movers
  const changedBuildings = buildingTrends.filter(b => b.netChange !== 0);
  const topIncreases = [...changedBuildings].filter(b => b.netChange > 0).sort((a, b) => b.netChange - a.netChange).slice(0, 5);
  const topDecreases = [...changedBuildings].filter(b => b.netChange < 0).sort((a, b) => a.netChange - b.netChange).slice(0, 5);

  const startTotalVacant = snapshots.length > 0 ? snapshots[0].totalVacant : 0;
  const endTotalVacant = snapshots.length > 0 ? snapshots[snapshots.length - 1].totalVacant : 0;

  // Current stats from latest snapshot
  const latest = snapshots.length > 0 ? snapshots[snapshots.length - 1] : null;
  const currentStats: VacancyStats | null = latest ? {
    totalVacant: latest.totalVacant,
    vacUnleased: latest.vacUnleased,
    vacPreleased: latest.vacPreleased,
    onNotice: latest.onNotice,
    eviction: latest.eviction,
  } : null;

  const currentAtRisk = latest ? latest.buildingData.filter(b => b.atRisk).sort((a, b) => b.vacancyPct - a.vacancyPct) : [];

  return {
    weekStart,
    weekEnd,
    totalBuildingsChanged: changedBuildings.length,
    totalNetChange: endTotalVacant - startTotalVacant,
    startTotalVacant,
    endTotalVacant,
    buildingTrends: buildingTrends.sort((a, b) => Math.abs(b.netChange) - Math.abs(a.netChange)),
    dailyChanges,
    topIncreases,
    topDecreases,
    currentStats,
    currentAtRisk,
  };
}

// ─── Payments: Net Rent Collected + Net Cash Flow ────────────────────────────

/**
 * Parse Net Rent Collected and Net Cash Flow per building from a single region's
 * getpaymentsfromdatabase HTML response.
 */
function parsePaymentsHtml(
  html: string,
  regionId: number
): BuildingPaymentData[] {
  const $ = cheerio.load(html);
  const regionName = REGION_NAMES[regionId] ?? `Region ${regionId}`;

  // Building names are in <th> elements inside the payments summary table.
  // The table header alternates: [empty spacer th] [building name th] [empty spacer th] ...
  // The very first th contains a <select> (building selector) — skip it.
  // We collect all th text values that look like building names (non-empty, no numbers).
  const buildingNames: string[] = [];
  $("table th").each((_, th) => {
    const text = $(th).text().replace(/[★*]/g, "").trim();
    // Skip: empty, contains numbers (date columns like "Mar 2026"), or contains select elements
    if (!text) return;
    if ($(th).find("select").length > 0) return;
    if (/\d{4}/.test(text)) return; // skip year-containing headers (month columns)
    if (text.length > 40) return; // skip long text (not a building name)
    buildingNames.push(text);
  });

  // Find Net Rent Collected row and Net Cash Flow row
  let netRentRow: ReturnType<typeof $> | null = null;
  let netCashFlowRow: ReturnType<typeof $> | null = null;
  $("tr").each((_, row) => {
    const rowText = $(row).text();
    if (rowText.includes("Net Rent Collected") && !netRentRow) netRentRow = $(row);
    if (rowText.includes("Net Cash Flow") && !netCashFlowRow) netCashFlowRow = $(row);
  });

  /**
   * Extract per-building values from a summary row.
   * Structure: first td = label (colspan=2), then alternating [value td][spacer td] per building.
   * Each value td contains a <strong> with the final net value.
   * We skip the first td (label) and the empty spacer tds, collecting only tds with a <strong> number.
   */
  function extractTdStrongValues(row: ReturnType<typeof $> | null): number[] {
    if (!row) return [];
    const vals: number[] = [];
    (row as ReturnType<typeof $>).find("td").each((_, td) => {
      const strong = $(td).find("strong").last(); // last strong = the net value (not the label)
      if (!strong.length) return;
      const text = strong.text().trim().replace(/,/g, "").replace(/\s/g, "");
      const num = parseFloat(text);
      if (!isNaN(num)) vals.push(num);
    });
    return vals;
  }

  const rentValues = extractTdStrongValues(netRentRow);
  const cashValues = extractTdStrongValues(netCashFlowRow);

  return buildingNames.map((name, i) => ({
    buildingName: name,
    regionId,
    regionName,
    netRentCollected: rentValues[i] ?? 0,
    netCashFlow: cashValues[i] ?? 0,
  }));
}

/**
 * Fetch Net Rent Collected + Net Cash Flow for all 4 regions and save to DB.
 * Uses the same vacancy.cfc endpoint as Marc's Net Cash.
 */
export async function fetchAndSavePaymentsSnapshot(dt?: string): Promise<PaymentsSnapshot> {
  const today = getTodayDateString();
  const dtParam = dt ?? `${today.slice(0, 7)}-01`;

  // Fetch all 4 regions in parallel
  const regionHtmls = await Promise.all(
    [1, 2, 3, 4].map((rid) =>
      fetchWithAuthRetry(FUNCTIONS_URL, {
        method: "getpaymentsfromdatabase",
        regionid: String(rid),
        dt: dtParam,
      }).then(decodeHtml)
    )
  );

  const allBuildings: BuildingPaymentData[] = [];
  for (let i = 0; i < 4; i++) {
    const parsed = parsePaymentsHtml(regionHtmls[i], i + 1);
    allBuildings.push(...parsed);
  }

  // Persist to DB (upsert by date + building name)
  const db = await getDb();
  if (db && allBuildings.length > 0) {
    try {
      const { buildingPayments } = await import("../drizzle/schema");
      // Delete existing rows for today to avoid duplicates
      const { eq: drizzleEq } = await import("drizzle-orm");
      await db.delete(buildingPayments).where(drizzleEq(buildingPayments.snapshotDate, today));
      // Insert fresh rows
      await db.insert(buildingPayments).values(
        allBuildings.map((b) => ({
          snapshotDate: today,
          buildingName: b.buildingName,
          regionId: b.regionId,
          netRentCollected: String(b.netRentCollected),
          netCashFlow: String(b.netCashFlow),
        }))
      );
      console.log(`[Scraper] Saved ${allBuildings.length} building payment records for ${today}`);
    } catch (err) {
      console.warn("[Scraper] Failed to save payments snapshot:", err);
    }
  }

  const totalNetRentCollected = allBuildings.reduce((s, b) => s + b.netRentCollected, 0);
  const totalNetCashFlow = allBuildings.reduce((s, b) => s + b.netCashFlow, 0);

  return { snapshotDate: today, buildings: allBuildings, totalNetRentCollected, totalNetCashFlow };
}

/**
 * Get today's payments snapshot from DB, or fetch fresh if not available.
 */
export async function getPaymentsSnapshot(forceRefresh = false): Promise<PaymentsSnapshot | null> {
  const today = getTodayDateString();
  const db = await getDb();

  if (!forceRefresh && db) {
    try {
      const { buildingPayments } = await import("../drizzle/schema");
      const { eq: drizzleEq } = await import("drizzle-orm");
      const rows = await db.select().from(buildingPayments).where(drizzleEq(buildingPayments.snapshotDate, today));
      if (rows.length > 0) {
        const buildings: BuildingPaymentData[] = rows.map((r) => ({
          buildingName: r.buildingName,
          regionId: r.regionId,
          netRentCollected: parseFloat(r.netRentCollected),
          netCashFlow: parseFloat(r.netCashFlow),
          regionName: REGION_NAMES[r.regionId] ?? `Region ${r.regionId}`,
        }));
        return {
          snapshotDate: today,
          buildings,
          totalNetRentCollected: buildings.reduce((s, b) => s + b.netRentCollected, 0),
          totalNetCashFlow: buildings.reduce((s, b) => s + b.netCashFlow, 0),
        };
      }
    } catch (err) {
      console.warn("[Scraper] Failed to read payments from DB:", err);
    }
  }

  // Not in DB — fetch fresh
  try {
    return await fetchAndSavePaymentsSnapshot();
  } catch (err) {
    console.warn("[Scraper] Failed to fetch payments snapshot:", err);
    return null;
  }
}

/**
 * Get payments for a specific date from DB.
 */
export async function getPaymentsForDate(date: string): Promise<BuildingPaymentData[]> {
  const db = await getDb();
  if (!db) return [];
  try {
    const { buildingPayments } = await import("../drizzle/schema");
    const { eq: drizzleEq } = await import("drizzle-orm");
    const rows = await db.select().from(buildingPayments).where(drizzleEq(buildingPayments.snapshotDate, date));
    return rows.map((r) => ({
      buildingName: r.buildingName,
      regionId: r.regionId,
      netRentCollected: parseFloat(r.netRentCollected),
      netCashFlow: parseFloat(r.netCashFlow),
      regionName: REGION_NAMES[r.regionId] ?? `Region ${r.regionId}`,
    }));
  } catch (err) {
    console.warn("[Scraper] Failed to get payments for date:", err);
    return [];
  }
}

// ─── Vacancy History for Sparklines ──────────────────────────────────────────

export interface VacancyHistoryPoint {
  date: string;
  buildings: Record<string, number>; // building name -> total vacant
  totalVacant: number;
}

export async function getVacancyHistory(days = 30): Promise<VacancyHistoryPoint[]> {
  try {
    const db = await getDb();
    if (!db) return [];

    const rows = await db
      .select()
      .from(vacancySnapshots)
      .orderBy(desc(vacancySnapshots.snapshotDate))
      .limit(days);

    return rows.reverse().map((row) => {
      const bData = typeof row.buildingData === "string"
        ? JSON.parse(row.buildingData as string)
        : (row.buildingData as BuildingVacancy[]);

      const buildings: Record<string, number> = {};
      for (const b of bData) {
        buildings[b.name] = b.totalVacant;
      }

      return {
        date: row.snapshotDate,
        buildings,
        totalVacant: row.totalVacant,
      };
    });
  } catch (err) {
    console.warn("[Scraper] Failed to get vacancy history:", err);
    return [];
  }
}

// ─── Collections (FLOW Tab) Scraper ──────────────────────────────────────────

export interface BuildingCollectionData {
  buildingName: string;
  regionId: number;
  regionName: string;
  rentBilled: number;
  rentCollected: number;
  utilityReimbursement: number;
  vouchersCount: number;
  collectionPct: number; // rentCollected / rentBilled * 100
}

export interface CollectionsSnapshot {
  snapshotDate: string;
  buildings: BuildingCollectionData[];
  totalRentBilled: number;
  totalRentCollected: number;
  overallCollectionPct: number;
}

/**
 * Parse the getpaymentsfromdatabase HTML to extract FLOW tab data:
 * Rent Billed, Rent Collected, Utility Reimbursement, Vouchers per building.
 *
 * The HTML has a single large table where:
 * - Row 0: building names (in <td> cells, first cell contains a <select>)
 * - Row "Rent Billed": billed amounts per building column
 * - Row "Utility Reimbursement Received": utility amounts per building column
 * - Row "Rent Collected (Manager)": collected amounts per building column
 * - Row "Vouchers [Current / Goal]": voucher counts per building column
 */
export function parseCollectionsHtml(html: string, regionId: number): BuildingCollectionData[] {
  const $ = cheerio.load(html);
  const regionName = REGION_NAMES[regionId] ?? `Region ${regionId}`;

  // Building names are in <th> elements (odd-indexed: 1, 3, 5, 7...)
  // Same structure as parsePaymentsHtml — th[0] is empty, th[1] = first building, etc.
  const buildingNames: string[] = [];
  $("table th").each((_, th) => {
    const text = $(th).text().replace(/[★*]/g, "").replace(/\s+/g, " ").trim();
    if (!text) return;
    if ($(th).find("select").length > 0) return; // skip the dropdown th
    if (/\d{4}/.test(text)) return; // skip year-containing headers
    buildingNames.push(text);
  });

  const rows = $("tr");

  // Helper: extract numeric values from a row by label match
  function extractRowValues(labelFragment: string): number[] {
    const vals: number[] = [];
    rows.each((_, row) => {
      const cells = $(row).find("td");
      const label = cells.first().text().replace(/\s+/g, " ").trim();
      if (label.includes(labelFragment)) {
        cells.each((ci, cell) => {
          if (ci === 0) return; // skip label cell
          const text = $(cell).text().replace(/\s+/g, " ").trim();
          if (!text) return; // skip the empty spacer cell after each building value
          // Extract first number found
          const match = text.match(/[\d,]+\.?\d*/);
          if (match) {
            vals.push(parseFloat(match[0].replace(/,/g, "")));
          } else {
            vals.push(0);
          }
        });
        return false; // break after first match
      }
    });
    return vals;
  }

  // Helper: extract voucher counts (format: "[24 / 0]")
  function extractVoucherValues(): number[] {
    const vals: number[] = [];
    rows.each((_, row) => {
      const cells = $(row).find("td");
      const label = cells.first().text().replace(/\s+/g, " ").trim();
      if (label.includes("Vouchers")) {
        cells.each((ci, cell) => {
          if (ci === 0) return;
          const text = $(cell).text().replace(/\s+/g, " ").trim();
          if (!text) return; // skip the empty spacer cell after each building value
          const match = text.match(/\[(\d+)\s*\/\s*\d+\]/);
          vals.push(match ? parseInt(match[1]) : 0);
        });
        return false;
      }
    });
    return vals;
  }

  const billedValues = extractRowValues("Rent Billed");
  const collectedValues = extractRowValues("Rent Collected");
  const utilityValues = extractRowValues("Utility Reimbursement");
  const voucherValues = extractVoucherValues();

  return buildingNames.map((name, i) => {
    const billed = billedValues[i] ?? 0;
    const collected = collectedValues[i] ?? 0;
    const pct = billed > 0 ? Math.round((collected / billed) * 1000) / 10 : 0;
    return {
      buildingName: name,
      regionId,
      regionName,
      rentBilled: billed,
      rentCollected: collected,
      utilityReimbursement: utilityValues[i] ?? 0,
      vouchersCount: voucherValues[i] ?? 0,
      collectionPct: pct,
    };
  });
}

/** Returns the authenticated raw FLOW report for diagnostics and parser validation. */
export async function fetchFlowReportHtml(regionId: number, dt?: string): Promise<string> {
  const today = getTodayDateString();
  const dtParam = dt ?? `${today.slice(0, 7)}-01`;
  const response = await fetchWithAuthRetry(FUNCTIONS_URL, {
    method: "getpaymentsfromdatabase",
    regionid: String(regionId),
    dt: dtParam,
  });
  return decodeHtml(response);
}

/**
 * Fetch FLOW tab data for all 4 regions and save to building_collections table.
 */
export async function fetchAndSaveCollectionsSnapshot(dt?: string): Promise<CollectionsSnapshot> {
  const today = getTodayDateString();
  const dtParam = dt ?? `${today.slice(0, 7)}-01`;

  const regionHtmls = await Promise.all(
    [1, 2, 3, 4].map((rid) => fetchFlowReportHtml(rid, dtParam))
  );

  const allBuildings: BuildingCollectionData[] = [];
  for (let i = 0; i < 4; i++) {
    const parsed = parseCollectionsHtml(regionHtmls[i], i + 1);
    allBuildings.push(...parsed);
  }

  const db = await getDb();
  if (db && allBuildings.length > 0) {
    try {
      const { buildingCollections } = await import("../drizzle/schema");
      const { eq: drizzleEq } = await import("drizzle-orm");
      await db.delete(buildingCollections).where(drizzleEq(buildingCollections.snapshotDate, today));
      await db.insert(buildingCollections).values(
        allBuildings.map((b) => ({
          snapshotDate: today,
          buildingName: b.buildingName,
          regionId: b.regionId,
          rentBilled: String(b.rentBilled),
          rentCollected: String(b.rentCollected),
          utilityReimbursement: String(b.utilityReimbursement),
          vouchersCount: b.vouchersCount,
          collectionPct: String(b.collectionPct),
        }))
      );
      console.log(`[Scraper] Saved ${allBuildings.length} building collection records for ${today}`);
    } catch (err) {
      console.warn("[Scraper] Failed to save collections snapshot:", err);
    }
  }

  const totalRentBilled = allBuildings.reduce((s, b) => s + b.rentBilled, 0);
  const totalRentCollected = allBuildings.reduce((s, b) => s + b.rentCollected, 0);
  const overallCollectionPct = totalRentBilled > 0
    ? Math.round((totalRentCollected / totalRentBilled) * 1000) / 10
    : 0;

  return { snapshotDate: today, buildings: allBuildings, totalRentBilled, totalRentCollected, overallCollectionPct };
}

/**
 * Get today's collections snapshot from DB, or fetch fresh if not available.
 */
export async function getCollectionsSnapshot(forceRefresh = false): Promise<CollectionsSnapshot | null> {
  const today = getTodayDateString();
  const db = await getDb();

  if (!forceRefresh && db) {
    try {
      const { buildingCollections } = await import("../drizzle/schema");
      const { eq: drizzleEq } = await import("drizzle-orm");
      const rows = await db.select().from(buildingCollections).where(drizzleEq(buildingCollections.snapshotDate, today));
      if (rows.length > 0) {
        const mostRecentCreatedAt = rows.reduce<Date | null>((latest, row) => {
          return !latest || new Date(row.createdAt).getTime() > new Date(latest).getTime()
            ? row.createdAt
            : latest;
        }, null);
        if (!forceRefresh && !isCollectionsSnapshotFresh(mostRecentCreatedAt)) {
          console.log("[Scraper] Collections snapshot is older than one minute; refreshing FLOW data");
        } else {
        const buildings: BuildingCollectionData[] = rows.map((r) => ({
          buildingName: r.buildingName,
          regionId: r.regionId,
          regionName: REGION_NAMES[r.regionId] ?? `Region ${r.regionId}`,
          rentBilled: parseFloat(r.rentBilled),
          rentCollected: parseFloat(r.rentCollected),
          utilityReimbursement: parseFloat(r.utilityReimbursement),
          vouchersCount: r.vouchersCount,
          collectionPct: parseFloat(r.collectionPct),
        }));
        const totalRentBilled = buildings.reduce((s, b) => s + b.rentBilled, 0);
        const totalRentCollected = buildings.reduce((s, b) => s + b.rentCollected, 0);
        const overallCollectionPct = totalRentBilled > 0
          ? Math.round((totalRentCollected / totalRentBilled) * 1000) / 10
          : 0;
        return { snapshotDate: today, buildings, totalRentBilled, totalRentCollected, overallCollectionPct };
        }
      }
    } catch (err) {
      console.warn("[Scraper] Failed to read collections from DB:", err);
    }
  }

  try {
    return await fetchAndSaveCollectionsSnapshot();
  } catch (err) {
    console.warn("[Scraper] Failed to fetch collections snapshot:", err);
    return null;
  }
}
