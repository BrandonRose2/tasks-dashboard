import addressparser from "nodemailer/lib/addressparser/index.js";

type RecipientInput = string | readonly string[];

const REPLACED_RECIPIENT = "brandon@apartmentcorp.com";
const REPLACEMENT_RECIPIENT = "ethan@apartmentcorp.com";

/**
 * Used only by Weekly Vacancy Summary and eviction reminders. Replace Brandon
 * in place, preserve other mailbox addresses/order, and dedupe case-insensitively
 * across To then CC. Never append Ethan when Brandon is absent. No input mutation
 * or transport/database access; named/manual recipient lists are parsed as mailboxes.
 */
export function replaceScopedReportRecipients(to: RecipientInput, cc: RecipientInput = []) {
  const seen = new Set<string>();
  const transform = (input: RecipientInput): string => {
    const headers = typeof input === "string" ? [input] : input;
    const result: string[] = [];
    for (const header of headers) {
      if (/[\r\n]/.test(header)) throw new Error("Invalid scoped report recipient header");
      for (const mailbox of addressparser(header, { flatten: true })) {
        const original = mailbox.address.trim();
        if (!original) continue;
        const address = original.toLowerCase() === REPLACED_RECIPIENT ? REPLACEMENT_RECIPIENT : original;
        const key = address.toLowerCase();
        if (seen.has(key)) continue;
        seen.add(key);
        result.push(mailbox.name ? `${JSON.stringify(mailbox.name)} <${address}>` : address);
      }
    }
    return result.join(", ");
  };
  // Process To first so a primary manager can never be demoted to CC by dedupe.
  return { to: transform(to), cc: transform(cc) };
}
