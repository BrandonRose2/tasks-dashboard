import { afterEach, describe, expect, it, vi } from "vitest";
import { fetchRailwayCollectionsSnapshot, fetchRailwayVacancySnapshot } from "./railwayReports";

const vacancyPayload = {
  stats: { totalVacant: 5, vacUnleased: 2, vacPreleased: 3, onNotice: 1, eviction: 2 },
  buildingVacancy: [
    { name: "Alpha", totalVacant: 2, vacUnleased: 2, vacPreleased: 0, onNotice: 1, eviction: 0, totalUnits: 20, vacancyPct: 10, atRisk: true },
    { name: "Bravo", totalVacant: 3, vacUnleased: 0, vacPreleased: 3, onNotice: 0, eviction: 2, totalUnits: 30, vacancyPct: 10, atRisk: true },
  ],
  dailyChanges: [{ building: "Alpha", todayVacant: 2, yesterdayVacant: 1, change: 1 }],
  vacantUnleased: [],
  vacantPreleased: [],
  onNotice: [],
  evictions: [],
  lastUpdated: "2026-10-19T20:34:08.692Z",
};

const collectionsPayload = {
  snapshotDate: "2026-10-19",
  buildings: [
    { buildingName: "Alpha", regionId: 1, regionName: "Region 1", rentBilled: 1000, rentCollected: 900, utilityReimbursement: 0, vouchersCount: 0, collectionPct: 90 },
    { buildingName: "Bravo", regionId: 2, regionName: "Region 2", rentBilled: 500, rentCollected: 500, utilityReimbursement: 0, vouchersCount: 0, collectionPct: 100 },
  ],
  totalRentBilled: 1500,
  totalRentCollected: 1400,
  overallCollectionPct: 93.3,
};

function railwayResponse(payload: unknown) {
  return {
    ok: true,
    status: 200,
    json: async () => ({ result: { data: { json: payload } } }),
  };
}

describe("Railway report source adapters", () => {
  afterEach(() => vi.unstubAllGlobals());

  it("uses and validates the Railway Vacancy snapshot as a complete building-level Daily Vacancy source", async () => {
    const fetchMock = vi.fn().mockResolvedValue(railwayResponse(vacancyPayload));
    vi.stubGlobal("fetch", fetchMock);

    const snapshot = await fetchRailwayVacancySnapshot();

    expect(fetchMock.mock.calls[0][0]).toContain("/api/trpc/vacancy.getDashboard");
    expect(snapshot.stats.totalVacant).toBe(5);
    expect(snapshot.buildingVacancy.reduce((sum, row) => sum + row.totalVacant, 0)).toBe(5);
    expect(snapshot.sourceStatus?.message).toContain("Railway Vacancy");
    expect(snapshot.vacantUnleased).toHaveLength(0);
  });

  it("rejects a Railway Vacancy payload when the headline and building totals disagree", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue(railwayResponse({
      ...vacancyPayload,
      stats: { ...vacancyPayload.stats, totalVacant: 6 },
    })));

    await expect(fetchRailwayVacancySnapshot()).rejects.toThrow("does not reconcile");
  });

  it("uses and validates the Railway Collections snapshot without a legacy PropertyMax comparison", async () => {
    const fetchMock = vi.fn().mockResolvedValue(railwayResponse(collectionsPayload));
    vi.stubGlobal("fetch", fetchMock);

    const snapshot = await fetchRailwayCollectionsSnapshot();

    expect(fetchMock.mock.calls[0][0]).toContain("/api/trpc/collections.getSnapshot");
    expect(snapshot.snapshotDate).toBe("2026-10-19");
    expect(snapshot.totalRentBilled).toBe(1500);
    expect(snapshot.totalRentCollected).toBe(1400);
    expect(snapshot.overallCollectionPct).toBe(93.3);
  });
});
