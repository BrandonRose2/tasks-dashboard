import type { EvictionManagerContact } from "./emailService";
import type { DashboardData } from "./scraper";

// ─── Eviction Contact Map ─────────────────────────────────────────────────────
// Maps PropertyMax.ai building names (lowercase) to manager contacts.
// Regional: Ginger Positerry (Region 3), Blake Weddington (Region 4)
export const EVICTION_CONTACTS: Record<string, Omit<EvictionManagerContact, "units">> = {
  "marrero": { property: "Marrero 3", managerName: "Ketorah Parks", managerEmail: "rubystarmanager@apartmentcorp.com", regionalEmail: "ginger@apartmentcorp.com" },
  "yorkshire": { property: "Yorkshire/Windsor Village", managerName: "Kimberly Powell", managerEmail: "windsor@apartmentcorp.com", regionalEmail: "ginger@apartmentcorp.com" },
  "windsor": { property: "Yorkshire/Windsor Village", managerName: "Kimberly Powell", managerEmail: "windsor@apartmentcorp.com", regionalEmail: "ginger@apartmentcorp.com" },
  "pelican": { property: "Pelican Bay", managerName: "Dequanta Sutherland", managerEmail: "pelican@apartmentcorp.com", regionalEmail: "ginger@apartmentcorp.com" },
  "thibodaux": { property: "Thibodaux - Colonial Estates", managerName: "Susie Rogers", managerEmail: "colonialleasing@apartmentcorp.com", regionalEmail: "ginger@apartmentcorp.com" },
  "colonial": { property: "Thibodaux - Colonial Estates", managerName: "Susie Rogers", managerEmail: "colonialleasing@apartmentcorp.com", regionalEmail: "ginger@apartmentcorp.com" },
  "granite": { property: "Granite Ridge", managerName: "James Abeyta", managerEmail: "james@apartmentcorp.com", regionalEmail: "blake@apartmentcorp.com" },
  "wilmington": { property: "New Wilmington Arms", managerName: "Alberto Spence", managerEmail: "alberto@apartmentcorp.com", regionalEmail: "blake@apartmentcorp.com" },
  "arbor": { property: "Arbor Crest", managerName: "", managerEmail: "", regionalEmail: "jr@apartmentcorp.com" },
  "walnut": { property: "Walnut Hill", managerName: "", managerEmail: "", regionalEmail: "jr@apartmentcorp.com" },
  "crossroads": { property: "Crossroads of Lees Summit", managerName: "Jennifer Parks", managerEmail: "crossroads@apartmentcorp.com", regionalEmail: "jr@apartmentcorp.com" },
  "holiday": { property: "Holiday Apts", managerName: "", managerEmail: "", regionalEmail: "jr@apartmentcorp.com" },
  "jefferson": { property: "Jefferson Arms", managerName: "", managerEmail: "", regionalEmail: "jr@apartmentcorp.com" },
};

/** Exact legacy missing predicate, substring match order, and managerEmail merge. No address/manager changes. */
export function getEvictionReminderContacts(evictions: DashboardData["evictions"]): EvictionManagerContact[] {
  const missingByBuilding: Record<string, string[]> = {};
  for (const e of evictions) {
    if (!e.amountOwed) {
      const key = e.building.toLowerCase();
      if (!missingByBuilding[key]) missingByBuilding[key] = [];
      missingByBuilding[key].push(e.unit);
    }
  }
  const contacts: EvictionManagerContact[] = [];
  for (const [buildingKey, units] of Object.entries(missingByBuilding)) {
    const matchKey = Object.keys(EVICTION_CONTACTS).find(k => buildingKey.includes(k));
    if (!matchKey) continue;
    const contact = EVICTION_CONTACTS[matchKey];
    if (!contact.managerEmail) continue;
    const existing = contacts.find(c => c.managerEmail === contact.managerEmail);
    if (existing) existing.units.push(...units);
    else contacts.push({ ...contact, units: [...units] });
  }
  return contacts;
}
