# OneSite Request #60001 Direct Filing — Microsoft Edge Companion

This **temporary, source-available Microsoft Edge extension** supports one narrow task: sending the existing, approved, completed **OneSite All Units (Excel)** results for portal Request **#60001** to the authenticated OneSite Reporting Hub for filing. It does not create reports, change report settings, send email, access provider credentials, read cookies, enumerate tabs, or access arbitrary downloads.

## Permission boundary

| Permission or origin | Reason |
|---|---|
| `storage` | Retains only the short-lived, portal-issued pairing capability in Edge session storage. It is cleared when Edge exits. |
| `https://www.realpage.com/reporting/my-reports*` | Watches only the existing **Download** action for the provider’s verified Request #60001 All Units results after a portal pairing is active. |
| `https://onesiterepor-tsrr864t.manus.space/*` | Receives the existing workbook bytes through the restricted portal endpoint and returns filing status. |

The extension cannot intercept a report result before pairing. After pairing, it accepts only the verified **08/28/2026 11:04 AM** completed All Units rows and the portal independently rejects any property outside the current 21-property filing plan, duplicate pairs, non-Excel data, and all in-progress or errored outcomes.

## Installation and removal

The extension is intentionally **unpacked** rather than published to an app store because it is tightly restricted to this internal one-time batch. In Microsoft Edge, open `edge://extensions`, enable **Developer mode**, select **Load unpacked**, and choose this `edge-companion` folder. The portal will display **Pair Edge companion** only after it detects the installed extension.

After Request #60001 is fully reconciled, open `edge://extensions` and select **Remove**. Removing it clears the local companion and its ephemeral session pairing. No report files, provider credentials, browser cookies, MFA codes, or persistent tokens are stored by the extension.
