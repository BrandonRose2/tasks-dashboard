const CHANNEL = "onesite-60001-edge-companion";
const PROVIDER_ORIGIN = "https://www.realpage.com";

if (location.origin === PROVIDER_ORIGIN && location.pathname === "/reporting/my-reports") {
  let active = null;
  let paired = false;
  const post = payload => window.postMessage({ channel: CHANNEL, ...payload }, PROVIDER_ORIGIN);
  const filenameFrom = (header, fallback) => {
    const extended = /filename\*=UTF-8''([^;]+)/i.exec(header);
    const simple = /filename="?([^";]+)"?/i.exec(header);
    try { return extended ? decodeURIComponent(extended[1]) : (simple?.[1] || fallback); } catch { return fallback; }
  };
  const isWorkbookResponse = response => {
    const disposition = response.headers.get("content-disposition") || "";
    const type = response.headers.get("content-type") || "";
    return disposition.includes("attachment") || /spreadsheet|ms-excel|application\/vnd\.ms-excel/.test(type);
  };
  const originalFetch = window.fetch.bind(window);
  window.fetch = async (...args) => {
    const response = await originalFetch(...args);
    if (active && isWorkbookResponse(response)) {
      const current = active;
      active = null;
      response.clone().arrayBuffer().then(bytes => post({ type: "WORKBOOK", transferId: current.transferId, filename: filenameFrom(response.headers.get("content-disposition") || "", current.filename), bytes })).catch(() => post({ type: "TRANSFER_ERROR", message: "The completed workbook could not be copied for direct filing." }));
    }
    return response;
  };
  const propertyFromRow = row => row?.querySelector(".report-col-property")?.innerText?.trim() || "";
  const isEligibleCurrentRow = row => {
    const text = row?.innerText || "";
    return text.includes("All Units (Excel)") && text.includes("Property Information / Management") && text.includes("Completed") && text.includes("08/28/2026 11:04 AM");
  };
  document.addEventListener("click", event => {
    const download = event.composedPath().find(node => node?.innerText?.trim?.() === "Download");
    const row = download?.closest?.("raul-grid-row");
    if (!download || !paired || !isEligibleCurrentRow(row) || download.dataset?.onesiteDirectTransferReplay === "1") return;
    const propertyName = propertyFromRow(row);
    if (!propertyName) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    active = { transferId: crypto.randomUUID(), filename: `${propertyName}-All-Units-2026-08-28.xlsx` };
    post({ type: "ARM", propertyName, transferId: active.transferId });
    download.dataset.onesiteDirectTransferReplay = "1";
    download.click();
    queueMicrotask(() => { delete download.dataset.onesiteDirectTransferReplay; });
  }, true);
  window.addEventListener("message", event => {
    if (event.origin !== PROVIDER_ORIGIN || event.source !== window || event.data?.channel !== CHANNEL) return;
    if (event.data.type === "PAIR_STATE") paired = Boolean(event.data.paired);
  });
  setInterval(() => post({ type: "PAIR_STATE_REQUEST" }), 5_000);
}
