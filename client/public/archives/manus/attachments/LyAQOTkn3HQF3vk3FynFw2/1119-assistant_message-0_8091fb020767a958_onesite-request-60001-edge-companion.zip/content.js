const CHANNEL = "onesite-60001-edge-companion";
const PORTAL_ORIGIN = "https://onesiterepor-tsrr864t.manus.space";
const PROVIDER_ORIGIN = "https://www.realpage.com";

if (location.origin === PORTAL_ORIGIN) {
  const announce = () => window.postMessage({ channel: CHANNEL, type: "READY", extensionId: chrome.runtime.id }, PORTAL_ORIGIN);
  announce();
  window.addEventListener("message", event => {
    if (event.origin !== PORTAL_ORIGIN || event.source !== window || event.data?.channel !== CHANNEL) return;
    if (event.data.type === "DISCOVER") announce();
    if (event.data.type === "PAIR") chrome.runtime.sendMessage(event.data).then(() => window.postMessage({ channel: CHANNEL, type: "PAIRED" }, PORTAL_ORIGIN));
  });
}

if (location.origin === PROVIDER_ORIGIN && location.pathname === "/reporting/my-reports") {
  let active = null;
  let port = null;
  let paired = false;
  const post = payload => window.postMessage({ channel: CHANNEL, ...payload }, PROVIDER_ORIGIN);
  const refreshPairState = () => chrome.runtime.sendMessage({ channel: CHANNEL, type: "STATUS" }).then(response => { paired = Boolean(response?.paired); }).catch(() => { paired = false; });
  refreshPairState();
  setInterval(refreshPairState, 5_000);
  window.addEventListener("message", event => {
    if (event.origin !== PROVIDER_ORIGIN || event.source !== window || event.data?.channel !== CHANNEL || event.data.type !== "WORKBOOK" || !active || event.data.transferId !== active.transferId || !(event.data.bytes instanceof ArrayBuffer)) return;
    const { propertyName, transferId } = active;
    const filename = event.data.filename || `${propertyName}-All-Units-2026-08-28.xlsx`;
    active = null;
    if (!port) port = chrome.runtime.connect({ name: CHANNEL });
    const bytes = new Uint8Array(event.data.bytes);
    let binary = "";
    for (let offset = 0; offset < bytes.length; offset += 0x8000) binary += String.fromCharCode(...bytes.subarray(offset, offset + 0x8000));
    const encoded = btoa(binary);
    port.postMessage({ type: "START", transferId, propertyName, filename, byteLength: bytes.byteLength });
    for (let offset = 0; offset < encoded.length; offset += 500000) port.postMessage({ type: "CHUNK", transferId, data: encoded.slice(offset, offset + 500000) });
    port.postMessage({ type: "END", transferId });
  });
  chrome.runtime.onMessage.addListener(message => { if (message?.channel === CHANNEL) post(message); });
  window.addEventListener("message", event => {
    if (event.origin !== PROVIDER_ORIGIN || event.source !== window || event.data?.channel !== CHANNEL) return;
    if (event.data.type === "PAIR_STATE_REQUEST") { refreshPairState(); post({ type: "PAIR_STATE", paired }); }
    if (event.data.type === "ARM") active = { propertyName: event.data.propertyName, transferId: event.data.transferId };
    if (event.data.type === "TRANSFER_ERROR") active = null;
  });
}
