# Howell Place — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 5313974**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/03/2026 |
| Property manager | Sandra Crump — howell@apartmentcorp.com — (225) 505-3965 |
| Regional manager | Ginger Positerry — ginger@apartmentcorp.com — (985) 637-2128 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Delinquency spreadsheet | `5313974_Howell Place_Delinquent - Excel_58.xls` |
| Ledger accounts for review | 103 resident accounts |
| Residents with amount owed | 98 accounts; $162,450.36 |
| Prepaid / credit accounts | 5 accounts; $-1,547.65 |
| Availability entries | 7 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit's reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| 3-324 | 4B2B | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 4-414 | 2B2B | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 5-521 | 2B2B | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 5-512 | 1B1B | NTV Not Leased | [ ] Verified | __________________ |
| 5-522 | 1B1B | NTV Not Leased | [ ] Verified | __________________ |
| 3-311 | 4B2B | Vacant Leased Not Ready | [ ] Verified | __________________ |
| 3-314 | 4B2B | Vacant Leased Not Ready | [ ] Verified | __________________ |

## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - 111 | Tennart, Keddrick Eugene | Former resident | $0.00 | $2,993.07 | $2,993.07 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 111 | Hollins, Jennelsie s | Former resident | $0.00 | $1,526.36 | $1,526.36 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 111 | Russell, India | Former resident | $0.00 | $4,314.09 | $4,314.09 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 111 | Montgomery, Jasmine | Current resident | $0.00 | $1,594.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 112 | Morris, Whitney Reachell | Former resident | $0.00 | $3,411.65 | $3,411.65 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 112 | Campbell, April D | Former resident | $0.00 | $1,534.39 | $1,534.39 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 112 | Lewis, Malesia | Current resident | $0.00 | $800.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 121 | Lewis, Mikeyaunna T | Former resident | $0.00 | $1,003.71 | $1,003.71 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 121 | *Nicholas, Meyone | Former resident | $0.00 | $4,959.20 | $4,959.20 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 121 | Miles, Racheal Leona | Current resident | $0.00 | $1,506.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 122 | *Gray Jr., Leroy G | Former resident | $0.00 | $6,636.84 | $6,636.84 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 124 | Adams, Letitia Alicia | Former resident | $0.00 | $1,526.10 | $1,526.10 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 124 | Joseph, Shandricka Latrese | Former resident | $0.00 | $1,169.71 | $1,169.71 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 124 | Oliver, Saran | Current resident | $0.00 | $1,204.16 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 211 | Pittman, Natalie | Former resident | $0.00 | $1,365.60 | $1,365.60 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 211 | Jones, Rose | Former resident | $0.00 | $1,226.31 | $1,226.31 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 211 | Thomas, Deborah | Current resident | $0.00 | $28.10 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 212 | Roberson, Gerol | Former resident | $0.00 | $1,075.00 | $1,075.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 212 | Williams, Sharron R | Former resident | $0.00 | $3,758.46 | $3,758.46 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 212 | Chambers, Larry DeAubra | Former resident | $0.00 | $2,343.68 | $2,343.68 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 213 | Broden, Vivian | Current resident | $44.00 | $98.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 214 | Wilson, Roderica | Current resident | $0.00 | $288.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 221 | Richard, Myesha | Former resident | $0.00 | $252.03 | $252.03 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 221 | Burton, Quandrika | Current resident | $0.00 | $6,095.99 | $344.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 221 | Taylor, Sylvia | Former resident | $0.00 | $4,228.94 | $4,228.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 221 | Daniels, Dyneisha | Former applicant | $0.00 | $50.00 | $50.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 222 | Jones, Debra | Former resident | $0.00 | $2,195.77 | $2,195.77 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 222 | Faust, Raven | Former resident | $0.00 | $2,454.87 | $2,454.87 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 222 | Bradford, Briannika | Former resident | $0.00 | $1,377.67 | $1,377.67 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 222 | Washington, Tonya Nicole | Former applicant | $0.00 | $50.00 | $50.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 223 | Taylor, Jade K | Former resident | $0.00 | $3,450.80 | $3,450.80 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 223 | Allen, Natalie | Former resident | $0.00 | $2,727.20 | $2,727.20 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 223 | Morrison, Kim | Former resident | $0.00 | $3,218.86 | $3,218.86 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 223 | Johnson, Fredericka | Current resident | $0.00 | $55.33 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 224 | White, D'Lisa L | Former resident | $0.00 | $2,174.77 | $2,174.77 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 224 | Gregoire, Jaquita | Former applicant | $0.00 | $50.00 | $50.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 224 | Whitfield, Sharnice | Former applicant | $0.00 | $50.00 | $50.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 312 | Landry, Rachelle | Current resident | $0.00 | $59.50 | $23.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 314 | Dunn, Jasmine Renee | Former resident | $0.00 | $3,242.55 | $3,242.55 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 314 | Bingham, Cynthia M | Former resident | $0.00 | $448.48 | $448.48 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 314 | Ross, Clarissa | Former resident | $0.00 | $1,114.00 | $24.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 321 | Robinson, Martha | Former resident | $0.00 | $1,038.00 | $1,038.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 321 | Jones, Lashica | Current resident | $0.00 | $33.35 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 323 | Mccullough, Rashema Roshell | Former resident | $0.00 | $3,877.42 | $3,877.42 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 323 | Bridges, Esperanza Denise | Former resident | $0.00 | $2,647.71 | $2,647.71 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 324 | Jackson, Linda K | Former resident | $0.00 | $516.23 | $516.23 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 411 | Scott, Lisa L | Former resident | $0.00 | $1,703.26 | $1,703.26 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 411 | Williams, Minister | Former resident | $0.00 | $1,536.00 | $1,536.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 411 | Davis, Luke | Current resident | $0.00 | $100.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 412 | Rideau, Frank | Current resident | $0.00 | $986.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 413 | O'Bear, Theresa | Former resident | $0.00 | $285.00 | $285.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 413 | Gordon, Shamyra S | Former resident | $0.00 | $1,289.00 | $1,289.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 413 | Blunt, Henry | Former resident | $0.00 | $2,863.60 | $1,554.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 414 | Herring, Ella | Former resident | $0.00 | $1,970.03 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 415 | Obear, Jalisa | Former resident | $0.00 | $209.00 | $209.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 415 | White-Veasey, Terrence | Former resident | $0.00 | $1,207.42 | $957.42 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 416 | Dedeaux, Ariana Leshea | Former resident | $0.00 | $2,222.74 | $2,222.74 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 416 | Coleman, Teneshia L | Former resident | $0.00 | $1,908.20 | $1,908.20 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 416 | Lewis, Oakley | Current resident | $0.00 | $1,103.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 421 | Mitchell, Tiffiny Raquel | Former resident | $0.00 | $515.14 | $515.14 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 421 | Smith, Quionna | Former resident | $0.00 | $1,817.09 | $1,817.09 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 421 | Wyatt, Rico | Current resident | $0.00 | $2,454.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 422 | Crawford Williams, Celette | Former resident | $0.00 | $2,026.10 | $2,026.10 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 422 | Parker, Kenneth D | Former resident | $0.00 | $2,017.76 | $2,017.76 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 422 | Sanders, Clayton | Former resident | $0.00 | $2,815.79 | $2,815.79 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 422 | Hurry, Kayla | Current resident | $0.00 | $12.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 423 | Richardson, Jakyria | Former resident | $0.00 | $325.00 | $325.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 423 | Bailey, Deaundre T | Current resident | $0.00 | $1,151.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 424 | White, Tanya Renita | Former resident | $0.00 | $2,206.50 | $2,206.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 424 | Tucker Jr, Robert | Former resident | $0.00 | $458.51 | $458.51 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 424 | Chatman, Thaddaus | Former applicant | $0.00 | $50.00 | $50.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 426 | Pratt, KeishaBreann | Former resident | $0.00 | $129.52 | $129.52 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 426 | Meyers, Jasmine Faye | Former resident | $0.00 | $63.45 | $63.45 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 426 | Tickles, Jacquan | Current resident | $0.00 | $1,857.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 511 | Prentiss, Tonica Nicole | Former resident | $0.00 | $1,409.39 | $1,409.39 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 511 | Holts, Trini L | Current resident | $0.00 | $211.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 512 | Tyquanya Burden | Former resident | $0.00 | $2,955.10 | $2,955.10 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 512 | *Derosin, Tevarious M | Former resident | $0.00 | $2,407.73 | $2,407.73 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 512 | Edwards, Sharon | Former applicant | $0.00 | $50.00 | $50.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 512 | Edwards, Sharon | NTV | $0.00 | $985.12 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 513 | Stringer, Gaynell Denise | Former resident | $0.00 | $1,414.00 | $1,414.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 515 | Thomas, Kenneth Ray | Former resident | $0.00 | $2,743.73 | $2,743.73 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 515 | *Veasey, Regina | Former resident | $0.00 | $1,895.29 | $21.42 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 516 | Keller, Natasha | Former resident | $0.00 | $2,621.87 | $2,621.87 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 521 | *Smith, Edward | Former resident | $0.00 | $2,864.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 522 | Barton, Kayla Lashun Monique | Former resident | $0.00 | $2,096.90 | $2,096.90 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 522 | Jackson, Dorcas D | Former resident | $0.00 | $1,436.32 | $1,436.32 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 522 | Woodruff, Trelin Markell | Former resident | $0.00 | $2,975.23 | $2,975.23 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 522 | Constant, Shirley | NTV | $0.00 | $36.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 523 | Nelson, Andrea Marie | Former resident | $0.00 | $3,229.81 | $3,229.81 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 523 | Whitfeild, Larhea | Former resident | $0.00 | $2,169.39 | $2,169.39 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 523 | Ricks, Toni | Former resident | $0.00 | $846.75 | $846.75 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 523 | Edmond, Doris | Current resident | $0.00 | $1,151.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 524 | JACKSON, ANGEL | Former resident | $0.00 | $532.40 | $532.40 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 524 | Winfrey, Destiny | Current resident | $0.00 | $1,151.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 525 | CARTER, EMMANUEL | Former resident | $0.00 | $1,073.81 | $1,073.81 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 525 | Robertson, Joshua | Former resident | $0.00 | $3,003.57 | $3,003.57 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 526 | Varnado, Corey R | Former resident | $0.00 | $2,180.94 | $2,180.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - 122 | Williams, Shayla | Current resident | $68.80 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 222 | Warren, Nacole Renay | Current resident | $16.27 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - 413 | Allen, Varice | Current resident | $14.58 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 525 | Cafey, Wendy Jane | Current resident | $72.00 | $12.00 | $0.00 | [ ] Confirm paid | — |
| WAIT | Stewart, Tyneisha | Applicant | $1,388.00 | $0.00 | $0.00 | [ ] Confirm paid | — |

## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.

## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property's supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*