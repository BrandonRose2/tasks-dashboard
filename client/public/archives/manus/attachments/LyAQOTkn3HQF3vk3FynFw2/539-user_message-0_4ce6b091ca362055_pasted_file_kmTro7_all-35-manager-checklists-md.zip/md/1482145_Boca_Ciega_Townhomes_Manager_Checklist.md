# Boca Ciega Townhomes — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 1482145**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/05/2026 |
| Property manager | Katrina Weekly — katrina@apartmentcorp.com — (215) 704-4099 |
| Regional manager | JR Rolon — jrrolon@apartmentcorp.com — (941) 716-1665; Leslie Rolon — leslie@apartmentcorp.com — (504) 247-3813 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Delinquency spreadsheet | `1482145_Boca Ciega Townhomes_Delinquent - Excel_58.xls` |
| Ledger accounts for review | 325 resident accounts |
| Residents with amount owed | 214 accounts; $301,204.01 |
| Prepaid / credit accounts | 110 accounts; $-55,844.15 |
| Availability entries | 1 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit's reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| 9-41 | 2BFLAT | Vacant Not Leased Not Ready | [ ] Verified | __________________ |

## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - 1 | WATERS, ERICA | Former resident | $0.00 | $1,613.85 | $1,613.85 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1 | NEGRIN, GRACE | Former resident | $0.00 | $97.00 | $97.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 2 | MCNEAL, NIQUARE W | Former resident | $0.00 | $131.00 | $131.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 3 | BAILEY, RENA | Former resident | $0.00 | $46.00 | $46.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 3 | Demers, Nicole | Former resident | $0.00 | $68.00 | $68.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 3 | NEGRON, KARLA | Former resident | $0.00 | $197.44 | $197.44 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 3 | GONZALEZ, AURIA | Former resident | $0.00 | $3.00 | $3.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 3 | CARBONELL, MARY A | Former resident | $1.00 | $144.00 | $143.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 4 | Donar, Crystal | Former resident | $0.00 | $265.00 | $265.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 4 | ROLLINS, ROLANDA M | Former resident | $0.00 | $4,870.83 | $4,870.83 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 4 | Bolden, Trinity Zirea | Former resident | $0.00 | $5,096.41 | $5,096.41 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 61 | Boyd, Stephanie Renee | Former resident | $0.00 | $2,094.00 | $2,094.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 61 | Dipina, Crystal | Former resident | $0.00 | $324.44 | $324.44 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 61 | Walton, Bianca | Current resident | $0.00 | $705.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 43 | MERCILIEN, MARGARETTA | Former resident | $0.00 | $498.00 | $498.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 43 | TAYLOR, ESTHER | Former resident | $0.00 | $1,436.00 | $1,436.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 43 | OLIVERAS CLEMENTE, JANOSKA IVONNE | Former resident | $0.00 | $193.62 | $193.62 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 43 | OUAKRIM, IJJA | Former resident | $0.00 | $49.96 | $49.96 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 43 | Rhoden, Monessia K | Former resident | $0.00 | $116.84 | $116.84 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 45 | BRADFORD, CHANTA | Former resident | $0.00 | $283.00 | $283.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 45 | Valbert, James L | Former resident | $0.00 | $1,734.95 | $1,734.95 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 45 | Baker, Janiyah Jessica | Former resident | $1.00 | $1,438.97 | $1,437.97 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 45 | Seals, Jalil | Former resident | $0.00 | $169.99 | $169.99 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 47 | WILLIAMS, JESSICA | Former resident | $0.00 | $142.00 | $142.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 48 | DAVIS, ISHERA | Former resident | $0.00 | $846.00 | $846.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 48 | SORIANO, MARY | Former resident | $0.00 | $517.00 | $517.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 48 | Mcneal, Rachael | Former resident | $0.00 | $95.88 | $95.88 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 49 | ALLEN, SHARELL | Former resident | $0.00 | $428.00 | $428.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 49 | Stegman, Samantha | Former resident | $0.00 | $33.23 | $33.23 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 49 | Bingham, Cypraea | Current resident | $0.00 | $41.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 50 | Wiggan, Kellyann T | Current resident | $0.00 | $337.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 51 | GREEN, AKILRAH M | Former resident | $0.00 | $196.00 | $196.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 51 | HERNANDEZ COTTO, JACQUELINE M | Former resident | $0.00 | $546.00 | $546.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 51 | Walton, Velmia Tanyasha | Former resident | $0.00 | $1,355.00 | $1,355.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 52 | JONES, SHIMYRA DN | Former resident | $1.00 | $8,623.71 | $8,622.71 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 52 | Figueroa Concepcion, Chesyl Marie | Former resident | $0.00 | $12.95 | $12.95 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 52 | Blackwell, Kayonte | Former resident | $0.00 | $539.18 | $539.18 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 53 | MALONE, ASHLEY | Former resident | $0.00 | $52.00 | $52.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 54 | BRUNSON, JERRICA A | Former resident | $0.00 | $621.00 | $621.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 55 | CHAVOUS, STARR Y | Former resident | $0.00 | $4,307.87 | $4,307.87 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 106 | NEGRON FALCON, KEISHLA M | Former resident | $0.00 | $74.00 | $74.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 106 | Santos, Izabella | Former resident | $1,799.00 | $2,501.94 | $702.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 107 | BRAY, THELMA | Former resident | $0.00 | $19.00 | $19.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 107 | Wooten, Takia DUEWA | Former resident | $1,092.00 | $8,122.19 | $7,030.19 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 108 | HARRY, TERRYANN | Former resident | $0.00 | $933.00 | $933.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 108 | AOUNE, ABDELKARIM | Former resident | $0.00 | $10.00 | $10.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 104 | NAZARIO, GLADYS | Former resident | $0.00 | $41.30 | $41.30 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 105 | Johnson, Wantina N | Former resident | $0.00 | $181.00 | $181.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 105 | GIBBS, VIRGINIA | Former resident | $0.00 | $277.00 | $277.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 105 | SEARY COLON, NATASHA A | Former resident | $0.00 | $9.00 | $9.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 105 | Alvarado, Jailene | Former resident | $0.00 | $118.69 | $118.69 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 109 | FRAZIER, FRANKIE | Former resident | $0.00 | $437.00 | $437.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 109 | Fluker, Ronald | Former resident | $0.00 | $1,624.00 | $1,624.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 109 | GRAHAM, DONNA | Former resident | $0.00 | $6,800.00 | $6,800.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 109 | Williams, Erin | Former resident | $0.00 | $2,299.94 | $2,299.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 72 | MORALES, NISA N | Former resident | $0.00 | $1.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 72 | Kimble, Kharisma Levonne | Former resident | $0.00 | $2,524.24 | $2,524.24 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 73 | WEBB, KIM | Former resident | $0.00 | $1,290.00 | $1,290.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 73 | Negrin, Grace | Former resident | $0.00 | $941.00 | $941.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 74 | MARRERO, IRIS Y | Former resident | $0.00 | $61.00 | $61.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 74 | Joslin, Shala Marie | Former resident | $0.00 | $345.00 | $345.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 75 | WILLIAMS, KIMBERLY | Former resident | $0.00 | $19.00 | $19.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 75 | WILLIAMS, YOLANDA S | Former resident | $0.00 | $142.27 | $142.27 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 77 | THOMPSON, CRYSTAL | Former resident | $8.00 | $389.00 | $381.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15 - 67 | STEWART, EVITA | Former resident | $0.00 | $599.00 | $599.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15 - 67 | Negrin, Milldred | Former resident | $0.00 | $84.36 | $84.36 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15 - 67 | REED, ASHLEY R | Former resident | $0.00 | $1,539.67 | $1,539.67 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15 - 68 | CLAYTON, BRANDON V | Former resident | $0.00 | $1,691.90 | $1,691.90 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15 - 68 | Hernandez, Krystie Y | Former resident | $150.00 | $886.42 | $736.42 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15 - 69 | Craft, Nerline M | Current resident | $0.00 | $22.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15 - 70 | JOHNVILLE, ASHKAR | Former resident | $0.00 | $1,059.16 | $1,059.16 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15 - 71 | LEE, KEYA | Former resident | $0.00 | $90.00 | $90.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15 - 71 | BLACK, BOBBI JO | Former resident | $0.00 | $60.00 | $60.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15 - 71 | Bonilla, Yaira L | Former resident | $0.00 | $261.92 | $261.92 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 62 | TOWNS, PATRICE | Former resident | $0.00 | $873.00 | $873.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 62 | Mitchell, Decener L | Current resident | $0.00 | $994.00 | $805.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 62 | CRUZ BENITEZ, FRANCIS | Former resident | $0.00 | $2,228.00 | $2,228.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 62 | ORTIZ CRUZ, ANA K | Former resident | $0.00 | $300.00 | $300.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 63 | DE LA CRUZ JR, CONRADO | Former resident | $0.00 | $2,136.94 | $2,136.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 63 | Shirley, Kiera A | Former resident | $0.00 | $3,263.90 | $3,263.90 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 64 | BAKER, DESIREE | Former resident | $0.00 | $0.94 | $0.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 64 | WALTON, JULISSA K | Former resident | $0.00 | $809.85 | $809.85 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 64 | Gordon, Dominique | Current resident | $0.00 | $212.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 65 | BRYANT, DAVINA | Former resident | $38.00 | $143.00 | $105.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 65 | MARQUEZ, KARINA V | Former resident | $0.00 | $1,976.00 | $1,976.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 66 | DAVIS, NATASHA | Former resident | $0.00 | $49.00 | $49.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 66 | KAMEUR, DALILA | Former resident | $0.00 | $52.93 | $52.93 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 66 | FLOWERS, KENYATTA J | Former resident | $0.00 | $1,200.00 | $1,200.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 78 | MCCALLISTER, NATASHA | Former resident | $0.00 | $157.00 | $157.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 78 | NAZARIO, ELIZABETH | Former resident | $0.00 | $2,364.16 | $2,364.16 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 78 | Battle, Karen Y | Former resident | $1.00 | $846.94 | $845.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 79 | SAMPSON, AKEENA M | Former resident | $0.00 | $2,241.50 | $2,241.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 79 | Walker, Alexis D | Former resident | $0.00 | $811.87 | $811.87 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 79 | Spradley, Jakasha | Former resident | $0.00 | $1,222.94 | $1,222.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 80 | NICHOLS, KENYA W | Former resident | $0.00 | $1,003.00 | $1,003.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 80 | CARTER, NAVIA C | Former resident | $0.00 | $37.07 | $37.07 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 81 | BELL, VIVIAN | Former resident | $0.00 | $1,240.00 | $1,240.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 81 | APPLING, CARRIE | Former resident | $0.00 | $123.00 | $123.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 81 | FLORIMON, ROSALYS J | Former resident | $0.00 | $84.78 | $84.78 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 81 | NELSON, CRYSTAL M | Former resident | $156.00 | $3,303.94 | $3,147.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 82 | Brinson, Jasmine | Former resident | $0.00 | $2,211.74 | $2,211.74 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18 - 83 | RUFFIN, SHRILEANIA | Former resident | $1.00 | $75.00 | $74.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18 - 84 | WILLIAMS, NICOLE | Former resident | $0.00 | $631.00 | $631.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18 - 85 | SEYMOUR, KEYATA | Former resident | $0.00 | $26.00 | $26.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18 - 86 | JONES, GERTRUDE | Former resident | $0.00 | $4.00 | $4.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18 - 86 | Wilson, Gregory | Former resident | $0.00 | $2,049.20 | $1,215.20 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18 - 86 | Robinson, Kenya | Current resident | $0.00 | $2,303.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19 - 87 | MURRAY, YOLANDA | Former resident | $0.00 | $75.00 | $75.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19 - 88 | Bright, Tasha | Former resident | $0.00 | $468.97 | $468.97 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19 - 89 | MORRIS, SHAMEKA | Former resident | $430.00 | $912.59 | $482.59 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19 - 89 | RODRIGUEZ BONILLA, STEPHANIE | Former resident | $0.00 | $60.00 | $60.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19 - 89 | LUNA, RACHEL | Former resident | $0.00 | $1,595.33 | $1,595.33 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19 - 90 | JOHNSON, DRICILLA | Former resident | $0.00 | $479.00 | $479.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19 - 90 | SANTANA, MARIA D | Former resident | $1,200.00 | $3,981.94 | $2,781.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19 - 90 | Ortiz, Angela D | Current resident | $183.00 | $488.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19 - 90 | NEWSOME, DIARRA | Former resident | $0.00 | $3,279.96 | $3,279.96 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19 - 91 | Newkirk, LISA D | Former resident | $0.00 | $670.00 | $670.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19 - 91 | Diaz, Ashley | Former resident | $0.00 | $1,137.00 | $1,137.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19 - 91 | DE LOS ANGELES DIAZ, BIANCA | Former resident | $0.00 | $998.00 | $998.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19 - 92 | OLIVERO, DORKA R | Former resident | $0.00 | $2,180.57 | $2,180.57 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19 - 93 | WEBB, KOURTNEY | Former resident | $0.00 | $998.00 | $998.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19 - 93 | GREEN, EMANUEL | Former resident | $0.00 | $1,268.00 | $1,268.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19 - 94 | Pierre, Darlyne L | Former resident | $0.00 | $1,918.00 | $1,918.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19 - 94 | GREEN, MELISSA D | Former resident | $0.00 | $293.00 | $293.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19 - 94 | VILLEGAS, VANESSA V | Former resident | $1.00 | $60.00 | $59.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 10 | YATES, REBECCA | Former resident | $180.00 | $362.00 | $182.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 10 | De La Cruz, Conrado | Former resident | $0.00 | $1,056.00 | $1,056.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 10 | Watts, Barbara R | Former resident | $1,127.00 | $1,172.81 | $45.81 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 6 | BOATMAN, IVANA | Former resident | $0.00 | $851.74 | $851.74 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 6 | WALKER, CHABRIER | Former resident | $0.00 | $317.00 | $317.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 6 | Dexter, Lashawnda M | Former resident | $0.00 | $1,849.83 | $1,849.83 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 7 | JULIUS, JESSICA | Former resident | $140.00 | $1,924.22 | $1,784.22 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 7 | Wesley, Diane R | Former resident | $60.00 | $152.52 | $92.52 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 7 | FORD, TAMIKA | Former resident | $0.00 | $82.00 | $82.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 7 | Franklin, Kierra Shanae | Former resident | $9,984.00 | $14,442.00 | $4,458.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 9 | WITHERSPOON, ALICIA | Former resident | $0.00 | $19.00 | $19.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 9 | JOHNSON, LISA D | Former resident | $0.00 | $37.95 | $37.95 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20 - 95 | MARQUEZ-PION, Kimberlee | Former resident | $1.00 | $108.92 | $107.92 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20 - 95 | Rivero  Vera, Yasleidy | Former resident | $0.00 | $198.90 | $198.90 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20 - 96 | GONZALEZ, ALISIA M | Former resident | $0.00 | $3.74 | $3.74 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20 - 96 | NAZARIO, CYNTHIA M | Former resident | $0.00 | $1,046.77 | $1,046.77 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20 - 97 | SEYMOUR, CHIQUITA | Former resident | $0.00 | $606.00 | $606.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20 - 97 | OLIVERO LEGER, HECTOR | Former resident | $1.00 | $2,022.58 | $2,021.58 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20 - 97 | Hall, Kathryn | Former resident | $0.00 | $1,886.40 | $1,886.40 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20 - 98 | ADAMS, DOMINIQUE | Former resident | $0.00 | $1,001.00 | $1,001.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20 - 99 | THORN, AURALIUS | Former resident | $0.00 | $512.00 | $512.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 21 | COLEMAN, MIRANDA | Former resident | $0.00 | $6.83 | $6.83 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 21 | Garcia Franco, Jeicha | Current resident | $1,237.00 | $2,163.00 | $-1,237.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 22 | VIRGO, GENEVE | Former resident | $0.00 | $11.25 | $11.25 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 22 | BUDDEN, BRIELLE M | Former resident | $0.00 | $66.00 | $66.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 22 | SMITH, LACIE D | Former resident | $0.00 | $85.00 | $85.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 23 | CHILDS, BOLISHA | Former resident | $0.00 | $1,099.00 | $1,099.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 23 | ROUNDTREE, NERISSA | Former resident | $0.00 | $2,440.00 | $2,440.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 24 | BYRD, DEMERTUS | Former resident | $0.00 | $12.00 | $12.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 24 | SMITH, VANESSA D | Former resident | $0.00 | $275.00 | $275.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 24 | LEWIS, LAKESHA T | Former resident | $0.00 | $77.12 | $77.12 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 25 | GREER, IRMA | Former resident | $0.00 | $1,074.00 | $1,074.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 26 | CRUZ JR, WILLIAM G | Former resident | $0.00 | $2,154.58 | $2,154.58 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 26 | Johnson, Danielle R | Former resident | $0.00 | $99.97 | $99.97 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 56 | CAMPBELL, TANEKA | Former resident | $0.00 | $1,057.00 | $1,057.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 56 | Matthews, Jasmine L | Former resident | $0.00 | $2,294.26 | $2,294.26 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 56 | HINES, CHANNIE | Former resident | $0.00 | $406.00 | $406.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 57 | BRYANT, MICHELLE | Former resident | $0.00 | $54.00 | $54.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 57 | NEELEY, BEVERLY D | Former resident | $0.00 | $177.90 | $177.90 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 57 | SOSA, ZENIA | Former resident | $0.00 | $135.00 | $135.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 57 | Smith, Vanessa | Former resident | $0.00 | $1,128.54 | $1,128.54 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 58 | MOULTRIE, ASHLEY | Former resident | $0.00 | $755.00 | $755.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 58 | RUSS, ASHLEY | Former resident | $0.00 | $69.00 | $69.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 58 | MORALES, MARIVETH | Former resident | $0.00 | $1,117.87 | $1,117.87 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 58 | Rodriguez Carrasio, Stephanie | Former resident | $0.00 | $403.92 | $403.92 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 59 | JORDAN, LATOYA | Former resident | $0.00 | $925.00 | $925.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 59 | WRIGHT, ASHLEY | Former resident | $1.00 | $87.00 | $86.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 59 | FRANCIS, DELLA | Former resident | $0.00 | $96.00 | $96.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 59 | RIVERA VILLAFANE, ISABEL | Former resident | $0.00 | $562.07 | $562.07 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 59 | CALDERO, JESUS M | Former resident | $0.00 | $979.00 | $979.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 59 | Williams, Shibraille | Current resident | $0.00 | $1,258.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 60 | Rasado, Elizabeth | Former resident | $0.00 | $1,361.00 | $1,361.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 60 | JOSEPH, PAOLA | Former resident | $0.00 | $2,297.00 | $2,297.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 60 | Mason, A'tiana | Former resident | $0.00 | $1,498.33 | $1,498.33 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 11 | Miller, Trisha | Former resident | $0.00 | $1,675.00 | $1,675.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 11 | SING, SHELBY | Former resident | $67.00 | $528.00 | $461.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 11 | POLANCO, YESENIA | Former resident | $1.00 | $694.95 | $693.95 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 13 | GARCIA PEREZ, JOANNA | Former resident | $0.00 | $189.13 | $189.13 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 15 | HIDALGO RIJO, LETICIA G | Former resident | $0.00 | $992.98 | $992.98 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 16 | BURT, YVETTE L | Former resident | $0.00 | $132.16 | $132.16 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 18 | BROWN, JEARIL | Former resident | $0.00 | $6.00 | $6.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 19 | WATKINS, MICHELE | Former resident | $0.00 | $449.00 | $449.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 19 | GLOVER, VA'KECIA | Former resident | $0.00 | $1,025.00 | $1,025.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 19 | RODRIGUEZ, MERCEDES | Former resident | $0.00 | $325.95 | $325.95 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 20 | Uyeda, Idalena F | Current resident | $1.00 | $1.90 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 27 | FACYSON, KENYATTA A | Former resident | $21.00 | $506.76 | $485.76 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 28 | NAZARIO, CRYSTAL | Former resident | $1.00 | $464.96 | $463.96 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 31 | RIVERA MATOS, KIMBERLY | Former resident | $0.00 | $503.00 | $503.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 31 | HOUSTON, NORMAN T | Former resident | $0.00 | $928.80 | $928.80 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 31 | Garcia, Iris N | Former resident | $0.00 | $184.55 | $184.55 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 31 | Allen, Milanya | Former resident | $0.00 | $3,195.79 | $3,195.79 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 32 | WALKER, BRITTNEY L | Former resident | $0.00 | $35.00 | $35.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 32 | RAMIREZ-DIAZ, EVA L | Former resident | $0.00 | $122.00 | $122.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 33 | FRANCO, NINA | Former resident | $0.00 | $1,971.00 | $1,971.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 33 | VELEZ, TANYAH | Former resident | $0.00 | $89.00 | $89.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 34 | POWELL, CAROLYN | Former resident | $0.00 | $1,765.00 | $1,765.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 34 | GRIFFIN, QUASHENE | Former resident | $0.00 | $43.80 | $43.80 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 34 | Owens, Kiera N | Former resident | $1,247.00 | $10,054.12 | $8,807.12 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 34 | Wilson, Tamesha | Current resident | $0.00 | $222.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 35 | SANDERS, SYMONE | Former resident | $0.00 | $1,114.00 | $1,114.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 35 | Calixto, Rosanne | Former resident | $0.00 | $1,275.04 | $1,275.04 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 36 | St Preux, Linda O | Former resident | $0.00 | $736.33 | $736.33 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 36 | Cooper, Miss | Former resident | $0.00 | $2,246.92 | $2,246.92 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 38 | GREEN, SHAQUEL D | Former resident | $200.00 | $784.94 | $584.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 38 | JOSEPH, ALEXIS | Former resident | $0.00 | $4,964.50 | $4,964.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 40 | BRYANT, DEZIA | Former resident | $0.00 | $1,070.50 | $1,070.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 40 | Parker, Rosie | Former resident | $0.00 | $7,422.73 | $7,422.73 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 41 | JILES, ANGELICA | Former resident | $0.00 | $93.00 | $93.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| NONE | HAP common ledger | Misc. Income | $0.00 | $87,277.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - 2 | Moto, Silverina | Current resident | $4,503.85 | $858.00 | $-2,494.00 | [ ] Confirm paid | — |
| 1 - 3 | Rodriguez, Erika | Current resident | $164.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 4 | Marble, Bernadette | Current resident | $246.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 5 | Ross, Gladys L | Current resident | $47.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 61 | MAYOL-ORTIZ, ANGIEVEL | Former resident | $359.00 | $0.00 | $-359.00 | [ ] Confirm paid | — |
| 10 - 42 | KING, JERIA | Former resident | $1,300.00 | $0.00 | $-1,300.00 | [ ] Confirm paid | — |
| 10 - 42 | Seay, Daryl J | Current resident | $102.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 10 - 43 | Plummer, Thelma | Current resident | $172.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 10 - 44 | NEWTON, REVA | Former resident | $250.00 | $0.00 | $-250.00 | [ ] Confirm paid | — |
| 10 - 44 | St Jean, Fergus | Current resident | $24.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 10 - 45 | Martinez Roque, Gladys | Current resident | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 10 - 46 | Dukes, Ashley M | Current resident | $529.50 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 11 - 51 | Mota, Grailin P | Current resident | $197.00 | $0.00 | $-197.00 | [ ] Confirm paid | — |
| 11 - 53 | Candelario, Yolanda | Current resident | $129.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 11 - 54 | De Los Santos, Virginia E | Current resident | $394.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 11 - 55 | Whitfield, Dartavia | Current resident | $621.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 12 - 106 | ELLIS, TASHA | Former resident | $1,714.00 | $60.00 | $-1,654.00 | [ ] Confirm paid | — |
| 12 - 106 | Rivera, Joselyn | Current resident | $126.29 | $0.00 | $-126.29 | [ ] Confirm paid | — |
| 12 - 108 | Reid, Cyani M | Current resident | $29.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 13 - 100 | Hernandez, Angelina O | Current resident | $73.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 13 - 101 | Jones, Martha | Current resident | $221.80 | $0.00 | $-44.80 | [ ] Confirm paid | — |
| 13 - 102 | Tramel, R N | Current resident | $309.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 13 - 103 | Demota, Antonia | Current resident | $409.00 | $0.00 | $-382.00 | [ ] Confirm paid | — |
| 13 - 104 | HILLMAN, TWANDA | Former resident | $1.00 | $0.00 | $-1.00 | [ ] Confirm paid | — |
| 13 - 105 | DRAYTON, FELICIA | Former resident | $893.00 | $0.00 | $-893.00 | [ ] Confirm paid | — |
| 13 - 105 | NAZARIO, GLADYS | Former resident | $540.00 | $0.00 | $-540.00 | [ ] Confirm paid | — |
| 13 - 105 | Madison, Tayshaun | Current resident | $134.00 | $0.00 | $-134.00 | [ ] Confirm paid | — |
| 14 - 72 | HARDEN, ASHLEY | Former resident | $29.00 | $0.00 | $-29.00 | [ ] Confirm paid | — |
| 14 - 73 | Santos Martinez, Magaly | Current resident | $71.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 14 - 74 | Newton, Sheretta | Current resident | $42.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 14 - 75 | Smith, Arnetta M | Current resident | $433.00 | $0.00 | $-433.00 | [ ] Confirm paid | — |
| 14 - 76 | Gordon, Kimberly | Current resident | $74.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 14 - 77 | Mcintosh, Katrina | Current resident | $203.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 15 - 67 | Maldonado Nieves, MariangelyM | Current resident | $332.00 | $0.00 | $-192.00 | [ ] Confirm paid | — |
| 15 - 70 | Broward, SHANNEL L | Current resident | $300.00 | $0.00 | $-299.00 | [ ] Confirm paid | — |
| 16 - 63 | Caicedo, KEYLA S | Current resident | $735.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 16 - 65 | Alfonso Hernandez, Yeraldine | Current resident | $1,878.00 | $0.00 | $-1,182.00 | [ ] Confirm paid | — |
| 16 - 66 | James, Shelene | Current resident | $71.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 17 - 78 | HAYWARD, BRITNEY N | Former resident | $2,321.00 | $1,480.00 | $-841.00 | [ ] Confirm paid | — |
| 17 - 78 | Katina, Shorter | Current resident | $745.00 | $0.00 | $-255.00 | [ ] Confirm paid | — |
| 17 - 80 | Faulk, Ashley | Current resident | $1,143.00 | $0.00 | $-367.00 | [ ] Confirm paid | — |
| 17 - 81 | Cooper, Rhiannon | Current resident | $5,612.00 | $962.00 | $-2,848.00 | [ ] Confirm paid | — |
| 17 - 82 | Sullivan, Christina | Former resident | $776.00 | $0.00 | $-776.00 | [ ] Confirm paid | — |
| 17 - 82 | SALAS, YESENIA C | Former resident | $1.00 | $0.00 | $-1.00 | [ ] Confirm paid | — |
| 17 - 82 | Guilbeaux Martinez, Josue | Current resident | $3.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 18 - 83 | Bonilla, Rene | Current resident | $346.00 | $0.00 | $-170.00 | [ ] Confirm paid | — |
| 18 - 84 | Placencia, Nayeli | Current resident | $761.00 | $0.00 | $-761.00 | [ ] Confirm paid | — |
| 18 - 85 | Salas Mendez, Doris J | Current resident | $221.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 19 - 87 | DELGADO, DULCILIO n | Current resident | $24.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 19 - 88 | Delgado Vilchez, Oskalit | Current resident | $15.00 | $0.00 | $-15.00 | [ ] Confirm paid | — |
| 19 - 89 | BRUNSON, YAKAIL | Former resident | $977.00 | $26.00 | $-951.00 | [ ] Confirm paid | — |
| 19 - 89 | Garvey, Rashauna C | Current resident | $6.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 19 - 90 | Estrada Rohena, Mary | Former resident | $2,728.00 | $99.95 | $0.00 | [ ] Confirm paid | — |
| 19 - 91 | Batista, Francisca A | Current resident | $165.00 | $0.00 | $-105.00 | [ ] Confirm paid | — |
| 19 - 93 | Boyd, Deja L | Current resident | $1,354.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 19 - 94 | IRVING, MARY | Former resident | $2,079.00 | $0.00 | $-2,079.00 | [ ] Confirm paid | — |
| 2 - 10 | Nuez Fermin, Yuderkis | Current resident | $75.00 | $1.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 6 | TALLEY, LIONDA | Current resident | $5.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 7 | Gordon, Sharee | Current resident | $2,131.00 | $446.00 | $-821.00 | [ ] Confirm paid | — |
| 2 - 8 | Pearson, Sierra M | Current resident | $239.00 | $0.00 | $-15.00 | [ ] Confirm paid | — |
| 20 - 95 | Luna Meza, Lisbeth | Current resident | $293.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 20 - 96 | MILLER, TRISHA | Former resident | $555.00 | $44.50 | $-510.50 | [ ] Confirm paid | — |
| 20 - 96 | Morgan, Cherisse | Former resident | $914.00 | $287.03 | $-626.97 | [ ] Confirm paid | — |
| 20 - 96 | Reid, Dyani I | Current resident | $173.00 | $0.00 | $-173.00 | [ ] Confirm paid | — |
| 20 - 97 | Maldonado, Milagros | Current resident | $82.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 20 - 98 | Bright, Loretta | Current resident | $176.99 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 20 - 99 | Albert, Mamie | Current resident | $114.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 22 | Garcia-franco, Awilda | Current resident | $58.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 23 | HANER, THOMAS | Former resident | $960.00 | $802.00 | $-158.00 | [ ] Confirm paid | — |
| 3 - 23 | Reid, Donna | Current resident | $13.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 24 | Rodriguez De Los Sant, Mayerlin V | Current resident | $649.00 | $0.00 | $-649.00 | [ ] Confirm paid | — |
| 3 - 25 | Skelton, Renita S | Current resident | $390.00 | $0.00 | $-390.00 | [ ] Confirm paid | — |
| 3 - 26 | WYNN, TAMEKA | Former resident | $40.00 | $0.00 | $-40.00 | [ ] Confirm paid | — |
| 3 - 26 | Nikulaidis, ColleenM | Current resident | $60.00 | $0.00 | $-15.00 | [ ] Confirm paid | — |
| 4 - 56 | Nong, Vicky N | Current resident | $20.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - 58 | Nelson, Berry | Current resident | $391.00 | $0.00 | $-391.00 | [ ] Confirm paid | — |
| 4 - 60 | REEDY, LINDA | Former resident | $745.00 | $365.00 | $-380.00 | [ ] Confirm paid | — |
| 4 - 60 | HINES, NOVELETTE A | Former resident | $105.00 | $82.74 | $-22.26 | [ ] Confirm paid | — |
| 4 - 60 | Lee, Alexis | Former resident | $1,902.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - 60 | Madison, Quadir | Current resident | $41.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 11 | MITCHELL, SHENEKA | Former resident | $1,935.00 | $0.00 | $-1,935.00 | [ ] Confirm paid | — |
| 5 - 11 | Ford, Shiquita | Current resident | $348.00 | $0.00 | $-348.00 | [ ] Confirm paid | — |
| 5 - 12 | BEACHAM, TANYA | Former resident | $506.00 | $235.00 | $-271.00 | [ ] Confirm paid | — |
| 5 - 12 | Frere, Jesula P | Current resident | $303.00 | $0.00 | $-227.00 | [ ] Confirm paid | — |
| 5 - 13 | COLEMAN, SIERA | Former resident | $478.00 | $0.00 | $-478.00 | [ ] Confirm paid | — |
| 5 - 14 | WRIGHT, JUANITA | Former resident | $440.00 | $356.00 | $-84.00 | [ ] Confirm paid | — |
| 5 - 14 | Perez, Kairaliz M | Current resident | $1,140.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 15 | MCCULLOUGH, TIE | Former resident | $316.00 | $45.00 | $-271.00 | [ ] Confirm paid | — |
| 5 - 15 | ST JEAN, MERLIKA | Former resident | $42.00 | $0.00 | $-42.00 | [ ] Confirm paid | — |
| 5 - 15 | Mota, Lucrecia | Current resident | $73.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 16 | Doughty, Sheryl L | Former resident | $1.00 | $0.00 | $-1.00 | [ ] Confirm paid | — |
| 5 - 16 | Walcott, Gabrylle | Current resident | $330.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 6 - 17 | Perry, Doretha | Current resident | $77.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 6 - 18 | Lyncee, Betie | Current resident | $80.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 6 - 19 | Ramirez, Wanda | Current resident | $257.00 | $0.00 | $-251.00 | [ ] Confirm paid | — |
| 7 - 27 | ALBERT, JOSILIN | Former resident | $540.00 | $0.00 | $-540.00 | [ ] Confirm paid | — |
| 7 - 27 | Nazario, Hector | Current resident | $56.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 7 - 28 | Stadom, Patricia | Current resident | $296.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 7 - 29 | Brown, Arsha S | Current resident | $14.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 7 - 30 | BOYD, ANASTASIA | Former resident | $1,012.00 | $0.00 | $-1,012.00 | [ ] Confirm paid | — |
| 7 - 30 | James, Denise L | Current resident | $5.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 7 - 31 | GARCIA RIO, YANEIXI | Current resident | $25.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 8 - 32 | Brown, Andrea R | Current resident | $719.00 | $0.00 | $-675.00 | [ ] Confirm paid | — |
| 8 - 33 | Boyd, Shaina Z | Current resident | $53.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 8 - 35 | Liepe, Robert | Current resident | $5,668.00 | $1,629.00 | $-3,894.00 | [ ] Confirm paid | — |
| 9 - 36 | Roquemore, Teresa | Current resident | $231.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 9 - 37 | St Jean, Raquel | Current resident | $636.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 9 - 38 | Griffin, Margaret | Current resident | $856.94 | $0.00 | $-742.94 | [ ] Confirm paid | — |
| 9 - 39 | Johnson, Grace E | Current resident | $36.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 9 - 40 | Hines, Annette | Current resident | $83.00 | $0.00 | $0.00 | [ ] Confirm paid | — |

## Resident Balance Follow-Up — Paid / Zero Balance

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 20 - 99 | ORTIZ, JESSICA | Former resident | $83.74 | $83.74 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property's supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*