# Crossroads of Lees Summit — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 5661023**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/05/2026 |
| Property manager | Jennifer Parks — crossroads@apartmentcorp.com — (816) 529-9274 |
| Regional manager | Leslie Rolon — leslie@apartmentcorp.com — (504) 247-3813 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Delinquency spreadsheet | `5661023_Crossroads of Lees Summit_Delinquent - Excel_58.xls` |
| Ledger accounts for review | 171 resident accounts |
| Residents with amount owed | 90 accounts; $196,214.63 |
| Prepaid / credit accounts | 81 accounts; $-112,814.09 |
| Availability entries | 18 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit's reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| 10-1002 | L3BC60CL | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 17-1705 | L3BC60CL | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 01-0106 | L3BC60CL | NTV Not Leased | [ ] Verified | __________________ |
| 04-0408 | L3BC60CL | NTV Not Leased | [ ] Verified | __________________ |
| 06-0601 | L3BC60CL | NTV Not Leased | [ ] Verified | __________________ |
| 09-0903 | L2BC60CL | NTV Not Leased | [ ] Verified | __________________ |
| 09-0905 | L2BC60CL | NTV Not Leased | [ ] Verified | __________________ |
| 12-1204 | L3BC60CL | NTV Not Leased | [ ] Verified | __________________ |
| 13-1306 | L2BC60CL | NTV Not Leased | [ ] Verified | __________________ |
| 14-1402 | L3BC60CL | NTV Not Leased | [ ] Verified | __________________ |
| 19-1906 | L3BC60CL | NTV Not Leased | [ ] Verified | __________________ |
| 21-2101 | L2BC60CL | NTV Not Leased | [ ] Verified | __________________ |
| 02-0206 | L2BC60CL | Vacant Leased Not Ready | [ ] Verified | __________________ |
| 04-0404 | L3BC60CL | Vacant Leased Not Ready | [ ] Verified | __________________ |
| 11-1105 | L2BC60CL | Vacant Leased Not Ready | [ ] Verified | __________________ |
| 14-1403 | L3BC60CL | Vacant Leased Not Ready | [ ] Verified | __________________ |
| 20-2001 | L2BC60CL | Vacant Leased Not Ready | [ ] Verified | __________________ |
| 21-2104 | L2BC60CL | Vacant Leased Not Ready | [ ] Verified | __________________ |

## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 01 - 0106 | Williams, Tamika L | NTV | $1.00 | $706.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02 - 0201 | Harrison, Ebony D | Current resident | $27.00 | $3,420.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02 - 0203 | Kinney, Ladina L | Current resident | $0.00 | $81.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02 - 0206 | Harvey, Kenya | Former resident | $0.00 | $1,646.00 | $1,646.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02 - 0206 | Kelly, Ailliesha | Applicant | $0.00 | $37.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02 - 0207 | Schwark, Ashley L | Current resident | $0.00 | $435.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02 - 0208 | Boldridge, Joyce | Current resident | $144.00 | $5,136.00 | $1,527.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 03 - 0302 | Tillmon, La'Kendra T | Current resident | $0.00 | $1,319.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 03 - 0305 | Cooke, TaylorRose | Current resident | $0.00 | $1,123.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 03 - 0306 | Dickerson, Monchel m | Current resident | $160.00 | $243.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 03 - 0308 | Jones 1, Partice | Current resident | $0.00 | $1,233.54 | $307.54 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04 - 0401 | Russell, Kyera | Current resident | $0.00 | $179.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04 - 0402 | Quarles, Gwendolyn | Current resident | $0.00 | $270.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04 - 0406 | Cooper, LaTanya Sharifa Aina | Current resident | $0.00 | $2,196.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04 - 0408 | Haynes, Melisa D | NTV | $0.00 | $833.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05 - 0502 | Westmoreland, Cierra | Current resident | $0.00 | $29.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05 - 0503 | Buford, Marteceonna | Current resident | $0.00 | $1,200.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05 - 0506 | Love, Briana | Current resident | $0.00 | $13,149.00 | $8,616.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05 - 0508 | Gardner, NaishiaO | Current resident | $0.00 | $1,917.00 | $131.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 06 - 0601 | Black, Alisha | NTV | $0.00 | $1,515.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 06 - 0602 | Williams, Tambra R | Current resident | $0.00 | $4,581.00 | $1,158.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 06 - 0603 | Deberry, Taytiana | Current resident | $0.00 | $98.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 06 - 0604 | Williams, Artessa V | Current resident | $36.00 | $240.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 07 - 0703 | Cunningham, Lauren N | Current resident | $0.00 | $2,265.00 | $111.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 07 - 0704 | Markeson, Brittany N | Current resident | $0.00 | $3,184.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 07 - 0705 | Barnes, Courtney | Current resident | $0.00 | $24.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 07 - 0706 | *Luster, Corletta | Current resident | $0.00 | $5,868.00 | $1,155.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 07 - 0707 | Hanks, Christen T | Current resident | $0.00 | $631.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 08 - 0801 | *Johnson, Sade | Current resident | $0.00 | $8,047.00 | $655.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 08 - 0803 | Beck, Denise E | Current resident | $0.00 | $1,253.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 08 - 0805 | Lee, Raven | Former resident | $0.00 | $5,615.00 | $5,423.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 08 - 0805 | Sullivan, Karen | Current resident | $148.00 | $6,067.74 | $340.74 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 08 - 0806 | Nooner, Janay E | Current resident | $0.00 | $319.00 | $75.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 08 - 0808 | Roberts, Iakita S | Current resident | $0.00 | $4,660.00 | $75.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 09 - 0901 | Hooker, Daeisha A | Current resident | $0.00 | $4,542.00 | $9.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 09 - 0905 | Holman, Daiva Nesha | NTV | $0.00 | $1,319.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 09 - 0906 | Wilkerson, Latoya Lunett | Current resident | $4.00 | $378.00 | $-4.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 09 - 0908 | Monroe, India | Current resident | $0.00 | $1,589.74 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1004 | Haskins, Brettkita Shanae | Current resident | $1.00 | $827.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1006 | Gaston, Nikia Bernice | Current resident | $0.00 | $1,662.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1101 | Midgyett, Krystal | Current resident | $0.00 | $2,364.36 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1102 | Swinney, TraMaine | Current resident | $0.00 | $697.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1104 | Merrill, ErinNichole | Current resident | $475.00 | $2,593.00 | $-475.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1105 | Atwood 2, Mindy | Applicant | $0.00 | $100.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1106 | Francis, Casandra Lynn | Current resident | $0.00 | $5,030.00 | $1,448.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1202 | JacksonBoyles, Vivian | Current resident | $0.00 | $1,582.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1204 | Hyman, Charlzetta Denise | NTV | $200.00 | $3,531.00 | $-200.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1206 | Crawford, Kichawn | Current resident | $0.00 | $2,928.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1207 | Adkins, Brianna Elaine | Current resident | $0.00 | $1,642.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1208 | Marshall, Ashley | Current resident | $0.00 | $116.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1306 | Jackson-Powell, AnitaGale | NTV | $0.00 | $9,625.00 | $5,398.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1307 | Johnson, Chanel N | Current resident | $0.00 | $745.74 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1308 | Harrington, Stephanie A | Current resident | $0.00 | $1,042.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1401 | Randle, Maya Ann | Current resident | $0.00 | $1,575.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1403 | Byers, Akia | Former resident | $0.00 | $4,266.87 | $2,071.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1403 | McDaniel, Charmetria | Current resident | $0.00 | $1,448.42 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1404 | Khiev, Christina | Current resident | $0.00 | $2,192.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1405 | *Cline, Timothy | Current resident | $0.00 | $8,588.39 | $3,762.39 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1406 | Brock, LarishaMichelle | Current resident | $215.00 | $371.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15 - 1504 | Hamilton, Jasmine | Current resident | $0.00 | $1,471.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 1601 | Alford, Kisha | Current resident | $0.00 | $4,370.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 1604 | Morris, Diane | Current resident | $0.00 | $182.68 | $13.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 1605 | Day, Kelly E | Current resident | $0.00 | $2,036.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 1607 | Moss, Re'Keya J | Current resident | $0.00 | $467.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 1701 | Baker, Keionna | Current resident | $0.00 | $1,048.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 1702 | Williams, Latoya Ann | Current resident | $0.00 | $2,863.00 | $157.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 1703 | Easter, Leslie | Current resident | $0.00 | $214.87 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 1705 | Dickerson, Dennisha | Former resident | $0.00 | $3,488.91 | $562.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 1707 | Davey, Cherrelle | Current resident | $0.00 | $1,998.29 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 1708 | Long Parsons, Morgan Mikayla | Current resident | $0.00 | $4,048.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18 - 1802 | Warrior, Keesha | Current resident | $0.00 | $644.02 | $594.02 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18 - 1806 | Jackson, Brittany Kiara | Current resident | $0.00 | $1,750.00 | $1,750.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18 - 1807 | Rotich, Chanelle Renee | Current resident | $0.00 | $294.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19 - 1902 | Turner, LaVeraM | Current resident | $0.00 | $3,988.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19 - 1908 | Booty, Marion | Current resident | $0.00 | $58.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20 - 2001 | Turner, SanDrea Eunique | Former applicant | $0.00 | $10.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20 - 2001 | Gordon, DeAndre | Applicant | $0.00 | $37.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20 - 2002 | Jones, Leah L | Current resident | $685.00 | $1,500.00 | $-685.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20 - 2004 | *Champions, Keianna | Current resident | $0.00 | $8,495.00 | $4,510.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20 - 2005 | Rodriquez, Lakesha | Current resident | $0.00 | $4,862.00 | $362.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20 - 2006 | Murray, Kearria Jarae | Current resident | $0.00 | $400.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20 - 2008 | Mathews, Shanicka | Current resident | $0.00 | $3,852.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 21 - 2102 | Hodges, Te'AuneLouise | Current resident | $0.00 | $6,082.00 | $1,657.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 21 - 2103 | Spann, Jalisa Angalique | Current resident | $0.00 | $20.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 21 - 2104 | *Pearson, Meshell'a | Former resident | $0.00 | $78.00 | $78.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 21 - 2104 | Howard, Latise | Applicant | $0.00 | $50.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 21 - 2106 | Jackson, Paige | Former resident | $0.00 | $2,215.67 | $2,215.67 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 21 - 2106 | Taylor 2, Lana | Current resident | $0.00 | $105.39 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 21 - 2107 | Lane, Jameshia Shontell | Current resident | $0.00 | $1,369.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| WAIT | Larkin, Ryan | Applicant | $0.00 | $37.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 01 - 0103 | Burnett, Cierra L | Current resident | $73.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 01 - 0105 | Milton, Miranna | Current resident | $1,569.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 02 - 0202 | Bullock, Shalise | Former resident | $974.00 | $0.00 | $-974.00 | [ ] Confirm paid | — |
| 02 - 0204 | Hill, Kee'arra | Current resident | $22.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 02 - 0205 | Abbott, Geneva | Former resident | $15,970.00 | $0.00 | $-15,970.00 | [ ] Confirm paid | — |
| 02 - 0205 | Kemp Pickens, Annette Irene | Current resident | $977.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 03 - 0301 | Moore, Jasmine S | Current resident | $548.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 03 - 0303 | *Cooper, TeQuilla | Former resident | $514.00 | $0.00 | $-514.00 | [ ] Confirm paid | — |
| 03 - 0303 | Gordon, DaNishaLeeann | Current resident | $0.33 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 03 - 0304 | Bridgeford, Latrina Rene | Current resident | $299.77 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 03 - 0305 | Kinchelow, Zearlmeka | Former resident | $2,710.00 | $2,238.00 | $-472.00 | [ ] Confirm paid | — |
| 03 - 0307 | Hodge, Barbara J | Current resident | $83.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 03 - 0308 | Griffin, RaKeyia | Former resident | $1,350.00 | $0.00 | $-1,350.00 | [ ] Confirm paid | — |
| 04 - 0401 | Leeks, Tyrainia | Former applicant | $1,052.00 | $0.00 | $-1,052.00 | [ ] Confirm paid | — |
| 04 - 0401 | Deberry, Monique | Former resident | $1,021.00 | $0.00 | $-1,021.00 | [ ] Confirm paid | — |
| 04 - 0403 | Scott, Precious Shaneece | Current resident | $2,538.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 04 - 0404 | Leeks, Tyrainia | Former resident | $3,129.00 | $0.00 | $-3,129.00 | [ ] Confirm paid | — |
| 05 - 0501 | Brackson, WandaDenise | Current resident | $1,166.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 05 - 0502 | Taylor, NatashaAurora | Former resident | $1,186.00 | $0.00 | $-1,186.00 | [ ] Confirm paid | — |
| 05 - 0504 | Rollins, Talisa R | Current resident | $152.00 | $0.00 | $-104.00 | [ ] Confirm paid | — |
| 06 - 0601 | Tivis, Natasha | Former resident | $565.00 | $0.00 | $-565.00 | [ ] Confirm paid | — |
| 06 - 0603 | Curtis, Quazandra | Former resident | $787.00 | $0.00 | $-787.00 | [ ] Confirm paid | — |
| 07 - 0701 | Bass, Ella Mae | Current resident | $298.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 07 - 0705 | Smith, Rose | Former resident | $1,059.00 | $0.00 | $-1,059.00 | [ ] Confirm paid | — |
| 08 - 0802 | Young, Lacheer | Former resident | $2,239.00 | $0.00 | $-2,239.00 | [ ] Confirm paid | — |
| 08 - 0804 | Vann, Michaela | Former resident | $7,477.00 | $37.00 | $-6,105.00 | [ ] Confirm paid | — |
| 08 - 0804 | COATES, CIERA B | Current resident | $172.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 08 - 0807 | Johnson, Nicole; Johnson, R'mya | Former resident | $2,333.00 | $0.00 | $-2,333.00 | [ ] Confirm paid | — |
| 08 - 0807 | Robinson, Tamisa | Current resident | $21.00 | $0.00 | $-21.00 | [ ] Confirm paid | — |
| 09 - 0904 | Phillips, BenjalaMichelle | Current resident | $76.00 | $0.00 | $-76.00 | [ ] Confirm paid | — |
| 10 - 1001 | Henderson, Xzaviara e | Current resident | $202.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 10 - 1002 | Taylor, Lana | Former resident | $254.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 10 - 1005 | Moore, Taneka | Former resident | $39.00 | $0.00 | $-39.00 | [ ] Confirm paid | — |
| 11 - 1102 | Knauls, Michelle | Former resident | $2,832.00 | $0.00 | $-2,832.00 | [ ] Confirm paid | — |
| 11 - 1105 | Shelby, Arnisha | Former resident | $293.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 12 - 1201 | Muhammad, Aminah | Former resident | $333.00 | $0.00 | $-333.00 | [ ] Confirm paid | — |
| 12 - 1201 | Robertson, Elizabeth | Current resident | $0.04 | $0.00 | $-0.04 | [ ] Confirm paid | — |
| 12 - 1203 | Ersery, Dianne L | Current resident | $3,683.00 | $0.00 | $-1,733.00 | [ ] Confirm paid | — |
| 12 - 1205 | Curtis, Qua'Zondra | Former resident | $1,347.00 | $0.00 | $-1,347.00 | [ ] Confirm paid | — |
| 12 - 1205 | Johnson, Chantae Nicole | Current resident | $37.96 | $0.00 | $-18.98 | [ ] Confirm paid | — |
| 13 - 1301 | Adams, JasmineDominique | Current resident | $1,886.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 13 - 1302 | *Lee, Cheyanne | Former resident | $9,184.00 | $0.00 | $-9,184.00 | [ ] Confirm paid | — |
| 13 - 1305 | Washington, Morgan | Former resident | $3,999.00 | $166.00 | $166.00 | [ ] Confirm paid | — |
| 13 - 1305 | Wray, Whitney | Current resident | $17.30 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 14 - 1402 | Greenlee, Danielle Dail | NTV | $1,515.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 14 - 1407 | Sylvan, D'Nesha M | NTV | $1,179.00 | $0.00 | $-461.00 | [ ] Confirm paid | — |
| 14 - 1408 | Sims, Kaelen | Former resident | $744.00 | $0.00 | $-744.00 | [ ] Confirm paid | — |
| 14 - 1408 | Taylor, MishonAbri | Current resident | $1,464.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 15 - 1501 | Love, Printess A | Current resident | $1,971.00 | $751.00 | $-1,587.00 | [ ] Confirm paid | — |
| 15 - 1502 | President, Jessica | Former resident | $1,272.00 | $0.00 | $-1,272.00 | [ ] Confirm paid | — |
| 15 - 1503 | Greer'Cobb, TiAjsia R | Current resident | $983.00 | $232.00 | $0.00 | [ ] Confirm paid | — |
| 15 - 1504 | Brown, Dianna | Former resident | $1,340.00 | $0.00 | $-1,340.00 | [ ] Confirm paid | — |
| 15 - 1505 | Mitchell, CheslaRenee | Current resident | $134.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 15 - 1506 | Murphy, Mila D. | Current resident | $590.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 16 - 1604 | *Griswold, Christionna | Former resident | $26.00 | $0.00 | $-26.00 | [ ] Confirm paid | — |
| 16 - 1606 | Smith, Tammra S | Current resident | $1,103.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 16 - 1608 | Johnson, Shanice | Former resident | $1,720.00 | $0.00 | $-1,720.00 | [ ] Confirm paid | — |
| 16 - 1608 | Williams, Makayla | Former resident | $72.00 | $0.00 | $-72.00 | [ ] Confirm paid | — |
| 17 - 1703 | Meyers, Tyteona | Former resident | $959.00 | $0.00 | $-959.00 | [ ] Confirm paid | — |
| 17 - 1704 | Smith, Shashawn Latrice | Current resident | $982.00 | $165.00 | $0.00 | [ ] Confirm paid | — |
| 17 - 1706 | Weaver, Jesse D | Current resident | $1,296.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 17 - 1707 | Williams, Lakaila | Former resident | $231.00 | $0.00 | $-231.00 | [ ] Confirm paid | — |
| 18 - 1803 | West, RaVeonna S | Current resident | $1,202.00 | $105.00 | $0.00 | [ ] Confirm paid | — |
| 18 - 1804 | Whitley, Kenyaria | Former resident | $5,653.00 | $0.00 | $-5,653.00 | [ ] Confirm paid | — |
| 18 - 1805 | Brim, Onyx | Former resident | $867.00 | $54.00 | $-867.00 | [ ] Confirm paid | — |
| 18 - 1805 | Griddine, Darrien | Current resident | $233.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 19 - 1901 | Dawson, Katelyn Sharell | Current resident | $1,874.00 | $5.00 | $5.00 | [ ] Confirm paid | — |
| 19 - 1903 | Killingsworth Jackson, Brittany Tenea | Current resident | $507.00 | $109.10 | $109.10 | [ ] Confirm paid | — |
| 19 - 1904 | Jerman, Genise | Current resident | $6.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 19 - 1905 | Davis, Shenetha | Former resident | $930.00 | $0.00 | $-930.00 | [ ] Confirm paid | — |
| 19 - 1906 | Jackson, Shiquita | Former resident | $848.00 | $0.00 | $-848.00 | [ ] Confirm paid | — |
| 19 - 1906 | Jones, DaraDornisha | NTV | $0.11 | $0.00 | $-0.11 | [ ] Confirm paid | — |
| 19 - 1907 | White, Latoya m | Current resident | $137.68 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 20 - 2001 | McCrory, Tijuana | Former resident | $665.00 | $0.00 | $-665.00 | [ ] Confirm paid | — |
| 20 - 2003 | Cates, Cristy L | Current resident | $1,166.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 20 - 2007 | Bland, Juanita | Current resident | $542.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 21 - 2101 | Caldwell, Nicole | Former resident | $8,866.00 | $0.00 | $-8,866.00 | [ ] Confirm paid | — |
| 21 - 2101 | Taylor, Ashley Nicole | NTV | $284.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 21 - 2105 | Scott, Alexia Nicole | Current resident | $792.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| WAIT | Caldwell, Nicolejanae | Applicant | $27.00 | $0.00 | $-27.00 | [ ] Confirm paid | — |
| WAIT | Petterson, Sugey | Applicant | $27.00 | $0.00 | $-27.00 | [ ] Confirm paid | — |

## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.

## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property's supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*