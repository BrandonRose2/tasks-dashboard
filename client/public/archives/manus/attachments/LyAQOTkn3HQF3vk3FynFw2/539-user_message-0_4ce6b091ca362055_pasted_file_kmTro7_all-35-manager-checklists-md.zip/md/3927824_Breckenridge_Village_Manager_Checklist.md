# Breckenridge Village — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 3927824**. Update the checkboxes and notes during or immediately after the manager call.

> **Note:** No named manager on file in Company Contacts for this property — only a shared assistant mailbox (lexingtonasst@apartmentcorp.com).

| Call details | Manager update |
|---|---|
| Availability report as of | 08/05/2026 |
| Property manager | _No contact on file in Company Contacts — confirm with regional manager._ |
| Regional manager | Leslie Rolon — leslie@apartmentcorp.com — (504) 247-3813 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Delinquency spreadsheet | `3927824_Breckenridge Village_Delinquent - Excel_58.xls` |
| Ledger accounts for review | 122 resident accounts |
| Residents with amount owed | 102 accounts; $157,147.13 |
| Prepaid / credit accounts | 20 accounts; $-3,139.17 |
| Availability entries | 4 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit's reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| 05-2006 | 4B2B | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| BREAK41-2107 | 4B2B | NTV Not Leased | [ ] Verified | __________________ |
| 54-2102 | 4B2B | Vacant Leased Ready | [ ] Verified | __________________ |
| BREAK41-2107 | 4B2B | NTV Not Leased | [ ] Verified | __________________ |

## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 01 - 2000 | Davis, Christian Dvan | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 01 - 2000 | Lopez, Miguel Angel | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 03 - 2004 | Clemons, Kendra | Former resident | $0.00 | $1,507.74 | $1,507.74 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04 - 2005 | DeLaCruz, Adelina | Former resident | $0.00 | $1,050.85 | $1,050.85 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04 - 2005 | *Harris, Janice Trinae | Former resident | $0.00 | $2,929.18 | $2,929.18 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05 - 2006 | Wethy, Katie | Former resident | $0.00 | $460.40 | $460.40 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05 - 2006 | Guzman-Ramirez, Guadalupe Adriana | Former resident | $0.00 | $2,891.19 | $2,891.19 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05 - 2006 | Moore-Evans, Amber | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05 - 2006 | Greenwood, Jyzharnae Anique | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05 - 2006 | Mayrhofen, Emerald Cea | Former resident | $0.00 | $199.93 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 06 - 2007 | King, Byron Dshawn | Current resident | $0.00 | $1,700.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 07 - 2008 | Powell, Nikkia | Former resident | $0.00 | $3,106.20 | $3,106.20 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 07 - 2008 | Mayes, Patricia | Former resident | $0.00 | $2,588.15 | $2,588.15 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 08 - 2009 | Carroll (EHA), Raveen | Former resident | $0.00 | $304.00 | $304.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 09 - 2100 | Showalter, Lauire Kathleen | Former resident | $0.00 | $619.38 | $619.38 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 09 - 2100 | Marusak, Alyssa | Former resident | $0.00 | $3,881.27 | $3,881.27 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 09 - 2100 | Torres, Edgar Ociel | Current resident | $0.00 | $1,410.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 2101 | Esparza (GPHA), Lanitra | Former resident | $76.00 | $376.00 | $300.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 2102 | Jenkins, Quashala | Former resident | $0.00 | $1,520.00 | $1,520.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 2102 | Potter(EHA), Akida Kecole | Current resident | $0.00 | $1,629.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 2103 | Massey, Tara | Former resident | $0.00 | $4,378.30 | $4,378.30 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 2103 | Ellis(DHA), Shelinda | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 2103 | Turner, Thomesha Quinta | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 2103 | Pyburn, Karmen | Former resident | $0.00 | $1,251.45 | $1,251.45 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 2103 | Hanford, Brandee Danielle | Former applicant | $0.00 | $90.00 | $90.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 2103 | Scott, Kendra Kimnae | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 2105 | Rocha, Andrea | Former resident | $0.00 | $3,176.13 | $3,176.13 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 2105 | Adam, Densel | Former resident | $0.00 | $333.00 | $333.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 2105 | Rodriguez, Efrain JR | Former applicant | $0.00 | $60.00 | $60.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 2107 | *Thomas(DHA), Kendra | Former resident | $0.00 | $7,666.49 | $7,666.49 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 2107 | Jones, Jessica Lynnette | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 2107 | Nash, Shanice | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 2107 | Showers, Mary Lockridge | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 2107 | Hall, Jerri | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 2107 | Lane, Jaida Logan | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 2107 | Williams, Brittanie Lanette | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 2107 | Abbs, Patrice D | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 2107 | Harris, Sandra Kay | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 2107 | Edwards, Veronica | Former resident | $0.00 | $2,539.65 | $2,539.65 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 2107 | Jones, Brittney Jacole | Current resident | $0.00 | $1,291.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 2108 | Kahn, Qaiser | Former resident | $0.00 | $2,022.10 | $2,022.10 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19 - 2200 | Bryant, Shelondria | Former resident | $0.00 | $1,662.00 | $1,662.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20 - 2201 | Vazquez-Perez, Luis Joel | Former resident | $0.00 | $1,845.85 | $1,845.85 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20 - 2201 | Robinson, Alyshia Sha Na | Former resident | $0.00 | $1,438.89 | $1,438.89 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20 - 2201 | Grant, Alexis Abril | Current resident | $0.00 | $1,415.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 21 - 2202 | Perkins, Pamela Jean | Former resident | $0.00 | $3,905.24 | $3,905.24 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 21 - 2202 | Selier, Amy | Former resident | $0.00 | $4,190.79 | $4,190.79 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 23 - 2204 | Smith, Trina Lashun | Former resident | $0.00 | $1,747.00 | $1,747.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 24 - 2000 | Burns, Jaquatia Nicole | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 25 - 2001 | Hughes, Joana | Current resident | $0.00 | $1,520.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 28 - 2004 | Job, Tedrick | Former resident | $0.00 | $1,258.01 | $1,258.01 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 29 - 2005 | Rufes, Gracia | Former resident | $0.00 | $1,942.74 | $1,942.74 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 29 - 2005 | Ontiveros, Ericka Vanessa | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 30 - 2006 | Kidd- Buie(EHA), Demecia | Former resident | $1,101.00 | $2,403.86 | $1,302.86 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 30 - 2006 | Floyd, Cynthia Ellen | Former resident | $0.00 | $0.01 | $0.01 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 30 - 2006 | Waits, Nikol Ann | Former resident | $0.00 | $1,083.68 | $1,083.68 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 31 - 2007 | Ramirez, Floriberta | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 31 - 2007 | Gonzalez, Crystal Marie | Current resident | $0.00 | $1,743.97 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 32 - 2008 | Franco, Consuelo | Former resident | $0.00 | $3,859.67 | $3,859.67 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 32 - 2008 | Gutierrez, Miranda Kay | Former resident | $0.00 | $4,232.00 | $4,232.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 33 - 2009 | Jones (GPHA), Alecia Makina | Former resident | $0.00 | $41.00 | $41.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 33 - 2009 | Hudgens, Alexandria Renee | Current resident | $0.00 | $1,752.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 37 - 2103 | Ladd, Joyce | Former resident | $0.00 | $2,738.60 | $2,738.60 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 37 - 2103 | Faz, Amanda | Former resident | $0.00 | $2,155.19 | $2,155.19 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 37 - 2103 | Young(GPHA), Tyra | Former resident | $0.00 | $504.25 | $504.25 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 38 - 2104 | McNamee, Tanya | Former resident | $0.00 | $2,022.81 | $2,022.81 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 39 - 2105 | Howell, Brandal D | Former resident | $0.00 | $2,120.00 | $2,120.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 39 - 2105 | *King, Dimetra | Former resident | $0.00 | $4,423.49 | $4,423.49 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 41 - 2107 | Ford, Shetterrica Laquinn | Current resident | $0.00 | $1,686.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 42 - 2108 | *Reed, Jessie | Former resident | $0.00 | $2,409.00 | $2,409.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 42 - 2108 | Hernandez, Silvia | Former resident | $0.00 | $718.30 | $718.30 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 44 - 2110 | McNeal-Young, Brittani Shavonne | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 44 - 2110 | Manning, Jacobie Jeneil | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 45 - 2111 | Wilson, Angel | Former resident | $0.00 | $1,263.46 | $1,263.46 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 45 - 2111 | Montgomery, Shuntai Levett | Former resident | $0.00 | $863.68 | $863.68 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 45 - 2111 | Campos, Brandy | Former resident | $0.00 | $2,245.49 | $2,245.49 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 46 - 2200 | Washington, Katherine | Former resident | $0.00 | $2,372.61 | $2,372.61 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 46 - 2200 | Barcenas-Lopez, Maria Tatiana | Former applicant | $0.00 | $60.00 | $60.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 46 - 2200 | Roberts, Arline Laraye | Current resident | $0.00 | $1,664.30 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 47 - 2201 | Hurt, Talonna Shanece | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 47 - 2201 | *Eme, Dashe | Former resident | $0.00 | $2,286.00 | $2,286.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 47 - 2201 | Limones, Diana | Former resident | $0.00 | $3,585.80 | $3,585.80 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 49 - 2203 | Cline, Shirley | Former resident | $0.00 | $3,380.77 | $3,380.77 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 53 - 2100 | Wafford, Ashley Nicole | Former resident | $0.00 | $2,042.60 | $2,042.60 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 54 - 2102 | Howard, Jennifer | Former resident | $0.00 | $3,992.96 | $3,992.96 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 54 - 2102 | Martin, Nathianna | Former resident | $0.00 | $3,679.05 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 54 - 2102 | Cherry, Maria Crystalyna | Applicant | $0.00 | $30.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 55 - 2104 | *Rolfe, Laverne | Former resident | $0.00 | $4,624.45 | $4,624.45 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 55 - 2104 | Turner, Amanda Michelle | Former resident | $0.00 | $1,478.50 | $1,478.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 55 - 2104 | McCormick, Jessica | Former resident | $0.00 | $2,836.99 | $2,836.99 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 55 - 2104 | Jones, Lydia Marie | Current resident | $0.00 | $1,776.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 56 - 2106 | Sargent(GPHA), Kaneshia | Former resident | $0.00 | $5,820.07 | $5,820.07 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 57 - 2200 | Lindsey(EHA), Lee Ethel | Former resident | $0.00 | $141.00 | $141.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 57 - 2200 | *Robinson, Kendra Zenea | Former resident | $0.00 | $3,393.18 | $3,393.18 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 57 - 2200 | Velaquez, Ruben Hernandez | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 57 - 2200 | McKnight, Diana Lynn | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 57 - 2200 | Strong, Liza Kendra Marie | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 58 - 2202 | Ross, Amanda | Former resident | $0.00 | $3,749.00 | $3,749.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 63 - 2302 | Gabriel(EHA), Arnette | Former resident | $0.00 | $42.00 | $42.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 63 - 2302 | Nelson, Karla(MHA) Lynette | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 65 - 2306 | Cofer(EHA), Katrecia | Former resident | $0.00 | $773.46 | $773.46 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 66 - 2308 | Alvarado, Aaron | Current resident | $0.00 | $1,672.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 03 - 2004 | Gonzalez, Maria | Current resident | $32.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 12 - 2103 | Wilson(GPHA), Tenisha | Former resident | $2,430.00 | $126.99 | $-2,303.01 | [ ] Confirm paid | — |
| 12 - 2103 | Shuck, Jayson Dale | Current resident | $0.26 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 15 - 2106 | Douglas(EHA), Diedra | Current resident | $301.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 21 - 2202 | Wiliams, Joyce Elaine | Former applicant | $5.00 | $0.00 | $-5.00 | [ ] Confirm paid | — |
| 21 - 2202 | Moran, Raegan Lexi | Current resident | $0.40 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 23 - 2204 | Edwards, Tiera Lutishia | Current resident | $10.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 24 - 2000 | Wallace, Zina(EHA) | Current resident | $3.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 28 - 2004 | Morales, Jose Luis | Current resident | $31.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 34 - 2100 | McBay, Charma | Current resident | $7.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 37 - 2103 | Kopaddy(GPHA), Kala Marie | Current resident | $4.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 40 - 2106 | English, Tonya | Current resident | $0.50 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 42 - 2108 | Lopez, Alexis Michelle | Current resident | $25.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 45 - 2111 | Trevino, Chelsea Mariah | Current resident | $13.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 47 - 2201 | Smith (EHA), Kristi Acy | Former resident | $288.00 | $0.00 | $-288.00 | [ ] Confirm paid | — |
| 48 - 2202 | Brown, Shandell R | Current resident | $0.33 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 52 - 2207 | Jenkins, Elisha Ladale | Current resident | $0.28 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 56 - 2106 | LeBlanc, Donna Mae | Current resident | $0.39 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 61 - 2300 | Maye, Tiffany Lynette | Current resident | $114.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 64 - 2304 | Lawson (EHA), Latonya | Current resident | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |

## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.

## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property's supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*