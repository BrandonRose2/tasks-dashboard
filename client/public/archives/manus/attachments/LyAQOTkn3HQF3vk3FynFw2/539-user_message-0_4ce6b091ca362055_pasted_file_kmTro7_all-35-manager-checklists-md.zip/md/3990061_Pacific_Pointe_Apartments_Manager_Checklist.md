# Pacific Pointe Apartments — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 3990061**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/04/2026 |
| Property manager | Hailey Huber — pacificpointe@apartmentcorp.com — (408) 510-4657 |
| Regional manager | Blake Weddington — blake@apartmentcorp.com — (310) 927-0020 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Delinquency spreadsheet | `3990061_Pacific Pointe Apartments_Delinquent - Excel_58.xls` |
| Ledger accounts for review | 213 resident accounts |
| Residents with amount owed | 159 accounts; $289,076.80 |
| Prepaid / credit accounts | 53 accounts; $-32,169.35 |
| Availability entries | 3 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit's reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| 4-H6 | 2B1B | Vacant Not Leased Ready | [ ] Verified | __________________ |
| 1-A4 | 1B1B | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 1-B1 | 1B1B | Vacant Not Leased Not Ready | [ ] Verified | __________________ |

## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - A1 | DelRio, Laticia | Former resident | $0.00 | $617.00 | $617.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - A1 | Aldana, Rosemary | Current resident | $20.00 | $224.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - A1 | Turner, Anwana Shanton | Former resident | $0.00 | $813.00 | $813.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - A2 | Carpenter, Harold | Former resident | $0.00 | $800.00 | $800.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - A2 | Atkins, Cheryl | Former resident | $0.00 | $300.00 | $300.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - A3 | Watkins, Jamal | Former resident | $0.00 | $66.00 | $66.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - A3 | MCCOY, APRIL J | Former resident | $0.00 | $336.00 | $336.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - A3 | Teel, Roslynn | Current resident | $0.00 | $363.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - A4 | Goudeaux, Annjanette | Former resident | $0.00 | $5,411.00 | $5,411.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - A4 | AMOS, RICKIE | Former resident | $30.00 | $496.00 | $466.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - A5 | Tanner, Theodore | Former resident | $0.00 | $161.00 | $161.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - A5 | Murphy, Constance Diane Nicole | Former resident | $0.00 | $2,536.00 | $2,536.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - A5 | Tiede, Sandra | Former resident | $0.00 | $502.00 | $502.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - A5 | Gonzales, Geraldine | Current resident | $0.00 | $471.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - A6 | Hernandez, Agustin | Current resident | $0.00 | $76.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - A7 | Garrett, Bria | Former resident | $0.00 | $77.00 | $77.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - A7 | Chavez, Shayla Guadalupe | Former resident | $0.00 | $625.00 | $625.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - A7 | Williams, Cheryl | Current resident | $145.00 | $375.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - A8 | Moralez, Virginia Ross | Former resident | $300.00 | $8,140.00 | $7,840.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - A8 | Russell, Lakin | Current resident | $850.00 | $6,300.00 | $608.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - B1 | Miller, Cecile | Former resident | $0.00 | $8,105.00 | $1,576.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - B2 | Ibanes, Anna | Current resident | $0.00 | $554.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - B4 | Campbell, Scott | Former resident | $0.00 | $227.11 | $227.11 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - B4 | Demattei, Anthony | Former resident | $0.00 | $3,027.00 | $3,027.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - B4 | hornsby, mark | Former resident | $0.00 | $1,261.00 | $1,261.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - B5 | Gonzales, Geraldine | Former resident | $0.00 | $206.00 | $206.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - B6 | Niblock, Wendy Marie | Former resident | $0.00 | $1,188.50 | $1,188.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - B6 | Gist, Melissa | Current resident | $97.00 | $1,124.00 | $25.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - B7 | Manriquez, Ofelia | Former resident | $0.00 | $254.00 | $254.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - B8 | Johnson, Kelly Ann | Former resident | $0.00 | $790.00 | $790.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - B8 | Coronel, Araceli | Former resident | $0.00 | $11,559.00 | $11,559.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - B8 | Brown, amaia | Former resident | $0.00 | $2,433.00 | $2,433.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - B8 | Jordan, Oscar | Current resident | $1.00 | $2,055.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - C1 | Hunter, Harry Dean | Former resident | $0.00 | $497.00 | $497.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - C1 | Thurmond, Kathy ann | Current resident | $0.00 | $106.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - C2 | Flores, Felicia | Former resident | $0.00 | $337.00 | $337.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - C2 | Thompson, Desire | Former resident | $0.00 | $1,376.00 | $1,376.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - C3 | Turner, Shannyn | Former resident | $0.00 | $539.00 | $539.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - C3 | McKinley, Carolyn | Former resident | $0.00 | $262.00 | $262.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - C3 | Salas, Susie | Former resident | $0.00 | $491.00 | $491.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - C3 | Arquines, Felipe J | Current resident | $160.00 | $738.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - C4 | WHATLEY, LISA MARIE | Former resident | $0.00 | $20,586.00 | $20,586.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - C4 | Williams, Cheryl Yvette | Former resident | $0.00 | $113.00 | $113.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - C5 | Pierre, Rickita | Former resident | $0.00 | $350.00 | $350.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - C5 | Alderson, Marcella | Former resident | $0.00 | $1,763.00 | $1,763.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - C5 | Scippio, Novis | Current resident | $0.00 | $198.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - C6 | Lynch Jr, Jamal | Former resident | $0.00 | $2,325.00 | $2,325.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - C6 | Pearson, Latres M | Former resident | $0.00 | $1,813.00 | $1,813.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - C6 | Pope, Embry | Current resident | $0.00 | $6,756.00 | $3,453.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - C7 | Carter, Toni | Former resident | $0.00 | $1,797.00 | $1,797.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - C7 | Wilson, Jamie | Former resident | $0.00 | $3,288.00 | $3,288.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - C7 | Blackburn, Niesha S | Current resident | $15.00 | $360.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - C8 | Champlin, Morgan | Former resident | $0.00 | $491.00 | $491.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - C8 | King, Bianca Jewel | Current resident | $146.00 | $419.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - D1 | Brownlee, Ruby | Former resident | $0.00 | $45.00 | $45.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - D1 | Melara, Ovidio | Former resident | $0.00 | $25.00 | $25.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - D1 | McGill, Pennie | Current resident | $29.00 | $546.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - D2 | Timberlake, Lorraine | Current resident | $256.00 | $317.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - D3 | Amos, Rickie | Former resident | $678.00 | $771.00 | $93.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - D3 | Matlard, Blondell K | Current resident | $0.00 | $362.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - D4 | THURMOND, KATHY ANN | Former resident | $603.00 | $624.00 | $21.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - D4 | Mclaren, Santasia Mahogany | Former resident | $0.00 | $8,887.60 | $8,887.60 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - D4 | Herrmann, Bradley R | Current resident | $0.00 | $97.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - D5 | Wofford, Debra | Former resident | $0.00 | $1,022.00 | $1,022.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - D5 | Tiexiera, Alicia | Former resident | $0.00 | $332.00 | $332.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - D5 | Piper, Michelle v | Former resident | $0.00 | $202.07 | $202.07 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - D5 | Taylor, Josephine | Current resident | $276.00 | $416.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - D6 | Kelly, Angela Rae | Former resident | $0.00 | $468.00 | $468.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - D6 | Lawson, Vera | Current resident | $29.00 | $68.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - D7 | Edwards, Tony | Former resident | $0.00 | $4,263.00 | $4,263.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - D8 | Cook, Joyce | Former resident | $0.00 | $971.00 | $971.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - D8 | Mcgehee, Juliette s | Former resident | $0.00 | $41.00 | $41.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - D8 | Jackson, Natashya | Current resident | $0.00 | $329.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - E1 | Russell, Glenda | Former resident | $0.00 | $3,858.00 | $3,858.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - E1 | Ayong, Gladys W | Former resident | $0.00 | $566.00 | $566.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - E1 | Warren, Marcellous | Current resident | $493.00 | $2,531.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - E2 | Brown, Russell | Current resident | $252.00 | $475.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - E3 | Zarkas, Ethel | Former resident | $0.00 | $650.00 | $650.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - E3 | Soun, Samath | Former resident | $0.00 | $3,135.00 | $3,135.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - E3 | Manglona, gregory | Former resident | $0.00 | $1,096.00 | $1,096.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - E3 | Hurley, Covell | Current resident | $0.00 | $718.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - E4 | Dearrillaga, Loren Gene | Former resident | $0.00 | $1,720.60 | $1,720.60 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - E4 | Romero, Marie v | Former resident | $0.00 | $1,507.00 | $1,507.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - E4 | Turner, Hope | Current resident | $206.00 | $281.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - E5 | Denison, Ryan | Former resident | $0.00 | $61.89 | $61.89 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - E5 | August, Kamilah Nicole | Former resident | $0.00 | $7,154.00 | $7,154.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - E5 | Johnson, barbara j | Current resident | $0.00 | $1,656.08 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - E6 | Porter, Lanetta | Former resident | $0.00 | $1,273.00 | $1,273.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - E6 | woods, saibre | Current resident | $0.00 | $1,325.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - E7 | Taavao, Feagaiai | Former resident | $0.00 | $1,275.00 | $1,275.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - E7 | TALTON, ROSE | Current resident | $0.00 | $691.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - E8 | Lord, Stephanie | Former resident | $0.00 | $1,054.00 | $1,054.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - E8 | Thurmond, Kathy | Former resident | $0.00 | $682.00 | $682.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - E8 | Scott, savannah N | Former resident | $0.00 | $8,168.08 | $8,168.08 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - E8 | Myers, demetrius | Former resident | $0.00 | $839.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - F1 | Plaster, Brandy N | Current resident | $0.00 | $1,033.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - F4 | *Miller, Kalikhia | Former resident | $856.00 | $5,904.00 | $5,048.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - F4 | Bonds, Johnny | Current resident | $0.00 | $815.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - F5 | DelaRosa Jr, Robert | Former resident | $272.00 | $611.00 | $339.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - F5 | West Taylor, Inesha | Current resident | $1,509.00 | $1,578.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - F6 | Navarrette, Vanessa | Former resident | $0.00 | $975.00 | $975.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - F6 | Rowel, Karen | Former resident | $0.00 | $4,049.87 | $4,049.87 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - F6 | Licon, Melania Bonnie | Former resident | $0.00 | $8,194.00 | $8,194.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - F6 | Hall, Adriano | Current resident | $2,345.00 | $3,725.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - F7 | Ward, Ruby | Current resident | $0.00 | $192.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - G3 | Edmond, Mathew | Current resident | $0.00 | $364.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - G4 | Booth, Barbara | Current resident | $239.00 | $364.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - G5 | Van, Thoeun | Current resident | $0.00 | $1,330.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - G6 | Vallem, Alexi M | Former resident | $0.00 | $5,543.00 | $5,543.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - G6 | Alvarado, Debbie Marie | Current resident | $0.00 | $933.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - G7 | Ricalde, Lambert | Former resident | $0.00 | $369.00 | $369.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - G7 | Sanchez, Sarah T | Former resident | $916.00 | $1,025.84 | $109.84 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - G8 | Jackson, Tinishia | Former resident | $0.00 | $3,273.00 | $3,273.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - G8 | Russell, Jevon | Current resident | $725.00 | $1,400.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - H1 | Perez, Michael | Former resident | $0.00 | $188.00 | $188.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - H2 | Hutchinson, Vashti i | Former resident | $0.00 | $321.26 | $321.26 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - H2 | Robbins, Bryan Richard | Former resident | $4,608.00 | $9,234.00 | $4,626.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - H3 | Spain, Jahquel | Former resident | $0.00 | $4,452.00 | $4,452.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - H3 | Ontiveros, Anthony Louis | Current resident | $0.35 | $481.00 | $-0.35 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - H4 | Vasquez, Renee Louise | Current resident | $0.00 | $1,406.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - H5 | Scrivens, Alexis | Former resident | $0.00 | $19,345.00 | $19,345.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - H6 | Mcquitter, Alice L | Former resident | $0.00 | $1,297.54 | $1,297.54 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - H6 | Powell, Natasha Monique | Former resident | $0.00 | $3,410.40 | $3,410.40 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - H6 | Ruiz, Julieanna | Former resident | $0.00 | $859.26 | $617.52 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - H7 | Owens, Rosalyn Lashawn | Former resident | $0.00 | $3,627.00 | $3,627.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - H7 | Flores, Blanca R | Former resident | $0.00 | $161.00 | $161.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - H7 | Martinez, Jalina | Current resident | $0.00 | $672.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - H8 | Ganner, Loreina | Former resident | $0.00 | $0.75 | $0.75 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - I1 | Gregerson, Diana | Former resident | $0.00 | $973.00 | $973.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - I1 | Stafford, Carol | Former resident | $0.00 | $946.00 | $946.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - I2 | White, Chauntae | Former resident | $0.00 | $41.00 | $41.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - I2 | Williams, Lori J | Current resident | $175.00 | $273.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - I3 | Kelley, Alexus | Former resident | $0.00 | $888.00 | $888.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - I3 | Wade, Roy | Former resident | $0.00 | $11,000.74 | $11,000.74 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - I3 | Brown, Betty | Former resident | $0.00 | $1,747.00 | $1,747.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - I3 | Hornsby, Mark | Current resident | $0.00 | $195.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - I4 | Hunter, Matthew | Former resident | $0.00 | $1,129.00 | $1,129.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - I5 | Wiebe, Terry | Current resident | $0.00 | $173.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - I7 | Battle, Vernon | Former resident | $0.00 | $725.00 | $725.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - I7 | Murray, Esbrionn Shynea | Former resident | $0.00 | $471.00 | $471.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - I7 | Lott, Donald Ray | Current resident | $224.00 | $1,160.00 | $148.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - I8 | VALLEM, ALEXI MICHELE | Former resident | $0.00 | $202.40 | $202.40 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - I8 | HAMILTON, BRANDY MARIE | Former resident | $879.00 | $1,034.00 | $155.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - I8 | Lewis, Ashley Marie | Former resident | $0.00 | $12,022.50 | $12,022.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - I8 | Ramirez, Susie Ann | Current resident | $0.00 | $197.99 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - J1 | Buckingham, Marjorie Lea | Former resident | $0.00 | $1,279.00 | $1,279.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - J1 | Conley, Jimmy | Current resident | $0.00 | $304.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - J3 | Mack, Debra | Former resident | $0.00 | $132.00 | $132.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - J5 | Perez, Gilbert | Former resident | $0.00 | $4,802.03 | $4,802.03 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - J5 | Harris, Kimba | Current resident | $0.00 | $81.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - J6 | Harrell, Ryan | Former resident | $0.00 | $4,858.00 | $4,858.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - J6 | Ocegueda, Jessica | Former resident | $0.00 | $78.00 | $78.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - J6 | Hart, Alissa Nicole | Former resident | $202.00 | $272.00 | $70.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - J6 | Martinez, Sonya Amparo | Former resident | $0.00 | $31.00 | $31.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - J6 | Grigsby, Kim c | Current resident | $0.00 | $1,636.31 | $10.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - J7 | *Zapata, Christina Marie | Former resident | $0.00 | $3,402.33 | $3,402.33 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - J7 | Rackley, Regina Lynn | Former resident | $0.00 | $1,092.00 | $1,092.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - J7 | Leon, Julia A | Current resident | $0.00 | $1,025.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - J8 | Rankins, James | Former resident | $338.00 | $1,065.00 | $727.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - A2 | Lopez, Linda rose | Current resident | $49.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - A5 | Alexander, Jatavia | Former resident | $1,664.00 | $0.00 | $-1,664.00 | [ ] Confirm paid | — |
| 1 - A7 | Khaton, Jasmine | Former resident | $1,085.00 | $0.00 | $-1,085.00 | [ ] Confirm paid | — |
| 1 - B1 | Baca, Connie | Former resident | $74.00 | $0.00 | $-74.00 | [ ] Confirm paid | — |
| 1 - B4 | Hurley, Covell | Former resident | $1,091.00 | $0.00 | $-1,091.00 | [ ] Confirm paid | — |
| 1 - B4 | Martinez, Stella | Current resident | $714.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - B5 | Fosterf, Antonio | Current resident | $4,727.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - B6 | Evans, Ivana | Former resident | $9.00 | $0.00 | $-9.00 | [ ] Confirm paid | — |
| 1 - B6 | Worku, Dejene A | Former resident | $464.94 | $0.00 | $-464.94 | [ ] Confirm paid | — |
| 1 - B6 | Leon, Julia a | Former resident | $222.00 | $0.00 | $-222.00 | [ ] Confirm paid | — |
| 1 - B7 | Trujillo, Vina Kathleen | Former resident | $757.00 | $0.00 | $-757.00 | [ ] Confirm paid | — |
| 1 - B7 | Huber, Hailey Anne | Current resident | $4,128.00 | $0.00 | $-1,318.00 | [ ] Confirm paid | — |
| 2 - C1 | Sandoval, Joaquin | Former resident | $61.00 | $0.00 | $-61.00 | [ ] Confirm paid | — |
| 2 - C2 | Warren, Brandy T | Former resident | $704.00 | $0.00 | $-704.00 | [ ] Confirm paid | — |
| 2 - C2 | Camarillo, Rogelio | Current resident | $161.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - C3 | Williams, Shadi B | Former resident | $283.00 | $0.00 | $-283.00 | [ ] Confirm paid | — |
| 2 - C4 | Sorce, Joseph | Current resident | $72.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - C6 | Rogers, Tyesha Nicole | Former resident | $889.00 | $0.00 | $-889.00 | [ ] Confirm paid | — |
| 2 - C6 | Holmes, Angela Christie | Former resident | $1,121.00 | $0.00 | $-1,121.00 | [ ] Confirm paid | — |
| 2 - D6 | Trejo, Huberto | Former resident | $35.00 | $0.00 | $-35.00 | [ ] Confirm paid | — |
| 2 - D7 | Ryan, Dejanay | Current resident | $1,142.00 | $480.00 | $0.00 | [ ] Confirm paid | — |
| 3 - E1 | Krag, Catherine | Former resident | $144.00 | $0.00 | $-144.00 | [ ] Confirm paid | — |
| 3 - E4 | Lozano, Ramon Enrique | Former resident | $532.00 | $0.00 | $-532.00 | [ ] Confirm paid | — |
| 3 - E6 | Turner, Brandon K | Former resident | $233.00 | $0.00 | $-233.00 | [ ] Confirm paid | — |
| 3 - E6 | Tafoya, Sandralina C. | Former resident | $1,717.00 | $0.00 | $-1,717.00 | [ ] Confirm paid | — |
| 3 - E8 | Stone, Jazmine | Current resident | $3,084.00 | $580.00 | $0.00 | [ ] Confirm paid | — |
| 3 - F1 | Willis, Y'Keisha | Former resident | $54.00 | $0.00 | $-54.00 | [ ] Confirm paid | — |
| 3 - F2 | Taylor, Betty Ann | Current resident | $458.00 | $363.00 | $0.00 | [ ] Confirm paid | — |
| 3 - F3 | Raleigh, Kevin | Current resident | $95.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - F8 | Anderson, Latisha | Current resident | $30.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - G1 | Lozano, Raelynn | Former resident | $616.00 | $0.00 | $-616.00 | [ ] Confirm paid | — |
| 4 - G1 | Dalton, Michael | Current resident | $646.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - G2 | Roberts, William | Current resident | $35.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - G6 | Spivey, Breneisha | Former resident | $6,918.00 | $5,978.00 | $-940.00 | [ ] Confirm paid | — |
| 4 - G7 | Arnold, Santrocilyn | Current resident | $48.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - G8 | Jackson, Natashya | Former resident | $160.65 | $0.00 | $-160.65 | [ ] Confirm paid | — |
| 4 - H1 | Aaron, Asheai d | Former resident | $262.00 | $0.00 | $-262.00 | [ ] Confirm paid | — |
| 4 - H1 | Tenette, Anthony J | Current resident | $1,103.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - H2 | Whitten, Vanessa Rose | Current resident | $814.00 | $165.00 | $0.00 | [ ] Confirm paid | — |
| 4 - H5 | McCullom, Sandra | Current resident | $800.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - H8 | Leon, Silvia I | Current resident | $352.00 | $199.00 | $0.00 | [ ] Confirm paid | — |
| 5 - I1 | King, Janice | Current resident | $990.00 | $844.00 | $0.00 | [ ] Confirm paid | — |
| 5 - I4 | ONEILL, KATHLEEN | Former resident | $678.00 | $0.00 | $-678.00 | [ ] Confirm paid | — |
| 5 - I4 | REED, BREOVIJANAY | Current resident | $36.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - I6 | San, Saleana | Current resident | $164.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - I7 | Nunez, Maria A | Former resident | $104.00 | $0.00 | $-104.00 | [ ] Confirm paid | — |
| 5 - J2 | Batton, Jeffrey | Current resident | $165.00 | $113.24 | $0.00 | [ ] Confirm paid | — |
| 5 - J3 | Stirling, Tyler | Former resident | $155.00 | $0.00 | $-155.00 | [ ] Confirm paid | — |
| 5 - J5 | Green, Darrell | Former resident | $173.00 | $62.00 | $-111.00 | [ ] Confirm paid | — |
| 5 - J7 | Slatton, Zeus Edward | Former resident | $3.00 | $0.00 | $-3.00 | [ ] Confirm paid | — |
| 5 - J8 | WATKINS, JAMOL RAMON | Former resident | $1,078.00 | $862.00 | $-216.00 | [ ] Confirm paid | — |
| 5 - J8 | Lillard, Kiona Shantel'ee | Former resident | $309.00 | $0.00 | $-309.00 | [ ] Confirm paid | — |
| 5 - J8 | Loud, Brittany | Current resident | $550.00 | $144.00 | $0.00 | [ ] Confirm paid | — |

## Resident Balance Follow-Up — Paid / Zero Balance

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - B3 | BLAKE, REGINA | Current resident | $96.00 | $96.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property's supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*