# Lexington Arms — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 3927823**. Update the checkboxes and notes during or immediately after the manager call.

> **Note:** No named manager on file in Company Contacts for this property — only a shared assistant mailbox (lexingtonasst@apartmentcorp.com).

| Call details | Manager update |
|---|---|
| Availability report as of | 08/05/2026 |
| Property manager | _No contact on file in Company Contacts — confirm with regional manager._ |
| Regional manager | Leslie Rolon — leslie@apartmentcorp.com — (504) 247-3813 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Delinquency spreadsheet | `3927823_Lexington Arms_Delinquent - Excel_58.xls` |
| Ledger accounts for review | 101 resident accounts |
| Residents with amount owed | 84 accounts; $180,015.77 |
| Prepaid / credit accounts | 17 accounts; $-1,414.10 |
| Availability entries | 2 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit's reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| 46-1521 | 4B2B | NTV Not Leased | [ ] Verified | __________________ |
| 17-1532 | 4B2B | Vacant Leased Not Ready | [ ] Verified | __________________ |

## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 01 - 400 | Sloan (GPHA), KathyRena | Former resident | $0.00 | $2,989.52 | $2,989.52 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 01 - 400 | Marquez, Velia | Current resident | $0.00 | $242.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02 - 402 | Becks, Vickie | Former resident | $0.00 | $1,561.11 | $1,561.11 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02 - 402 | Pineda, Victoria Carmen | Former resident | $0.00 | $1,924.50 | $1,924.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02 - 402 | Carroll, Stormy Elizabeth | Former resident | $0.00 | $626.00 | $626.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 03 - 404 | Redic, Antwyan | Former resident | $0.00 | $2,039.49 | $2,039.49 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04 - 406 | Kiertekles(WHA), Crystal | Former resident | $0.00 | $5,182.49 | $5,182.49 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05 - 408 | Parks(WHA), Shirley | Former resident | $0.00 | $1,565.00 | $1,565.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05 - 408 | Bryant, Sallie(WHA) Denise | Former resident | $0.00 | $111.00 | $111.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05 - 408 | Brooks, Sabrina Selena | Former resident | $0.00 | $2,005.05 | $2,005.05 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05 - 408 | Means, Terri | Former resident | $0.00 | $4,221.85 | $4,221.85 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05 - 408 | Barrett, Natalie Yeicia | Current resident | $0.00 | $1,821.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 06 - 409 | Williams, Carla | Former resident | $0.00 | $6,262.71 | $6,262.71 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 06 - 409 | Toler, Margie Nell-Davis | Former resident | $0.00 | $3,513.00 | $3,513.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 08 - 411 | Debase(WHA), Billie | Former resident | $0.00 | $27.00 | $27.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 09 - 412 | *White, Sherika Latoya | Former resident | $0.00 | $2,239.24 | $2,239.24 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 414 | Aguinaga, AdrianDeJesus | Former resident | $0.00 | $2,182.06 | $2,182.06 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 415 | Conway, Phillip Ahmad | Former resident | $0.00 | $3,599.35 | $3,599.35 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 415 | Zuniga, Maria DeLaCarmen | Former resident | $413.00 | $413.82 | $0.82 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 416 | Willis, Shalinthia | Former resident | $0.00 | $2,642.35 | $2,642.35 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15 - 100 | Fuller, Kristi Sharee | Former resident | $0.00 | $4,217.19 | $4,217.19 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 102 | Randall(DHA), Shamara | Former resident | $1,525.00 | $2,509.74 | $984.74 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 1532 | Becks(WHA), Linda | Former resident | $0.00 | $434.00 | $434.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18 - 1534 | Morsett, Gabriella | Former resident | $0.00 | $3,974.25 | $3,974.25 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19 - 1536 | Serrano, Candice Lynn | Current resident | $0.00 | $1,685.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 21 - 1540 | Gonzalez Sr, Robert | Former resident | $0.00 | $2,193.47 | $2,193.47 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 21 - 1540 | Webster, Jacklyn | Former resident | $0.00 | $3,386.10 | $3,386.10 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 21 - 1540 | Taulton, Natasha Lashawn | Current resident | $0.00 | $1,730.25 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 24 - 1546 | Majors, La'Quina Iesha | Current resident | $0.00 | $1,600.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 26 - 1501 | Sallie (GPHA), Lateefah Raqaih | Former resident | $0.00 | $59.00 | $59.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 26 - 1501 | Williams, Keisha Shanae | Former resident | $0.00 | $1,751.45 | $1,751.45 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 28 - 1503 | *Schellhas, Brenae E | Former resident | $0.00 | $3,534.19 | $3,534.19 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 28 - 1503 | Rubio, Antonio | Former resident | $0.00 | $2,233.29 | $2,233.29 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 29 - 1504 | Sims, Sable Deone | Former resident | $0.00 | $176.25 | $176.25 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 30 - 1505 | Justiniano, Josue | Former resident | $0.00 | $275.00 | $275.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 30 - 1505 | Sanders, Khyela Kaye | Current resident | $0.00 | $1,378.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 31 - 1506 | Newton, Rasheeda | Current resident | $0.00 | $1,751.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 33 - 1508 | Willis, Darshia | Former resident | $0.00 | $1,150.00 | $1,150.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 33 - 1508 | Wigfall (WHA), Crystal Shanae | Former resident | $0.00 | $965.00 | $965.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 34 - 1509 | Smith, Ashley Necole | Former resident | $0.00 | $2,981.75 | $2,981.75 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 34 - 1509 | *Harden, Jasmin Jerrod | Former resident | $0.00 | $4,209.00 | $4,209.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 35 - 1510 | Godbey, Fannie | Former resident | $0.00 | $150.00 | $150.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 37 - 1512 | Brown, Kristen | Former resident | $0.00 | $1,202.19 | $1,202.19 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 37 - 1512 | Carroll, Evelyn Denise | Former resident | $0.00 | $2,567.00 | $2,567.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 37 - 1512 | *Smith, DevonaNiesha | Former resident | $0.00 | $2,895.99 | $2,895.99 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 37 - 1512 | Taylor, Ambert Michelle | Former applicant | $0.00 | $60.00 | $60.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 37 - 1512 | Burns, Raphael C-V | Current resident | $0.00 | $1,472.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 39 - 1514 | Johnson(WHA), Latasha | Former resident | $0.00 | $29.00 | $29.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 39 - 1514 | Robinson, De'Quavius Rashad | Former resident | $0.00 | $1,723.10 | $1,723.10 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 39 - 1514 | Ladd, Becky | Former resident | $0.00 | $1,324.45 | $1,324.45 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 39 - 1514 | Davis, Rachel Lenore | Current resident | $0.00 | $1,777.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 40 - 1515 | Rollins, Chauncey | Former resident | $0.00 | $4,324.63 | $4,324.63 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 40 - 1515 | *Zubiri, Destanye | Former resident | $0.00 | $4,727.75 | $4,727.75 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 40 - 1515 | Henley, Holly C | Current resident | $0.00 | $0.53 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 41 - 1516 | Butler, Kimberly | Former resident | $0.00 | $2,107.19 | $2,107.19 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 42 - 1517 | Callejas, Erika | Former resident | $0.00 | $664.00 | $664.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 43 - 1518 | Ingram, Shayla | Former resident | $0.00 | $4,178.33 | $4,178.33 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 43 - 1518 | Alexander(EHA), Shena | Former resident | $0.00 | $2,862.74 | $2,862.74 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 44 - 1519 | Walker, Angie Alaine | Former resident | $0.00 | $4,510.00 | $4,510.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 45 - 1520 | Mason, SheneshiaL | Former resident | $0.00 | $3,147.84 | $3,147.84 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 45 - 1520 | Parker, Jasmine Rochelle | Former resident | $0.00 | $3,472.00 | $3,472.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 45 - 1520 | Herod, Amber Nichole | Former resident | $0.00 | $2,571.94 | $2,571.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 45 - 1520 | Arevalo, Bianka | Former resident | $0.00 | $2,224.30 | $2,224.30 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 46 - 1521 | *Patrick, Jaclyn Leeann | Former resident | $0.00 | $4,354.76 | $4,354.76 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 47 - 1522 | Willams (WHA), Gloria | Former resident | $366.00 | $1,719.85 | $1,353.85 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 47 - 1522 | Hearn, Valarie | Former resident | $0.00 | $2,980.24 | $2,980.24 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 48 - 1523 | Alsbrooks, Harley Marshall | Former resident | $0.00 | $954.58 | $954.58 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 49 - 1524 | Cabrera, Vanessa | Former resident | $0.00 | $5,259.00 | $5,259.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 50 - 1525 | Taylor (LHHA), JamiliaNaquee | Former resident | $0.00 | $614.00 | $614.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 50 - 1525 | *Lark, Diamond Lorine | Former resident | $0.00 | $7,227.00 | $7,227.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 51 - 1526 | Patino, Petra | Former resident | $0.00 | $2,154.14 | $2,154.14 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 52 - 1527 | Kane, Sara | Former resident | $0.00 | $1,879.50 | $1,879.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 53 - 1528 | Hubbard(GPHA), DianeReynolds | Former resident | $0.00 | $1,201.19 | $1,201.19 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 54 - 1529 | *Morales, Gabriel | Former resident | $0.00 | $5,361.38 | $5,361.38 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 55 - 1530 | Wofford(GPHA), Shanae | Former resident | $0.00 | $611.00 | $611.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 57 - 1532 | Smith(WHA), Donna | Former resident | $0.00 | $176.00 | $176.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 58 - 1533 | Davis(WHA), Bernice | Former resident | $0.00 | $1,007.00 | $1,007.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 58 - 1533 | *Sadler, Aaron B | Former resident | $0.00 | $2,266.79 | $2,266.79 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 59 - 1534 | Jackson, Davon | Former resident | $0.00 | $3,636.00 | $3,636.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 59 - 1534 | Jones, Barbara Jean | Current resident | $0.00 | $180.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 60 - 1536 | Mack, Joann(GPHA) | Former resident | $0.00 | $284.00 | $284.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 61 - 1538 | Piper, Michael Earl | Former resident | $0.00 | $1,718.54 | $1,718.54 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 61 - 1538 | Clark, Mark Anthony | Former resident | $0.00 | $1,678.35 | $1,678.35 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 61 - 1538 | Davis, Andrea Deshawn | Current resident | $0.00 | $1,702.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 03 - 404 | Moreno, Nikki A | Current resident | $1.33 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 04 - 406 | Alvarez, Erica Ranee | Current resident | $2.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 06 - 409 | Nash, Shantel A | Current resident | $0.50 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 13 - 416 | Solis, Kasey Michelle | Current resident | $4.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 17 - 1532 | Talton, Breylin Trent | Former resident | $16.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 18 - 1534 | Starks, Magayle Andrew | Current resident | $5.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 22 - 1542 | Johnson(GPHA), LaKeisha D | Current resident | $2.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 27 - 1502 | Williams, Velma | Current resident | $3.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 33 - 1508 | Partida, Jessie Raquel | Current resident | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 34 - 1509 | Thompson, Dezarai Symone | Current resident | $14.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 36 - 1511 | Rodriguez, Stephanie Marie | Current resident | $15.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 38 - 1513 | Davis, Jennifer | Current resident | $35.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 46 - 1521 | Ontiveros III, Antonio | NTV | $15.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 47 - 1522 | Brown, Lela Joanne | Current resident | $0.37 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 48 - 1523 | Jay, Tessia Marlene | Current resident | $0.90 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 51 - 1526 | Salazar (GPHA), Kriselda | Former resident | $5,147.00 | $3,849.00 | $-1,298.00 | [ ] Confirm paid | — |
| 51 - 1526 | Wright, Ariane Na`Chel | Current resident | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |

## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.

## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property's supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*