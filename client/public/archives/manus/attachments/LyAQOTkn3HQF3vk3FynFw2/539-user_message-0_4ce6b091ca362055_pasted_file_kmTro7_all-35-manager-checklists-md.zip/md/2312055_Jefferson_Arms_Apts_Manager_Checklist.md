# Jefferson Arms Apts — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 2312055**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/05/2026 |
| Property manager | Brandy Amador — jefferson@apartmentcorp.com — (352) 230-2606 |
| Regional manager | JR Rolon — jrrolon@apartmentcorp.com — (941) 716-1665; Leslie Rolon — leslie@apartmentcorp.com — (504) 247-3813 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Delinquency spreadsheet | `2312055_Jefferson Arms Apts_Delinquent - Excel_58.xls` |
| Ledger accounts for review | 321 resident accounts |
| Residents with amount owed | 249 accounts; $234,550.18 |
| Prepaid / credit accounts | 68 accounts; $-32,471.87 |
| Availability entries | 0 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit's reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| — | — | No unit-status entries in the selected source export | [ ] Verified | __________________ |

## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| A1 | ROWLES, VALKEITHSHA C | Former resident | $0.00 | $42.00 | $42.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A1 | WILLIAMS, DARIUS | Former resident | $0.00 | $130.00 | $130.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A1 | Flowers, Archie L | Former resident | $0.00 | $63.67 | $63.67 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A1 | QUINTERO HERNANDEZ, MAGDALIS | Former resident | $0.00 | $191.94 | $191.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A1 | Perez, Johanna | Former resident | $0.00 | $65.97 | $65.97 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A2 | RANDALL, ANNIE BEVERLY | Former resident | $0.00 | $42.40 | $42.40 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A2 | KILLAM, STEVEN CHESTER | Current resident | $0.00 | $245.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A3 | ANDERSON, ALANNA | Former resident | $0.00 | $222.00 | $222.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A3 | PARRISH, NINETTA MONICA | Current resident | $0.00 | $24.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A4 | WAGNER, SHANTEL | Former resident | $0.00 | $35.00 | $35.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A4 | RICHARDS, FELICIA | Former resident | $0.00 | $76.00 | $76.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A4 | PARKER, LAKENDRIA | Former resident | $0.00 | $1.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A4 | HEADY, LINDSEY R | Former resident | $0.00 | $12.96 | $12.96 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A4 | Wade, Ladeja Rashawn | Former resident | $44.00 | $283.94 | $239.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A4 | Henry, Tyshunda K | Former resident | $0.00 | $1,036.75 | $1,036.75 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A5 | SPANKS, MAQUISHA | Former resident | $0.00 | $5.00 | $5.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A5 | COE, SHARAHONDRA L | Current resident | $9.00 | $241.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A6 | SUTTON, ANGELA | Former resident | $0.00 | $271.00 | $271.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A7 | BRYANT, KACY | Former resident | $0.00 | $111.00 | $111.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A7 | MILLER, NARTOSA W | Former resident | $0.00 | $2,193.00 | $2,193.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A7 | GRIFFIN, SHANTILLE M | Former resident | $0.00 | $4.94 | $4.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A7 | DEAL, MEGHAN MARIE | Former resident | $0.00 | $18.00 | $18.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A7 | Cruz Franco, Judith Waleska | Former resident | $0.00 | $1.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A7 | JOHNSON, SHONTAY PATRICE | Former resident | $0.00 | $104.00 | $104.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A7 | TONTHAT, KHANH BAO | Former resident | $0.00 | $324.03 | $324.03 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A8 | DENT, ELOUISE | Former resident | $0.00 | $646.00 | $646.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A8 | SCULLEY, DEYSI C | Former resident | $0.00 | $749.00 | $749.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A8 | HILLS, JASMINE LASHAY | Former resident | $0.00 | $1.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A8 | BURNS, CRISSA LEEANN | Former resident | $1.00 | $124.98 | $123.98 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A8 | Jordan, Timeika L | Former resident | $0.00 | $17.76 | $17.76 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A8 | Powell, Amminta | Former resident | $0.00 | $39.96 | $39.96 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A8 | Campbell, Debra | Current resident | $0.00 | $882.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B1 | MILLER, TAQUARA | Former resident | $0.00 | $830.00 | $830.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B1 | WILLIAMS, ANDRIA S | Former resident | $0.00 | $55.00 | $55.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B1 | MORALES, YARRISA Y | Former resident | $0.00 | $1.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B1 | REESE, CRYSTAL DENIECE | Former resident | $0.00 | $129.88 | $129.88 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B1 | Adams, Erica | Former resident | $0.00 | $3,272.87 | $3,272.87 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B2 | JOHNSON, JACQUELINE | Former resident | $0.00 | $237.00 | $237.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B2 | PARAMORE, KATHY D | Former resident | $0.00 | $794.00 | $794.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B2 | PEREZ, ROSANA C | Former resident | $0.00 | $971.00 | $971.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B2 | Alguire, Kimberly Anne | Former resident | $0.00 | $235.00 | $235.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B3 | SEABROOKS, DVONACHE | Former resident | $0.00 | $1,524.00 | $1,524.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B3 | CAMPBELL, YOLANDA NICHOLE | Former resident | $7.00 | $904.00 | $897.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C1 | JOHNSON, VERONICA L | Current resident | $0.00 | $865.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C10 | JUETT, NATALIE | Former resident | $0.00 | $764.00 | $764.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C11 | HAWKINS, REGINA | Former resident | $0.00 | $1,279.00 | $1,279.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C11 | GREENE, KEMESHONA PATRICE | Former resident | $0.00 | $124.99 | $124.99 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C11 | Kirksey, Kimyrian L | Former resident | $0.00 | $151.99 | $151.99 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C11 | Gibson, Detra E | Former resident | $0.00 | $41.00 | $41.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C12 | MILLER, SHANTAVIA A | Former resident | $0.00 | $918.00 | $918.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C12 | DEMPS, ASHLIE C | Former resident | $0.00 | $8.00 | $8.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C12 | BOOKER, BARBARA A | Former resident | $0.00 | $359.82 | $359.82 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C2 | BROOKS, SHANICE | Former resident | $0.00 | $2,051.00 | $2,051.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C2 | WALKER, KA'LEICIA DENISE LAVON | Former resident | $0.00 | $301.84 | $301.84 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C2 | Kirksey, Kimyrian | Current resident | $0.00 | $72.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C3 | MOORE, CARRIE | Former resident | $0.00 | $507.00 | $507.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C4 | LAMAR, LATOYA | Former resident | $0.00 | $752.00 | $752.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C4 | WALKER, FLORA CRESHAWN | Former resident | $309.00 | $1,254.85 | $945.85 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C4 | WHITE, ANGEL LEI | Former resident | $0.00 | $524.99 | $524.99 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C6 | WILLIAMS, ANNETTE | Former resident | $0.00 | $58.13 | $58.13 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C6 | Winters, James E | Former resident | $0.00 | $143.00 | $143.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C6 | Littles, Jasia | Former resident | $0.00 | $151.97 | $151.97 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C7 | LINDSEY, CHAQUANDA | Former resident | $0.00 | $688.00 | $688.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C7 | SHELLEY, SALLY MAE | Former resident | $0.00 | $3,598.00 | $3,598.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C7 | HILLS, SHONTERIA LATRICE | Current resident | $511.00 | $1,537.00 | $-52.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C8 | WILLIAMS, MONIKA | Former resident | $0.00 | $1,338.00 | $1,338.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C8 | FISHBURN, JASMIN | Former resident | $0.00 | $124.00 | $124.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C8 | HAMPTON, T'SANANI MONE | Former resident | $1.00 | $971.99 | $970.99 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C8 | Denmark, Tamiramah Jasmine | Former resident | $0.00 | $51.00 | $51.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C8 | BROWNELL, COURTNEY LEIGH | Former resident | $1.00 | $74.97 | $73.97 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C8 | Tillman, Brandon R | Former resident | $0.00 | $45.95 | $45.95 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C9 | GALLON, KHIER | Former resident | $0.00 | $458.00 | $458.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C9 | DAVIS, KIMBERLY | Former resident | $0.00 | $630.00 | $630.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C9 | WILLIAMS, CASSANDRA | Former resident | $0.00 | $1,028.72 | $1,028.72 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C9 | BRYANT, STORMI | Former resident | $1.00 | $103.00 | $102.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C9 | STEVENS, KENYA JAQUETTA | Former resident | $0.00 | $12,174.79 | $12,174.79 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C9 | Patrick, Javion D | Current resident | $98.00 | $351.00 | $-11.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D1 | SOLDIEW, KARLEE ELYSE | Former resident | $0.00 | $2,824.87 | $2,824.87 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D2 | LOCKLEY, STACI | Former resident | $0.00 | $636.00 | $636.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D2 | WALKER, CARDREICA | Former resident | $0.00 | $566.91 | $566.91 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D2 | STEEN, JAMIYA A | Former resident | $0.00 | $4,653.70 | $4,653.70 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D3 | CRUMITIE, NANCY | Former resident | $0.00 | $842.00 | $842.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D3 | MOSLEY, KENDRICK A | Former resident | $0.00 | $1,802.26 | $1,802.26 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D3 | SCOTT, KEYANNA JANET | Former resident | $0.00 | $1,005.90 | $1,005.90 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E1 | MCINTOSH, CHRISTOPHER | Former resident | $0.00 | $1,466.71 | $1,466.71 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E2 | ELLIS, SHONTINA | Former resident | $0.00 | $795.00 | $795.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E3 | PLEAS, KEYONDRA | Former resident | $0.00 | $938.00 | $938.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E3 | DAWSON, LATESHIA | Former resident | $68.00 | $880.00 | $812.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E3 | GREER, SHEANTIA L | Former resident | $0.00 | $1,272.00 | $1,272.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E3 | JOHNSON, MOSES | Former resident | $0.00 | $1,014.94 | $1,014.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E3 | Jones, Shekote T | Current resident | $227.00 | $718.00 | $-87.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E4 | GREEN, BRITTNEY | Former resident | $0.00 | $829.00 | $829.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E4 | RANDLE, LASHONTE R | Former resident | $60.00 | $1,866.02 | $1,806.02 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E4 | Thomas, AnJonai Breanna | Former resident | $0.00 | $125.96 | $125.96 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E6 | MILLER, NARTOSA | Former resident | $0.00 | $944.00 | $944.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E6 | JONES, SHATARA | Former resident | $0.00 | $575.00 | $575.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E6 | BOOKER, ALICIA R | Former resident | $0.00 | $565.96 | $565.96 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E6 | PAYNE, KELLY ANN | Former resident | $0.00 | $1.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E6 | SMITH, DORA MAE | Former resident | $159.00 | $527.00 | $368.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E6 | Taylor, Vonshayla B | Former resident | $0.00 | $1.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E6 | Ardley, Antwhon | Current resident | $0.00 | $31.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E7 | PARKER, SALLY | Former resident | $0.00 | $1,501.00 | $1,501.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E7 | MERCADO COLON, KARLA M | Former resident | $0.00 | $190.43 | $190.43 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E7 | GILLYARD, EZEKIEL DEVAN | Former resident | $0.00 | $831.42 | $831.42 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E7 | McDaniel, Felisla | Former resident | $0.00 | $2,324.34 | $2,324.34 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E8 | LEWIS, PRISCILLA D | Former resident | $0.00 | $835.00 | $835.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E8 | ANDREWS, JAMAURA G | Former resident | $972.00 | $2,287.78 | $1,315.78 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E8 | Lewis, JhaQuorsha Kaeisa | Current resident | $330.00 | $596.00 | $-129.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F1 | CAMPBELL, TOCARRA | Former resident | $0.00 | $1,695.00 | $1,695.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F1 | DUGENT, HEATHER | Former resident | $0.00 | $135.00 | $135.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F1 | MILLER, LASHAVIA | Former resident | $0.00 | $212.00 | $212.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F1 | WADE, JAZZ'LYN D | Former resident | $0.00 | $2,120.87 | $2,120.87 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F1 | STEEN, YAKIRA M | Former resident | $0.00 | $2,650.73 | $2,650.73 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F1 | APONTE VAZQUEZ, PAULA ESTHER | Former resident | $0.00 | $1,886.00 | $1,886.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F1 | GREGORY, KAWONNA LASHAYE | Former resident | $47.00 | $64.94 | $17.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F1 | Johnson, Demeacha | Former resident | $0.00 | $40.31 | $40.31 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F2 | LEONARD, QUIENKKA | Former resident | $0.00 | $855.00 | $855.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F2 | BROWN, NEVA | Former resident | $0.00 | $91.00 | $91.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F2 | *PARAMORE, EVELYN M | Former resident | $80.00 | $740.00 | $660.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F2 | MATHIS, WILLIAM RANDALL | Former resident | $0.00 | $629.51 | $629.51 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F2 | Placensia, Nevaeh | Former resident | $0.00 | $34.74 | $34.74 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F3 | *COPELAND, ESSIE M | Former resident | $0.00 | $2,685.00 | $2,685.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F3 | PLEAS, AKEILA JARON WENDELL | Former resident | $0.00 | $211.00 | $211.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F4 | JONES, LAPHADRA | Former resident | $0.00 | $1,551.56 | $1,551.56 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F4 | SHIVER, CHRISTINA | Former resident | $0.00 | $51.00 | $51.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F4 | Scott, Lovie | Former resident | $0.00 | $40.00 | $40.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F4 | Toussaint, Gemima | Former resident | $0.00 | $1.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F4 | Taylor, Vonshalya | Current resident | $0.00 | $1.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F5 | Garcia Cruz, Carla M | Former resident | $0.00 | $1.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F5 | DEMBY, TIERRA QIANA NICOLE | Former resident | $0.00 | $132.00 | $132.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F7 | ODOM, KELVONTAE | Former resident | $0.00 | $815.00 | $815.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F7 | JONES, PORTIA | Former resident | $0.00 | $82.00 | $82.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F7 | BEVERLY, HARYANA M | Former resident | $0.00 | $2,316.00 | $2,316.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F7 | BRYANT, MICHELLE NICOLE | Former resident | $0.00 | $3,228.00 | $3,228.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F7 | *Parker Johnson, Lakendria Roshay | Former resident | $0.00 | $204.00 | $204.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F7 | JAMES, SHATILA LANE | Former resident | $0.00 | $1,157.88 | $1,157.88 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F7 | Tatum, Jasmine L | Former resident | $0.00 | $1,456.94 | $1,456.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F8 | MCDANIEL, FELICIA | Former resident | $0.00 | $565.00 | $565.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F8 | DICKEY, AMBER S | Former resident | $0.00 | $52.00 | $52.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F8 | BRNETT, BRANDI | Former resident | $0.00 | $59.00 | $59.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F8 | SCOTT, FREIDA BEYONKA | Former resident | $770.00 | $6,697.00 | $5,927.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G1 | RUSSELL, REGINA | Former resident | $0.00 | $607.00 | $607.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G1 | SCOTT, TAMARA | Former resident | $0.00 | $2.00 | $2.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G1 | PULZONE, ANDREA | Former resident | $0.00 | $43.98 | $43.98 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G1 | BENTON, JOY | Former resident | $0.00 | $907.00 | $907.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G2 | GALLON, BEATRICE | Former resident | $0.00 | $794.00 | $794.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G2 | HENDERSON, RENA | Former resident | $0.00 | $143.00 | $143.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G2 | MARIN-PRIETO, SUSAN | Former resident | $1.00 | $128.00 | $127.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G2 | COLON CARLO, WILMA | Former resident | $0.00 | $40.00 | $40.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G2 | APONTE-BETANCOURT, MARIA DE LOURDES | Former resident | $0.00 | $491.81 | $491.81 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G2 | Parrish, Kiara Rojunnar | Former resident | $0.00 | $1.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G2 | MCGRIFF, BRIDGET FELICIA | Former resident | $0.00 | $2,301.50 | $2,301.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G3 | OLIVER, BELINDA | Former resident | $0.00 | $597.00 | $597.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G3 | SMITH, CIARA | Former resident | $0.00 | $526.00 | $526.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G3 | Johnson, Lashanda T | Former resident | $0.00 | $60.00 | $60.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G3 | Edwards, Mercedes April | Former resident | $0.00 | $4,531.95 | $4,531.95 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G4 | GILLEY, MARGARET D | Former resident | $0.00 | $522.00 | $522.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G4 | Harrison, Rodredka L | Former resident | $0.00 | $33.98 | $33.98 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G5 | JOHNSON, SABRINA | Former resident | $107.49 | $1,210.00 | $1,102.51 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G5 | ALEXANDER, SHANADRIA V | Former resident | $0.00 | $37.00 | $37.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G5 | SLATER, KIASHANDRA | Former resident | $0.00 | $134.19 | $134.19 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G5 | DIAZ GONZALEZ, GLADYS MARITZA | Former resident | $0.00 | $116.00 | $116.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G6 | GILLEY, NATORIA | Former resident | $0.00 | $580.00 | $580.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G6 | HARRIS, MARISA | Former resident | $0.00 | $803.00 | $803.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G6 | STOKES, BRITTNEY NYESHIA | Former resident | $0.00 | $6,140.86 | $6,140.86 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G7 | HOWARD, YASHICA | Former resident | $0.00 | $815.00 | $815.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G7 | JONES, HELEN | Former resident | $0.00 | $54.99 | $54.99 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G7 | MITCHELL, KENISHA ALTAMEASE | Former resident | $0.00 | $89.97 | $89.97 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G8 | SANDS, NICHATE | Former resident | $0.00 | $1,467.00 | $1,467.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G8 | LENARD, CASSIE | Former resident | $0.00 | $909.00 | $909.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G8 | BYTHEWOOD, ALEXIA | Former resident | $35.00 | $445.00 | $410.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G8 | TICE, SHEREKA L | Former resident | $0.00 | $2,986.00 | $2,986.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G8 | YOUNG, ALEXUS MARIA | Former resident | $0.00 | $542.47 | $542.47 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H2 | MOORE, LOWANDERA D | Former resident | $0.00 | $47.72 | $47.72 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H2 | Mccarthy Cranstoun, Janiece Amelia | Former resident | $0.00 | $48.00 | $48.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H2 | WHITE, JEANETTE LATRESS | Former resident | $1.00 | $9,474.95 | $9,473.95 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H2 | Drawdy, Stephanie | Current resident | $268.00 | $578.00 | $-17.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H3 | WILLIAMS, DIEDRE | Former resident | $0.00 | $2,252.00 | $2,252.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H3 | WALKER, ALEXIS OCTAVIS | Former resident | $0.00 | $540.00 | $540.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H3 | *WOOTEN, JASMINE VANESSA | Former resident | $0.00 | $2,549.00 | $2,549.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H4 | ZUNGIA, MICHELLE | Former resident | $0.00 | $790.00 | $790.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H4 | Hudson, Candace Lyn | Former resident | $1.00 | $268.95 | $267.95 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H4 | Campbell, Jeraldine | Current resident | $0.00 | $139.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H5 | THOMPSON, TORIANN | Former resident | $0.00 | $1,604.00 | $1,604.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H5 | MILLER, MYESHA E | Former resident | $1.00 | $232.00 | $231.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H6 | YOUNG, LAKISTA | Former resident | $0.00 | $859.00 | $859.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H6 | DAVIS, EVELYN N | Former resident | $0.00 | $600.00 | $600.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H6 | BRADLEY, ALLIYAH V | Former resident | $0.00 | $138.00 | $138.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H6 | Faison, Armoni Z | Former resident | $0.00 | $138.81 | $138.81 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H7 | WALKER, LAKEITRA | Former resident | $0.00 | $774.00 | $774.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H7 | MILLAGE, ASHIYA | Former resident | $0.00 | $1,033.00 | $1,033.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H7 | PARKER, DATHAN | Former resident | $0.00 | $26.00 | $26.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H7 | ARTHUR, JOHNNIE M | Former resident | $0.00 | $248.00 | $248.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H7 | Lewis, Margaret Louise | Former resident | $646.00 | $2,856.00 | $2,210.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H7 | GRIFFIN, SASHA RENEE | Former resident | $0.00 | $55.68 | $55.68 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H7 | Larry, Toccara S | Former resident | $0.00 | $2,938.95 | $2,938.95 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H8 | JONES, LAWANDA | Former resident | $0.00 | $1,578.00 | $1,578.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H8 | GREENE, NICOLE | Former resident | $0.00 | $720.00 | $720.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H8 | BAYNARD, SHEENA | Former resident | $0.00 | $92.00 | $92.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H8 | WEBSTER, KATRINA D | Former resident | $0.00 | $2,691.00 | $2,691.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H8 | BUCKNER, SANTANA KAI | Former resident | $1,000.00 | $1,121.80 | $121.80 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I1 | PLEAS, DEONDRA | Former resident | $6.00 | $14.00 | $8.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I1 | PARRISH, NICOLE Q | Former resident | $0.00 | $76.63 | $76.63 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I1 | CARTER, CHARLESIA | Former resident | $957.00 | $1,065.22 | $108.22 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I1 | Pearson, Brittney | Former resident | $0.00 | $6.00 | $6.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I2 | FELIX, TERESA | Former resident | $0.00 | $962.00 | $962.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I2 | GILBERT, BRANDON | Former resident | $0.00 | $1,380.00 | $1,380.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I2 | WALKER, LAKEITRA Q | Former resident | $0.00 | $265.86 | $265.86 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I2 | Williams, Sheena Nasha | Former resident | $422.00 | $565.00 | $69.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I2 | SLECHTA, ANGELA JOY | Former resident | $0.00 | $6,647.98 | $6,647.98 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I2 | Scott, Dashawna P | Former resident | $0.00 | $1,576.69 | $1,576.69 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I3 | FARMER, KRYSTAL | Former resident | $0.00 | $871.00 | $871.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I3 | PLEAS, KEYONDRA L | Former resident | $0.00 | $3,750.48 | $3,750.48 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I3 | *VIRGIL, LAKEITA SHONTA | Former resident | $0.00 | $920.00 | $920.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I3 | Bellamy, Equilla ann | Current resident | $0.00 | $84.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I4 | ELLIS, WILBUR | Former resident | $0.00 | $652.00 | $652.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I4 | THOMAS, SHARESA SHAHEMA | Former resident | $0.00 | $2.00 | $2.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I4 | SCOTT, MAVIS L | Former resident | $0.00 | $108.99 | $108.99 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I6 | MILLER, TROYELLA | Former resident | $0.00 | $1,033.00 | $1,033.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I6 | CAMPBELL, LATOYA L | Former resident | $0.00 | $670.45 | $670.45 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I6 | Williams, De'ongla Lashai | Former resident | $0.00 | $52.00 | $52.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I6 | LITTLES, JADA MARIE | Former resident | $0.00 | $258.73 | $258.73 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I6 | Dansey, Tometha R | Current resident | $425.00 | $1,070.00 | $-153.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I8 | JONES, KEONJALA | Former resident | $0.00 | $539.00 | $539.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I8 | FLANDERS, BRITTANY D | Former resident | $0.00 | $2,948.00 | $2,948.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I8 | MILLER, BRIANNA ALEXIS | Former resident | $0.00 | $1,620.00 | $1,620.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I8 | BARR, LA'CHELLE YVONN | Former resident | $0.00 | $2,022.59 | $2,022.59 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J1 | FORD, LYNN | Former resident | $0.00 | $858.00 | $858.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J1 | BAPTISTE, HAZEL | Former resident | $0.00 | $77.00 | $77.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J1 | BOOKER, ALICIA R | Former resident | $0.00 | $913.00 | $913.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J1 | CARTER, CHARLETTE SHANQUILLA | Former resident | $94.00 | $9,345.00 | $9,251.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J1 | FOOTMAN, SHAQUNA VONTRESSE | Former resident | $0.00 | $11.87 | $11.87 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J2 | BELLAMY, MOTISHA | Former resident | $0.00 | $869.00 | $869.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J3 | JONES, DAMIEN | Former resident | $0.00 | $1,097.00 | $1,097.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J3 | NORTON, NARRESHIA AALIYAH | Former resident | $840.00 | $1,184.96 | $344.96 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J4 | WALKER, ROSA | Former resident | $0.00 | $65.47 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J4 | Wilson, Kimiriya | Current resident | $309.00 | $2,349.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J5 | FISHBURN, CHARMESE J | Former resident | $0.00 | $816.00 | $816.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J5 | WAGNER, SHANTEL | Former resident | $0.00 | $1,595.00 | $1,595.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J6 | BEVERLY, MARIA | Former resident | $0.00 | $815.00 | $815.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J6 | SCOTT, MYSTERIA ANGELL | Former resident | $0.00 | $1,324.00 | $1,324.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J6 | YOUNG, IESHA JAYNA | Former resident | $90.00 | $3,237.00 | $3,147.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J6 | JOHNSON, ALEXIS MARIE | Former resident | $0.00 | $3,681.55 | $3,681.55 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J7 | CAMPBELL, YOLANDA | Former resident | $0.00 | $820.00 | $820.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J7 | FEACHER, DOROTHY L | Former resident | $0.00 | $1,331.00 | $1,331.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J7 | WILLIAMS, MIAMAI RACHELLE | Former resident | $0.00 | $450.91 | $450.91 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J7 | HOWARD, TYKERIA Z | Former resident | $0.00 | $1,645.00 | $1,645.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J7 | Campbell, Dedra | Current resident | $190.00 | $628.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| NONE | HAP common ledger | Misc. Income | $0.00 | $2,336.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| A1 | HAGAN, MARY | Former resident | $7.00 | $0.00 | $-7.00 | [ ] Confirm paid | — |
| A2 | JOHNSON, SHANA | Former resident | $7.00 | $0.00 | $-7.00 | [ ] Confirm paid | — |
| A4 | LEWIS, PRISCILLA | Current resident | $30.00 | $0.00 | $-30.00 | [ ] Confirm paid | — |
| A5 | HOWARD, TABATHA | Former resident | $7.00 | $0.00 | $-7.00 | [ ] Confirm paid | — |
| A6 | Oliver, Jabriya L | Current resident | $1,234.46 | $89.00 | $-812.46 | [ ] Confirm paid | — |
| A7 | SUMPTER, SANDRA DENISE | Current resident | $37.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| B3 | JOHNSON, JAUA CARUCHIA | Current resident | $1,189.00 | $423.00 | $-203.00 | [ ] Confirm paid | — |
| B4 | STARLING, ETHA | Current resident | $58.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| C10 | BROWN, DESIRAY RAGINE | Current resident | $3,036.00 | $1,386.00 | $-2,090.00 | [ ] Confirm paid | — |
| C11 | ALLEN, SHAQURIA VONSHANAY | Former resident | $1.00 | $0.00 | $-1.00 | [ ] Confirm paid | — |
| C11 | Hill, Phylicia | Current resident | $60.00 | $0.00 | $-60.00 | [ ] Confirm paid | — |
| C12 | Bellamy, Iyania | Current resident | $1,093.00 | $83.00 | $-95.00 | [ ] Confirm paid | — |
| C3 | HATCHETT, JOANNA DALANA | Former resident | $76.00 | $51.00 | $-25.00 | [ ] Confirm paid | — |
| C3 | Thomas, Kendra R | Current resident | $488.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| C4 | BIVENS, TARISHEA J | Former resident | $53.00 | $0.00 | $-53.00 | [ ] Confirm paid | — |
| C4 | Lamar, Tekisha N | Current resident | $1,746.00 | $1,166.00 | $-660.00 | [ ] Confirm paid | — |
| C5 | KING, KENYATTA | Current resident | $24.00 | $0.00 | $-24.00 | [ ] Confirm paid | — |
| C6 | Wells, Marissa | Current resident | $20.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| C8 | Fishburn, Shatay R | Current resident | $136.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| D2 | Booker, Michael J | Current resident | $356.00 | $0.00 | $-249.00 | [ ] Confirm paid | — |
| D3 | Coffey, Nicole Lynn | Current resident | $449.00 | $30.00 | $30.00 | [ ] Confirm paid | — |
| E1 | BARRINGTON, JA'KERIA Q | Current resident | $476.00 | $0.00 | $-22.00 | [ ] Confirm paid | — |
| E2 | JOHNSON, ERICA SHANAY | Former resident | $130.00 | $13.00 | $-117.00 | [ ] Confirm paid | — |
| E2 | JONES, MIARA JANEICIA | Current resident | $787.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| E4 | Walker, Kimberly Y | Current resident | $641.00 | $476.00 | $-25.00 | [ ] Confirm paid | — |
| E5 | Allen, Ashley | Current resident | $553.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| E7 | Graham, Timeshia | Current resident | $312.00 | $124.00 | $-43.00 | [ ] Confirm paid | — |
| F1 | Oliver, Diamond J | Former resident | $1.00 | $0.00 | $-1.00 | [ ] Confirm paid | — |
| F3 | Williams, Sheena | Current resident | $788.00 | $280.00 | $-614.00 | [ ] Confirm paid | — |
| F4 | FORD, ANDREA DANIELLE | Former resident | $1,994.00 | $180.00 | $-1,814.00 | [ ] Confirm paid | — |
| F4 | Green, Brittany S | Former resident | $270.00 | $212.63 | $-57.37 | [ ] Confirm paid | — |
| F5 | BURT, RAICHELLE | Former resident | $149.00 | $0.00 | $-149.00 | [ ] Confirm paid | — |
| F5 | Thompson, Aniyaiah | Current resident | $481.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| F6 | Lofton, BriannaA | Current resident | $83.00 | $0.00 | $-83.00 | [ ] Confirm paid | — |
| F7 | CRIM, KATINA | Current resident | $147.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| F8 | Hill, Kenshonna M | Former resident | $996.00 | $55.97 | $-940.03 | [ ] Confirm paid | — |
| F8 | Marlowe, Susan C | Current resident | $899.95 | $250.00 | $-63.00 | [ ] Confirm paid | — |
| G1 | AKINS, LATISHA EVETTE | Current resident | $754.00 | $419.00 | $-44.00 | [ ] Confirm paid | — |
| G2 | Sims, Maranda K | Current resident | $1,297.00 | $1,066.00 | $-14.00 | [ ] Confirm paid | — |
| G3 | LAMAR, RUBY M | Current resident | $361.00 | $0.00 | $-235.00 | [ ] Confirm paid | — |
| G3 | SAUNDERS, TESSIE MARIE | Former resident | $1.00 | $0.00 | $-1.00 | [ ] Confirm paid | — |
| G4 | BURNS, YVONNEABBY BEATRICE | Former resident | $709.00 | $440.94 | $-268.06 | [ ] Confirm paid | — |
| G4 | Gallon, Latrice S | Current resident | $1,373.00 | $0.00 | $-1,352.00 | [ ] Confirm paid | — |
| G5 | GALLON, LATRICE SHONTEL | Former resident | $135.00 | $75.00 | $-60.00 | [ ] Confirm paid | — |
| G5 | VANN, KAMESHA LASHAY | Current resident | $660.00 | $590.00 | $300.00 | [ ] Confirm paid | — |
| G7 | SAUNDERS, TESSIE MARIE | Current resident | $2,724.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| G8 | NEELY, BRIANNA | Current resident | $1,372.00 | $1.00 | $1.00 | [ ] Confirm paid | — |
| H1 | HOWARD, ROSE M | Current resident | $526.00 | $0.00 | $-82.00 | [ ] Confirm paid | — |
| H3 | GARCIA FRANCO, JEICHA MARIE | Former resident | $2,210.00 | $0.00 | $-2,210.00 | [ ] Confirm paid | — |
| H3 | CAMPBELL, SHATAVIA DEORSHAY | Current resident | $2,376.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| H4 | Harrison, Rodreka L | Former resident | $51.00 | $0.00 | $-51.00 | [ ] Confirm paid | — |
| H5 | Cruz Alicano, Ashmin E | Former resident | $1.00 | $0.00 | $-1.00 | [ ] Confirm paid | — |
| H5 | FRANKLIN, KENDRA KATRICE | Current resident | $3.00 | $0.00 | $-3.00 | [ ] Confirm paid | — |
| H6 | Ghee, Jiyah | Current resident | $433.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| H7 | Bellamy, Dikerria | Current resident | $19.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| H8 | Harrison, Tykeshiyonna Q | Current resident | $438.00 | $200.00 | $-22.00 | [ ] Confirm paid | — |
| I1 | Wyche, Nalonie | Current resident | $133.00 | $0.00 | $-132.00 | [ ] Confirm paid | — |
| I2 | Jones, Consuela | Current resident | $217.00 | $0.00 | $-157.00 | [ ] Confirm paid | — |
| I3 | LEWIS, JHA'QUORSHA K | Former resident | $576.00 | $228.00 | $-348.00 | [ ] Confirm paid | — |
| I4 | Beverly, Beatrice M | Current resident | $237.00 | $0.00 | $-43.00 | [ ] Confirm paid | — |
| I6 | GARY, DEBRA L | Former resident | $421.00 | $85.00 | $-336.00 | [ ] Confirm paid | — |
| I8 | Adams, Eric B | Current resident | $2,576.00 | $59.00 | $-78.00 | [ ] Confirm paid | — |
| J1 | Oliver, Janice | Current resident | $79.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| J2 | THOMPSON, JEVONSHAY | Former resident | $234.00 | $213.00 | $-21.00 | [ ] Confirm paid | — |
| J2 | PARKER, CALVONTA DESHON | Current resident | $324.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| J3 | Fishburn, Charmese J | Current resident | $1,484.00 | $777.00 | $-194.00 | [ ] Confirm paid | — |
| J6 | Thompkins, Jaquisha | Current resident | $56.00 | $24.00 | $-30.00 | [ ] Confirm paid | — |
| J8 | GRAHAM, LASHONDRA R | Current resident | $1,586.00 | $712.00 | $-152.00 | [ ] Confirm paid | — |

## Resident Balance Follow-Up — Paid / Zero Balance

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| F1 | HARRIS, KASHARI | Former resident | $51.97 | $51.97 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F5 | WHITE, CHARQUITA ALEXIS | Former resident | $406.00 | $406.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G4 | Gallon, Latrice Shontel | Former resident | $2,269.83 | $2,269.83 | $-0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I6 | JOHNSON, KALEA IYONA | Former resident | $144.00 | $144.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property's supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*