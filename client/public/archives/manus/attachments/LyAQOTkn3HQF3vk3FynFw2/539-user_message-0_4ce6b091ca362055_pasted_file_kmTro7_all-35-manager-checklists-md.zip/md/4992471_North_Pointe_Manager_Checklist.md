# North Pointe — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 4992471**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/05/2026 |
| Property manager | Jennifer Frederick — northpointe@apartmentcorp.com — (318) 440-6712 |
| Regional manager | Ginger Positerry — ginger@apartmentcorp.com — (985) 637-2128 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Delinquency spreadsheet | `4992471_North Pointe_Delinquent - Excel_58.xls` |
| Ledger accounts for review | 47 resident accounts |
| Residents with amount owed | 31 accounts; $33,576.00 |
| Prepaid / credit accounts | 16 accounts; $-8,008.55 |
| Availability entries | 5 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit's reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| BREAK6-1611C | 2x2 | NTV Not Leased | [ ] Verified | __________________ |
| BREAK7-1618A | 2x2 | NTV Leased | [ ] Verified | __________________ |
| 2-2608K | 2x2 | Vacant Leased Not Ready | [ ] Verified | __________________ |
| BREAK6-1611C | 2x2 | NTV Not Leased | [ ] Verified | __________________ |
| BREAK7-1618A | 2x2 | NTV Leased | [ ] Verified | __________________ |

## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - 1609A | Cooper, Helen | Former resident | $0.00 | $3.00 | $3.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1615A | Thomas, Rosetta | Current resident | $0.00 | $1,594.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 2604K | Ashley, Teresa | Current resident | $0.00 | $15.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 2616K | Sanders, Lashannon | Former resident | $0.00 | $3,262.00 | $3,262.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 2616K | JUne, Kaitlyn K | Current resident | $0.00 | $1,240.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15 - 2620K | Richardson, Joselyn | Former resident | $0.00 | $730.00 | $730.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 2636K | Lee, Raven | Current resident | $0.00 | $1,796.00 | $660.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 1610C | Washington, Lamar | Current resident | $0.00 | $163.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18 - 1607C | Jernigan, Jamila | Current resident | $0.00 | $1,138.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19 - 1617C | Sims, Kimberly | Current resident | $0.00 | $82.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2608K | Curry, Charneidra | Former resident | $595.00 | $4,778.00 | $2,386.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2608K | O'Neal, Antaneisha | Current resident | $0.00 | $778.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 22 - 1619A | Reed, Ella | Former resident | $0.00 | $1,357.00 | $1,357.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 22 - 1619A | Ashley, Alatrecia | Former resident | $0.00 | $447.00 | $447.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 22 - 1619A | McDaniel, Alexus | Current resident | $0.00 | $1,242.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 23 - 2624K | Patterson, Kowanna | Current resident | $0.00 | $1,326.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 27 - 1602C | Burton, Morgan | Former resident | $0.00 | $366.00 | $366.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 27 - 1602C | Sneed, Bianca | Former resident | $0.00 | $86.00 | $86.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 27 - 1602C | Sylvie, Kennibya M | Current resident | $0.00 | $1,244.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 2632K | Lyons, Karen | Former resident | $0.00 | $774.00 | $774.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 2632K | Johnson, Moneca L | Former resident | $0.00 | $1,402.00 | $1,402.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 2632K | Richardson, Sharon L | Current resident | $0.00 | $24.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 1603C | Burton, Taylor | Former resident | $0.00 | $470.00 | $470.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 1603C | Montgomery, Takeveyatta | Current resident | $0.00 | $11.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 1611C | Marshall, Shadiamond S | NTV | $0.00 | $974.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 1618A | Hill, Roderick | Former resident | $0.00 | $690.00 | $690.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 1618A | Simmons, Alexis | NTV | $0.00 | $2,033.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 1608A | Bryant, Sanitra B | Former resident | $0.00 | $637.00 | $637.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 1608A | Dumas, Sylvia D | Former resident | $0.00 | $2,372.00 | $2,372.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 1605A | Young, Amber | Former resident | $204.00 | $1,964.00 | $1,760.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 1605A | Henderson, Erika M | Current resident | $0.00 | $1,377.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - 1609A | Taylor, Johnnie M | Current resident | $216.00 | $200.00 | $0.00 | [ ] Confirm paid | — |
| 11 - 2605K | Davenport, Monique | Current resident | $766.00 | $15.00 | $0.00 | [ ] Confirm paid | — |
| 13 - 2612K | Ford, Brittany | Current resident | $1,138.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 15 - 2620K | Davis, Andrea N | Current resident | $216.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 20 - 1614A | Pero, Nadia D | Current resident | $17.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 21 - 1604A | Lewis, Rachard | Current resident | $13.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 24 - 2628K | Harrison, Rosana | Current resident | $100.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 25 - 2640K | Lewis, Starletta | Current resident | $0.55 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 27 - 1602C | Richardson, Veronica | Former applicant | $50.00 | $0.00 | $-50.00 | [ ] Confirm paid | — |
| 4 - 1606C | MCKEEVER, JAMIE M | Current resident | $403.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 6 - 1611C | Williams, Malik | Former resident | $554.00 | $0.00 | $-554.00 | [ ] Confirm paid | — |
| 7 - 1618A | WEBB, ARIANNA M | Former applicant | $100.00 | $0.00 | $-100.00 | [ ] Confirm paid | — |
| 7 - 1618A | Thomas, Cierra | Former resident | $3,541.00 | $0.00 | $-3,541.00 | [ ] Confirm paid | — |
| 7 - 1618A | Jones, Briana | Applicant | $30.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| WAIT | COOPER, ARTISHA | Former applicant | $849.00 | $0.00 | $-849.00 | [ ] Confirm paid | — |
| WAIT | Cotton, Cabria | Former applicant | $230.00 | $0.00 | $-230.00 | [ ] Confirm paid | — |

## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.

## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property's supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*