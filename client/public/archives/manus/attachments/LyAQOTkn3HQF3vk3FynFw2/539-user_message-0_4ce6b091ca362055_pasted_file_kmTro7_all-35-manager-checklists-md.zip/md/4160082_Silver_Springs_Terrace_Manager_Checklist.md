# Silver Springs Terrace — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 4160082**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/05/2026 |
| Property manager | Tarshia Pierce — silversprings@apartmentcorp.com — (336) 689-8976 |
| Regional manager | Johann Armstead — johann@apartmentcorp.com — (804) 481-2503 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Delinquency spreadsheet | `4160082_Silver Springs Terrace_Delinquent - Excel_58.xls` |
| Ledger accounts for review | 264 resident accounts |
| Residents with amount owed | 199 accounts; $335,507.28 |
| Prepaid / credit accounts | 62 accounts; $-43,637.89 |
| Availability entries | 10 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit's reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| 1-1A | 2A | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 6-6H | 3A | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 7-7B | 3A | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 8-8B | 4A | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 10-10A | 3A | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 10-10G | 3A | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 10-10H | 3A | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 11-11A | 2A | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 11-11C | 2A | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 14-14B | 3A | Vacant Not Leased Not Ready | [ ] Verified | __________________ |

## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - 1A | Brown, Tonya | Former resident | $0.00 | $177.00 | $177.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1B | Corpening, Antonia D | Former resident | $0.00 | $119.00 | $119.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1B | Owens, April | Current resident | $10.00 | $223.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1C | Paul, Stephanie Rene | Former resident | $0.00 | $404.00 | $404.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1C | Blevins, LanceP | Former resident | $0.00 | $348.00 | $348.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1C | Early, Talisha C | Current resident | $192.00 | $368.00 | $-48.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1D | Woods, Nitaya Sharquice | Former resident | $0.00 | $684.00 | $684.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1E | Carson, Amalia S | Current resident | $0.00 | $45.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1F | Prunty, Daquaydra | Current resident | $0.00 | $1,329.00 | $683.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1F | Coleman, Shenice Renee | Former resident | $0.00 | $5,484.53 | $5,484.53 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1F | Dukes, Jamessa Shantel | Former resident | $0.00 | $872.00 | $872.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1G | Brown, Brianna | Former resident | $0.00 | $1,591.19 | $1,591.19 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1G | Bryant, Quentin Dion | Former resident | $0.00 | $4,008.00 | $4,008.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1H | Mabe, Anita R | Former resident | $0.00 | $1,514.00 | $1,420.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 10A | Hill, Amy | Former resident | $0.00 | $1,284.00 | $1,284.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 10A | Coffey, Ciera N | Former resident | $0.00 | $311.00 | $311.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 10A | Montenegro, Vianca G | Former resident | $0.00 | $200.00 | $200.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 10B | Halmi, Emilee Rae | Former resident | $0.00 | $2,766.00 | $2,766.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 10B | Williams, Heather maire | Former resident | $0.00 | $1,136.00 | $1,136.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 10C | Wilson, Walter Montreal | Former resident | $0.00 | $6,859.00 | $6,859.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 10C | Jackson, Ruben | Former resident | $0.00 | $2,047.00 | $2,047.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 10C | Rogers, Ashley F | Current resident | $186.00 | $269.00 | $8.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 10D | Serrano Santana, Michael Hommy | Former resident | $0.00 | $2,148.00 | $2,148.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 10D | Sanders, Jessica Danielle | Current resident | $0.00 | $1,347.00 | $54.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 10E | Griggs, Jakeyia | Current resident | $0.00 | $2,696.00 | $1,259.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 10E | Webb, Erica N | Former resident | $0.00 | $814.00 | $814.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 10E | Jenkins, Shannon | Former resident | $0.00 | $1,262.00 | $1,262.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 10H | Huffman, Jesse Jacqueline Lena | Former resident | $0.00 | $2,936.00 | $2,936.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 10H | Bell, Jayla M | Former resident | $0.00 | $4,545.00 | $4,545.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 11A | Duggar, Sulma S | Former resident | $0.00 | $1.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 11A | Portman, Jasquella | Former resident | $0.00 | $431.00 | $431.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 11A | Page, Patricia Tucker | Former resident | $81.00 | $820.00 | $739.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 11B | Bumgarner, Elisha Nicol | Former resident | $0.00 | $4,228.00 | $4,228.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 11B | Grier, Teaerra Renea | Former resident | $648.00 | $2,400.00 | $1,752.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 11B | Hull, BillyC | Former resident | $0.00 | $46.00 | $46.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 11B | Little, Joel | Current resident | $0.00 | $299.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 11C | Dozier, Jalea | Former resident | $0.00 | $453.00 | $453.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 11C | Martinez, Norma A | Former resident | $319.00 | $1,980.00 | $-319.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 11D | Jordan, Gary | Former resident | $0.00 | $5,130.89 | $5,130.89 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 11D | Broome, Aleahya M | Former resident | $0.00 | $1,473.20 | $1,473.20 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 11D | Wilfong, Anastacia z | Current resident | $0.00 | $294.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 11E | Morejon, Hector | Former resident | $0.00 | $1,286.00 | $1,286.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 11E | Izard, Seqouria | Former resident | $0.00 | $917.00 | $917.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 11E | Blount, Marques Craig | Former resident | $0.00 | $3,532.00 | $3,532.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 11E | Brown, RachaelA | Former resident | $45.00 | $1,265.00 | $1,220.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 11F | Anderson, Cerria Sunae | Former resident | $0.00 | $104.00 | $104.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 11F | Laws, Israel J | Former resident | $540.00 | $833.00 | $-540.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 11F | Stamps, Navayia | Current resident | $28.00 | $548.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 11G | Craig, Shavaya Nicole | Former resident | $0.00 | $6,844.02 | $6,844.02 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 11H | Singletary, Keisha | Former resident | $0.00 | $2,039.00 | $2,039.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 11H | Haskins, Clinton Xavier | Former resident | $0.00 | $3,164.00 | $3,164.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 11H | Moretz, Tammy | Current resident | $0.00 | $14.00 | $14.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 12A | Jordan, Jennifer | Former resident | $0.00 | $375.00 | $375.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 12A | Chandler, Jessica | Former resident | $0.00 | $4,172.94 | $4,172.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 12B | Davidson, Kali | Former resident | $0.00 | $285.00 | $285.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 12B | Abernathy, Winter | Current resident | $0.00 | $3,931.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 12E | Smith, Shontae Antoinette | Former resident | $0.00 | $2,585.00 | $2,585.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 12F | Story, Carrie | Former resident | $0.00 | $860.00 | $860.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 12F | Little, Maquada L | Current resident | $0.00 | $3,944.00 | $15.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 13B | Rippy, Yolanda | Former resident | $0.00 | $12.00 | $12.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 13B | White, Crystal Tiawan | Former resident | $0.00 | $762.00 | $762.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 13B | Vazquez, Nannischie Zoett | Former resident | $0.00 | $391.00 | $391.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 13B | Mauney, Tiffany | Current resident | $0.00 | $1,368.00 | $279.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 13E | Glass, Angela | Current resident | $4.00 | $275.00 | $275.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 13F | Wilson, Alexus | Former resident | $0.00 | $128.00 | $128.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 13F | Ramseur, Arieanne Da'nae | Former resident | $0.00 | $1,383.00 | $1,383.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 13F | Rivera, Jhajaira M | Former resident | $0.00 | $5,266.00 | $5,266.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 13F | Ripply, Kadejah | Current resident | $0.00 | $36.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 14A | Rogers, Curtis Shamone | Former resident | $0.00 | $830.00 | $830.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 14A | Petty, Shirlene | Former resident | $0.00 | $1,061.00 | $192.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 14E | Lewis, Monique | Former resident | $0.00 | $679.00 | $679.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 14E | Reese, Patricia Ann | Former resident | $0.00 | $1,639.00 | $1,639.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 14E | Glass, Mattie L | Current resident | $4,022.00 | $9,130.00 | $-3,369.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 14F | Weedman, Kari | Former resident | $0.00 | $7,924.00 | $7,924.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 14F | Mills, Dwayne | Former resident | $0.00 | $2,401.80 | $2,401.80 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 14F | Jones, Shaniqua Shanae | Former resident | $0.00 | $886.00 | $886.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 14F | Bourne, Brandi | Former resident | $488.00 | $1,858.00 | $1,370.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 14F | Lashey, Aretha | Former resident | $0.00 | $52.00 | $52.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 14F | SMYRE, JOHN | Current resident | $0.00 | $2,853.00 | $1,767.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15 - 15A | Scott, Carolyn Vanesa | Former resident | $0.00 | $544.00 | $544.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15 - 15B | Hinson, Debra | Former resident | $0.00 | $323.00 | $323.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15 - 15F | Krebs, Wanda | Current resident | $0.00 | $2.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 16A | Beatty, Antwaine D | Current resident | $0.00 | $38.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 16B | McDonald, Celia | Former resident | $2.00 | $641.00 | $639.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 16F | Middlebrooks, Danny Teyone | Former resident | $236.60 | $3,675.00 | $3,438.40 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 16F | Rogers, Patricia A | Former resident | $0.00 | $25.00 | $25.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 17A | White, Marquriea Lashay | Former resident | $0.00 | $1,221.97 | $1,221.97 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 17A | Boyd, Michelle Zipporah | Former resident | $0.00 | $425.12 | $425.12 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 17B | Jordan, Tiffany Samone | Former resident | $0.00 | $5,503.00 | $5,503.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 17B | Humphries, Candace | Current resident | $0.00 | $72.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 17C | Wells, William | Former resident | $0.00 | $277.00 | $277.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 17C | Outlaw, Jamie | Former resident | $0.00 | $2,379.00 | $2,379.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 17C | Fritz, Ashley | Current resident | $0.00 | $5,001.00 | $1,026.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 17D | Ussery, Khala Brianne | Current resident | $0.00 | $387.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 17E | Woods, Nitaya Sharquice | Former resident | $200.00 | $424.00 | $224.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 17E | Jones, Kenneth L | Former resident | $0.00 | $1,430.00 | $1,430.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 17E | Geter, Chandra R | Former resident | $0.00 | $918.00 | $918.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 17E | Harshaw, Arista | Current resident | $0.00 | $4,958.00 | $983.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 17F | Ward, Heather | Former resident | $0.00 | $593.00 | $593.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 17F | McRae, Helena | Former resident | $0.00 | $2,424.00 | $2,424.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 17F | Montenegro, Evelia Esbetlana | Former resident | $0.00 | $5,479.00 | $5,479.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 17F | Handy, Dennis | Current resident | $0.00 | $561.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 17G | Aikens, Kasey Justina | Current resident | $0.00 | $209.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 17G | Bracey, Tyrongla Katisha | Former resident | $0.00 | $1,039.00 | $1,039.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 17G | Thomas, Frances M | Former resident | $0.00 | $2,584.00 | $2,584.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 17H | Davis, Andrew M | Former resident | $0.00 | $1,714.00 | $1,714.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 17H | Wright, Alan Michael | Former resident | $0.00 | $300.00 | $300.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 17H | Hampton, Danielle | Former resident | $0.00 | $38.00 | $38.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2A | Hunt, Shavoughnte Lamez | Former resident | $0.00 | $185.00 | $185.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2A | McLean, Jessica | Former resident | $0.00 | $2,693.00 | $2,693.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2A | Lester, Megan Leann | Former resident | $0.00 | $517.00 | $517.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2A | Shade, Inez T | Former resident | $2,900.00 | $3,639.00 | $739.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2B | Martin, Jammie l | Current resident | $0.00 | $7,273.00 | $15.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2C | Conley, Dana M | Former resident | $27.00 | $3,010.00 | $2,983.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2E | Howell, Kebriana Cantese | Former resident | $75.00 | $549.00 | $474.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2E | Winkler, Lazariah | Former resident | $1.00 | $30.00 | $29.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2E | Gaither, Wanda | Current resident | $4.00 | $715.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2F | Linebarger, Valesha Jasmine | Former resident | $452.50 | $905.00 | $452.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2G | Peterson, Shytavia Lameecha | Former resident | $1.00 | $281.00 | $280.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2H | Cortez, Erik | Former resident | $0.00 | $1,155.00 | $1,155.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2H | Owens, Megan D | Current resident | $0.00 | $1,749.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3A | Harris, Emoni A | Current resident | $0.00 | $1,346.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3B | Patterson, Tanique Raegene | Former resident | $0.00 | $942.00 | $942.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3B | Conley, Treavon Jamont | Former resident | $0.00 | $699.76 | $699.76 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3C | Cornwell, Destane S | Current resident | $0.00 | $612.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3D | Barber, Jasmine Kyauna Marie | Former resident | $0.00 | $1,350.00 | $1,350.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3D | Gore, Kimyada Symone | Former resident | $0.00 | $1,990.00 | $1,990.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3D | Spradling, Kathy Rebecca | Former resident | $0.00 | $2,400.00 | $2,400.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3D | Starks, Kimberly Ann | Former resident | $0.00 | $1,640.00 | $1,640.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3D | Smith, Ashley | Former resident | $0.00 | $4,034.00 | $4,034.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3D | ADAMSON, SHANIEL | Current resident | $117.00 | $4,915.00 | $1,966.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3E | Owens, April | Former resident | $40.00 | $117.00 | $77.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3E | McCall, Crystal Carroll | Former resident | $0.00 | $1,494.00 | $1,494.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3E | Love, Frantina | Former resident | $0.00 | $519.00 | $519.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3E | Dukes, Madinah | Former resident | $0.00 | $61.00 | $61.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3E | Hansel, Joseph | Current resident | $0.00 | $4,789.00 | $1,653.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3F | Goddard, Angela Dawn | Former resident | $0.00 | $1,585.00 | $1,585.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3F | Budish, Yuliia | Former resident | $3,052.80 | $3,898.00 | $845.20 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3F | Hall, Angel N | Current resident | $78.00 | $5,471.00 | $3,515.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3G | Nguyen, Luc | Current resident | $0.00 | $150.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3H | Woods, Catoura | Former resident | $0.00 | $2,323.00 | $2,323.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3H | Lewis, Ayijanae Marie | Former resident | $0.00 | $62.00 | $62.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3H | Miller, Nahashi S | Former resident | $0.00 | $1,689.00 | $1,689.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 5B | Nelson, Tiarra Lindsey | Former resident | $0.00 | $851.83 | $851.83 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 5E | Velez Arroyo, Aslin | Former resident | $0.00 | $851.00 | $851.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 5E | Pruitt, Paul Allen | Former resident | $0.00 | $5,346.00 | $5,346.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 5F | Mapp, Keshia | Former resident | $229.00 | $4,154.00 | $3,925.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 5F | Brown, Shalaya T | Current resident | $0.00 | $11,811.00 | $8,203.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 6A | Holt, Jessica Jo | Former resident | $0.00 | $1.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 6A | Hewitt, AndreaC | Former resident | $0.00 | $1,093.83 | $1,093.83 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 6A | Gattison, Tonya A | Current resident | $0.00 | $114.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 6B | Martinez, Sierra Maria | Former resident | $0.00 | $40.00 | $40.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 6B | Tipps, Tyshayla Tenae | Former resident | $0.00 | $849.00 | $849.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 6B | Linebarger, Chapele T | Current resident | $21.00 | $584.00 | $203.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 6C | Abernathy, Shannan L | Current resident | $0.00 | $909.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 6D | Rice, Angie | Former resident | $0.00 | $2,808.00 | $2,808.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 6D | Freeman, Elizabeth C | Current resident | $35.00 | $5,780.00 | $1,410.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 6E | Martinez, Roslyn | Former resident | $0.00 | $2,346.00 | $2,346.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 6E | White, Marthisa E | Current resident | $0.00 | $1,536.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 6G | Hernandez, Jenniffer | Former resident | $0.00 | $445.00 | $445.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 6G | Weaver, Jessica M | Current resident | $7.00 | $676.00 | $44.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 6H | Wilson, Shankita Monay | Former resident | $0.00 | $2,274.86 | $2,274.86 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 7A | Weaver, Kaitlin D | Former resident | $0.00 | $415.00 | $415.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 7A | Wright, Alan M | Current resident | $0.00 | $4,720.00 | $574.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 7B | Galligher Sherrill, Porscha | Former resident | $0.00 | $3,412.00 | $3,412.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 7B | Dukes, Rentia Ann | Former resident | $0.00 | $27.00 | $27.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 7B | Clark, LaQuisF | Former resident | $0.00 | $360.00 | $360.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 7B | White, Robert R | Former resident | $1,234.00 | $3,873.00 | $2,639.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 7B | Arenas, Fornesha J | Former resident | $0.00 | $1,887.00 | $1,887.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 7C | Shuford, Aliyah Antrell | Former resident | $0.00 | $1.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 7D | Sloan, Latoya | Former resident | $0.00 | $777.59 | $777.59 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 7E | King, Shana | Current resident | $0.00 | $1,060.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 7F | Stidham, Carrie Renae | Former resident | $1.00 | $601.96 | $600.96 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 7F | Robinson, Phylicia A | Current resident | $19.00 | $476.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 7G | Daniels, Antasia | Former resident | $0.00 | $1,026.00 | $1,026.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 7H | Sherrill, Samorya Evette | Former resident | $0.00 | $402.00 | $402.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 7H | Freeman, Latasha | Current resident | $0.00 | $3,829.00 | $3,325.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 8A | Trevorah, Danielle Lashaye | Former resident | $0.00 | $2,132.00 | $2,132.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 8A | Blackburn, ShatinaS | Former resident | $0.00 | $2,836.11 | $2,836.11 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 8A | Blount, Raven T | Current resident | $0.00 | $208.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 8B | Wilfong, Diane Denise | Former resident | $0.00 | $6,460.00 | $6,460.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 8E | Edmonds, Tonya | Former resident | $0.00 | $962.00 | $962.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 8E | Ikard, Tamara Anna-Lisa | Former resident | $0.00 | $1,221.00 | $1,221.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 8E | Conley, Patrice Amanda | Former resident | $0.00 | $1,800.00 | $1,800.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 8F | Holsclaw, Tammie | Former resident | $0.00 | $728.00 | $728.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 9A | Santillan, Daisy | Former resident | $0.00 | $489.00 | $489.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 9A | Sims, Tomeka Nickoo | Former resident | $0.00 | $1,291.00 | $1,291.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 9B | Maddox, Cheryl | Former resident | $0.00 | $314.00 | $314.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 9B | Cumberlander, Latesha Renae | Former resident | $0.00 | $3,769.00 | $3,769.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 9B | Batchelor, Chenoa m | Former resident | $0.00 | $13.57 | $13.57 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 9B | Sumpter-Roberts, Leann | Former resident | $0.00 | $1,365.00 | $1,365.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 9C | Davis, Eddie | Former resident | $191.00 | $492.00 | $301.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 9D | Ocasio, Maribel | Former resident | $0.00 | $2,845.01 | $2,845.01 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 9E | Turner, Latosha Marie | Former resident | $0.00 | $2,140.00 | $2,140.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 9F | Sharpe, Ashlee Corakaye | Former resident | $0.00 | $3,355.00 | $3,355.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 9F | Vanover, Misty Rose | Former resident | $0.00 | $1,693.00 | $1,693.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 9F | Susee, Samantha | Current resident | $0.00 | $1,019.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 9H | Mauzon, Tammaray M | Former resident | $0.00 | $534.00 | $534.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 9H | Fletcher, Dominique T | Current resident | $0.00 | $1,040.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - 1A | Henderson, Marion | Former resident | $697.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1D | Boller, Debra | Former resident | $1,465.00 | $0.00 | $-1,465.00 | [ ] Confirm paid | — |
| 1 - 1E | Adame, Yuritza Orozco | Former resident | $43.00 | $0.00 | $-43.00 | [ ] Confirm paid | — |
| 1 - 1H | Williams, Kiara Forsha | Former resident | $656.00 | $181.00 | $-475.00 | [ ] Confirm paid | — |
| 1 - 1H | Bogar, Tiyonna Ajene' | Former resident | $143.00 | $0.00 | $-143.00 | [ ] Confirm paid | — |
| 1 - 1H | Key, Sydney | Former resident | $24.00 | $0.00 | $-24.00 | [ ] Confirm paid | — |
| 10 - 10A | Nash, Cherie | Former resident | $334.00 | $116.00 | $0.00 | [ ] Confirm paid | — |
| 10 - 10B | Smyre, Anthony L | Former resident | $836.00 | $0.00 | $-836.00 | [ ] Confirm paid | — |
| 10 - 10C | Caldwell, Ashley Cornelia Shakur | Former resident | $1,689.00 | $0.00 | $-1,689.00 | [ ] Confirm paid | — |
| 10 - 10F | Grant, Cassandra | Former resident | $638.00 | $0.00 | $-638.00 | [ ] Confirm paid | — |
| 10 - 10F | Williams, NuQuita | Current resident | $15.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 10 - 10G | Fleming, Tomkia R | Former resident | $4,711.00 | $0.00 | $-4,711.00 | [ ] Confirm paid | — |
| 10 - 10G | Spears, Courtney | Former resident | $1,281.00 | $836.00 | $-1,045.00 | [ ] Confirm paid | — |
| 11 - 11B | Isbell, Jessica D | Former resident | $3,590.00 | $0.00 | $-3,590.00 | [ ] Confirm paid | — |
| 11 - 11E | Powell, A'Ja Marie | Former resident | $615.00 | $168.00 | $-447.00 | [ ] Confirm paid | — |
| 11 - 11E | Todd, Brandon Scott | Former resident | $354.00 | $0.00 | $-354.00 | [ ] Confirm paid | — |
| 11 - 11E | Wilson, Jahacea | Current resident | $200.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 11 - 11G | Sigmon, Amanda D | Current resident | $131.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 12 - 12A | Peters, Ebony | Current resident | $2,041.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 13 - 13A | Moore, MelonieEva | Current resident | $424.00 | $423.00 | $0.00 | [ ] Confirm paid | — |
| 14 - 14A | Shuford, Alex | Current resident | $183.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 14 - 14B | McCall, Dorinda M | Former resident | $3,577.00 | $1,717.00 | $0.00 | [ ] Confirm paid | — |
| 15 - 15B | Ortiz Rivera, Doris | Current resident | $22.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 16 - 16B | Solera, Carlos L | Current resident | $2.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 16 - 16F | BUIE, VAN | Current resident | $2.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 17 - 17A | Blackburn, Rossella C | Current resident | $180.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 17 - 17B | Geter, Ciera Sade | Former resident | $1,867.00 | $564.00 | $-1,303.00 | [ ] Confirm paid | — |
| 2 - 2A | Russell, Brandy P | Current resident | $10.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 2D | Kaylor, Mary | Current resident | $12.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 2F | Boston, Allison | Former resident | $50.00 | $0.00 | $-50.00 | [ ] Confirm paid | — |
| 2 - 2F | Sione, Loruama F | Former resident | $741.00 | $0.00 | $-741.00 | [ ] Confirm paid | — |
| 2 - 2F | Harris, Alivih | Current resident | $30.00 | $0.00 | $-30.00 | [ ] Confirm paid | — |
| 3 - 3A | Reid, Sasha Nicole | Former resident | $1,674.00 | $0.00 | $-1,674.00 | [ ] Confirm paid | — |
| 3 - 3E | Streeter, Alexis | Former applicant | $194.00 | $0.00 | $-194.00 | [ ] Confirm paid | — |
| 3 - 3F | Lopp, Gina | Former resident | $1.00 | $0.00 | $-1.00 | [ ] Confirm paid | — |
| 3 - 3H | Jacobson, Joshua | Former resident | $863.00 | $312.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 5B | Oxendine, Whitney | Current resident | $2.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 5B | Craig, Latoya | Former resident | $1,548.00 | $994.00 | $-554.00 | [ ] Confirm paid | — |
| 5 - 5E | White-Blackburn, Regina Lanee | Former resident | $437.00 | $0.00 | $-437.00 | [ ] Confirm paid | — |
| 5 - 5E | Jones, Kenyettea | Current resident | $2.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 5F | Walker, Regina Jo | Former resident | $677.00 | $0.00 | $-677.00 | [ ] Confirm paid | — |
| 6 - 6F | Cardenas-Lemus, Gladis | Current resident | $135.00 | $15.00 | $-5.00 | [ ] Confirm paid | — |
| 6 - 6G | Pope, Deshinta Enid | Former resident | $407.00 | $16.00 | $-391.00 | [ ] Confirm paid | — |
| 6 - 6H | Steele, Cameo Nicole | Former resident | $937.89 | $553.00 | $-384.89 | [ ] Confirm paid | — |
| 6 - 6H | Mosteller, Peggy | Former resident | $695.00 | $0.00 | $-695.00 | [ ] Confirm paid | — |
| 7 - 7A | Fuller, Letha S | Former resident | $13.00 | $0.00 | $-13.00 | [ ] Confirm paid | — |
| 7 - 7C | Scott, Keyana D | Current resident | $1,476.00 | $1,261.00 | $0.00 | [ ] Confirm paid | — |
| 7 - 7D | Mclean, Jasmine | Current resident | $1,476.00 | $729.00 | $0.00 | [ ] Confirm paid | — |
| 7 - 7G | Nash, Cherie | Former resident | $3,602.00 | $0.00 | $-3,602.00 | [ ] Confirm paid | — |
| 7 - 7G | Edwards, Felicia V | Current resident | $13.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 7 - 7H | Perez, Janice Marie | Former resident | $3,057.00 | $214.00 | $-2,843.00 | [ ] Confirm paid | — |
| 8 - 8A | Hill, Shannon M | Former resident | $507.00 | $0.00 | $-507.00 | [ ] Confirm paid | — |
| 8 - 8B | Daye, Gladys Marie | Former applicant | $402.00 | $0.00 | $-402.00 | [ ] Confirm paid | — |
| 8 - 8B | Wilson, Alexus | Former resident | $1,500.00 | $0.00 | $-1,500.00 | [ ] Confirm paid | — |
| 8 - 8F | Abrams, Leah | Former resident | $845.00 | $0.00 | $-845.00 | [ ] Confirm paid | — |
| 8 - 8F | Morgan, Gary | Current resident | $175.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 9 - 9D | Dukes, Saadia | Former resident | $19.00 | $0.00 | $-19.00 | [ ] Confirm paid | — |
| 9 - 9D | Montgomery, Kahjia T | Current resident | $42.00 | $0.00 | $-42.00 | [ ] Confirm paid | — |
| 9 - 9E | Gibbs, Amber S | Current resident | $1,313.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 9 - 9F | Whiteside, Bradley Eugene | Former resident | $427.00 | $327.00 | $-100.00 | [ ] Confirm paid | — |
| 9 - 9G | Soto, Jessica | Current resident | $72.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 9 - 9H | Rivera, JhajairaMargarita | Former resident | $3,109.00 | $120.00 | $-2,989.00 | [ ] Confirm paid | — |

## Resident Balance Follow-Up — Paid / Zero Balance

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - 1C | Martinez, Sierra | Former resident | $370.00 | $370.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2E | BYRD, SHANNON E | Former resident | $341.00 | $341.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3E | Woods, Niashaa Shacore | Former resident | $64.00 | $64.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property's supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*