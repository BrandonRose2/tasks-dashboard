# Marrero 3 LP — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 4276597**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/05/2026 |
| Property manager | Ketorah Parks — rubystarmanager@apartmentcorp.com — (513) 413-6243 |
| Regional manager | Ginger Positerry — ginger@apartmentcorp.com — (985) 637-2128 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Delinquency spreadsheet | `4276597_Marrero 3 LP_Delinquent - Excel_58.xls` |
| Ledger accounts for review | 307 resident accounts |
| Residents with amount owed | 243 accounts; $385,929.68 |
| Prepaid / credit accounts | 62 accounts; $-31,881.39 |
| Availability entries | 0 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit's reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| — | — | No unit-status entries in the selected source export | [ ] Verified | __________________ |

## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 01 - 530A | Williams, Jovan | Former resident | $0.00 | $278.00 | $278.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 01 - 530A | Lampkin, Trenice | Current resident | $0.00 | $24.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05 - 546A | JONES, PAMELA | Former resident | $0.00 | $2,383.00 | $2,383.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05 - 546A | White, Ebony | Former resident | $0.00 | $96.50 | $96.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05 - 546A | Payne, Toinedra Angela | Former resident | $0.00 | $2,682.00 | $2,682.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05 - 546A | Walkey, Leonise | Current resident | $0.00 | $178.12 | $142.12 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 07 - 554A | Bass, Shanaica | Former resident | $0.00 | $27.00 | $27.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 07 - 554A | Duncan, Bridget Marie | Former resident | $0.00 | $5,547.00 | $5,547.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 08 - 560A | Jones, Taisha | Former resident | $0.00 | $1,878.00 | $1,878.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 08 - 560A | Blair, Kecia | Former resident | $0.00 | $2,173.00 | $2,173.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 09 - 564A | Reaux, Mashona | Former resident | $0.00 | $46.00 | $46.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 09 - 564A | Ellison, Ebone' Renee | Current resident | $0.00 | $1,536.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 568A | AUGUSTUS, KAREN | Former resident | $0.00 | $118.00 | $118.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 100 - 7130H | McIntyre, Jamie | Former resident | $0.00 | $1,453.00 | $1,453.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 100 - 7130H | Ellis, Krissy | Former resident | $0.00 | $43.00 | $43.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 102 - 7134H | Foster, Chezzada | Former resident | $0.00 | $331.00 | $331.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 103 - 7137H | Williams, Anisha Vanita | Current resident | $0.00 | $1,124.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 104 - 7138H | ROBERTSON, VALENE | Former resident | $0.00 | $536.00 | $536.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 104 - 7138H | Hawkins, Narrisa | Former resident | $0.00 | $968.00 | $968.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 106 - 7142H | Cox, Ashley Rochelle | Current resident | $0.00 | $12.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 107 - 7145H | Bilbo, Derrick | Current resident | $0.00 | $1,124.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 109 - 7149H | Lemieux, Candy | Former resident | $0.00 | $1,047.00 | $1,047.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 572A | Davis, Kenyetta | Former resident | $0.00 | $1,456.00 | $1,456.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 572A | Williams, Yasmeen | Former resident | $0.00 | $195.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 572A | Johnson, Sandra | Current resident | $0.00 | $84.00 | $48.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 110 - 7150H | PERRIER, DANNA | Former resident | $0.00 | $218.00 | $218.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 110 - 7150H | Paige, Patricia Ann | Current resident | $0.00 | $1,346.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 114 - 7100K | RAYMOND, LUCILLE | Former resident | $0.00 | $311.00 | $311.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 114 - 7100K | Woodford, Erica | Former resident | $0.00 | $1,231.00 | $1,231.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 114 - 7100K | Houston, Wynika | Former resident | $0.00 | $811.00 | $811.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 114 - 7100K | Burns, Valerie C | Current resident | $0.00 | $2,634.00 | $132.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 119 - 7109K | HOLDER, ELVIS | Former resident | $0.00 | $1,338.00 | $1,338.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 119 - 7109K | Williams, Keva | Former resident | $0.00 | $3,147.00 | $3,147.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 119 - 7109K | Williams, Darrenika L | Current resident | $0.00 | $86.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 535F | Simmons, Tanya | Former resident | $0.00 | $3,303.00 | $3,303.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 120 - 7112K | DUPLESSIS, TIWANA | Former resident | $0.00 | $1,311.00 | $1,311.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 121 - 7113K | ALEXANDER, TYESHA | Former resident | $0.00 | $328.00 | $328.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 121 - 7113K | Butler, LaQueshia M | Former resident | $557.00 | $2,332.00 | $1,775.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 121 - 7113K | Williams, Tearrani'Cheress | Current resident | $0.00 | $36.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 122 - 7116K | Wilson, Christina | Former resident | $0.00 | $660.00 | $660.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 122 - 7116K | Hunter, Terri | Current resident | $0.00 | $925.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 123 - 7117K | PRICE, AJANAI | Former resident | $0.00 | $548.00 | $548.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 123 - 7117K | Brown, AshleyCeleste | Former resident | $0.00 | $81.00 | $81.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 123 - 7117K | Coler, Kihantae | Current resident | $0.00 | $1,112.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 124 - 7120K | HUNTER, RODERICK | Former resident | $0.00 | $742.00 | $742.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 125 - 7121K | Chirlow, Montez | Former resident | $0.00 | $2,347.00 | $1,322.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 125 - 7121K | Roberts, Iyanna Marie | Current resident | $0.00 | $1,201.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 127 - 7129K | Johnson, Dione | Former resident | $0.00 | $407.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 129 - 7137K | Moore- Farrow, Carolyn | Current resident | $0.00 | $1,124.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 131 - 7145K | Bazile, Candria | Current resident | $0.00 | $1,124.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 132 - 7149K | Preatto, Octavia | Current resident | $0.00 | $1,124.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 133 - 7157H | Burkes, Mornika | Current resident | $0.00 | $278.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 134 - 7158H | Burkes, Mia | Current resident | $0.00 | $1,199.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 135 - 7161H | Webber, Jonathan | Current resident | $0.00 | $1,124.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 136 - 6908G | Sanders, Donisha M | Current resident | $0.00 | $700.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 137 - 6928G | Henderson, HowardDarmel | Current resident | $0.00 | $2,772.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 138 - 1916S | Houston, Shabrina | Current resident | $0.00 | $15.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 140 - 2000S | Johnson, Kavodas | Former resident | $0.00 | $1,534.00 | $1,534.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 141 - 6802SA | Peters, Ireyaun | Current resident | $0.00 | $22.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 142 - 6804SA | Batiste, Vernida | Current resident | $0.00 | $663.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 143 - 6808SA | Love, Melissa | Former resident | $681.00 | $1,054.02 | $373.02 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 144 - 6809SA | George, Natalie | Former resident | $31.00 | $2,162.00 | $2,131.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 144 - 6809SA | Williams, Tyroneisha M | Former resident | $0.00 | $1,535.00 | $1,535.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 144 - 6809SA | Brown, Yvotta | Former resident | $0.00 | $1,021.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 145 - 6816SA | BRIDGES, SAMUEL | Former resident | $0.00 | $1,399.00 | $1,399.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 145 - 6816SA | Lenox, Dewaner | Former resident | $0.00 | $1,418.00 | $1,418.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 146 - 6817SA | Odoms, Suzette | Former resident | $0.00 | $451.00 | $451.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 148 - 6824SA | Hodges, Catina | Former resident | $0.00 | $1,867.00 | $1,867.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 150 - 6829SA | Pinion, Mary | Current resident | $0.00 | $29.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 151 - 6900SA | Bailey, Diane | Former resident | $567.00 | $4,463.00 | $3,896.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 152 - 6901SA | Smith, Gloria | Former resident | $0.00 | $17,046.00 | $11,881.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 153 - 6908SA | MURRAY, SHEILA | Former resident | $0.00 | $2,137.04 | $2,137.04 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 153 - 6908SA | Napoleon, Latoya | Former resident | $0.00 | $774.00 | $774.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 153 - 6908SA | Roberson, Chantelle B'nai | Former resident | $0.00 | $1,286.00 | $1,286.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 153 - 6908SA | Walker, Charon M | Current resident | $0.00 | $24.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 154 - 6912SA | Jackson, Robin | Former resident | $0.00 | $2,050.15 | $2,050.15 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 154 - 6912SA | Hudson, Shantrell | Former resident | $0.00 | $852.00 | $852.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 154 - 6912SA | Robinson, Michaelena | Current resident | $0.00 | $1,444.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 155 - 6916SA | Coolie, Flora | Former resident | $0.00 | $31.00 | $31.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 156 - 6917SA | BUCKLEY, IRA'NEISHA | Former resident | $0.00 | $2,341.00 | $2,341.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 156 - 6917SA | Williams, Ashley R | Current resident | $0.00 | $855.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 157 - 6920SA | BELGROVE, YUKLYN | Former resident | $0.00 | $1,792.00 | $1,792.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 157 - 6920SA | Carter, Ashley | Former resident | $0.00 | $1,716.11 | $1,716.11 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 158 - 6921SA | Barnes, Thaddeus | Former resident | $0.00 | $476.00 | $476.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 158 - 6921SA | Williams, Doris Marie | Current resident | $0.00 | $729.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 159 - 6924SA | Azema, Showand | Former resident | $0.00 | $3,009.00 | $3,009.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 159 - 6924SA | Bernard, CharlotteFelicia | Current resident | $0.00 | $12.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 544F | Dillon, Keychelle | Former resident | $0.00 | $1,517.00 | $1,517.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 161 - 6936SA | Carter, Latoryer | Current resident | $0.00 | $482.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 162 - 6904G | JACKSON, EDNA | Former resident | $0.00 | $1,642.00 | $1,642.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 162 - 6904G | Wallace, Mallory | Former resident | $0.00 | $1,996.52 | $1,996.52 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 162 - 6904G | Brown, Rikeea | Former resident | $0.00 | $836.03 | $836.03 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 163 - 6936G | Brooks, Anita L | Current resident | $0.00 | $1,121.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 164 - 6813SA | EDWARDS, DENISHA | Former resident | $0.00 | $595.00 | $595.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 164 - 6813SA | Anderson, Jacob | Former resident | $0.00 | $700.00 | $700.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 164 - 6813SA | Ford, Tiriaun N | Current resident | $0.00 | $29.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 165 - 1901C | Watkins, Lakeisha | Current resident | $0.00 | $1,044.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 166 - 6800SA | Robinson, Tashonna | Current resident | $0.00 | $1,201.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 167 - 6805SA | BLACKMORE, DONNA | Former resident | $0.00 | $3,039.15 | $3,039.15 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 167 - 6805SA | Carter, Arielle | Former resident | $0.00 | $1,175.00 | $1,175.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 167 - 6805SA | Lewis, Wendy M | Current resident | $0.00 | $12.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 168 - 6821SA | Williams, Trena L | Current resident | $0.00 | $12.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 169 - 6909SA | Leferre, Leigh E. | Former resident | $0.00 | $1,538.00 | $1,538.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 169 - 6909SA | Davis, Brittney | Former resident | $0.00 | $1,119.00 | $1,119.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 169 - 6909SA | Wilson, Saudia | Former resident | $0.00 | $3,040.00 | $3,040.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 169 - 6909SA | Berry, Acharmbi | Current resident | $0.00 | $35.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 547F | Jasmine, Alice | Current resident | $0.00 | $517.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 173 - 6913SA | Mitchell, Timeka | Former resident | $0.00 | $4,904.00 | $4,904.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18 - 548F | Bazile, Joanna | Former resident | $0.00 | $3,988.00 | $3,988.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20 - 552F | Trepagnier, Erica | Former resident | $0.00 | $1,134.00 | $1,134.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 21 - 556F | PANSY, DESTINIE | Former resident | $0.00 | $1,482.00 | $1,482.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 22 - 560F | MARSHALL, QUANEISHA | Former resident | $0.00 | $569.00 | $569.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 22 - 560F | Curtis, Nakisha | Former resident | $0.00 | $574.00 | $574.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 24 - 604F | FLORANT, TRISCHELL | Former resident | $0.00 | $1,486.00 | $1,486.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 24 - 604F | Gilmore, Latorya | Former resident | $0.00 | $5,515.00 | $5,515.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 24 - 604F | Caston, Marcia Reena | Former resident | $204.00 | $2,334.11 | $2,130.11 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 24 - 604F | Sanford, Jazlyn Nichelle | Current resident | $0.00 | $12.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 25 - 605F | Mitchell, Robert | Former resident | $0.00 | $1,968.00 | $1,968.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 26 - 608F | Ellis, Tariska | Former resident | $0.00 | $3,315.00 | $3,315.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 26 - 608F | Price, Tracey | Former resident | $0.00 | $1,842.00 | $1,842.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 26 - 608F | Johnson, Terrilynn Ann | Former resident | $0.00 | $167.00 | $167.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 26 - 608F | Carter, Shakita M | Current resident | $0.00 | $569.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 27 - 609F | Ford, Gregory | Current resident | $0.00 | $8.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 30 - 620F | JONES, BRIONNE | Former resident | $0.00 | $1,992.00 | $1,992.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 30 - 620F | Johnson, Quentella | Former resident | $0.00 | $3,627.07 | $3,627.07 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 30 - 620F | Jones, Amber | Former resident | $0.00 | $3,044.76 | $3,044.76 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 30 - 620F | Hayes, Tyyone | Former resident | $0.00 | $102.00 | $102.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 30 - 620F | Sanders, Lenette Roberta | Former resident | $0.00 | $84.00 | $84.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 32 - 535S | Larkins, Lynn | Former resident | $0.00 | $2,287.00 | $2,287.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 33 - 539S | Wiggins, Tammara M | Current resident | $0.00 | $595.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 34 - 543S | Johnson, Lacey | Former resident | $0.00 | $855.00 | $855.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 34 - 543S | Collins, Shekitra Roshon | Former resident | $973.00 | $3,524.50 | $2,551.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 34 - 543S | Hudson, Sha'Ron | Current resident | $0.00 | $1,124.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 35 - 547S | Brumfield, Sada | Former resident | $0.00 | $447.00 | $447.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 35 - 547S | Hudson, Nikesha | Former resident | $0.00 | $2,468.00 | $358.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 36 - 551S | Jones, Kavis | Current resident | $0.00 | $944.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 38 - 601S | Starks, Laurence | Former resident | $218.00 | $3,320.00 | $3,102.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 38 - 601S | McClendon, Lila Patrice | Former resident | $0.00 | $1,358.00 | $1,358.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 38 - 601S | Simon, Vannika Mione | Current resident | $199.00 | $291.00 | $-199.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 40 - 609S | Rodney, Chasity | Former resident | $0.00 | $5,434.00 | $5,434.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 40 - 609S | Martin, Natalie Nicole | Former resident | $0.00 | $1,683.00 | $1,683.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 43 - 621S | Ray, Mable | Former resident | $0.00 | $2,219.26 | $2,219.26 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 43 - 621S | Rhodes, Tankia Terrell | Former resident | $0.00 | $1,750.00 | $1,750.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 44 - 625S | Golden, Dale | Former resident | $0.00 | $3,480.00 | $3,480.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 44 - 625S | Blunt, TerrioneDanielle | Current resident | $0.00 | $150.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 45 - 629S | Burns, Malerie Charmaine | Former resident | $0.00 | $2,029.00 | $1,029.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 45 - 629S | Hill, Andrea | Current resident | $0.00 | $787.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 46 - 624F | GORDON, ROSIE | Former resident | $1.00 | $930.00 | $929.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 46 - 624F | Blunt, Trenisha | Current resident | $0.00 | $27.95 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 47 - 628F | BATISTE, CLAUDETTE | Former resident | $0.00 | $429.00 | $429.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 47 - 628F | Greathouse, Rasheika C | Former resident | $0.00 | $8,670.00 | $8,670.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 47 - 628F | White, FayeAnn | Current resident | $0.00 | $12.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 49 - 1112 | MCCOY, DENEDRA | Former resident | $0.00 | $1,397.00 | $1,397.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 49 - 1112 | Johnson, Latoya | Former resident | $0.00 | $983.00 | $983.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 49 - 1112 | Anderson, BaidgetJannai | Current resident | $0.00 | $417.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 50 - 1116 | Williams, Nikiya | Former resident | $0.00 | $2,970.00 | $2,970.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 50 - 1116 | Harris, Tracey Montoya | Former resident | $0.00 | $2,278.00 | $2,278.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 50 - 1116 | Badon, Davineka Deloris Ladae | Current resident | $0.00 | $1,889.00 | $1,016.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 51 - 1117 | Hernaez, Dorothea | Former resident | $0.00 | $1,505.00 | $1,505.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 52 - 1119 | Cousain, Lula | Former resident | $0.00 | $6,722.00 | $6,722.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 53 - 1121 | Davis, Eleria | Former resident | $0.00 | $1,489.00 | $1,489.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 53 - 1121 | Casnave, Kyra | Former resident | $0.00 | $775.01 | $775.01 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 55 - 1203 | YOUNG, JACQUELINE | Former resident | $0.00 | $1,953.00 | $1,953.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 55 - 1203 | Feimster, Natasha | Former resident | $0.00 | $1,042.00 | $1,042.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 55 - 1203 | Perkins, Jonell | Former resident | $441.00 | $963.00 | $522.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 56 - 1204 | MITCHELL, BENNY | Former resident | $0.00 | $1,917.00 | $1,917.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 56 - 1204 | Paul, Dionne | Former resident | $0.00 | $831.00 | $831.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 58 - 1206 | Dillon, April | Former resident | $0.00 | $2,292.00 | $2,292.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 59 - 1207 | HILLS, PHIL | Former resident | $0.00 | $553.00 | $553.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 59 - 1207 | Carter, Tracy | Former resident | $87.00 | $2,015.16 | $1,928.16 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 59 - 1207 | Johnson, Patrice | Former resident | $0.00 | $1,849.36 | $1,849.36 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 60 - 1209 | Bell, Lakisha | Former resident | $0.00 | $1,751.00 | $1,751.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 60 - 1209 | Dove, Lynell | Former resident | $0.00 | $2,227.81 | $2,227.81 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 60 - 1209 | Godbolt, Natasha | Former resident | $0.00 | $329.00 | $329.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 60 - 1209 | Bank, Jah'wah-kesa Shantell | Former resident | $0.00 | $4,669.00 | $4,669.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 60 - 1209 | Miller, Crystal L | Former resident | $0.00 | $1,032.00 | $1,032.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 60 - 1209 | Hunter, Ashante | Current resident | $0.00 | $1,995.50 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 61 - 1211 | Cousain, Robin | Former resident | $0.00 | $7,225.00 | $7,225.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 61 - 1211 | Jackson, Margaret Nacole | Current resident | $0.00 | $217.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 62 - 1213 | WEARY, BIQUANTA | Former resident | $0.00 | $1,811.00 | $1,811.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 62 - 1213 | Givens, Anteanitha | Former resident | $0.00 | $151.00 | $151.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 62 - 1213 | Edmon, Kateria | Former resident | $0.00 | $754.00 | $754.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 62 - 1213 | Williams, Feleniser | Former resident | $0.00 | $1,986.00 | $1,986.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 62 - 1213 | Jenkins, La'Quanta | Former resident | $0.00 | $5,743.00 | $5,743.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 62 - 1213 | Taylor, Kimkesha | Former resident | $0.00 | $4,297.00 | $4,297.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 62 - 1213 | Jackson, Darnae Patrice | Current resident | $0.00 | $215.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 63 - 1217 | BADON, TERESA | Former resident | $0.00 | $160.00 | $160.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 63 - 1217 | Oliver, Wanda | Former resident | $0.00 | $1,026.00 | $1,026.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 63 - 1217 | Cousain, Terrilisha | Former resident | $0.00 | $34.00 | $34.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 63 - 1217 | Simmons, Pricilla | Former resident | $0.00 | $2,710.00 | $260.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 64 - 1219 | Evans, Deloris | Former resident | $177.00 | $1,713.00 | $1,536.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 64 - 1219 | Polezcek, Theresa | Current resident | $0.00 | $60.00 | $24.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 65 - 1301 | Stewart, La'zetta | Former resident | $0.00 | $3,405.00 | $3,405.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 65 - 1301 | Thomas, Maylin | Former resident | $0.00 | $5,192.00 | $5,192.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 65 - 1301 | James, Dontranique Raheem | Former resident | $0.00 | $2,318.00 | $2,318.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 65 - 1301 | Cornish, DesireeShudae | Current resident | $0.00 | $131.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 66 - 1303 | HUNTER, NIVIA | Former resident | $0.00 | $469.00 | $469.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 66 - 1303 | Hawkins, Fondrell | Current resident | $0.00 | $995.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 67 - 1305 | McNickles, Brianna | Former resident | $0.00 | $3,515.00 | $3,515.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 67 - 1305 | Jolliff, Lameeca | Former resident | $0.00 | $822.00 | $822.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 67 - 1305 | Mack, Kimber Michelle | Current resident | $357.00 | $809.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 68 - 1309 | WILLIAMS, JOHONDALL | Former resident | $0.00 | $2,966.00 | $2,966.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 68 - 1309 | Hutchinson, Darrlynn | Former resident | $0.00 | $10,291.00 | $10,291.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 68 - 1309 | MaGee, Tamayia | Former resident | $0.00 | $2,473.00 | $2,473.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 68 - 1309 | Francis, Renacer | Former resident | $0.00 | $1,672.42 | $1,172.42 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 68 - 1309 | Harris, Chan'Tavia | Current resident | $0.00 | $1,043.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 70 - 1317 | Lewis, Precious | Former resident | $0.00 | $3,010.00 | $3,010.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 70 - 1317 | Henderson, Paris | Current resident | $0.00 | $1,767.00 | $633.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 71 - 1319 | Harris, Levan | Former resident | $0.00 | $1,121.00 | $1,121.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 71 - 1319 | Moore, Tradonna | Former resident | $0.00 | $2,503.00 | $2,503.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 71 - 1319 | Wilson, Rashitta Reshawn | Former resident | $0.00 | $225.00 | $225.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 71 - 1319 | Dillon, Yiesha | Current resident | $0.00 | $2,088.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 72 - 1114 | HARVEY, LATASHIA | Former resident | $0.00 | $2,861.30 | $2,861.30 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 72 - 1114 | Davis, MiracleBernice | Current resident | $0.00 | $51.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 73 - 1208 | Little, Marcus | Current resident | $0.00 | $1,046.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 74 - 1215 | Gales, Irma | Former resident | $0.00 | $2,938.00 | $288.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 75 - 1307 | SMITH, BRANDY | Former resident | $0.00 | $1,596.00 | $1,596.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 76 - 1315 | KENNEDY, RANADA | Former resident | $0.00 | $2,439.00 | $2,439.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 76 - 1315 | Brown, Terrial Leshia | Former resident | $131.00 | $518.00 | $387.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 76 - 1315 | Dantzler, Raeven | Former resident | $597.00 | $2,888.00 | $-479.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 77 - 3140 | Nickelson, Samyata | Former resident | $0.00 | $1,515.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 78 - 3136 | Leagea, Shanta | Current resident | $0.00 | $1,124.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 79 - 3132 | Joseph, Sheyba | Former resident | $0.00 | $968.00 | $968.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 79 - 3132 | Harris, Jamon J | Former resident | $0.00 | $110.00 | $110.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 79 - 3132 | Turner, Reginik | Current resident | $0.00 | $1,124.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 80 - 3128 | Wallace, Harriet | Current resident | $0.00 | $1,120.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 81 - 3124 | Varnado, Tiffany | Current resident | $0.00 | $1,124.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 82 - 3120 | Evans, Dawntrell | Former resident | $0.00 | $8.00 | $8.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 83 - 3116 | Francis, Ashley | Former resident | $272.00 | $1,721.00 | $1,449.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 83 - 3116 | McClure, Kitara Tiara | Former resident | $0.00 | $405.00 | $405.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 83 - 3116 | Poole, Shameka | Current resident | $0.00 | $2,942.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 90 - 3148 | Thomas, Chris | Former resident | $0.00 | $3,453.00 | $3,453.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 91 - 3137 | Varise, Lyndrell | Former resident | $0.00 | $763.00 | $763.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 91 - 3137 | Major, Derionisha | Current resident | $0.00 | $557.00 | $521.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 92 - 3113 | Greenway, AinMary | Current resident | $0.00 | $12.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 93 - 3117 | Davis, Antoinetta | Former resident | $0.00 | $10,591.50 | $10,591.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 93 - 3117 | Jones, Ashley Allen | Former resident | $1,882.00 | $2,823.00 | $941.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 93 - 3117 | Spotville, NadineNicole | Current resident | $0.00 | $644.19 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 95 - 3125 | GAINES, ANGELA | Former resident | $0.00 | $1,802.75 | $1,802.75 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 95 - 3125 | McKnight, Brittany Dichelle | Current resident | $0.00 | $24.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 98 - 3133 | WALLACE, KEANE | Former resident | $0.00 | $3,477.18 | $3,477.18 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 98 - 3133 | Nellon, Keindill D | Current resident | $0.00 | $1,124.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 99 - 7129H | Gipson, Doris | Current resident | $123.00 | $266.21 | $-123.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 02 - 534A | Lewis, Audra | Former resident | $765.00 | $106.00 | $-659.00 | [ ] Confirm paid | — |
| 02 - 534A | Harris, Shemeka Lynn | Current resident | $736.00 | $0.00 | $-700.00 | [ ] Confirm paid | — |
| 03 - 538A | Thompson, Mary | Current resident | $22.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 04 - 542A | Batiste, Cynthia | Current resident | $2.77 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 06 - 550A | Lambert, CarlaHodges | Current resident | $398.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 08 - 560A | Jasmine, BrittanyNikida | Current resident | $2.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 09 - 564A | Kaywood, Jasmine | Former resident | $4,269.00 | $166.36 | $-4,102.64 | [ ] Confirm paid | — |
| 10 - 568A | Taylor, Verna J | Current resident | $3.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 100 - 7130H | Hunter, Kye | Current resident | $552.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 101 - 7133H | Mouton, Cheryl | Current resident | $159.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 113 - 7162H | Carey, Alicia R | Current resident | $4,912.00 | $0.00 | $-4,912.00 | [ ] Confirm paid | — |
| 115 - 7101K | Singleton, Eloise | Current resident | $20.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 116 - 7104K | Spencer, Patrice | Current resident | $300.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 120 - 7112K | Dunbar, Jennie A | Current resident | $4.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 123 - 7117K | Stevens, Kayla | Former applicant | $50.00 | $0.00 | $-50.00 | [ ] Confirm paid | — |
| 124 - 124-7120K | Smtih, LaTasha Marie | Applicant | $50.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 125 - 7121K | Butler, Brittany | Former applicant | $100.00 | $0.00 | $-100.00 | [ ] Confirm paid | — |
| 127 - 7129K | Thomas, Ronjique Dominique | Current resident | $1,071.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 13 - 539F | Reese, Tamara | Current resident | $18.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 130 - 7141K | Sheppard, StephanieMarie | Current resident | $242.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 136 - 6908G | Barker, Latasha | Former resident | $397.00 | $0.00 | $-397.00 | [ ] Confirm paid | — |
| 140 - 2000S | Walker, Tracy Nicole | Current resident | $133.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 143 - 6808SA | Ross, ShantaRayon | Current resident | $544.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 144 - 6809SA | Smith, Florestine | Applicant | $850.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 147 - 6820SA | Haywood, Tiffiney | Current resident | $78.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 15 - 543F | Jackson, Alice | Current resident | $120.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 151 - 6900SA | Johnson, Jessica Marie | Former resident | $1,257.00 | $0.00 | $-1,257.00 | [ ] Confirm paid | — |
| 151 - 6900SA | Shirley, CarmesiaRekay | Current resident | $44.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 152 - 6901SA | Brooks, Tersina | Current resident | $8.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 155 - 6916SA | Paige, Patricia A | Former applicant | $1,321.00 | $0.00 | $-50.00 | [ ] Confirm paid | — |
| 155 - 6916SA | Caston, RuthMae | Current resident | $75.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 159 - 6924SA | Clayton, Robyn | Former resident | $1,300.00 | $0.00 | $-1,300.00 | [ ] Confirm paid | — |
| 16 - 544F | Banks, Lisa Leshay | Former applicant | $50.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 16 - 544F | Jolla, GwendolynFay | Former applicant | $150.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 162 - 6904G | McDonald, Shendrika M | Current resident | $4.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 164 - 6813SA | Dean, Jeannetta | Former applicant | $50.00 | $0.00 | $-50.00 | [ ] Confirm paid | — |
| 171 - 6825SA | LAMBERT, LAKEISHA | Current resident | $28.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 172 - 6905SA | Hillard, Lois | Current resident | $12.00 | $0.00 | $-12.00 | [ ] Confirm paid | — |
| 22 - 560F | Simmons, Neknitta Marie | Current resident | $648.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 23 - 601F | Bailey, Chianti Teleka | Current resident | $411.00 | $0.00 | $-411.00 | [ ] Confirm paid | — |
| 30 - 620F | Quinn, Keyanna M | Current resident | $517.00 | $0.00 | $-361.00 | [ ] Confirm paid | — |
| 31 - 531S | Young, Diane | Current resident | $378.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 35 - 547S | Carter, Nadine | Former resident | $1,017.00 | $0.00 | $-1,017.00 | [ ] Confirm paid | — |
| 35 - 547S | Banks, Gernika Arian | Applicant | $50.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 40 - 609S | Hankerson, Felecia | Current resident | $96.98 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 42 - 617S | Young, Regina | Current resident | $2.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 43 - 621S | Dillon, Joyce | Current resident | $235.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 56 - 1204 | Wilson, Valeria | Current resident | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 58 - 1206 | Collins, Latasha | Current resident | $388.00 | $135.00 | $0.00 | [ ] Confirm paid | — |
| 59 - 1207 | Gaines, Sandra | Current resident | $48.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 68 - 1309 | RESIDENT, NON | Former applicant | $100.00 | $0.00 | $-100.00 | [ ] Confirm paid | — |
| 68 - 1309 | Seabron, Lamika Tiarra | Former applicant | $50.00 | $0.00 | $-50.00 | [ ] Confirm paid | — |
| 72 - 1114 | Miller, Crystal | Former resident | $1,352.00 | $0.00 | $-1,352.00 | [ ] Confirm paid | — |
| 72 - 1114 | Brown, Trena Lashon | Former applicant | $50.00 | $0.00 | $-50.00 | [ ] Confirm paid | — |
| 74 - 1215 | Warren, Wanda | Former resident | $1,169.00 | $0.00 | $-1,169.00 | [ ] Confirm paid | — |
| 77 - 3140 | Turner, Kenneth | Current resident | $734.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 79 - 3132 | Bryant, Sicquia R | Former resident | $2,000.00 | $0.00 | $-2,000.00 | [ ] Confirm paid | — |
| 84 - 3108 | Johnson, Jacqueline | Current resident | $2.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 87 - 3144 | Williams, Arkeydia Rachell | Current resident | $4.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 90 - 3148 | Hawkins, DemetricAnn | Current resident | $4.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 92 - 3113 | Coler, Charlesha | Former resident | $2,648.00 | $477.00 | $-2,171.00 | [ ] Confirm paid | — |
| 95 - 3125 | Hudson, Marla M | Former resident | $1,100.00 | $336.00 | $-764.00 | [ ] Confirm paid | — |

## Resident Balance Follow-Up — Paid / Zero Balance

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 160 - 6932SA | Dabney, Tanjal | Current resident | $108.00 | $108.00 | $-108.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 89 - 3127 | Peck, Jessie | Current resident | $87.00 | $87.00 | $-87.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property's supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*