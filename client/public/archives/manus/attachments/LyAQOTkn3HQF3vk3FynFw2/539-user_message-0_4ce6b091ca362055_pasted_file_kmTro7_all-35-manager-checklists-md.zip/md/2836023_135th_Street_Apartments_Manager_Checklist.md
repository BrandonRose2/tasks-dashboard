# 135th Street Apartments — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 2836023**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/05/2026 |
| Property manager | Rosa Villarroel — opa@apartmentcorp.com — (786) 270-7932 |
| Regional manager | JR Rolon — jrrolon@apartmentcorp.com — (941) 716-1665; Leslie Rolon — leslie@apartmentcorp.com — (504) 247-3813 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Delinquency spreadsheet | `2836023_135th Street Apartments_Delinquent - Excel_58.xls` |
| Ledger accounts for review | 61 resident accounts |
| Residents with amount owed | 54 accounts; $59,812.96 |
| Prepaid / credit accounts | 7 accounts; $-8,295.00 |
| Availability entries | 0 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit's reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| — | — | No unit-status entries in the selected source export | [ ] Verified | __________________ |

## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 101 | FARRINGTON, SYLVIA V | Current resident | $0.00 | $8.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 103 | TAYLOR, MATTIE B | Former resident | $0.00 | $347.00 | $347.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 103 | Mosquera, Manuel | Former resident | $0.00 | $14.99 | $14.99 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 104 | MORENO, LUCY O | Former resident | $0.00 | $142.00 | $142.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 108 | BARRUETA, CELIA | Former resident | $0.00 | $559.00 | $559.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 108 | ZAYAS, EMILIO | Former resident | $0.00 | $305.00 | $305.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 113 | POWELL, SISLYNN R | Former resident | $0.00 | $392.00 | $392.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 113 | CRISPIN PENA, CARMEN R | Former resident | $0.00 | $1,730.00 | $1,730.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 114 | SOCARRAS, LETI | Current resident | $0.00 | $243.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 119 | BENBOW, CHARLENE L | Former resident | $0.00 | $590.00 | $590.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 120 | MILINDEZ, LATAURIUS D | Former resident | $0.00 | $1,124.00 | $1,124.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 121 | WILLIAMS, ALTEASHA R | Current resident | $0.00 | $331.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 123 | LOPEZ DIPEGAL, ARGELIA | Current resident | $0.00 | $669.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 124 | LOPEZ, OLGA L | Former resident | $0.00 | $1,139.00 | $1,139.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 125 | STEPNEY, SHONIKA L | Former resident | $0.00 | $156.00 | $156.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 127 | SWINDLE, SHELIA L | Former resident | $0.00 | $705.00 | $705.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 127 | SCOTT, TRAVINA T | Former resident | $0.00 | $948.00 | $948.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 129 | DUKES, ELON | Former resident | $0.00 | $1,006.00 | $1,006.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 130 | Walker, General J | Former resident | $0.00 | $734.00 | $734.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 132 | William, Arriette | Former resident | $0.00 | $780.00 | $780.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 132 | Tundidor, Marilyn | Former resident | $0.00 | $363.00 | $363.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 132 | Alvarez, Aimim | Former resident | $0.00 | $4,030.00 | $4,030.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 132 | ORTIZ, MANUEL | Current resident | $0.00 | $1,587.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 133 | BROWN, ROGERENE N | Former resident | $0.00 | $290.00 | $290.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 133 | Vasquez, Teresa K | Former resident | $0.00 | $1,802.00 | $1,802.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 133 | NARANJO, GLORIA | Former resident | $0.00 | $302.00 | $302.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 201 | Walker, Mary Lee | Former resident | $0.00 | $702.00 | $702.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 202 | REYES, FRIDA | Former resident | $0.00 | $74.00 | $74.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 204 | Rodriguez, Magaly | Former resident | $0.00 | $249.00 | $249.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 205 | Kilpatrick, TRESSY L | Former resident | $0.00 | $729.00 | $729.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 206 | SANDERS, JESSIE | Former resident | $0.00 | $521.00 | $521.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 208 | SWARN, BRENDA D | Former resident | $0.00 | $2,156.00 | $2,156.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 208 | CID, Jose D | Former resident | $0.00 | $436.00 | $436.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 208 | Baez Castillo, Isbeth E | Former resident | $0.00 | $197.00 | $197.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 210 | RAMSAY, IAN C | Former resident | $0.00 | $132.00 | $132.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 211 | DIAS, SANDRA D | Former resident | $0.00 | $9,621.54 | $9,621.54 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 212 | JOHNSON, MYCHELLE | Former resident | $0.00 | $1,079.00 | $1,079.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 212 | ROCHE LOPEZ, ADIXA | Former resident | $0.00 | $704.00 | $704.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 216 | Butler, Crystal C | Former resident | $0.00 | $501.59 | $501.59 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 217 | KNIGHT, TYKETIA S | Former resident | $0.00 | $1,309.50 | $1,309.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 218 | James, Lisa H | Former resident | $0.00 | $5,341.00 | $5,341.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 219 | MOORE, MONICA S | Former resident | $0.00 | $1,167.93 | $1,167.93 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 219 | COLLINS, KYMONI D | Former resident | $0.00 | $2,922.50 | $2,922.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 220 | DELGADO, ROBERTO | Former resident | $0.00 | $1,317.00 | $1,317.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 220 | Thomas, AndreaI | Former resident | $0.00 | $936.00 | $936.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 220 | Castillo, Fatima I | Former resident | $0.00 | $3,714.00 | $3,714.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 220 | BAEZ, FATIMAISBEL | Current resident | $0.00 | $309.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 221 | ROMERO, DARLENE | Former resident | $54.00 | $791.00 | $737.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 221 | Escorcia, Brittnay I | Former resident | $0.00 | $205.54 | $205.54 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 222 | ROLLE, KATRINA | Former resident | $0.00 | $1,324.37 | $1,324.37 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 224 | Curry, Kenisha L | Former resident | $0.00 | $131.00 | $131.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 225 | BRIGHT, GIOVANNI S | Former resident | $0.00 | $2,086.00 | $2,086.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 226 | CURRY, QUINTILLA L | Current resident | $0.00 | $197.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 227 | CRIBBS, TIFFANY N | Former resident | $0.00 | $716.00 | $716.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 108 | BARRIOS, KEILY | Current resident | $35.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 117 | Barnes, Shandrea L | Former resident | $7,023.00 | $0.00 | $-7,023.00 | [ ] Confirm paid | — |
| 131 | SMITH, SOPHIA K | Current resident | $19.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 133 | Davis, Tekeshia T | Former resident | $129.00 | $0.00 | $-129.00 | [ ] Confirm paid | — |
| 218 | Romero, Arelis C | Current resident | $33.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 221 | Sanchez Pino, Gustavo | Current resident | $22.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 227 | OJEDA, SAUL | Current resident | $1,034.00 | $0.00 | $-1,034.00 | [ ] Confirm paid | — |

## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.

## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property's supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*