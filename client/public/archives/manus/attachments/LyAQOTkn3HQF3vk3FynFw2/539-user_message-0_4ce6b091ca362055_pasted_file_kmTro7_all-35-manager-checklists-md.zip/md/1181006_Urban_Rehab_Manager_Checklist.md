# Urban Rehab — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 1181006**. Update the checkboxes and notes during or immediately after the manager call.

> **Note:** Two Urban Rehab contacts exist in Notion ("Urban Rehab 1" and "Urban Rehab 2") and it wasn't clear which maps to this property — both are listed; confirm the correct one.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/05/2026 |
| Property manager | Amunique Cannon — — — (323) 456-7800; Lyndon Jernigan — — — (323) 456-7800 |
| Regional manager | Blake Weddington — blake@apartmentcorp.com — (310) 927-0020 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Delinquency spreadsheet | `1181006_Urban Rehab_Delinquent - Excel_58.xls` |
| Ledger accounts for review | 266 resident accounts |
| Residents with amount owed | 239 accounts; $636,698.50 |
| Prepaid / credit accounts | 27 accounts; $-18,150.58 |
| Availability entries | 0 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit's reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| — | — | No unit-status entries in the selected source export | [ ] Verified | __________________ |

## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 101 | WILLIAMS, CHARLES JR | Former resident | $0.00 | $1,937.76 | $1,937.76 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 101 | Mitchell, Sahmia | Former resident | $0.00 | $1,894.96 | $1,894.96 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 101 | BARNES, JOAN ELIZABETH | Former resident | $0.00 | $2,260.44 | $2,260.44 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 101 | HENDERSON, ALPHONSE | Current resident | $0.00 | $2,767.13 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 102 | TAYLOR, CLIFFORD | Former resident | $0.00 | $927.00 | $927.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 102 | HAYES, BIANCIA | Current resident | $13.88 | $1,697.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 103 | SMITH, MC | Former resident | $0.00 | $798.68 | $798.68 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 103 | Rand, Steve | Former resident | $0.00 | $385.00 | $385.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 103 | JONES, ROY | Former resident | $0.00 | $820.00 | $820.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 103 | FREW, DORITA E | Current resident | $0.00 | $5,321.90 | $1,558.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 104 | GREGORY, ALICIA | Former resident | $0.00 | $873.96 | $873.96 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 104 | JOHNSON, THERRELL | Former resident | $0.00 | $145.00 | $145.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 104 | COTTERELL, DONALD | Former resident | $0.00 | $1,238.42 | $1,238.42 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 104 | MUNOZ, GEORGE | Former resident | $216.91 | $487.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 105 | HAYDEN, NEAL | Former resident | $0.00 | $191.96 | $191.96 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 105 | Braxton, Danielle | Former resident | $0.00 | $857.00 | $857.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 105 | WORTHAM, SOUNDRA | Former resident | $0.00 | $1,442.68 | $1,442.68 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 105 | BROCK, CHANTEL MIA | Former resident | $0.00 | $1,365.72 | $1,365.72 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 105 | GRIFFIN, JAMES | Current resident | $0.00 | $1,738.96 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 106 | MOSLEY, SHAMONA | Former resident | $366.00 | $4,208.60 | $3,842.60 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 106 | KILLION, DIAMOND RONEE | Former resident | $0.00 | $160.00 | $160.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 107 | CLARK, STEVE | Former resident | $0.00 | $1,191.88 | $1,191.88 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 107 | JERNIGAN, LYNDON D | Former resident | $144.00 | $581.00 | $437.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 107 | YOUNGBLOOD, DAVENE | Current resident | $0.00 | $2,638.82 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 108 | BREWER, DAWN | Former resident | $0.00 | $577.00 | $577.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 108 | HUGHES, NATHANIEL | Former resident | $0.00 | $421.04 | $421.04 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 108 | Trass, Richard | Former resident | $0.00 | $501.08 | $501.08 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 108 | OWENS, DEANGELO | Former resident | $0.00 | $844.00 | $844.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 108 | ACORD, KEITH | Former resident | $0.00 | $532.00 | $532.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 108 | GARCIA, MIGUEL A | Former resident | $0.00 | $486.00 | $486.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 108 | DAQUASHA, JONES | Current resident | $0.00 | $1,436.06 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 108 | CRISTINO, RODRIGUEZ | Former resident | $0.00 | $628.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 109 | GLOVER, DONYELLE | Former resident | $0.00 | $749.00 | $749.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 109 | TIPPIN, JUSTICE LATIKA | Former resident | $0.00 | $342.20 | $342.20 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 109 | RUIZ, TAJA | Current resident | $0.00 | $489.06 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 110 | STERLING, JEROME | Former resident | $0.00 | $698.10 | $698.10 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 110 | LUNA, EVELIN | Former resident | $0.00 | $1,662.00 | $1,662.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 110 | MOSES, TIMMEKA S | Former resident | $0.00 | $20.88 | $20.88 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 110 | BANNER, BIANCA D | Former resident | $0.00 | $18.47 | $18.47 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 110 | MARABLE, JARA KAY RENEE | Former resident | $0.00 | $148.89 | $148.89 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 110 | WILLIAMS, DANIEL | Current resident | $0.00 | $1,765.06 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 111 | Mason, Elsworth | Former resident | $0.00 | $886.00 | $886.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 111 | TURNAGE, LISA | Former resident | $69.00 | $582.00 | $513.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 111 | GARCIA, ERICA | Former resident | $0.00 | $4,399.46 | $4,399.46 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 111 | RODGERS, PRENTISS | Current resident | $0.00 | $2,198.25 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 112 | LOVE, ALINE D | Former resident | $0.00 | $2,010.00 | $2,010.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 112 | LOVE, ALINE | Current resident | $0.00 | $2,655.82 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 201 | WOODS, LICHEEN | Former resident | $0.00 | $54.64 | $54.64 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 201 | Porch, Cavetta | Former resident | $0.00 | $553.00 | $553.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 201 | SANCHEZ, ANTONIA | Former resident | $0.00 | $60.00 | $60.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 201 | JACKSON, MONIQUE | Former resident | $0.00 | $1,506.64 | $1,506.64 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 201 | SILVA, SUHEY ELENA | Former resident | $0.00 | $349.00 | $349.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 201 | Jackson, Exelona | Current resident | $0.00 | $3,354.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 202 | MURRAY, ASIA | Former resident | $0.00 | $1,278.32 | $1,278.32 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 202 | Kelly, Lemetrious | Former resident | $0.00 | $1,546.76 | $1,546.76 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 202 | MOORE II, CYNTHIA | Former resident | $0.00 | $3,966.76 | $3,966.76 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 202 | GUIJARRO, ISAMAR | Former resident | $0.00 | $2,188.68 | $2,188.68 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 202 | HENDRICKS, JEFFEREY | Former resident | $0.00 | $36.25 | $36.25 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 202 | GARCIA, MIGUEL | Current resident | $29.18 | $1,765.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 203 | PERRY, MARLITA | Former resident | $0.00 | $284.00 | $284.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 203 | HENDERSON, SHYAHNA | Former resident | $0.00 | $4,520.48 | $4,520.48 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 203 | ODOM, JAMIE DEFON | Former resident | $0.00 | $256.96 | $256.96 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 203 | ODOM, JAMIE | Current resident | $0.00 | $3,451.86 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 204 | SMITH, DANNIELLE | Former resident | $0.00 | $796.76 | $796.76 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 204 | TARRY NAIRN, NEA | Former resident | $0.00 | $804.00 | $804.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 204 | TILLOTSON, TAMARAE | Former resident | $0.00 | $951.40 | $951.40 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 204 | PRICE, JAMES | Former resident | $0.00 | $2,832.96 | $2,832.96 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 204 | HENDERSON, AMERYAH | Current resident | $0.00 | $3,266.78 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 205 | TAYLOR, ESAU | Former resident | $0.00 | $666.00 | $666.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 205 | SMITH III, WILLIE J | Current resident | $72.08 | $8,452.00 | $4,429.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 206 | KIM, JOHNPAUL J | Former resident | $0.00 | $5,051.92 | $5,051.92 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 206 | CORREA, EMILY KATHLEEN | Former resident | $0.00 | $96.76 | $96.76 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 206 | MARTINEZ, THALIA | Current resident | $0.00 | $1,690.01 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 207 | LINCOLN, ELLESE | Former resident | $0.00 | $216.56 | $216.56 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 207 | Coffee, Roslyn L. | Former resident | $0.00 | $1,428.84 | $1,428.84 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 207 | STERLING, WILFRED | Current resident | $0.00 | $3,447.96 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 208 | JENKINS, BEVERLY | Former resident | $0.00 | $258.72 | $258.72 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 208 | CLARK, STEVEN | Former resident | $0.00 | $713.88 | $713.88 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 208 | WILLIAMS, TYLER | Current resident | $6.85 | $933.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 209 | MITCHELL, INA M | Former resident | $141.00 | $1,555.00 | $1,414.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 209 | MITCHELL, INA | Current resident | $0.00 | $3,628.88 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 210 | MADISON, FREDERICK | Former resident | $0.00 | $122.00 | $122.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 210 | Hunter, Lashanel L | Former resident | $801.00 | $2,222.80 | $1,421.80 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 210 | MITCHELL, JAYLIN | Current resident | $0.00 | $1,867.01 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 211 | WEBB, PHILLIP H | Former resident | $0.00 | $1,545.00 | $1,545.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 211 | WILKERSON, GABRIEL | Current resident | $0.00 | $1,885.01 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 212 | ELZY, EVELYN | Former resident | $0.00 | $958.40 | $958.40 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 212 | Lewis, Carolyn | Former resident | $0.00 | $1,624.00 | $1,624.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 212 | TARRY, EAN | Former resident | $0.00 | $879.20 | $879.20 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 212 | PAYNE, LEONDRA | Current resident | $0.00 | $2,831.02 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9310A | EDWARDS, CASSANDRA | Former resident | $0.00 | $1,104.04 | $1,104.04 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9310A | Kilgore, Deshonna R | Former resident | $0.00 | $2,102.89 | $2,102.89 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9310A | PORCH, CAVETTA | Former resident | $0.00 | $1,191.20 | $1,191.20 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9310A | HENRY, SAMANTHA | Former resident | $0.00 | $337.00 | $337.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9310A | WILLIAMS, AFRIKA | Former resident | $0.00 | $1,673.00 | $1,673.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9310A | SAMUEL, LATIA | Former resident | $0.00 | $356.52 | $356.52 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9310A | COLEMAN, TRAYNISHA CHERRELL | Former resident | $608.00 | $1,568.60 | $960.60 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9310A | FELIX OJEDA, BEATRIZ | Current resident | $0.00 | $973.84 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9310B | GROVES, AISHA | Former resident | $0.00 | $3,084.92 | $3,084.92 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9310B | TORRES RUIZ, SAYRA E | Current resident | $560.00 | $4,346.92 | $520.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9310C | GONZALEZ, MARTHA | Former resident | $0.00 | $1,310.00 | $1,310.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9310C | CRUZ, METZY | Former resident | $0.00 | $565.84 | $565.84 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9310C | LUDWIG, KARLA | Former resident | $0.00 | $2,868.00 | $2,868.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9310C | COTTON, TIFFANY | Former resident | $0.00 | $1,136.72 | $1,136.72 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9310C | TERRY, MYESHA | Former resident | $0.00 | $34.04 | $34.04 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9310C | CARTER, SARAH PM | Former resident | $0.00 | $411.64 | $411.64 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9310C | MCFADDEN, BRITTANY DENISE | Current resident | $4.00 | $7,850.92 | $2,312.04 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9310D | QUINN, MOLLIETTA | Former resident | $0.00 | $2,749.84 | $2,749.84 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9310D | WILLIAMS, DOMINIQUE | Former resident | $0.00 | $1,056.60 | $1,056.60 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9310D | DAVENPORT, SOFIA C | Former resident | $0.00 | $108.80 | $108.80 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9310D | LOPEZ RIGGS, MELISSA | Current resident | $0.00 | $7,558.08 | $2,023.20 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9310E | SMITH, SHERIDAN | Former resident | $0.00 | $1,132.88 | $1,132.88 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9310E | STEPHENS, AMBER E | Former resident | $0.00 | $889.00 | $889.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9310E | BOWEN, RAYSHANAE CHARLESETTA | Former resident | $0.00 | $43.22 | $43.22 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9310E | MITCHELL, SHAUNTRICE D | Current resident | $0.00 | $6,663.48 | $1,280.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9310F | MCCORD, JERREAL D | Current resident | $309.04 | $6,799.00 | $2,140.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9312A | SMITH, KANIESHAY L | Former resident | $0.00 | $1,000.05 | $1,000.05 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9312A | SANDOVAL, SELENE | Current resident | $0.48 | $7,842.00 | $3,225.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9312B | SANCHEZ, ANTONIA | Former resident | $0.00 | $894.42 | $894.42 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9312B | BROWN, DAPHNE L | Former resident | $148.00 | $5,567.88 | $5,419.88 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9312B | CHAVEZ LUVIANO, ELIZABETH | Former resident | $1,879.00 | $7,000.32 | $4,998.32 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9312B | MIRANDA MARTINEZ, ANITA | Current resident | $0.00 | $2,602.82 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9312C | HOWSER, TERESA | Former resident | $0.00 | $423.96 | $423.96 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9312C | Houston, La'Desiree | Former resident | $1.00 | $105.60 | $104.60 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9312C | Cadenas, Maria L | Former resident | $0.00 | $2,692.14 | $2,692.14 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9312C | ROBINSON, TRENATI T | Former resident | $0.00 | $134.00 | $134.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9312C | LINTHICUM, CHARON C | Former resident | $0.00 | $502.31 | $502.31 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9312C | GODDEN, TERRELL WARREN | Current resident | $912.00 | $5,410.95 | $-600.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9312D | BOATRIGHT, CAROLYN | Former resident | $0.00 | $6,768.67 | $6,768.67 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9312D | KENNEDY, SCHANIQUE | Former resident | $0.00 | $1,728.56 | $1,728.56 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9312D | JOHNSON, CHRISTAL M | Former resident | $197.00 | $399.72 | $202.72 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9312D | ROBERTS, LAKESHA RUPEZ | Former resident | $0.00 | $3,720.76 | $3,720.76 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9312D | PENA HENRIQUEZ, LORENA GRACIELA | Current resident | $0.00 | $4,322.58 | $972.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9312E | Basulto, Monica | Former resident | $0.00 | $1,543.00 | $1,543.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9312E | VALLIER, DAYSHAREE A | Former resident | $0.00 | $4,116.79 | $4,116.79 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9312E | LOPEZ DE LUGO, MARIA | Current resident | $0.00 | $6,990.47 | $1,738.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9312F | Smith, Shereka | Former resident | $0.00 | $1,559.27 | $1,559.27 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9312F | CAMPBELL, NADIA S | Former resident | $0.00 | $5,174.84 | $5,174.84 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9312F | ARNOLD, LACHELLE A | Current resident | $0.00 | $4,253.76 | $989.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9316A | HENDERSON, DANIEL | Former resident | $0.00 | $27.36 | $27.36 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9316A | FRAZIER, CHAVON | Former resident | $0.00 | $1,323.00 | $1,323.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9316A | COLLINS, VELMA | Former resident | $0.00 | $1,111.40 | $1,111.40 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9316A | MCNEAL, JAMEYA MYNYETTE | Former resident | $0.00 | $2,117.52 | $2,117.52 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9316A | WILLIAMS, DIMINIQUE D | Current resident | $0.00 | $7,227.19 | $1,692.31 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9316B | WARMACK, SHERMAINE | Former resident | $0.00 | $1,838.60 | $1,838.60 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9316B | ALLEN, CAROLYN L | Former resident | $0.00 | $2,791.36 | $2,791.36 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9316B | GREEN, ADRIAN L | Former resident | $0.00 | $7,392.40 | $7,392.40 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9316B | GATES, JASMINE CARESSA | Current resident | $1,036.00 | $7,406.04 | $835.16 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9316C | ABDUSSALAAM, INAYAH | Former resident | $0.00 | $1,424.04 | $1,424.04 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9316C | TITUS, LASHEENIA | Former resident | $0.00 | $1,019.86 | $1,019.86 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9316C | SKINNER, GRAYLON B | Former resident | $0.00 | $943.76 | $943.76 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9316C | WOODS, BRITTNEY E | Current resident | $0.00 | $6,352.74 | $1,013.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9316D | AGUAYO, ARNOLDO | Former resident | $0.00 | $2,879.00 | $2,879.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9316D | WILLIAMS, VANESSA | Former resident | $0.00 | $169.72 | $169.72 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9316D | GABLE, JASMINE E | Former resident | $0.00 | $1,524.96 | $1,524.96 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9316D | MENDOZA, MICHELL A | Former resident | $0.00 | $171.96 | $171.96 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9316D | MCFARLAND, DONNETTE RONESHA | Former resident | $0.00 | $231.34 | $231.34 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9316D | JIMENEZ LUVIANO, NANCY | Current resident | $0.00 | $7,011.65 | $1,602.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9316E | CRUSOE, CANDY | Former resident | $0.00 | $577.00 | $577.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9316E | LEE, BRITNEY | Former resident | $0.00 | $991.90 | $991.90 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9316E | RASPBERRY, MONICA | Former resident | $0.00 | $567.00 | $567.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9316E | REYES, GLORIA | Former resident | $0.00 | $2,561.84 | $2,561.84 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9316E | TOURE, KIMANTHI ABEJE | Former resident | $0.00 | $22.00 | $22.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9316E | MATTHEWS, ANDREA D | Current resident | $1,790.41 | $7,523.00 | $206.59 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9316F | ALLEN, LATOYA | Former resident | $0.00 | $677.20 | $677.20 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9316F | Nearn, Lawrence L | Former resident | $0.00 | $3,770.36 | $3,770.36 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9316F | HUMPHREY, EARLASHA DANIELLE | Former resident | $0.00 | $103.52 | $103.52 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9316F | LICEA, RAMONA VALENCIA | Current resident | $120.08 | $5,952.04 | $1,041.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9318A | WILLIAMS, MANOLIA | Former resident | $0.00 | $1,502.56 | $1,502.56 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9318A | ROBINSON, AKAMIE | Former resident | $0.00 | $2,217.24 | $2,217.24 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9318A | EVANS BROOKS, SYLVIA A | Former resident | $0.00 | $675.12 | $675.12 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9318A | PEREZ, WENDY LIZETH | Former resident | $0.00 | $1,194.92 | $1,194.92 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9318A | LOPEZ, VERONICA | Current resident | $0.00 | $6,416.12 | $1,280.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9318B | SANDERS, BRIDGET | Current resident | $0.00 | $9,548.46 | $4,213.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9318C | SHEPARD, ANGELA | Former resident | $0.00 | $1,286.60 | $1,286.60 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9318C | STONE, MICHELLE | Former resident | $0.00 | $1,785.29 | $1,785.29 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9318C | MORENO, RUBY | Former resident | $0.00 | $22.72 | $22.72 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9318C | RAMIREZ, CHRISTIAN A | Former resident | $709.00 | $1,267.28 | $558.28 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9318C | HORTA, STEFANY | Current resident | $83.52 | $6,521.00 | $1,688.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9318D | JOHNSON, JULIAN | Former resident | $0.00 | $1,496.72 | $1,496.72 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9318D | Byone, Cecilia S | Former resident | $0.00 | $2,000.04 | $2,000.04 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9318D | NICHOLSON, LEILANI | Former resident | $0.00 | $35,915.08 | $35,915.08 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9318D | MONTES DE OCA, NATALY | Current resident | $0.00 | $4,736.24 | $924.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9318E | Williams, Samuel J. | Former resident | $0.00 | $718.00 | $718.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9318E | ALLEN, DEANDRE R | Former resident | $0.00 | $3,295.00 | $3,295.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9318E | ELLISON, SHERMAINE ALINA | Former resident | $0.00 | $215.00 | $215.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9318E | MONTES DELGADO, LIDIA STEPHANIE | Current resident | $83.00 | $5,792.76 | $525.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9318F | GRACE, TAIJA | Former resident | $0.00 | $267.52 | $267.52 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9318F | Heath, Mercedes | Former resident | $0.00 | $1,516.00 | $1,516.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9318F | CARLOS, MARIELENA | Former resident | $0.00 | $4,756.60 | $4,756.60 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9318F | FARRELL, OTIS | Current resident | $0.00 | $4,801.56 | $972.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9404A | HARRELL, BARBARA | Current resident | $0.00 | $8,832.76 | $3,963.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9404B | WINFORD, LUESENDIA | Former resident | $0.00 | $1,505.92 | $1,505.92 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9404B | SANDRIDGE, ASHLEE | Former resident | $0.00 | $2,791.80 | $2,791.80 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9404B | HERNANDEZ, PATRICIA | Former resident | $173.00 | $1,647.92 | $1,474.92 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9404B | EASLY ALI, FATIMA MS | Current resident | $378.73 | $5,868.00 | $1,251.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9404C | ADAMS, SOPHIA | Former resident | $0.00 | $1,585.04 | $1,585.04 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9404C | POTTS, ATIYA ST | Former resident | $0.00 | $4,034.68 | $4,034.68 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9404C | ZUNIGA, KARINA | Current resident | $0.00 | $5,810.96 | $1,322.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9404D | Roy, Clonett | Former resident | $0.00 | $2,437.68 | $2,437.68 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9404D | HARRIS, KEYYONNA | Former resident | $373.24 | $560.00 | $186.76 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9404D | DICKERSON, MICHAEL D | Former resident | $1,142.00 | $7,660.04 | $6,518.04 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9404D | HEARNS, SHANIYA C | Current resident | $0.00 | $7,015.95 | $1,687.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9404E | SNEED, LAVADA | Former resident | $0.00 | $275.64 | $275.64 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9404E | Proby, Odelliott K | Former resident | $0.00 | $2,224.08 | $2,224.08 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9404E | WALTERS, NIKKI EYVETTE | Former resident | $1,611.00 | $5,138.24 | $3,527.24 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9404E | LUVIANO MALDONADO, VICENTA | Current resident | $0.00 | $5,838.94 | $860.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9404F | WILLOUGHBY, PRECIOUS | Former resident | $0.00 | $4,185.72 | $4,185.72 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9404F | HAYES, PATIENCE J | Former resident | $0.00 | $84.04 | $84.04 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9404F | FISHER, MARTELL P | Former resident | $0.00 | $1,747.82 | $1,747.82 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9404F | JORDAN, KANEAL LK | Former resident | $0.00 | $8,615.92 | $8,615.92 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9404F | DREAR, KEISHANE | Current resident | $7.92 | $9,966.00 | $4,983.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9408A | SIMPLISS, SANDRA | Former resident | $0.00 | $844.90 | $844.90 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9408A | GIBSON, DIANNA | Former resident | $0.00 | $1,949.00 | $1,949.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9408A | SHAW, AMANDA R | Former resident | $0.00 | $18,031.60 | $18,031.60 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9408A | PITTS, WINESHA R | Current resident | $0.00 | $5,684.39 | $228.51 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9408B | WARMACK, JUNE A | Former resident | $0.00 | $1,393.00 | $1,393.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9408B | BERNARD, MICHELLE | Former resident | $0.00 | $1,215.64 | $1,215.64 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9408B | HERVEY, JACQUELINE DENISE | Former resident | $0.00 | $1,100.72 | $1,100.72 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9408B | MCGHEE, TAMISHA NASHAUN | Current resident | $622.00 | $5,354.77 | $140.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9408C | Smith, Damon | Former resident | $0.00 | $1,554.00 | $1,554.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9408C | MORENO, SANDRA | Former resident | $0.00 | $2,972.92 | $2,972.92 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9408C | SALCEDO, JOSEFINA A | Current resident | $0.00 | $5,171.96 | $1,109.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9408C | ROVIRA, RUBEN | Former resident | $0.00 | $1,828.84 | $1,828.84 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9408D | PROUDIE, MARGARET | Former resident | $0.00 | $156.03 | $156.03 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9408D | Frew, Sandra | Former resident | $0.00 | $495.84 | $495.84 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9408D | HILL, HELENA | Former resident | $0.00 | $3,185.84 | $3,185.84 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9408D | ADDISON, SHALESE L | Former resident | $0.00 | $216.36 | $216.36 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9408D | MAY, KA LONNIE L | Current resident | $0.00 | $6,708.45 | $1,173.57 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9408E | Saiz, Rita | Former resident | $0.00 | $2,174.96 | $2,174.96 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9408E | RASPBERRY, PHILLIP | Former resident | $0.00 | $1,209.92 | $1,209.92 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9408E | SCOTT, DELORES D | Former resident | $0.00 | $54.04 | $54.04 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9408E | CANNON, AMUNIQUE E | Current resident | $0.00 | $7,240.81 | $1,956.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9408E | JONES, JASON D | Former resident | $0.00 | $0.36 | $0.36 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9408F | HARDY, DEBORAH | Former resident | $2.00 | $30.84 | $28.84 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9408F | Williams, Cynthia | Former resident | $0.00 | $1,682.77 | $1,682.77 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9408F | HERNANDEZ, JOSEFINA | Former resident | $0.00 | $1,164.00 | $1,164.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9408F | SCOTT, SHATRRA MONET | Former resident | $0.00 | $43,276.92 | $43,276.92 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9408F | DOMINGUES DE JESUS, ROSIO | Current resident | $0.00 | $6,573.88 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 104 | THOMAS, MARCUS A | Former resident | $2,341.00 | $1,767.16 | $-573.84 | [ ] Confirm paid | — |
| 106 | MCGOWAN, CAROLYN MILLISA | Former resident | $2,768.00 | $2,293.01 | $-474.99 | [ ] Confirm paid | — |
| 106 | MARTINEZ ANGUIANO, CONSUELO | Former resident | $278.99 | $233.00 | $0.00 | [ ] Confirm paid | — |
| 202 | LACOUR, GLORIA | Former resident | $997.00 | $0.00 | $-997.00 | [ ] Confirm paid | — |
| 208 | NICHOLSON, DEREK | Former resident | $1,293.00 | $822.76 | $-470.24 | [ ] Confirm paid | — |
| 209 | BOLDEN, EARSLEY | Former resident | $649.00 | $118.92 | $-530.08 | [ ] Confirm paid | — |
| 9310B | JOHNSON, SHAWNTEAL | Former resident | $2,156.00 | $182.84 | $-1,973.16 | [ ] Confirm paid | — |
| 9310D | YANCEY, RAYNESHA LASHAWN | Former resident | $463.00 | $1.24 | $-461.76 | [ ] Confirm paid | — |
| 9312A | TAYLOR, JACOB | Former resident | $1,296.00 | $0.00 | $-1,296.00 | [ ] Confirm paid | — |
| 9312A | LEE, SHANEQUA | Former resident | $111.00 | $3.10 | $-107.90 | [ ] Confirm paid | — |
| 9312B | BURKE, YOLANDA | Former resident | $1,032.00 | $0.00 | $-1,032.00 | [ ] Confirm paid | — |
| 9312B | CORRY, KHARIZMA | Former resident | $161.00 | $98.00 | $0.00 | [ ] Confirm paid | — |
| 9312D | GRAY, DIJONEE | Former resident | $2,383.00 | $43.00 | $-2,340.00 | [ ] Confirm paid | — |
| 9312E | MILLER, MARCUS ANTOINE | Former resident | $880.00 | $0.00 | $-880.00 | [ ] Confirm paid | — |
| 9312F | HINKSMON, LAUREN | Former resident | $122.00 | $1.99 | $-120.01 | [ ] Confirm paid | — |
| 9312F | STRINGER, ALEXIS MONIQUE | Former resident | $334.00 | $0.00 | $-334.00 | [ ] Confirm paid | — |
| 9316A | JOHNSON, TASHAWNNA M | Former resident | $6.00 | $0.00 | $-6.00 | [ ] Confirm paid | — |
| 9316C | JOHNSON, KEYERA DESHAE | Former resident | $814.00 | $0.00 | $-814.00 | [ ] Confirm paid | — |
| 9316F | JONES, DAY-JAH L | Former resident | $1,242.00 | $498.80 | $-743.20 | [ ] Confirm paid | — |
| 9318F | VASQUEZ, AARON | Former resident | $957.00 | $448.00 | $-509.00 | [ ] Confirm paid | — |
| 9404B | BAILEY, BRE'YANNA MI'YOSHIA | Former resident | $889.00 | $500.96 | $-388.04 | [ ] Confirm paid | — |
| 9404D | *WATSON, YOLANDA | Former resident | $753.00 | $12.00 | $-741.00 | [ ] Confirm paid | — |
| 9404F | GARRETT, REGINA | Former resident | $4,673.00 | $4,202.00 | $-471.00 | [ ] Confirm paid | — |
| 9408D | Brown, Benjamen | Former resident | $1,233.00 | $245.19 | $-987.81 | [ ] Confirm paid | — |
| 9408D | YELL, ZENDA | Former resident | $1,284.00 | $4.44 | $-1,279.56 | [ ] Confirm paid | — |
| NONE | HAP common ledger | Misc. Income | $375.00 | $0.00 | $-375.00 | [ ] Confirm paid | — |
| WAIT | MOSLEY, AMANDA | Applicant | $136.00 | $0.00 | $-136.00 | [ ] Confirm paid | — |

## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.

## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property's supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*