# Pirates Bend — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 5313977**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/03/2026 |
| Property manager | Sandra Crump — pirates@apartmentcorp.com — (225) 505-3965 |
| Regional manager | Ginger Positerry — ginger@apartmentcorp.com — (985) 637-2128 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Delinquency spreadsheet | `5313977_Pirates Bend_Delinquent - Excel_58.xls` |
| Ledger accounts for review | 84 resident accounts |
| Residents with amount owed | 80 accounts; $163,375.73 |
| Prepaid / credit accounts | 4 accounts; $-1,296.00 |
| Availability entries | 7 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit's reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| 2-212 | 4B2Ba | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 2-224 | 4B2Ba | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 4-414 | 1B1Ba | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 4-423 | 1B1Ba | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 4-426 | 2B2Ba | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 5-513 | 3B2Ba | NTV Not Leased | [ ] Verified | __________________ |
| 1-113 | 3B2Ba | Vacant Leased Ready | [ ] Verified | __________________ |

## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - 111 | Harris, Alexis | Current resident | $0.00 | $1,306.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 111 | Revish, Nicholas Jamal | Former resident | $0.00 | $4,871.84 | $4,871.84 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 112 | Watkins, Ashley Nichole | Former resident | $0.00 | $2,516.36 | $2,516.36 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 112 | White, Harry L | Former resident | $0.00 | $2,415.00 | $2,415.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 112 | Miller, Charmainee | Current resident | $0.00 | $1,306.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 113 | Chambers, Kyeshia N | Former resident | $0.00 | $6,645.00 | $6,645.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 113 | Collier, Carneshia Shanel | Former resident | $0.00 | $875.71 | $875.71 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 113 | Simmons, Matthew | Former resident | $0.00 | $1,809.60 | $1,809.60 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 113 | Sims, Anita Angelina | Former applicant | $0.00 | $62.00 | $50.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 114 | Montgomery, Jasmine L | Former resident | $0.00 | $6,102.35 | $6,102.35 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 114 | Watson, Kayla | Former resident | $0.00 | $1,026.84 | $1,026.84 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 114 | Gregoire, Jaquita | Former resident | $0.00 | $3,377.50 | $3,377.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 114 | Daniels, Dyneisha | Current resident | $0.00 | $1,306.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 123 | Townsend, Carlos | Former resident | $0.00 | $1,941.48 | $1,941.48 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 211 | Dedrick, Conrad Barnel | Former resident | $0.00 | $2,866.42 | $2,866.42 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 211 | Davis, Carla Maria | Former resident | $0.00 | $2,501.00 | $2,501.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 211 | Vaughan, Jessie Lynn | Current resident | $0.00 | $100.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 212 | Poole, Jontell Larae | Former resident | $0.00 | $6,113.52 | $6,113.52 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 212 | White, Linda | Former resident | $0.00 | $1,043.97 | $1,043.97 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 212 | Kennard, Maranda | Former resident | $101.42 | $1,307.23 | $1,205.81 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 212 | West, Deshannon | Former applicant | $0.00 | $50.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 214 | Knight, Ryneshia | Current resident | $0.00 | $433.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 214 | Allen, Patrick N | Former resident | $0.00 | $2,670.13 | $2,670.13 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 221 | Cage, Delandria | Former resident | $0.00 | $1,444.00 | $1,444.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 221 | Fountain, Derendra Lashay | Current resident | $0.00 | $12.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 224 | Prophet, Erica S | Former resident | $0.00 | $2,075.00 | $2,075.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 224 | Wright, Lakethia | Former resident | $0.00 | $4,057.93 | $4,057.93 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 224 | Bell, Lamondra | Former resident | $0.00 | $1,673.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 311 | Vessel, Earnest Lawrence | Former resident | $0.00 | $3,167.25 | $3,167.25 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 311 | Jasmine, Timothy John | Former resident | $0.00 | $1,493.11 | $1,493.11 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 311 | Taylor, Kunta | Former resident | $0.00 | $2,149.32 | $2,149.32 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 311 | Hampton, Mary | Former resident | $0.00 | $2,074.60 | $2,074.60 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 312 | Johnson, Unwai | Former resident | $0.00 | $1,091.00 | $1,091.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 312 | Holloway, Jasmine A | Former resident | $0.00 | $2,852.10 | $2,852.10 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 312 | Green, Yolanda | Former applicant | $0.00 | $50.00 | $50.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 315 | Crooper, John | Former resident | $0.00 | $63.71 | $63.71 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 315 | Green, Passion M | Former resident | $0.00 | $1,912.33 | $1,912.33 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 321 | Jackson II, Gerald Charles | Current resident | $0.00 | $800.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 322 | Morrison, Helen Marie | Former resident | $0.00 | $2,339.71 | $2,339.71 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 322 | Holloway, Dajuan Lamarcus | Former resident | $0.00 | $2,471.98 | $2,471.98 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 322 | Brumfield, Kyle | Current resident | $0.00 | $1,767.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 324 | Palmer, Doreen | Current resident | $0.00 | $232.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 325 | *Powell, Shanita Nicole | Former resident | $0.00 | $3,522.61 | $3,522.61 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 325 | Jefferson, Kamber Shontrell | Former resident | $0.00 | $3,981.71 | $3,981.71 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 325 | Grifin, Jakayla Lashay | Former applicant | $0.00 | $0.01 | $0.01 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 325 | Davis, Percy | Current resident | $0.00 | $100.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 326 | Williams, Mister Samitheus | Former applicant | $0.00 | $100.00 | $100.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 326 | Comeaux, ChadJoseph | Current resident | $0.00 | $2,454.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 412 | Harris, Ernecia Shonquel | Former resident | $0.00 | $3,757.90 | $3,757.90 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 413 | Mckinney, Klaas | Former resident | $0.00 | $1,328.84 | $1,328.84 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 414 | Davis, Damon | Former resident | $0.00 | $919.35 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 415 | Winchester, Charleston | Former resident | $0.00 | $1,653.90 | $1,653.90 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 415 | Wilson, Alexis Tiara | Current resident | $0.00 | $1,251.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 421 | Brown, Brenda | Former applicant | $0.00 | $50.00 | $50.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 421 | Ealy, Shenka Dente | Current resident | $0.00 | $3,433.54 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 422 | Fields, Adrieana | Former resident | $0.00 | $1,710.66 | $1,710.66 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 423 | *Joseph, Crystal | Former resident | $0.00 | $3,114.47 | $1,908.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 424 | Badon, Veronica | Former resident | $0.00 | $1,376.00 | $1,376.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 424 | JONES, KILA | Former resident | $0.00 | $22.76 | $22.76 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 424 | Chatman, Thaddus | Current resident | $0.00 | $24.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 424 | Broden, Charolette | Former applicant | $0.00 | $50.00 | $50.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 425 | Ricks, Dequincia Dajauna | Former resident | $0.00 | $1,389.28 | $1,389.28 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 425 | BLOUIN, MARY P | Former resident | $0.00 | $2,967.80 | $2,967.80 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 426 | Tennart, Twila | Former resident | $0.00 | $3,575.33 | $3,575.33 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 426 | Sanders, Tyra | Former resident | $0.00 | $1,880.48 | $1,880.48 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 426 | Williams, Dorein | Former resident | $0.00 | $2,880.89 | $184.89 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 512 | Bell, LaMonica A | Former resident | $0.00 | $1,455.48 | $1,455.48 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 512 | Spears, Trevonna | Current resident | $0.00 | $2,281.86 | $581.86 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 513 | Armstrong, Tammie M | Former resident | $0.00 | $2,588.00 | $2,588.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 513 | Daniel Jr., Edwin Damonte | Former resident | $0.00 | $1,607.94 | $1,607.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 513 | Smith, Britteny | Former resident | $0.00 | $1,411.00 | $1,411.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 514 | Wallace, JenniferMarie | Former resident | $0.00 | $4,196.50 | $4,196.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 514 | Law, Avery | Former resident | $0.00 | $4,446.20 | $4,446.20 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 514 | Washington, Tonya Nicole | Current resident | $0.00 | $1,570.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 521 | Hayes, Geroldyn | Former resident | $0.00 | $2,467.39 | $2,467.39 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 521 | Whitfeild, Domoneik | Former resident | $0.00 | $3,667.62 | $3,667.62 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 521 | Collins, Brian Dewayne | Current resident | $0.00 | $2,099.60 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 522 | Martin, Monique N | Former resident | $0.00 | $5,606.49 | $5,606.49 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 524 | WILLIAMS, TIERRA | Former resident | $0.00 | $2,690.55 | $2,690.55 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 524 | Lee, Yolanda | Current resident | $0.00 | $1,471.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - 113 | Bajoie, Quaneisha | Applicant | $330.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 223 | Bougere, Nicole | Current resident | $263.00 | $0.00 | $-263.00 | [ ] Confirm paid | — |
| 4 - 411 | Smith, Tarongela | Current resident | $121.00 | $18.00 | $-103.00 | [ ] Confirm paid | — |
| WAIT | Tickles, Jaquan Tyrone | Applicant | $600.00 | $0.00 | $-600.00 | [ ] Confirm paid | — |

## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.

## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property's supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*