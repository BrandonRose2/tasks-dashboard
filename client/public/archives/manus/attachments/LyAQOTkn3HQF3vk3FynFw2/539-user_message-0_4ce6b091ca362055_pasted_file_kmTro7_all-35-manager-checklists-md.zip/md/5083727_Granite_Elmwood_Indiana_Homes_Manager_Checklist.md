# Granite Elmwood Indiana Homes — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 5083727**. Update the checkboxes and notes during or immediately after the manager call.

> **Note:** Not in Company Contacts — you confirmed Blake Weddington as regional manager; property manager still needs to be provided.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/05/2026 |
| Property manager | _No contact on file in Company Contacts — confirm with regional manager._ |
| Regional manager | Blake Weddington — blake@apartmentcorp.com — (310) 927-0020 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Delinquency spreadsheet | `5083727_Granite Elmwood Indiana Homes_Delinquent - Excel_58.xls` |
| Ledger accounts for review | 0 resident accounts |
| Residents with amount owed | 0 accounts; $0.00 |
| Prepaid / credit accounts | 0 accounts; $0.00 |
| Availability entries | 0 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit's reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| — | — | No unit-status entries in the selected source export | [ ] Verified | __________________ |

## Resident Balance Follow-Up — Amount Owed

No resident ledger entries were detected in the selected source export.

## Resident Balance Follow-Up — Prepaid / Credit

No resident ledger entries were detected in the selected source export.

## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.

## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property's supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*