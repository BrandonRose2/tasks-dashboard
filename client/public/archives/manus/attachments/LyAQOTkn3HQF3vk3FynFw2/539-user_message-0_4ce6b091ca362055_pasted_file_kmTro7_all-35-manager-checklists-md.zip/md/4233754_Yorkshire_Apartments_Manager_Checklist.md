# Yorkshire Apartments — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 4233754**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/04/2026 |
| Property manager | Kimberly Powell — windsor@apartmentcorp.com — (318) 230-0656 |
| Regional manager | Ginger Positerry — ginger@apartmentcorp.com — (985) 637-2128 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Delinquency spreadsheet | `4233754_Yorkshire Apartments_Delinquent - Excel_58.xls` |
| Ledger accounts for review | 354 resident accounts |
| Residents with amount owed | 270 accounts; $323,506.03 |
| Prepaid / credit accounts | 83 accounts; $-66,136.61 |
| Availability entries | 3 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit's reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| 5-507 | 1B1B | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 16-1603 | 2B1B | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 19-1901 | 2B1B | Vacant Not Leased Not Ready | [ ] Verified | __________________ |

## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - 101 | Douglas, Valoria E | Current resident | $567.80 | $786.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 102 | Mosley, Stephanie | Former resident | $0.00 | $728.00 | $728.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 102 | Lee, Avery A | Former resident | $0.00 | $254.00 | $254.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 102 | Capers, Meagan | Former resident | $1,548.00 | $2,580.00 | $1,032.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 102 | Thomas, Quinisha Monique | Current resident | $28.00 | $75.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 103 | Haywood, Sandra | Former resident | $0.00 | $886.00 | $886.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 103 | Summage, Catherine Robinson | Former resident | $0.00 | $1,667.00 | $1,667.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 103 | Edwards, Shukara S | Former resident | $0.00 | $2,350.00 | $2,350.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 103 | Marshall, Moeshay M | Former resident | $0.00 | $863.00 | $863.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 104 | Hall, Deantoinejacreed | Former resident | $1,412.00 | $2,816.00 | $1,404.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 104 | Young, Jaquan C | Former resident | $0.00 | $937.00 | $937.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 104 | Howard, April Berince | Current resident | $0.00 | $1,260.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1001 | Sessum, Azell | Former resident | $0.00 | $888.00 | $888.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1001 | Moten, LaDaisha D | Former resident | $0.00 | $1,482.00 | $1,482.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1001 | Polk, Moesha C | Former resident | $0.00 | $2,201.00 | $2,201.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1001 | Small, Jasmine R | Former resident | $0.00 | $2,956.00 | $2,956.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1001 | Washington, Carolyn Dawkins | Current resident | $25.00 | $365.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1002 | Johnson, Felicia | Former resident | $0.00 | $224.00 | $224.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1002 | Smith, Safiya Zainab | Former resident | $0.00 | $1,139.00 | $1,139.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1002 | Watkins, Jatearrica Lyshae | Former resident | $0.00 | $1,263.00 | $1,263.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1002 | Patterson, Lillie M | Current resident | $0.00 | $10.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1003 | Butler, Janniesha Michele | Former resident | $0.00 | $1,339.00 | $1,339.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1003 | Musgrove, Alexis Moshay | Former resident | $0.00 | $147.00 | $147.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1003 | Morris, Jalisa Janae | Current resident | $0.00 | $1,809.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1004 | Sims, Johnetta Tracyia | Former resident | $0.00 | $1,762.00 | $1,762.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1004 | Self, Christine Raechelle | Former resident | $0.00 | $322.00 | $322.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1004 | Gayden, Crystal | Former resident | $0.00 | $2,173.00 | $2,173.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1004 | Walls, Timothy W | Former resident | $0.00 | $2,005.00 | $2,005.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1004 | Bates, Reshiada R | Current resident | $0.00 | $22.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1101 | Scott, Satterica | Former resident | $0.00 | $1,814.00 | $1,814.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1101 | Stewart, Erma Jean | Former resident | $0.00 | $1,263.00 | $1,263.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1101 | LeGrande, Mallory Nicole | Former resident | $0.00 | $882.00 | $882.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1101 | Harris, Alexius Shardaie | Former resident | $0.00 | $2,071.00 | $2,071.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1102 | Priest, Cammie | Former resident | $0.00 | $160.00 | $160.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1102 | Burks, Star Samone | Former resident | $0.00 | $1,309.00 | $1,309.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1102 | George, LaTonya Evette | Former resident | $0.00 | $1,428.00 | $1,428.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1102 | Thomas, Shadoe Q | Former resident | $229.00 | $2,793.00 | $2,564.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1102 | Persley, Mia | Former resident | $0.00 | $2,576.00 | $2,576.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1102 | Collins, Jamie R | Current resident | $0.00 | $397.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1103 | Burks, Latasha | Former resident | $0.00 | $97.00 | $97.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1103 | Johnson, Quansetta Quinese | Former resident | $0.00 | $1,171.00 | $1,171.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1103 | Griffin, Diana Rena | Current resident | $0.00 | $417.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1104 | Black, Margie Kidd | Former resident | $236.00 | $478.00 | $242.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1104 | Monroe, Glennisha | Former resident | $0.00 | $1,994.00 | $1,994.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1104 | Steadman, Shaneeda J | Former resident | $0.00 | $2,453.00 | $2,453.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1104 | McNeil, Bykia S | Current resident | $0.00 | $2,035.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1202 | Mason Jones, Tammy | Former resident | $0.00 | $56.00 | $56.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1202 | Carpenter, Tiffany Shantell | Former resident | $86.00 | $1,664.00 | $1,578.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1202 | Willis, Felicia Ann | Former resident | $0.00 | $2,171.00 | $2,171.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1202 | Mason, Olivia Ann | Former resident | $0.00 | $2,162.00 | $2,162.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1202 | Jackson, Alexis M | Former resident | $0.00 | $299.00 | $299.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1202 | Reynolds, Megan K | Former resident | $0.00 | $500.00 | $500.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1202 | Avertte-Jones, Amya | Current resident | $0.00 | $103.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1203 | Owens, Shardaisa C | Former resident | $0.00 | $2,792.00 | $2,792.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1203 | Cooksey, Ladericka | Former resident | $1,665.00 | $2,192.00 | $527.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1203 | McGee, Rhonda | Current resident | $0.00 | $494.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1204 | McCoy, Charmeda Sharisse | Former resident | $0.00 | $1,014.00 | $1,014.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1204 | Roper, Maisha Omega | Former resident | $0.00 | $2,827.00 | $2,827.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1204 | Crawford, Cornay Sharie | Former resident | $0.00 | $1,083.00 | $1,083.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1204 | Woods, Pauline n | Current resident | $0.00 | $143.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1301 | Haggarty, Valenica | Former resident | $0.00 | $712.00 | $712.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1301 | Dale, JaniceLamache | Former resident | $0.00 | $2,006.67 | $2,006.67 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1301 | Thomas, Olivia Christine | Former resident | $54.78 | $223.00 | $168.22 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1301 | Roberson, Briana | Former resident | $0.00 | $1,365.00 | $1,365.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1301 | Persley, Malayzhea A | Former resident | $0.00 | $669.00 | $669.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1302 | Madison, Tysae S | Former resident | $0.00 | $619.00 | $619.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1302 | Pipkins, Diamond M | Former resident | $0.00 | $1,027.00 | $1,027.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1302 | Speed, Quantavious D | Former resident | $0.00 | $522.00 | $522.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1302 | Williams, Trask L. | Current resident | $52.00 | $638.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1303 | Thomas, Raven | Former resident | $0.00 | $692.00 | $692.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1303 | Heard, Rhonda D | Current resident | $651.00 | $1,668.00 | $-651.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1304 | Johnson, VelmaAnn | Former resident | $0.00 | $384.00 | $384.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1304 | Gillyard, Martina E | Former resident | $0.00 | $1,068.00 | $1,068.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1304 | Hill, Jerice F | Current resident | $34.00 | $652.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1401 | Harris, Nadia Savonna | Former resident | $0.00 | $1,905.00 | $1,905.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1401 | McCoy, Charmeda Sharisse | Current resident | $0.00 | $1,577.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1402 | Harrison, Fil | Former resident | $0.00 | $10.00 | $10.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1402 | Jefferson, Shantrell Dion | Former resident | $0.00 | $1,431.00 | $1,431.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1402 | Bullock, Tammy T | Current resident | $0.00 | $147.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1403 | Smith, Sherry | Former resident | $0.00 | $883.00 | $883.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1403 | Carter, Johnny D | Former resident | $0.00 | $342.00 | $342.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1403 | Taylor, Wendy M | Former resident | $0.00 | $2,896.50 | $2,896.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1403 | Johnson, Walter J | Current resident | $8.00 | $646.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1404 | Sanders, Brenda | Former resident | $0.00 | $260.58 | $260.58 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1404 | Roquemore, Frederick J | Former resident | $249.00 | $1,637.00 | $1,388.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1404 | Taylor, Linda | Former resident | $0.00 | $443.00 | $443.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1404 | Thomas, Nicole | Current resident | $0.00 | $937.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15 - 1501 | Cooper, Patrica | Former resident | $0.00 | $444.00 | $444.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15 - 1501 | Owens, Bobbie Lashay | Former resident | $0.00 | $509.00 | $509.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15 - 1501 | Bradley, Candace R. | Former resident | $0.00 | $525.00 | $525.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15 - 1501 | Persley, Leeshuntania Cashandra | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15 - 1501 | Hinton, Brittney Nicole | Current resident | $0.00 | $911.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15 - 1502 | Blackshire, Sharon denise | Former resident | $0.00 | $181.00 | $181.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15 - 1502 | Amos, Ashley Nichole | Former resident | $0.00 | $79.42 | $79.42 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15 - 1503 | Wilson, Robert | Former resident | $0.00 | $1,402.00 | $1,402.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15 - 1503 | Wood, Holly | Current resident | $0.00 | $140.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15 - 1504 | Henderson, Jeanenne M | Former resident | $0.00 | $1,793.90 | $1,793.90 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15 - 1504 | Williams, Saqueda P | Former resident | $0.00 | $2,101.00 | $2,101.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 1601 | Morris, Phyllis Marie | Current resident | $0.00 | $1,441.99 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 1602 | Livingston, Kisiah | Former resident | $0.00 | $224.00 | $224.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 1602 | Smith, Sharon Denise | Former resident | $0.00 | $1,515.00 | $1,515.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 1602 | McCray, LaTonya Monique | Former resident | $0.00 | $1,292.00 | $1,292.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 1602 | Anderson, Felisha D | Former resident | $0.00 | $1,749.00 | $1,749.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 1602 | Johnson, Anquinette L | Current resident | $0.00 | $366.00 | $278.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 1603 | Harris, Marcea Janea | Former resident | $75.00 | $4,765.00 | $4,690.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 1603 | White, LaShonda | Former resident | $0.00 | $377.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 1604 | McCray, LaTonya Monique | Former resident | $0.00 | $2,080.00 | $2,080.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 1604 | Butler, Lashieka Cherelle | Former resident | $0.00 | $2,218.50 | $2,218.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 1604 | Martinez, Toni Ann | Current resident | $0.00 | $1,013.50 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 1604 | Woods, Latrisa S | Former resident | $453.76 | $1,740.00 | $1,286.24 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 1701 | Wood, Tammie | Former resident | $0.00 | $485.00 | $485.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 1701 | Clark, Stephon | Former resident | $0.00 | $2,474.00 | $2,474.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 1701 | Anderson, Rhonda | Current resident | $0.00 | $1,041.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 1702 | Reddix, Bernadine | Former resident | $0.00 | $376.00 | $376.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 1702 | Williams, Mary Belle | Current resident | $0.00 | $111.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 1703 | Williams, Kierica Monate | Former resident | $0.00 | $6,212.50 | $6,212.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 1703 | English, LaQuawn E | Current resident | $0.00 | $507.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 1704 | Sinegal, Victoria L | Current resident | $0.00 | $622.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18 - 1801 | Brown, Jessica | Former resident | $0.00 | $53.00 | $53.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18 - 1801 | Pouncy, Keyonta | Former resident | $0.00 | $276.00 | $276.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18 - 1801 | Montgomery, Rolanda Collette | Former resident | $0.00 | $1,919.00 | $1,919.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18 - 1801 | Miles, Shontanay Lateish | Former resident | $0.00 | $3,832.00 | $3,832.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18 - 1801 | Primer, Lakendra Trierr-Lashay | Former resident | $0.00 | $1,748.00 | $1,748.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18 - 1802 | Winn, Tracy | Former resident | $0.00 | $217.00 | $217.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18 - 1802 | Ellis, Hazetta Lashunna | Former resident | $0.00 | $621.00 | $621.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18 - 1802 | Parker, Keorion Jaquaw | Former resident | $0.00 | $1,983.00 | $1,983.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18 - 1802 | Palmer   #2, Richard | Former resident | $0.00 | $1,835.34 | $1,835.34 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18 - 1802 | Sanders Jr, Carl Kelvin | Current resident | $0.00 | $7.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18 - 1803 | Savannah, Taja | Former resident | $0.00 | $177.00 | $177.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18 - 1803 | Shepard, Sabrina | Former resident | $0.00 | $625.00 | $625.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18 - 1803 | Granville, TashondaJuanee | Former resident | $0.00 | $569.00 | $569.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18 - 1803 | Duffie, Shimaria lashon | Former resident | $0.00 | $1,912.00 | $1,912.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18 - 1803 | Green, Ashley L | Former resident | $0.00 | $2,374.00 | $2,374.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18 - 1803 | Henry, Halle I | Former resident | $0.00 | $3,377.00 | $3,377.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18 - 1803 | Winn, Jamie Renee | Former resident | $0.00 | $2,007.00 | $2,007.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18 - 1803 | Pennywell, Jakierra J | Former resident | $181.28 | $424.78 | $243.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18 - 1804 | Taylor, Charquisha E | Former resident | $0.00 | $1,322.00 | $1,322.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18 - 1804 | Taylor, Charquisha | Former resident | $0.00 | $2,801.00 | $2,801.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18 - 1804 | Palmer #3, Richard | Former resident | $0.00 | $2,861.34 | $2,861.34 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19 - 1901 | Brown, Mary | Former resident | $0.00 | $3,529.00 | $3,529.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19 - 1901 | Palmer #4, Ricahard | Former resident | $0.00 | $1,836.34 | $1,836.34 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19 - 1901 | Osborne, Charleszetta | Former resident | $182.25 | $920.00 | $737.75 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19 - 1901 | Grace, Tina | Former resident | $0.00 | $2,238.00 | $1,392.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19 - 1902 | Stewart, Billy Ray | Former resident | $0.00 | $559.00 | $559.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19 - 1902 | Levy, Alexandria Sabrina | Former resident | $0.00 | $379.00 | $379.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19 - 1902 | Jones, Jonetria S | Former resident | $0.00 | $398.00 | $398.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19 - 1902 | Abraham, Claude Douglas | Former resident | $0.00 | $2,083.50 | $2,083.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19 - 1902 | Hall, Kalaesha B | Former resident | $0.00 | $1,979.00 | $1,979.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19 - 1902 | Jefferson, Dainh D | Current resident | $268.00 | $343.00 | $58.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19 - 1903 | Rush, Marester Nanzique | Former resident | $0.00 | $1,510.13 | $1,510.13 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19 - 1903 | Brown, LaTrice Monique | Former resident | $0.00 | $581.00 | $581.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19 - 1903 | Palmer #5, Richard | Former resident | $0.00 | $1,586.34 | $1,586.34 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19 - 1903 | Edmond, Mary L | Current resident | $734.00 | $775.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19 - 1904 | Smith, Virginia | Former resident | $0.00 | $2.00 | $2.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 201 | Hill, Angela | Former resident | $330.00 | $644.00 | $314.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 201 | Priest, Gloria Jean | Current resident | $38.00 | $90.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 203 | Mason, Melvin | Former resident | $0.00 | $508.00 | $508.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 203 | *Montgomery, Veronica Leann | Former resident | $333.00 | $1,744.00 | $1,411.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 203 | Richardson, Reshiya K | Former resident | $0.00 | $4,234.50 | $4,234.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 203 | Smith, Shymiracle R | Former resident | $0.00 | $1,921.00 | $1,921.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 203 | Harvey, Joekedra Virginia | Former resident | $0.00 | $2,876.00 | $2,876.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 203 | Hilliard, Wilbert W | Current resident | $0.00 | $644.24 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 204 | Butler, Keyonia | Former resident | $0.00 | $1,679.00 | $1,679.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 204 | Mitchell, Tevshavion Xuvette | Former resident | $0.00 | $1,027.00 | $1,027.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 204 | Toliver, Kenyotta Leshuntae | Former resident | $0.00 | $501.00 | $501.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20 - 2001 | Smith, Stanecia Louise | Former resident | $0.00 | $604.00 | $604.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20 - 2001 | Williams, Londell | Former resident | $0.00 | $1,711.00 | $1,711.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20 - 2002 | Crutchfield, Tabitha | Former resident | $0.00 | $959.00 | $959.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20 - 2002 | Pouncy, Breonka Tashay | Former resident | $0.00 | $32.00 | $32.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20 - 2002 | Williams, Kashanna T | Former resident | $0.00 | $1,850.00 | $1,850.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20 - 2002 | Green, Malik C | Former resident | $0.00 | $1,319.00 | $1,319.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20 - 2003 | Harris, SelenaMarcell | Former resident | $0.00 | $677.00 | $677.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20 - 2003 | McCarthy, Will | Former resident | $924.00 | $1,602.00 | $678.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20 - 2004 | Williams, Ruthie | Former resident | $0.00 | $883.00 | $883.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20 - 2004 | Lewis, Joshua Lafairious | Former resident | $0.00 | $2,160.00 | $2,160.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20 - 2004 | VA, Palmer Richard | Former resident | $0.00 | $2,086.34 | $2,086.34 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20 - 2004 | Henderson, Tequila K | Former resident | $0.00 | $3,214.00 | $3,214.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 301 | Washington, Darnell | Former resident | $0.00 | $819.00 | $819.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 301 | Hughes, Latasha D | Former resident | $0.00 | $2,360.00 | $2,360.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 301 | Foster, Abbie | Current resident | $0.00 | $23.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 302 | Collins, James | Former resident | $0.00 | $312.00 | $312.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 302 | Ashley, Angela | Former resident | $0.00 | $1,736.00 | $1,736.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 302 | Ashley, Laterrell Vontrel | Former resident | $0.00 | $3,472.00 | $3,472.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 302 | Holden, Tasha N | Former resident | $0.00 | $3,599.00 | $3,599.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 302 | Blakes, Jasmine D | Former resident | $0.00 | $402.00 | $402.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 302 | Savannah, Alice Faye | Current resident | $0.00 | $816.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 303 | Robinson, Jamie Lee | Former resident | $0.00 | $6,040.00 | $6,040.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 303 | *Palmer, Richard VA | Former resident | $0.00 | $2,795.30 | $2,795.30 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 303 | Rogers, Latisha S | Former resident | $0.00 | $1,590.00 | $1,590.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 304 | Ary, Johnetta | Former resident | $0.00 | $91.00 | $91.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 304 | Johnson, Cleola Glover | Former resident | $0.00 | $1,045.00 | $1,045.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 304 | Mathews, Destini J | Former resident | $0.00 | $222.00 | $222.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 304 | Jefferson, Djuna c. | Former resident | $0.00 | $2,502.00 | $2,502.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 401 | Taylor, Adrianne | Former resident | $0.00 | $177.00 | $177.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 401 | Hudson, Diamond Jyereil | Former resident | $0.00 | $246.00 | $246.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 402 | Powel, Gerame Dwayne | Former resident | $0.00 | $798.00 | $798.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 402 | Moore, Tearrica Marshay | Former resident | $0.00 | $598.00 | $598.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 402 | Miller, Jhanea eugenia | Former resident | $1,501.00 | $4,976.38 | $3,475.38 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 402 | Henry, Latrennzora D | Former resident | $0.00 | $2,077.00 | $2,077.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 402 | Alford, ShaRaven Lashawn | Current resident | $0.00 | $5.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 403 | Johnson, Kierra | Former resident | $0.00 | $1,210.00 | $1,210.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 403 | Wilson, Shantasha C | Current resident | $0.00 | $512.12 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 404 | Jones, Donecia | Former resident | $0.00 | $868.00 | $868.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 404 | Jackson, T'andre Eugene | Former resident | $0.00 | $89.00 | $89.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 404 | Brown, Michael Wynn | Former resident | $0.00 | $10.00 | $10.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 404 | Taylor, Shequette Shunta | Former resident | $0.00 | $1,127.00 | $1,127.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 404 | Thomas, Jayonna Kiana | Former resident | $0.00 | $201.79 | $201.79 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 404 | Vickers, LevBurton Dewayne | Former resident | $69.00 | $279.00 | $210.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 405 | Colbert, Linda Marie | Current resident | $0.00 | $536.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 406 | Booker, Rose | Former resident | $0.00 | $16.00 | $16.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 406 | Rush, Aurora I | Former resident | $0.00 | $93.00 | $93.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 406 | Caldwell, Malina Marie | Former resident | $0.00 | $777.00 | $777.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 406 | Collins, Natalie C | Current resident | $0.00 | $72.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 407 | White, Ronald J | Former resident | $0.00 | $1,530.00 | $1,530.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 407 | Hobbs, Elexis Orbreanna | Former resident | $0.00 | $2,024.00 | $749.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 408 | Edwards, Buford | Former resident | $0.00 | $718.00 | $718.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 408 | James, Jennie | Former resident | $0.00 | $127.00 | $127.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 408 | Battle, Shaun J | Former resident | $0.00 | $44.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 501 | Tilman, Lindale | Former resident | $104.00 | $425.00 | $321.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 502 | Driver, Jenita Vernay | Current resident | $12.00 | $519.61 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 503 | Mitchell, Darien Wayne | Former resident | $0.00 | $1,189.00 | $1,189.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 503 | Simmons, Diquan rakeem | Former resident | $0.00 | $2,432.00 | $2,432.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 503 | Hampton, CeKeydrick J | Former resident | $0.00 | $1,367.40 | $1,367.40 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 504 | Jackson, Queen | Current resident | $65.00 | $179.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 506 | Haynes, Derrick | Current resident | $30.00 | $930.00 | $-30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 507 | Henderson, Davilon A | Former resident | $0.00 | $2,135.31 | $712.31 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 601 | Chatman, Destani Dazanai | Former resident | $0.00 | $1,903.11 | $1,903.11 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 602 | Kincade, Ebony S | Current resident | $85.00 | $1,100.00 | $-85.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 603 | Fuggent, Queuna Monia | Former resident | $0.00 | $2,004.00 | $2,004.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 603 | Jones, Victoria A | Current resident | $303.00 | $326.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 604 | Hampton, Padrenia | Former resident | $0.00 | $1,417.14 | $1,417.14 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 604 | Johnson, Renekia Renese | Former resident | $0.00 | $193.00 | $193.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 604 | Wilson, Brinesha Shunta | Former resident | $0.00 | $1,816.00 | $1,816.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 604 | Garner, Tasia Donatrece | Former resident | $0.00 | $1,804.00 | $1,804.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 604 | Dorsey, Chad | Former resident | $0.00 | $2,430.00 | $2,430.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 604 | Anderson, Tarece S | Former resident | $0.00 | $59.00 | $59.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 604 | Thomas, Adriana L | Current resident | $0.00 | $1,064.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 701 | Anozie, Grace | Former resident | $0.00 | $1,594.00 | $1,594.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 701 | Pouncy, Kuderrick D | Former resident | $0.00 | $2,337.00 | $2,337.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 702 | Braxton, Theresa | Former resident | $100.00 | $110.00 | $10.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 702 | Hobley, Saterica D | Former resident | $0.00 | $328.00 | $328.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 702 | Danielson, Amanda Nicole | Current resident | $0.00 | $10.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 703 | Jones, Shalisa | Former resident | $89.00 | $579.00 | $490.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 703 | Williams, Carshenna Yvette | Former resident | $0.00 | $4,339.00 | $4,339.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 703 | Copp, Jolisa L | Former resident | $0.00 | $1,140.98 | $1,140.98 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 704 | Evans, Ninya Sacardro | Former resident | $0.00 | $644.00 | $644.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 704 | Crawford, Joycelin Aileen | Former resident | $0.00 | $1,581.00 | $1,581.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 704 | Jones, Breoshore Ynesha Berna | Former resident | $0.00 | $1,422.00 | $1,422.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 704 | Anderson, Christine L | Former resident | $0.00 | $1,692.00 | $1,692.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 704 | Little, Marvette R | Current resident | $0.00 | $10.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 801 | Lewis, Carlita Denise | Former resident | $0.00 | $386.50 | $386.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 801 | Scott, Lisa Rene | Former resident | $0.00 | $763.00 | $763.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 801 | Willie, Freddie Christina | Former resident | $0.00 | $761.00 | $761.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 801 | Stewart, Shavetta Trenise | Former resident | $519.00 | $2,442.59 | $1,923.59 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 801 | Lane, Porsha Ranautica | Former resident | $209.00 | $1,346.00 | $1,137.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 801 | Goines, Krystal | Current resident | $0.00 | $744.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 802 | Mandosia, Alexis | Former resident | $0.00 | $924.00 | $924.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 802 | Reece, Janice Renee | Former resident | $0.00 | $630.00 | $630.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 802 | *Oliver, Rose Ann | Former resident | $0.00 | $3,262.26 | $3,262.26 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 802 | Morris, RobinR | Current resident | $0.00 | $790.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 901 | Ball, Leaman | Former resident | $0.00 | $269.00 | $269.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 901 | Dale, April Denise | Former resident | $0.00 | $3,262.00 | $3,262.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 901 | Lattin, Tiesse | Former resident | $0.00 | $1,309.00 | $1,309.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 901 | *Bolden, Moneak L | Former resident | $0.00 | $3,300.00 | $3,300.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 901 | Davis, Desorae Dashaun | Former resident | $0.00 | $2,151.00 | $2,151.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 901 | Miller, Veleka Fleshette | Former resident | $336.00 | $1,214.00 | $878.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 901 | Walker, Huey P | Current resident | $0.00 | $27.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 902 | Willis, Antavious Chanteria | Former resident | $0.00 | $772.00 | $772.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 902 | Barnes, Shandreia Nichole | Former resident | $0.00 | $621.00 | $621.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 902 | Gardner, Lakesha Ann | Former resident | $0.00 | $3,441.00 | $3,441.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - 103 | Zackery, Jasmine | Former resident | $538.00 | $0.00 | $-538.00 | [ ] Confirm paid | — |
| 1 - 103 | Hines, Shunya Remejea | Current resident | $715.00 | $226.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 104 | Vinson, LeslieNicole | Former resident | $364.00 | $0.00 | $-364.00 | [ ] Confirm paid | — |
| 1 - 104 | Alford, Kashunda L | Former resident | $444.00 | $0.00 | $-444.00 | [ ] Confirm paid | — |
| 10 - 1001 | Bullock, Jessica Sharlene | Former resident | $490.00 | $0.00 | $-490.00 | [ ] Confirm paid | — |
| 10 - 1003 | Gray, Jacueline Denise | Former applicant | $30.00 | $0.00 | $-30.00 | [ ] Confirm paid | — |
| 10 - 1003 | Williams, Tierra M | Former resident | $578.00 | $107.00 | $-471.00 | [ ] Confirm paid | — |
| 11 - 1101 | White, Jamie Lynn | Former applicant | $20.00 | $0.00 | $-20.00 | [ ] Confirm paid | — |
| 11 - 1101 | White, Samantha M | Current resident | $1,491.00 | $243.00 | $-1,290.00 | [ ] Confirm paid | — |
| 11 - 1102 | Johnson, Linda K | Former resident | $3,684.00 | $1,096.00 | $-2,588.00 | [ ] Confirm paid | — |
| 11 - 1103 | Musgrove, Kenyatta L | Former resident | $1,052.00 | $828.00 | $-224.00 | [ ] Confirm paid | — |
| 12 - 1201 | Milton, LeandreLamour | Current resident | $56.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 12 - 1202 | Jones, Cordelia E | Former resident | $3,190.00 | $998.00 | $-2,192.00 | [ ] Confirm paid | — |
| 12 - 1203 | Chism, PatriciaAnn | Former resident | $899.00 | $598.00 | $-301.00 | [ ] Confirm paid | — |
| 12 - 1203 | Claville, Monique T | Former resident | $3,705.00 | $0.00 | $-3,705.00 | [ ] Confirm paid | — |
| 12 - 1203 | McDonald, Erica L | Former resident | $566.00 | $0.00 | $-566.00 | [ ] Confirm paid | — |
| 13 - 1301 | Stewart, Kadisha R | Current resident | $441.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 13 - 1302 | Grant, Kristy | Former resident | $268.00 | $0.00 | $-268.00 | [ ] Confirm paid | — |
| 14 - 1401 | Reed, DeandraLashawn | Former resident | $50.00 | $0.00 | $-50.00 | [ ] Confirm paid | — |
| 14 - 1404 | Shaw, Oshameria Shynesia | Former resident | $430.00 | $49.00 | $-381.00 | [ ] Confirm paid | — |
| 15 - 1501 | Allen, Braie Breyton | Former resident | $273.00 | $0.00 | $-273.00 | [ ] Confirm paid | — |
| 15 - 1501 | Henry, Jessica N | Former resident | $4,317.00 | $12.00 | $-4,305.00 | [ ] Confirm paid | — |
| 15 - 1502 | Prude, Dominique | Former resident | $1,053.00 | $0.00 | $-1,053.00 | [ ] Confirm paid | — |
| 15 - 1502 | Barlow, Jennifer L | Current resident | $2,010.00 | $0.00 | $-237.00 | [ ] Confirm paid | — |
| 15 - 1504 | Jackson, Pauline | Former resident | $47.00 | $0.00 | $-47.00 | [ ] Confirm paid | — |
| 15 - 1504 | Gardner, Shakari LaQuincey | Current resident | $64.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 16 - 1603 | Morris, Tatyana L | Former resident | $9,566.00 | $816.00 | $-7,028.00 | [ ] Confirm paid | — |
| 16 - 1603 | Stovall, Pamela G | Former applicant | $18.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 16 - 1604 | Williams, Larkelia | Former resident | $107.00 | $0.00 | $-107.00 | [ ] Confirm paid | — |
| 16 - 1604 | Bass, David | Former resident | $736.00 | $0.00 | $-736.00 | [ ] Confirm paid | — |
| 16 - 1604 | Thompson, Casandra L | Former resident | $1,728.00 | $26.30 | $-1,701.70 | [ ] Confirm paid | — |
| 17 - 1701 | Johnson, Joshuna Ladestiny | Former resident | $678.00 | $75.00 | $-603.00 | [ ] Confirm paid | — |
| 17 - 1704 | Thomas, Stephanie Michelle | Former resident | $138.00 | $52.00 | $-86.00 | [ ] Confirm paid | — |
| 18 - 1801 | Snell, Simone Lashoya | Former resident | $3,145.00 | $0.00 | $-3,145.00 | [ ] Confirm paid | — |
| 18 - 1801 | Clark, Kadija Tauntrese | Current resident | $159.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 18 - 1802 | Norris, Jakia Dominique | Former resident | $374.00 | $119.68 | $-254.32 | [ ] Confirm paid | — |
| 18 - 1803 | Robinson, Nataha D | Former applicant | $200.00 | $0.00 | $-200.00 | [ ] Confirm paid | — |
| 18 - 1803 | Jackson, Latasha L | Current resident | $140.00 | $0.00 | $-92.00 | [ ] Confirm paid | — |
| 18 - 1804 | Lister, Pamela | Former resident | $168.00 | $0.00 | $-168.00 | [ ] Confirm paid | — |
| 18 - 1804 | Lee, Angel | Former resident | $333.00 | $72.00 | $-261.00 | [ ] Confirm paid | — |
| 18 - 1804 | Mitchell, Tyrianna T | Former resident | $1.00 | $0.00 | $-1.00 | [ ] Confirm paid | — |
| 18 - 1804 | Edwards, Roger L | Current resident | $74.59 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 19 - 1902 | Stout, Sherise | Former resident | $1,236.00 | $774.00 | $-462.00 | [ ] Confirm paid | — |
| 19 - 1904 | Grant, Gloria Williams | Current resident | $209.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 204 | Walker, Angela Denise | Current resident | $338.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 20 - 2001 | Moore, Geraldine A | Current resident | $589.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 20 - 2002 | Buffin, Alexandra A | Current resident | $42.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 20 - 2003 | Mazier, Erica M | Former resident | $419.00 | $0.00 | $-419.00 | [ ] Confirm paid | — |
| 20 - 2003 | Moore, Chakawanna S | Current resident | $127.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 20 - 2004 | Merritt, Douglas | Former resident | $757.00 | $0.00 | $-217.00 | [ ] Confirm paid | — |
| 3 - 301 | Stephens, Dalijha Nicole | Former resident | $75.00 | $0.00 | $-75.00 | [ ] Confirm paid | — |
| 3 - 301 | Foster, Abbie | Former applicant | $30.00 | $0.00 | $-30.00 | [ ] Confirm paid | — |
| 3 - 304 | McDaniel, Beverly H | Current resident | $85.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - 401 | Linear, Laura W | Current resident | $150.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - 403 | Mitchell, Merlin | Former resident | $197.00 | $0.00 | $-197.00 | [ ] Confirm paid | — |
| 4 - 403 | Williams, John P | Former resident | $40.00 | $0.00 | $-40.00 | [ ] Confirm paid | — |
| 4 - 407 | Dale, Roderick | Former resident | $297.00 | $136.00 | $-161.00 | [ ] Confirm paid | — |
| 4 - 407 | Draper, Sarah Louise | Current resident | $42.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - 408 | Campbell, Vernon | Former resident | $1,386.00 | $1,186.00 | $-200.00 | [ ] Confirm paid | — |
| 5 - 502 | Minniefield, Ola | Former resident | $2,314.00 | $182.00 | $-2,132.00 | [ ] Confirm paid | — |
| 5 - 503 | Snell, Andrew Dewayne | Former applicant | $30.00 | $0.00 | $-30.00 | [ ] Confirm paid | — |
| 5 - 503 | Cathron, Twania Y | Current resident | $47.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 505 | Lane, Sakeythia Vershay | Current resident | $45.00 | $0.00 | $-9.00 | [ ] Confirm paid | — |
| 5 - 506 | Carranza, Frances M | Former resident | $1,914.00 | $224.00 | $-1,690.00 | [ ] Confirm paid | — |
| 5 - 507 | Haynes, Ida | Former resident | $540.00 | $0.00 | $-540.00 | [ ] Confirm paid | — |
| 5 - 507 | Boyd, Johnny C | Former applicant | $30.00 | $0.00 | $-30.00 | [ ] Confirm paid | — |
| 5 - 508 | Anderson, Farley | Current resident | $417.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 6 - 601 | Woodfolks, Mar'quez De'quincei | Former resident | $460.00 | $0.00 | $-460.00 | [ ] Confirm paid | — |
| 6 - 601 | Randle, Toni j | Current resident | $190.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 6 - 602 | Morris, Pamela | Former resident | $503.00 | $84.00 | $-419.00 | [ ] Confirm paid | — |
| 6 - 604 | Ardoin, Scherrazade | Former resident | $4,084.00 | $0.00 | $-4,084.00 | [ ] Confirm paid | — |
| 7 - 701 | Ratcliff, Miesha A | Former resident | $2,790.00 | $0.00 | $-2,790.00 | [ ] Confirm paid | — |
| 7 - 702 | Battle, Jessica Michelle | Former resident | $361.00 | $202.00 | $-159.00 | [ ] Confirm paid | — |
| 7 - 703 | Stricklin, Ebone Dante | Former resident | $2,132.00 | $61.00 | $-2,071.00 | [ ] Confirm paid | — |
| 7 - 703 | Johnson, Rolanda A | Current resident | $49.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 8 - 801 | Thomas, Shashawanda | Former resident | $588.00 | $0.00 | $-588.00 | [ ] Confirm paid | — |
| 8 - 802 | Birdsong, JeanitaLashae | Former resident | $941.00 | $0.00 | $-941.00 | [ ] Confirm paid | — |
| 8 - 802 | Cummings, Marilyn Ann | Former resident | $1,538.00 | $0.00 | $-1,538.00 | [ ] Confirm paid | — |
| 8 - 902 | Moody, Shaun | Former resident | $158.00 | $150.00 | $-8.00 | [ ] Confirm paid | — |
| 8 - 902 | Dismukes, Shannon I | Current resident | $149.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| NONE | Online application fees | Misc. Income | $4,606.00 | $252.00 | $-3,418.00 | [ ] Confirm paid | — |
| WAIT | Mack, Melvin C | Former applicant | $430.00 | $0.00 | $-430.00 | [ ] Confirm paid | — |
| WAIT | Williams, Diamond D | Former applicant | $30.00 | $0.00 | $-30.00 | [ ] Confirm paid | — |

## Resident Balance Follow-Up — Paid / Zero Balance

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 10 - 1004 | Haley, Sammie | Former resident | $367.00 | $367.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property's supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*