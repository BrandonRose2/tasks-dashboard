# Macedonia Gardens — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 2432257**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/04/2026 |
| Property manager | Erika Scales — macedonia@apartmentcorp.com — (850) 899-2270 |
| Regional manager | JR Rolon — jrrolon@apartmentcorp.com — (941) 716-1665; Leslie Rolon — leslie@apartmentcorp.com — (504) 247-3813 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Delinquency spreadsheet | `2432257_Macedonia Gardens_Delinquent - Excel_58.xls` |
| Ledger accounts for review | 419 resident accounts |
| Residents with amount owed | 279 accounts; $254,987.31 |
| Prepaid / credit accounts | 97 accounts; $-40,148.63 |
| Availability entries | 0 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit's reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| — | — | No unit-status entries in the selected source export | [ ] Verified | __________________ |

## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| A-101 | Brown, Latasha | Former resident | $0.00 | $173.96 | $173.96 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A-101 | Figueroa, Nilsa L | Former resident | $0.00 | $429.00 | $429.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A-103 | Spears, Crystal | Former resident | $0.00 | $109.00 | $109.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A-103 | Williams, Iesha N | Former resident | $0.00 | $8,031.00 | $8,031.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A-103 | Laracuente-Diaz, Darlene | Current resident | $243.00 | $579.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A-104 | Majors, Mckinley Noel | Former resident | $1.00 | $3,664.00 | $3,663.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A-104 | Raively, Tina M | Former resident | $0.00 | $1,426.00 | $1,426.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A-201 | TRAVIS, LISA | Former resident | $0.00 | $107.98 | $107.98 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A-201 | Honore, Dymeshia | Former resident | $0.00 | $56.00 | $56.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A-202 | DYKE, ASHLEY | Former resident | $0.00 | $1,450.50 | $1,450.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A-202 | Runnion, Samantha | Former resident | $0.00 | $888.84 | $888.84 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A-202 | Melendez, Ruth | Former resident | $0.00 | $752.00 | $752.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A-202 | Booker, Lilliane Joneice | Former resident | $888.00 | $6,489.00 | $5,601.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A-203 | Crawford, Amber | Former resident | $0.00 | $225.37 | $225.37 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A-203 | Curry, Monica L | Former resident | $359.00 | $5,600.00 | $5,241.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A-203 | Mouton, Andrea Tyrez | Former resident | $0.00 | $1,006.00 | $1,006.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A-204 | Salih, Osama K | Former resident | $0.00 | $188.00 | $188.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A-204 | Tyson, Makele | Former resident | $0.00 | $4.95 | $4.95 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A-204 | Nunez, Robert R | Former resident | $0.00 | $332.83 | $332.83 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B-102 | Wagner, Brionna | Former resident | $0.00 | $115.08 | $115.08 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B-102 | Huyghue, Timesha J | Former resident | $0.00 | $1,928.00 | $1,928.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B-103 | Torrales, Katia Y | Former resident | $0.00 | $6,893.00 | $6,893.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B-103 | Taylor, Precious Tykeia | Former resident | $0.00 | $47.00 | $47.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B-104 | Caceres, Barbara M | Former resident | $0.00 | $1,201.26 | $1,201.26 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B-201 | GOLSON, LESLIE | Former resident | $0.00 | $29.00 | $29.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B-201 | Mendez Alvarado, Manuelli M | Former resident | $0.00 | $108.00 | $108.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B-202 | Ward, Leigha | Former resident | $0.00 | $276.14 | $276.14 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B-202 | Moses, Katelan Nicole | Former resident | $0.00 | $8,996.00 | $8,996.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B-202 | Robinson, Lilyann C | Current resident | $0.00 | $5.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B-203 | Scott, Florence D | Former resident | $1.00 | $1,844.95 | $1,843.95 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B-203 | Outlaw, Dana | Former resident | $0.00 | $389.92 | $389.92 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B-203 | Guerra-Garcia, Minellis M | Former resident | $294.00 | $3,049.00 | $2,755.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B-204 | KING, TINA | Former resident | $21,684.00 | $23,120.14 | $1,436.14 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B-204 | Alonso, Osiris C | Former resident | $0.00 | $144.25 | $144.25 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B-204 | Speights, Tiffany | Former resident | $0.00 | $77.00 | $77.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B-204 | Givens, Seirieata | Former resident | $101.00 | $996.00 | $895.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B-204 | Lornes, Tracy L | Former resident | $0.00 | $1,070.00 | $1,070.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B-204 | Khudiaieva, Anastasiia | Former resident | $0.00 | $53.00 | $53.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C-101 | MITCHELL, ARLITHIA | Former resident | $0.00 | $439.34 | $439.34 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C-101 | Lebar, Christine N | Former resident | $0.00 | $139.94 | $139.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C-101 | Quintero Gonzalez, Yesenia | Former resident | $0.00 | $168.00 | $168.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C-103 | WALKER, IDELLA | Former resident | $0.06 | $503.24 | $503.18 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C-104 | GREER, CRYSTAL M | Former resident | $0.00 | $861.67 | $861.67 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C-104 | Lambright, Gabriella | Former resident | $0.00 | $815.00 | $815.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C-104 | Moreau Pereira, Yeralis | Former resident | $0.00 | $1,201.00 | $1,201.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C-104 | Rodriguez Asencio, Glorimar | Current resident | $1,008.00 | $1,476.00 | $119.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C-201 | LEE, BRENDA A | Former resident | $0.00 | $149.05 | $149.05 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C-201 | Hammond, Altevious B | Former resident | $0.00 | $400.00 | $400.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C-201 | Wade, Tracy Monique | Former resident | $0.00 | $3,060.99 | $3,060.99 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C-202 | GALLOWAY, VICTORIA D | Former resident | $245.00 | $685.00 | $440.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C-202 | Robinson, Shanequa B | Former resident | $954.00 | $9,180.00 | $8,226.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C-202 | Palmer, Lenona D | Former resident | $0.00 | $1,458.00 | $1,458.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C-203 | Fosmire, Kayla | Former resident | $0.00 | $365.08 | $365.08 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C-204 | JACKSON, COURTNEY V | Former resident | $0.00 | $11.52 | $11.52 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D-101 | FERNANDEZ, ANGELA | Former resident | $0.91 | $95.00 | $94.09 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D-101 | Furey, Kendall E | Former resident | $0.00 | $1,137.00 | $1,137.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D-102 | Matela, Jacqueline N | Former resident | $0.00 | $2,863.00 | $2,863.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D-102 | Mckinnie, Sherrie Lynn | Former resident | $0.00 | $285.00 | $285.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D-103 | Babcock, Jami-Leigh | Former resident | $7.00 | $631.00 | $624.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D-103 | CRESPO, HECTOR | Former resident | $0.00 | $6.00 | $6.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D-103 | Printz, Tiara | Former resident | $0.00 | $412.00 | $412.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D-103 | Baez Rivera, Sasha I | Former resident | $0.00 | $52.00 | $52.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D-104 | KING, SUSIE D | Former resident | $359.00 | $4,844.00 | $4,485.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D-201 | Barnes, Kricket | Former resident | $1.00 | $62.00 | $61.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D-201 | Santiago, Abram | Former resident | $0.00 | $8,233.00 | $8,233.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D-201 | Lara, Victoria M | Former resident | $50.00 | $125.00 | $75.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D-201 | Barton, Briauna Marie | Former resident | $0.00 | $3,991.00 | $3,991.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D-202 | Baker, Regina M | Former resident | $0.00 | $98.93 | $98.93 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D-202 | Armstead, Kamilah | Former resident | $0.00 | $504.94 | $504.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D-202 | Lopez, Elizabeth | Former resident | $0.00 | $74.00 | $74.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D-202 | Serrano, Karla | Former resident | $89.00 | $118.00 | $29.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D-202 | Hinson, Michelle N | Former resident | $0.00 | $176.00 | $176.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D-203 | Crews, Ericka D | Former resident | $0.00 | $96.54 | $96.54 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D-203 | Johnson, Kimberly | Former resident | $0.00 | $1,578.00 | $1,578.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D-203 | Stuck, Chassidy M | Former resident | $0.00 | $796.00 | $796.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D-204 | GARCIA CARABALLO, MARIA V | Former resident | $0.00 | $1.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D-204 | Cavazos, Kimberly | Former resident | $0.00 | $636.00 | $636.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D-204 | De Jesus, Mileyn Carillo | Current resident | $536.00 | $1,018.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E-101 | GARCIA-MANCERA, TINA | Former resident | $1.00 | $243.72 | $242.72 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E-101 | Neal, BrittanyNicole | Former resident | $0.00 | $37.00 | $37.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E-102 | Ramirez Tovar, Carmen | Current resident | $78.00 | $1,403.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E-103 | Dukes, Sheika | Former resident | $1.00 | $1,261.32 | $1,260.32 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E-103 | Smal, Nikkia | Former resident | $0.00 | $167.00 | $167.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E-201 | Rivera, Freddy A | Former resident | $0.00 | $372.76 | $372.76 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E-201 | Sheehan, Lyndsey L | Former resident | $0.00 | $1,040.11 | $1,040.11 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E-202 | MERCADO, MARGARITA | Former resident | $0.00 | $196.01 | $196.01 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E-202 | Quellet, Kayla | Former resident | $785.00 | $1,137.00 | $352.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E-202 | Roberts, Latavia Jasemine | Former resident | $0.00 | $851.00 | $851.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E-203 | Roman - Ramarez, Julia E | Former resident | $0.00 | $141.00 | $141.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E-203 | PORTER, PETRINA N | Former resident | $581.00 | $933.00 | $352.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E-204 | VIOLA PHILLIPS | Former resident | $0.00 | $1,002.81 | $1,002.81 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E-204 | Laureano, Wilmarie | Former resident | $0.00 | $50.96 | $50.96 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E-204 | Funderburk, Mary E | Former resident | $1.00 | $625.00 | $624.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E-204 | Rasnic, Frank E | Former resident | $0.00 | $1.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E-204 | Carrasquillo, Lourdes Enid | Former resident | $750.00 | $1,102.00 | $352.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F-101 | Shelmon, Blanche V | Former resident | $0.00 | $27.00 | $27.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F-101 | Calderon, Luis | Former resident | $0.00 | $5.00 | $5.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F-101 | Gray, Irma | Former resident | $0.00 | $483.01 | $483.01 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F-101 | Hernandez, Felicita | Former resident | $0.00 | $16.95 | $16.95 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F-101 | Watson, Latasha Y | Former resident | $777.00 | $1,129.00 | $352.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F-102 | Buckley, Tina M | Former resident | $11.00 | $1,903.70 | $1,892.70 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F-102 | Young, Tameka Danyale | Former resident | $0.00 | $2.00 | $2.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F-102 | Rivera Alamo, Ciara Lee | Former resident | $129.00 | $339.00 | $210.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F-104 | Jones, Sherenia N | Former resident | $759.00 | $1,111.00 | $352.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F-104 | Greene, Stacey R | Current resident | $0.00 | $4.41 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F-201 | HANKERSON, RENADA | Former resident | $0.00 | $421.10 | $421.10 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F-201 | Frazier, Ladacia | Former resident | $0.00 | $996.94 | $996.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F-202 | HERNANDEZ, BECKY | Former resident | $0.00 | $296.96 | $296.96 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F-202 | Colon Carlo, Wilma | Former resident | $621.00 | $973.00 | $352.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F-202 | Espinoza, Angelia D | Former resident | $0.00 | $8,740.84 | $8,740.84 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F-202 | Bonner, Trinity | Current resident | $0.00 | $33.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F-203 | Peace, Devonna Marquise | Former resident | $785.00 | $1,137.00 | $352.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F-203 | Heald, Leslie N | Former resident | $0.00 | $76.00 | $76.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F-204 | Fortier, Eleanor M | Former resident | $0.00 | $1,257.74 | $1,257.74 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F-204 | Young, Linda | Former resident | $0.00 | $2.00 | $2.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F-204 | Adorno Machuca, Kathya M | Former resident | $774.00 | $1,126.00 | $352.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F-204 | Perez, Stefani | Current resident | $0.00 | $1.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F-204 | Vanravensway, Raven | Former resident | $0.00 | $19.00 | $19.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G-101 | SOLIS, TONYA | Former resident | $0.00 | $559.71 | $559.71 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G-101 | Depriest, Mary A | Former resident | $0.00 | $1.04 | $1.04 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G-101 | Graham, Tanja Denise | Former resident | $780.00 | $1,132.00 | $352.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G-102 | Storms, Lelia | Former resident | $0.00 | $2,114.00 | $2,114.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G-102 | Dixon, LaQuista S | Former resident | $0.00 | $786.95 | $786.95 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G-102 | Matos Laracuente, Denisse | Former resident | $0.00 | $249.00 | $249.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G-102 | Carter, Angela Lizzett | Former resident | $777.00 | $1,129.00 | $352.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G-102 | Grice, Amanda R | Former resident | $0.00 | $275.00 | $275.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G-102 | Bennett, Tamara Latin | Current resident | $1,802.00 | $2,778.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G-103 | Rivas, Marjorie | Former resident | $750.00 | $1,102.00 | $352.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G-104 | Perez, Rosana C. | Former resident | $0.00 | $71.00 | $71.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G-104 | Caraballo Lopez, Elsabel | Former resident | $0.00 | $80.91 | $80.91 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G-104 | Matias Cintron, Graciela Marie | Former resident | $51.00 | $403.00 | $352.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G-104 | Scales, Anthony Malek | Former resident | $0.00 | $14.00 | $14.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G-104 | Maldonado Garcia, Marieliz | Former resident | $0.00 | $18.00 | $18.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G-104 | Porter, Caitlin Alisz | Current resident | $164.00 | $165.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G-201 | Jones, Bethel R | Former resident | $0.00 | $1,820.56 | $1,820.56 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G-201 | Gomez, Nahomy | Former resident | $0.00 | $97.00 | $97.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G-201 | Crespo, Joan M | Former resident | $0.00 | $13.00 | $13.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G-201 | Morales Rodriguez, Mayra Socorro | Former resident | $0.00 | $8,859.00 | $8,859.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G-201 | Maestri, Mindy L | Former resident | $0.00 | $1,453.00 | $1,453.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G-201 | Ragadio, Erniece Josierene | Current resident | $177.00 | $274.00 | $-177.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G-202 | Johnson, Tiffany L | Former resident | $0.00 | $202.76 | $202.76 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G-202 | Baker, Candace A | Former resident | $209.00 | $216.11 | $7.11 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G-202 | McNair, Stephanie | Former resident | $1.00 | $70.00 | $69.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G-202 | jONES, Audrey | Former resident | $0.00 | $1,588.02 | $1,588.02 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G-202 | Daniels, Chasity Renae | Former resident | $0.00 | $1,066.11 | $1,066.11 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G-202 | Waugh Davis, Amanda Lynn | Former resident | $658.00 | $1,010.00 | $352.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G-203 | Hollinger, Wanda J | Former resident | $0.00 | $10,099.47 | $10,099.47 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G-203 | Bieser, Whitney | Former resident | $0.00 | $482.97 | $482.97 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G-203 | Gonzalez, Jorge | Former resident | $0.00 | $7.99 | $7.99 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G-203 | Robbins, Ruth M | Former resident | $0.00 | $1.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G-204 | CIRILO CRUZ, MANUEL | Former resident | $0.00 | $202.51 | $202.51 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G-204 | Jackson, Katoya | Former resident | $47.85 | $76.50 | $28.65 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G-204 | Abas, Karen | Former resident | $0.00 | $43.61 | $43.61 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G-204 | Moran, Luis F | Former resident | $750.00 | $1,102.00 | $352.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H-101 | clarke, Katrina | Former resident | $0.00 | $1.52 | $1.52 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H-101 | Garcia Torres, Swanette E | Former resident | $1.00 | $250.00 | $249.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H-101 | Corley, Megan Nicole | Former resident | $741.00 | $1,093.00 | $352.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H-102 | Johnson, Desiree A | Former resident | $1.00 | $22.00 | $21.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H-103 | Green, Melissa D | Former resident | $0.00 | $74.00 | $74.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H-103 | Thomas, Anjonai Breanna | Current resident | $1.00 | $11.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H-104 | Sheffield, Amanda | Former resident | $0.00 | $1,512.00 | $1,512.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H-201 | Mullis, Crystal A | Former resident | $1.00 | $954.92 | $953.92 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H-201 | Bloxson, Tysheba | Former resident | $0.00 | $7,368.00 | $7,368.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H-201 | McCall, Makasia A | Current resident | $0.00 | $1.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H-202 | Peterson, Tonya | Former resident | $0.00 | $3,848.45 | $3,848.45 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H-202 | Perez, Rosana Charlene | Former resident | $759.00 | $1,111.00 | $352.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H-203 | RUSS, CASSANDRA | Former resident | $469.00 | $821.00 | $352.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H-204 | Gampfer, Angelica F | Former resident | $0.00 | $360.92 | $360.92 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H-204 | Santos, Maria D | Former resident | $0.00 | $1.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H-204 | Smith, Teresa Ann | Former resident | $540.00 | $892.00 | $352.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I-101 | Delgado, Janett | Former resident | $0.00 | $210.00 | $210.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I-101 | Santiago, Ervin | Former resident | $0.00 | $12.20 | $12.20 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I-101 | Boone, Manyara | Former resident | $0.00 | $8,031.00 | $8,031.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I-102 | PEREZ, YEIMELIZ | Former resident | $0.00 | $1,092.48 | $1,092.48 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I-102 | Lea-Scandrett, Kahla | Former resident | $0.00 | $51.00 | $51.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I-102 | Pabon, Wilma I | Former resident | $0.00 | $2,793.10 | $2,793.10 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I-103 | Page, Urania | Former resident | $0.00 | $1.07 | $1.07 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I-103 | Mcghee, Keisha | Former resident | $2,248.00 | $2,600.00 | $352.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I-103 | Gray, Sara N | Former resident | $0.00 | $518.00 | $518.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I-104 | GONZALEZ TRABAL, YARITZA | Former resident | $149.00 | $149.97 | $0.97 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I-104 | Johnson, Dionzia Sartez | Former resident | $300.00 | $335.00 | $35.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I-104 | King, Misty Marie | Former resident | $596.00 | $948.00 | $352.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I-202 | Morency, Molly A | Former resident | $785.00 | $1,137.00 | $352.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I-203 | GARCIA, MARIA | Former resident | $0.00 | $605.88 | $605.88 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I-203 | Fry, Amber N | Former resident | $1.00 | $317.97 | $316.97 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I-203 | Washington, Octavia D | Former resident | $0.00 | $22.00 | $22.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I-203 | Williams, Anyssa Nicole | Former resident | $0.00 | $4,099.00 | $4,099.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I-203 | Mills, Courtney B | Former resident | $0.00 | $27.00 | $27.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I-203 | Rivera Perez, Nachmarie | Former resident | $0.00 | $9.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I-204 | MEAD, JEANETTE F | Former resident | $0.00 | $153.98 | $153.98 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I-204 | Morgan, Danyeal | Former resident | $101.00 | $1,664.16 | $1,563.16 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I-204 | Roman, Desiree | Former resident | $0.00 | $132.66 | $132.66 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I-204 | Santiago Rivera, Jared J | Former resident | $1.00 | $63.00 | $62.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I-204 | Morales Olmo, Ileana | Former resident | $7.00 | $112.00 | $105.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I-204 | Richardson, Tanisha Charmaine | Former resident | $785.00 | $1,137.00 | $352.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I-204 | De Jesus-Perez, Lizmara | Former resident | $0.00 | $2,895.00 | $2,895.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I-204 | Cruz, Shakira | Current resident | $0.00 | $1.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J-101 | THOMAS, KIARA | Former resident | $0.00 | $5.00 | $5.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J-101 | Roberson, Chala L | Former resident | $2.00 | $304.98 | $302.98 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J-101 | Leskovac, Kristina Nicole | Former resident | $550.00 | $918.00 | $368.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J-101 | McDaniel, Dawn A | Former resident | $495.00 | $520.00 | $25.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J-101 | Brown, Herod G | Former resident | $5,922.00 | $9,791.00 | $3,869.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J-102 | RHOE, JANETTE | Former resident | $0.00 | $21.00 | $21.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J-102 | Thornton, Kayla D | Former resident | $0.00 | $202.97 | $202.97 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J-102 | Perez, Stefani | Former resident | $551.00 | $919.00 | $368.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J-103 | Bomia, Donna F | Former resident | $0.00 | $107.00 | $107.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J-103 | Joyner, Laura | Former resident | $0.00 | $216.67 | $216.67 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J-103 | Ramirez, Alba | Former resident | $0.00 | $55.89 | $55.89 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J-103 | Barnes, Bethene Miller | Former resident | $0.00 | $1,316.00 | $1,316.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J-103 | Stephenson, Kenneth J | Former resident | $3,340.00 | $6,270.00 | $2,930.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J-104 | Romero, Cassandra | Former resident | $0.00 | $2,323.08 | $2,323.08 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J-104 | Andrews, Valerie | Former resident | $0.00 | $0.98 | $0.98 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J-104 | Thomas, Anjonai Breanna | Former resident | $559.00 | $927.00 | $368.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J-201 | Hall, Mary | Former resident | $0.00 | $80.94 | $80.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J-201 | Crawford, Gabrielle Desaray | Former resident | $1,617.00 | $1,985.00 | $368.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J-202 | SNIDER, HEATHER | Former resident | $0.00 | $606.16 | $606.16 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J-202 | Adams, Latiqua Cheneal | Former resident | $0.00 | $666.59 | $666.59 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J-202 | Colon-Ramos, Carmen L | Former resident | $468.00 | $836.00 | $368.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J-202 | Garcia, Grasheliz Maldonado | Former resident | $0.00 | $423.00 | $423.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J-203 | HALE, CASSANDRA | Former resident | $0.00 | $1,191.00 | $1,191.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J-203 | Muniz-Gerena, Aixa | Former resident | $27.00 | $28.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J-203 | Gutierrez, Stephanie | Former resident | $0.00 | $23.93 | $23.93 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J-203 | Medina Couvertier, Velinda | Former resident | $182.00 | $550.00 | $368.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J-204 | Dorsey, Sandra L | Former resident | $382.00 | $750.00 | $368.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K-101 | WILSON, GERALDINE L | Former resident | $371.00 | $739.00 | $368.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K-101 | Perez Ricardo, Oscar | Former resident | $0.00 | $1,098.00 | $1,098.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K-102 | Causey, Precious | Former resident | $0.00 | $18.00 | $18.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K-103 | WILLIAMS, GENEATH | Former resident | $447.00 | $815.00 | $368.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K-201 | Young, Tameka D | Former resident | $0.00 | $59.07 | $59.07 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K-201 | Vaughan, Briana S | Former resident | $567.00 | $935.00 | $368.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K-202 | BANNISTER, DEZAREA | Former resident | $0.00 | $536.57 | $536.57 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K-202 | Bonner, Maretha | Former resident | $1.00 | $192.39 | $191.39 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K-202 | Burgamy, Alexis Breonna | Former resident | $460.00 | $828.00 | $368.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K-202 | Andrews, Jkeva J | Former resident | $0.00 | $3,299.00 | $3,299.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K-203 | Lowery, Susan M | Former resident | $0.00 | $33.27 | $33.27 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K-203 | McNeil, Lashon | Former resident | $2.00 | $541.00 | $539.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K-203 | Guzman, Mayra J | Former resident | $0.00 | $515.94 | $515.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K-203 | Paris, Alyssa Marie | Former resident | $351.00 | $719.00 | $368.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K-203 | Van Sweringen, Erika K | Former resident | $0.00 | $205.00 | $205.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K-203 | Smith, Lillian Ann | Former resident | $0.00 | $35.00 | $35.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K-203 | Puerto, Carlos Manuel | Current resident | $1,319.00 | $1,860.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K-204 | Monlyn, Jermaine | Former resident | $0.00 | $191.28 | $191.28 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K-204 | Ortiz Ortiz, Jeannette Y | Former resident | $0.00 | $6,805.00 | $6,805.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L-101 | Rogers, Amanda S | Former resident | $1.00 | $593.93 | $592.93 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L-101 | Minor, Brittany G | Former resident | $551.00 | $919.00 | $368.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L-101 | Harrison, Robert G | Current resident | $0.00 | $6.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L-102 | Nichols, Victoria L | Former resident | $0.00 | $605.00 | $605.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L-102 | Engelby, Sarah | Former resident | $1.00 | $723.62 | $722.62 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L-102 | Seago, Kimberly K | Former resident | $371.00 | $739.00 | $368.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L-103 | Rivera, Annelisse | Former resident | $0.00 | $1,319.00 | $1,319.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L-103 | Valentin Cruz, Luis D | Former resident | $0.00 | $2,743.00 | $2,743.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L-104 | Manuel, Valerie M | Former resident | $0.00 | $37.93 | $37.93 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L-104 | Mateo Roman, Mileni | Former resident | $555.00 | $923.00 | $368.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L-104 | Salameh, Antoine | Former resident | $0.00 | $2.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L-201 | Lewis, Kiera R | Former resident | $0.00 | $20.69 | $20.69 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L-201 | MARSHALL, LASHARA | Former resident | $0.00 | $108.87 | $108.87 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L-201 | Small, Kiesha R | Former resident | $0.00 | $108.94 | $108.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L-201 | Graver, Mercedes April | Former resident | $0.00 | $2,833.00 | $2,833.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L-201 | Campbell, Alera L | Former resident | $0.00 | $12.00 | $12.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L-201 | Hernandez, MayaAngelica | Former resident | $0.00 | $2,351.00 | $2,351.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L-202 | Bush, Kylah D | Former resident | $0.00 | $171.00 | $171.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L-202 | Cruz Rivera, Jose Raul | Former resident | $81.00 | $449.00 | $368.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L-203 | Harris, Sheila D | Former resident | $0.00 | $82.42 | $82.42 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L-203 | Gathers, Briana S | Former resident | $0.00 | $152.94 | $152.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L-203 | Torres Cruz, Omayra Liz | Former resident | $543.00 | $911.00 | $368.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L-204 | Perez JR, Isaac | Former resident | $547.00 | $915.00 | $368.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L-204 | Fernandez, Isabel G | Former resident | $0.00 | $209.99 | $209.99 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L-204 | Rodriguez, Elsa | Former resident | $0.00 | $13.00 | $13.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| M-101 | SWORD, TONYA | Former resident | $0.00 | $844.94 | $844.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| M-101 | Fresse, Jessenia | Former resident | $0.00 | $144.00 | $144.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| M-101 | Johnson, Patricia Charlene | Former resident | $1,748.00 | $2,116.00 | $368.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| M-102 | RAMANAND, DAYOUTTEE | Former resident | $359.00 | $1,449.00 | $1,090.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| M-102 | FITZGERALD, CHRISTIE L | Former resident | $381.00 | $749.00 | $368.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| M-103 | Sepulveda, Zornae M | Former resident | $0.00 | $235.95 | $235.95 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| M-104 | BARNES, BETHENE | Former resident | $0.00 | $95.99 | $95.99 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| M-104 | Eldridge, Julie | Former resident | $0.00 | $210.00 | $210.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| M-104 | Rivera Baez, Jose L | Former resident | $0.00 | $956.96 | $956.96 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| M-104 | Lisenby, Rodney Neal | Former resident | $455.00 | $823.00 | $368.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| M-104 | Rouse, Candi | Former resident | $0.00 | $1,406.00 | $1,406.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| A-101 | Flores, Adaliz | Former resident | $7.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| A-102 | Patterson, Pamela Joyce | Current resident | $570.00 | $360.00 | $-150.00 | [ ] Confirm paid | — |
| A-201 | Almodovar, Ivanshka | Former resident | $143.00 | $0.00 | $-143.00 | [ ] Confirm paid | — |
| A-201 | Mercado, Kathia Y | Current resident | $73.00 | $0.00 | $-73.00 | [ ] Confirm paid | — |
| A-202 | Jorge, Stephanie | Former resident | $107.00 | $5.00 | $-102.00 | [ ] Confirm paid | — |
| A-202 | Torres-Perez, Jesus A | Current resident | $237.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| A-203 | Runnion, Angela D | Former resident | $772.00 | $0.00 | $-772.00 | [ ] Confirm paid | — |
| A-204 | Wilson, Whitney A | Former resident | $611.00 | $18.00 | $-593.00 | [ ] Confirm paid | — |
| A-204 | Ramos Colon, Lismar | Current resident | $8.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| B-101 | Gotay, Lizandra V | Former resident | $119.00 | $40.00 | $-79.00 | [ ] Confirm paid | — |
| B-101 | Mercado, Ivette Yolanda | Former resident | $58.91 | $58.89 | $-0.02 | [ ] Confirm paid | — |
| B-101 | Matos, Shalimar | Current resident | $906.00 | $727.00 | $-179.00 | [ ] Confirm paid | — |
| B-102 | Colon, Carmen E | Former resident | $60.00 | $0.00 | $-60.00 | [ ] Confirm paid | — |
| B-102 | Torres, Rose Elizabeth | Current resident | $582.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| B-103 | Lyons, Mercedes R | Former resident | $912.50 | $910.00 | $-2.50 | [ ] Confirm paid | — |
| B-104 | Leverette, Latoyia | Former resident | $158.00 | $147.91 | $-10.09 | [ ] Confirm paid | — |
| B-201 | Cromer, Kayla R | Current resident | $359.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| B-203 | Acosta Western, Zulmary | Former resident | $1,449.02 | $399.90 | $-1,049.12 | [ ] Confirm paid | — |
| B-203 | Ming, Juwuan Fatrey | Current resident | $27.41 | $24.00 | $-3.41 | [ ] Confirm paid | — |
| B-204 | Garcia Cuevas, victoria | Current resident | $52.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| C-101 | Katherman, Tania Rena | Current resident | $1,919.00 | $1,309.00 | $0.00 | [ ] Confirm paid | — |
| C-102 | Greene, Phyllis t | Current resident | $21.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| C-103 | Hull, Dionna Nisonya | Current resident | $610.00 | $424.00 | $-69.00 | [ ] Confirm paid | — |
| C-203 | Lewis, Patra A | Former resident | $1,434.00 | $100.00 | $-1,334.00 | [ ] Confirm paid | — |
| C-203 | Holmes, TamikoRoslana | Current resident | $1,137.00 | $735.00 | $-44.00 | [ ] Confirm paid | — |
| C-204 | Hazelrig, Nichole M | Current resident | $702.00 | $0.00 | $-118.00 | [ ] Confirm paid | — |
| D-103 | Carroll, Monique D | Former resident | $207.00 | $5.99 | $-201.01 | [ ] Confirm paid | — |
| D-103 | MATTHEW, Natacha M | Current resident | $85.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| D-104 | De La Rosa Paulino, Maria | Current resident | $2,836.00 | $1,467.00 | $-1,253.00 | [ ] Confirm paid | — |
| D-201 | Gilmore, Cherrelle Lavisha | Current resident | $133.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| D-202 | ROCHON, DEBBIE | Former resident | $260.00 | $0.00 | $-260.00 | [ ] Confirm paid | — |
| D-202 | Mercado, Kelly Gloria | Current resident | $6.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| E-101 | Gaston Ramirez, Alejandra | Former resident | $212.00 | $0.00 | $-212.00 | [ ] Confirm paid | — |
| E-102 | Graves, Wycithia M | Former resident | $1.00 | $0.00 | $-1.00 | [ ] Confirm paid | — |
| E-102 | Brattin, Jaime | Former resident | $1,700.00 | $0.00 | $-206.00 | [ ] Confirm paid | — |
| E-103 | Oliver, Dawn | Current resident | $6,909.00 | $6,482.00 | $-132.00 | [ ] Confirm paid | — |
| E-104 | Taylor, Shakila Danielle | Former resident | $1.00 | $0.00 | $-1.00 | [ ] Confirm paid | — |
| E-104 | Rhodes, Derick D | Current resident | $183.00 | $172.00 | $0.00 | [ ] Confirm paid | — |
| E-201 | Corley, Megan Nicole | Current resident | $3,131.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| E-203 | Sisk, Melissa L | Current resident | $70.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| E-204 | Crawford, Audrina E | Former resident | $14.00 | $0.00 | $-14.00 | [ ] Confirm paid | — |
| E-204 | Thomas, Deonnie W | Current resident | $1,258.00 | $988.00 | $57.00 | [ ] Confirm paid | — |
| F-101 | Ramos Guardiola, Zuleyka L | Former resident | $1.00 | $0.00 | $-1.00 | [ ] Confirm paid | — |
| F-101 | Anderson, Letrice N'Dara | Current resident | $9.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| F-102 | Colon Martinex, Feliz | Current resident | $4.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| F-103 | Smiley, Tramika S | Current resident | $411.00 | $374.00 | $-116.00 | [ ] Confirm paid | — |
| F-201 | Bloxson, Tysheba L | Current resident | $17.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| F-203 | Morency, Molly A | Former resident | $567.00 | $566.00 | $-1.00 | [ ] Confirm paid | — |
| F-203 | Cepeda, Yorky | Current resident | $319.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| G-103 | Katherman, Brittany N | Current resident | $240.00 | $0.00 | $-240.00 | [ ] Confirm paid | — |
| G-202 | Carrasquillo-Garcia, Luzviannezaday Marie | Current resident | $48.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| G-203 | Longo-De Jesus, Monica | Former resident | $100.00 | $20.00 | $-80.00 | [ ] Confirm paid | — |
| G-203 | Sanders, Alexandria Dshae | Former resident | $38.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| H-101 | Williams, Andretta M | Current resident | $300.00 | $261.00 | $0.00 | [ ] Confirm paid | — |
| H-102 | Montanez, Rosa M | Former resident | $359.00 | $8.84 | $-350.16 | [ ] Confirm paid | — |
| H-102 | Garcia Diaz, Alyssa Yareo | Former resident | $1,442.00 | $98.80 | $-1,343.20 | [ ] Confirm paid | — |
| H-102 | Hyatt, Racheal A | Current resident | $31.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| H-104 | Campbell, Alera L | Current resident | $286.00 | $0.00 | $-119.00 | [ ] Confirm paid | — |
| H-202 | CRESPO, YARITZA | Former resident | $5,475.00 | $2,456.56 | $-3,018.44 | [ ] Confirm paid | — |
| H-202 | Cobb, Hannah E | Current resident | $557.00 | $0.00 | $-449.00 | [ ] Confirm paid | — |
| H-203 | Caraballo, Lizmarie F | Current resident | $185.00 | $0.00 | $-185.00 | [ ] Confirm paid | — |
| H-204 | Smith, Teresa A | Current resident | $7.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| I-101 | Olan-Marin, Mercedes Maria | Current resident | $235.00 | $94.00 | $-137.00 | [ ] Confirm paid | — |
| I-102 | Mcgriff, Tiqueasha | Former resident | $280.81 | $279.81 | $-1.00 | [ ] Confirm paid | — |
| I-102 | Crespo Rivas, Claribel | Former resident | $2.00 | $0.00 | $-2.00 | [ ] Confirm paid | — |
| I-102 | Niebla Salazar, Idalida | Current resident | $1,140.00 | $926.00 | $-924.00 | [ ] Confirm paid | — |
| I-103 | Young, Tiara | Former resident | $5,094.00 | $494.35 | $-4,599.65 | [ ] Confirm paid | — |
| I-103 | Sauls, Anna Marie | Current resident | $304.00 | $0.00 | $-13.00 | [ ] Confirm paid | — |
| I-201 | Thomas, Misty D | Current resident | $35.00 | $0.00 | $-14.00 | [ ] Confirm paid | — |
| I-202 | GONZALEZ-TRABAL, YASMIN | Former resident | $20.00 | $19.00 | $-1.00 | [ ] Confirm paid | — |
| I-202 | Taylor, Maxine D | Current resident | $53.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| J-101 | Rivera Virella, Jaime | Former resident | $64.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| J-102 | Ortega Rodriguez, Nancy O | Current resident | $77.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| J-104 | Cooper, SandraE | Current resident | $544.00 | $320.00 | $-224.00 | [ ] Confirm paid | — |
| J-201 | Spears, Crystal | Former resident | $171.41 | $0.00 | $-171.41 | [ ] Confirm paid | — |
| J-201 | Adams, Deontre Lashawn | Former resident | $1,642.00 | $13.69 | $-1,628.31 | [ ] Confirm paid | — |
| J-201 | Ruiz Gonzalez, Petra N | Current resident | $195.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| J-202 | Smith, La'Jare'eal M | Former resident | $98.00 | $0.00 | $-98.00 | [ ] Confirm paid | — |
| J-203 | Abdelhay, Ahmed Fouad | Current resident | $390.00 | $0.00 | $-102.00 | [ ] Confirm paid | — |
| J-204 | Funes, Jabier Gonzalez | Current resident | $1,707.00 | $1,380.00 | $-1,494.00 | [ ] Confirm paid | — |
| K-102 | Crum, Wanda | Former resident | $564.00 | $0.00 | $-564.00 | [ ] Confirm paid | — |
| K-102 | Roberts, Savannah Jean | Former resident | $373.00 | $0.00 | $-373.00 | [ ] Confirm paid | — |
| K-103 | Gaines, Geneath L | Current resident | $427.00 | $266.00 | $-155.00 | [ ] Confirm paid | — |
| K-104 | Wright, Sallie L | Current resident | $6,277.59 | $4,572.00 | $-644.59 | [ ] Confirm paid | — |
| K-202 | Shanin, Mykhailo | Current resident | $45.00 | $0.00 | $-30.00 | [ ] Confirm paid | — |
| K-204 | McMiller, Neshia | Current resident | $296.00 | $0.00 | $-296.00 | [ ] Confirm paid | — |
| L-102 | Flowers, Archie L | Current resident | $108.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| L-103 | Hudson, Candace L | Current resident | $223.00 | $148.00 | $-75.00 | [ ] Confirm paid | — |
| L-104 | Marsh, Alexis | Former resident | $267.63 | $0.00 | $-267.63 | [ ] Confirm paid | — |
| L-202 | Hinnant, Dominique T | Current resident | $308.00 | $0.00 | $-190.00 | [ ] Confirm paid | — |
| L-204 | Pizarro Garcia, Eddeicha Marie | Current resident | $1,404.00 | $125.00 | $40.00 | [ ] Confirm paid | — |
| M-101 | Barnes, Sakeeria T | Former resident | $1.00 | $0.00 | $-1.00 | [ ] Confirm paid | — |
| M-101 | Melendez, Blanca I | Former resident | $1,240.00 | $301.91 | $-938.09 | [ ] Confirm paid | — |
| M-101 | Weeks, Wendy L | Current resident | $1,836.00 | $1,378.00 | $-366.00 | [ ] Confirm paid | — |
| M-103 | Parker, Charlene | Current resident | $139.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| M-104 | Spears, Patricia A | Current resident | $77.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| NONE | HAP common ledger | Misc. Income | $2,550.00 | $0.00 | $0.00 | [ ] Confirm paid | — |

## Resident Balance Follow-Up — Paid / Zero Balance

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| A-102 | McDowell, Lakisha R | Former resident | $4,782.00 | $4,782.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A-104 | FLOWERS, ARCHIE L | Former resident | $819.00 | $819.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A-201 | Rios Vazquez, Brenda L | Former resident | $1,137.00 | $1,137.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B-101 | Roman Jimenez, Jose Manuel | Former resident | $19.00 | $19.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B-102 | Ghorafi, Maida | Former resident | $1,193.00 | $1,193.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B-104 | Ayala Pellot, Guillermo | Former resident | $746.00 | $746.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B-202 | Ruckman, Cynthia L | Former resident | $40.00 | $40.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B-202 | Lopez, Elizabeth | Former resident | $23.98 | $23.98 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B-203 | Oquendo Adorno, Jennifer C | Former resident | $2,653.00 | $2,653.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B-204 | Diaz Gavino, Kennya I | Former resident | $1,137.00 | $1,137.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C-101 | Johnson, Luchrisha Elizabeth | Former resident | $961.00 | $961.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C-103 | Lee, Danielle M | Former resident | $1,137.00 | $1,137.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C-104 | Lovette, Yaterica | Former resident | $352.98 | $352.98 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C-104 | Porter Chism, Shawn | Former resident | $1,136.00 | $1,136.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C-201 | Caraballo Ramirez, Maria | Former resident | $1,122.00 | $1,122.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C-203 | White, Lakisha D | Former resident | $36.00 | $36.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C-203 | Robbins, Ruth | Former resident | $1,137.00 | $1,137.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C-204 | Aponte Cruz, Enid L | Former resident | $862.00 | $862.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D-102 | Porter, Desiree Angela | Former resident | $9.00 | $9.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D-103 | Figueroa, Carmen Maria | Former resident | $1,137.00 | $1,137.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D-202 | Quintero Gonzalez, Yesenia | Former resident | $1,137.00 | $1,137.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D-203 | Moreau Pereira, Yeralis | Former resident | $1,137.00 | $1,137.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E-101 | Zamora Olmo, Maria De Los Angeles | Former resident | $727.00 | $727.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E-102 | Aiken, Crystal L | Former resident | $4.00 | $4.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E-103 | FELICITA HERNANDEZ | Former resident | $76.00 | $76.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E-103 | Gonzalez Trabel, Yaritza | Former resident | $779.00 | $779.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E-104 | Spears, Patricia A | Former resident | $747.00 | $747.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E-201 | Trabel, Ivette Y | Former resident | $95.00 | $95.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F-103 | JOHNSON, LASHANDA T | Former resident | $27,013.00 | $27,013.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F-201 | Fiqueroa Matos, Carlos | Former resident | $1,496.00 | $1,496.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H-102 | Pintor, Leonor | Former resident | $26.00 | $26.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H-103 | BOSTWICK, CYNIKEIA T | Former resident | $27,321.00 | $27,321.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I-102 | Ocasio Cotto, Samaira | Former resident | $38,465.00 | $38,465.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I-104 | Matos, Adriana M | Current resident | $1.00 | $1.00 | $-1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I-201 | Dixon, Cheyenne M | Former resident | $2,292.00 | $2,292.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I-203 | Young, Tameka | Former resident | $250.00 | $250.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| I-203 | Croom, Kayln | Former resident | $134.00 | $134.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J-202 | Rivera Pacheco, Nadia | Former resident | $10.94 | $10.94 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K-104 | Cherry, Chalet M. | Former resident | $234.09 | $234.09 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K-104 | Garcia Cruz, Carla Michelle | Former resident | $1,752.00 | $1,752.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K-202 | Suarez-Montanez, Joshua | Former resident | $13.00 | $13.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L-104 | Flores, Paula D | Former resident | $53.93 | $53.93 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| M-103 | Hudson, Candace Lyn | Former resident | $1,823.00 | $1,823.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property's supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*