# St. Charles — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 4371422**. Update the checkboxes and notes during or immediately after the manager call.

> **Note:** This checklist uses the prior successful run's delinquency data (run 55) since this property failed to generate in the latest run (58).

| Call details | Manager update |
|---|---|
| Availability report as of | 08/03/2026 |
| Property manager | Deon Tolliver — stcharles@apartmentcorp.com — (337) 804-2549 |
| Regional manager | Ginger Positerry — ginger@apartmentcorp.com — (985) 637-2128 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Delinquency spreadsheet | `4371422_St Charles_Delinquent and Prepaid - Excel_1954147.xls` |
| Ledger accounts for review | 77 resident accounts |
| Residents with amount owed | 29 accounts; $15,733.00 |
| Prepaid / credit accounts | 48 accounts; $-10,011.99 |
| Availability entries | 5 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit's reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| 04-032 | 2A | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 15-113 | 2A | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 06-043 | 2A | Vacant Leased Not Ready | [ ] Verified | __________________ |
| 08-064 | 2A | Vacant Leased Not Ready | [ ] Verified | __________________ |
| 12-089 | 3A | Vacant Leased Not Ready | [ ] Verified | __________________ |

## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 01 - 002 | Peterman, Eldrionna Nicole | Current resident | $0.00 | $1,501.00 | $934.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 01 - 007 | Preston, Kristopher Erik | Current resident | $0.00 | $42.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02 - 010 | Ross, Cameron Lee | Current resident | $0.00 | $12.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02 - 016 | Chambers, Rita Marie | Current resident | $0.00 | $5.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 03 - 018 | Ross, Mason Alexander | Current resident | $0.00 | $331.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 03 - 021 | Seymore, Janaysha | Current resident | $0.00 | $116.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05 - 034 | Jefferson, Alice Faye | Current resident | $0.00 | $34.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 06 - 041 | Beverly, Curt Van Allen | Current resident | $0.00 | $825.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 06 - 044 | Anderson, Carolina Lashay | Current resident | $0.00 | $690.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 06 - 045 | Parker, Brenda Sue | Current resident | $0.00 | $525.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 07 - 052 | Lewis, Donald Ray | Current resident | $0.00 | $787.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 08 - 060 | Richard, Reginald Dawayne | Current resident | $0.00 | $626.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 08 - 062 | Edwards, Charita Semonia | Current resident | $0.00 | $252.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 08 - 063 | Ramer, TrevianaNakaya Monae | Current resident | $0.00 | $550.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 069 | Thomas, NakiraDezaniqua renee Thomas | Current resident | $117.00 | $396.00 | $148.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 075 | Armstrong, TarellLemar | Current resident | $0.00 | $973.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 076 | Saucier, TiffanyNichole | Current resident | $0.00 | $1,546.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 077 | Anderson, Joseph Keith | Current resident | $0.00 | $1,550.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 080 | Louis, VeronicaMarie | Current resident | $0.00 | $75.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 091 | Simien, Carolyn | Current resident | $0.00 | $359.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 092 | Landry, Dinika D | Current resident | $0.00 | $1,961.00 | $1,198.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 093 | Ashley, Diamonds Veronica | Current resident | $0.00 | $8.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 094 | Rubin, AnJanae Raion | Current resident | $0.00 | $553.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 096 | Bias, JameshiaSheere | Current resident | $0.00 | $478.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 097 | Simien, Devanee Rosha | Current resident | $0.00 | $58.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 099 | Anderson, KiaraJaquelle | Current resident | $0.00 | $451.00 | $284.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 100 | Harden, Shayla | Current resident | $0.00 | $290.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 102 | Willis, Tiffany Nicole | Current resident | $0.00 | $115.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 114 | Landry, TerryMarie | Current resident | $0.00 | $741.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 01 - 001 | Bernard, Shannon Marie | Current resident | $73.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 01 - 003 | Williamson, MalisaRamirez | Current resident | $70.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 01 - 006 | Guidry, CarnnettaRene | Current resident | $5.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 01 - 008 | Goudeau, Ricky Wayne | Current resident | $250.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 02 - 009 | Austin, Dionne Monique | Current resident | $613.00 | $0.00 | $-149.00 | [ ] Confirm paid | — |
| 02 - 011 | Zackery, Janice Thomas | Current resident | $16.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 02 - 012 | Thomas, Aleia Janee | Current resident | $175.00 | $0.00 | $-175.00 | [ ] Confirm paid | — |
| 02 - 013 | Prejaen, Lindsey Dymond | Current resident | $58.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 02 - 014 | Potts, TrinityDeshay | Current resident | $101.00 | $0.00 | $-37.00 | [ ] Confirm paid | — |
| 02 - 015 | Oliver, LarryDarnell | Current resident | $171.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 03 - 017 | Ozane, Tashara Monae | Current resident | $49.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 03 - 023 | Brown, MarkAnthony | Current resident | $143.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 04 - 025 | Phills, Regionald Van | Current resident | $164.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 04 - 027 | Glodd, Ericka None | Current resident | $37.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 04 - 028 | Bias, Desmond Devontaye | Current resident | $115.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 04 - 029 | Thomas, Kenadie Ashlynn | Current resident | $8.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 04 - 031 | Allen, Tammy C | Current resident | $17.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 05 - 037 | Joseph, CleotaMarie | Current resident | $25.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 05 - 039 | Ardoin, ScherrazadeMechelle | Current resident | $609.00 | $0.00 | $-66.00 | [ ] Confirm paid | — |
| 05 - 040 | Richmond, TekesaDanielle | Current resident | $146.00 | $0.00 | $-146.00 | [ ] Confirm paid | — |
| 07 - 050 | Siverand, Erica Louise | Current resident | $122.00 | $0.00 | $-122.00 | [ ] Confirm paid | — |
| 07 - 051 | Davis, FlorenceL Sharomone | Current resident | $308.00 | $0.00 | $-43.00 | [ ] Confirm paid | — |
| 07 - 055 | Mckoy, Donondra Rachelle | Current resident | $266.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 07 - 056 | Siverand, JacquelineMiranda | Current resident | $21.00 | $0.00 | $-21.00 | [ ] Confirm paid | — |
| 09 - 065 | Ledet, D'Dara Lashay | Current resident | $10.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 10 - 067 | Hadnot, Antoinette Jewell Joshanique | Current resident | $88.00 | $0.00 | $-88.00 | [ ] Confirm paid | — |
| 10 - 070 | Hall, Tiffany Latoya | Current resident | $4.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 10 - 072 | Jacobs, Nicole Frances | Current resident | $51.00 | $0.00 | $-51.00 | [ ] Confirm paid | — |
| 12 - 083 | Batiste, Michael Wayne | Current resident | $649.00 | $0.00 | $-362.00 | [ ] Confirm paid | — |
| 12 - 085 | Leo, FaimataAgnes Palepa | Current resident | $424.00 | $0.00 | $-322.00 | [ ] Confirm paid | — |
| 12 - 086 | Shell, Patricia Lekee | Current resident | $52.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 12 - 087 | Smith, Brandy Nicole | Current resident | $124.00 | $0.00 | $-124.00 | [ ] Confirm paid | — |
| 12 - 088 | Williams, TiffanyLynn | Current resident | $1,060.00 | $0.00 | $-914.00 | [ ] Confirm paid | — |
| 14 - 101 | Simmons, Emeric Dewayne | Current resident | $700.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 14 - 104 | Ceasar, Yowanda Chantal | Current resident | $117.00 | $0.00 | $-66.00 | [ ] Confirm paid | — |
| 14 - 105 | Walker, Asia Dizhane | Current resident | $36.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 15 - 106 | Sears, Nancy Mae | Current resident | $134.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 15 - 107 | Watts, MeghanNekole | Current resident | $189.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 15 - 108 | Dobson, Yazmin Nykole | Current resident | $340.00 | $0.00 | $-274.00 | [ ] Confirm paid | — |
| 15 - 109 | Guillory, Shamikia Danielle | Current resident | $290.00 | $0.00 | $-116.00 | [ ] Confirm paid | — |
| 15 - 110 | Jones, April Marie | Current resident | $94.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 15 - 111 | Richard, ShaniceMarie Renee | Current resident | $1,064.99 | $0.00 | $-19.00 | [ ] Confirm paid | — |
| 16 - 115 | Atkins, Destiny Sherell | Current resident | $15.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 16 - 116 | Carrier, TysheannerKevina | Current resident | $443.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 16 - 117 | Shavers, Vinston D | Current resident | $18.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 16 - 119 | Hudson, Dillard none | Current resident | $71.00 | $0.00 | $-62.00 | [ ] Confirm paid | — |
| 16 - 120 | Ruffin, Judy Ann | Current resident | $175.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 16 - 121 | Tillman, Vanessa Marie | Current resident | $301.00 | $0.00 | $0.00 | [ ] Confirm paid | — |

## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.

## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property's supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*