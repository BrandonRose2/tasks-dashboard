# Coral Village — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 4859069**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/05/2026 |
| Property manager | Keyla Maranon — coralvillage@apartmentcorp.com — (857) 272-6217 |
| Regional manager | JR Rolon — jrrolon@apartmentcorp.com — (941) 716-1665; Leslie Rolon — leslie@apartmentcorp.com — (504) 247-3813 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Delinquency spreadsheet | `4859069_Coral Village_Delinquent - Excel_58.xls` |
| Ledger accounts for review | 62 resident accounts |
| Residents with amount owed | 27 accounts; $7,347.20 |
| Prepaid / credit accounts | 33 accounts; $-13,708.37 |
| Availability entries | 0 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit's reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| — | — | No unit-status entries in the selected source export | [ ] Verified | __________________ |

## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - 101A | Ramos, MargaritaP | Current resident | $0.00 | $400.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 102A | Resau, Margaret M | Former resident | $0.00 | $886.00 | $886.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 105 | Fernandez Sabatel, Luz G | Current resident | $0.00 | $159.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 106B | Vidal, Digna | Current resident | $0.00 | $3.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 107 | Borrero, Elizabeth | Current resident | $0.00 | $4.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 201 | Markham, Beverly | Former resident | $0.00 | $21.00 | $21.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 205 | Coral Village | Former resident | $0.00 | $20.00 | $20.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 206 | Perez, Rosa Maria | Former resident | $0.00 | $46.20 | $46.20 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 207 | Narvaez, Margarita | Former resident | $0.00 | $19.00 | $19.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 304 | Torres, Pedro | Current resident | $0.00 | $5.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 308 | Lopez, Liduvina D | Former resident | $0.00 | $19.00 | $19.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 308 | Machado, Leony | Former resident | $0.00 | $649.00 | $649.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 401 | Peggy Senna | Former resident | $0.00 | $15.00 | $15.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 401 | Perez, Rosa M | Former resident | $0.00 | $52.71 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 401 | Cobas Cobas, Gregoria | Current resident | $0.00 | $1,380.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 405 | Velazquez Sanchez, MariaD | Current resident | $0.00 | $2.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 501 | Caceres, Cruz | Current resident | $384.00 | $760.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 502 | Reichle, RobertaA | Former resident | $0.00 | $86.29 | $86.29 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 503 | Vergel, Yolanda | Current resident | $0.00 | $122.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 505 | Cortes, Lillian | Former resident | $0.00 | $20.00 | $20.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 506 | Marin, Angela | Former resident | $0.00 | $14.00 | $14.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 605 | Rivera, Carlos | Former resident | $0.00 | $8.00 | $8.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 703 | Lopez Morales, Buenaventura | Current resident | $0.00 | $239.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 706 | Alvarez, Nora E | Current resident | $0.00 | $916.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 707 | Aviles, Olga | Current resident | $0.00 | $1.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 803 | Otto, Joann | Former resident | $0.00 | $52.00 | $52.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 806 | Lopez Yanes, Maria D | Current resident | $0.00 | $1,832.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - 103B | Solomon, Marcia | Former resident | $1,245.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 103B | Diaz, Emma | Current resident | $1,351.00 | $174.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 104 | Wilmot, Dorla D | Former resident | $788.00 | $0.00 | $-788.00 | [ ] Confirm paid | — |
| 1 - 104 | Serrano, Juan | Current resident | $164.00 | $155.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 108 | Hernandez, Georgina M | Current resident | $4.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 108B | Johnson, Eliorminia | Current resident | $300.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 204 | Carusone, Josephine F | Current resident | $630.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 205 | Forte, Robert M | Current resident | $36.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 206 | Hernandez, Olivia | Current resident | $18.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 208 | Rojas, Alma | Former applicant | $1.00 | $0.00 | $-1.00 | [ ] Confirm paid | — |
| 2 - 208 | Fischer, Gloria N | Current resident | $6.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 301 | Hazel Cruz | Former resident | $132.00 | $0.00 | $-132.00 | [ ] Confirm paid | — |
| 3 - 301 | Hernandez, Pedro | Current resident | $105.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 302 | Peter Lester | Former resident | $93.00 | $0.00 | $-93.00 | [ ] Confirm paid | — |
| 3 - 302 | Green, Ruth Ann | Current resident | $1,425.00 | $516.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 305 | Llanes Bencomo, Mayra | Former resident | $2,046.47 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 307 | Flores, Raul | Current resident | $374.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - 402 | Palacio, Gonzalo | Former resident | $621.00 | $0.00 | $-621.00 | [ ] Confirm paid | — |
| 4 - 403 | Rondon, Sara | Former resident | $828.00 | $0.00 | $-828.00 | [ ] Confirm paid | — |
| 4 - 404 | Whetsell, Ronald A | Current resident | $75.00 | $71.00 | $-75.00 | [ ] Confirm paid | — |
| 4 - 407 | Fentross, Maureen L | Current resident | $804.00 | $174.00 | $0.00 | [ ] Confirm paid | — |
| 4 - 408 | Kornet, Kenneth A | Current resident | $6.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 502 | Exposito, Manuel | Current resident | $1,082.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 504 | Pampinella, Barbara | Current resident | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 507 | Gomez, Isolina Ines | Current resident | $40.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 6 - 601 | Delaney, Margaret | Former resident | $1,096.00 | $0.00 | $-1,096.00 | [ ] Confirm paid | — |
| 6 - 603 | Gibson, Sumiko | Current resident | $378.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 6 - 607 | Lohmiller, Shirley A | Current resident | $329.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 7 - 703 | Patterson, BettieS | Former resident | $44.45 | $0.00 | $-44.45 | [ ] Confirm paid | — |
| 7 - 704 | Henley, RuthE | Former resident | $264.45 | $0.00 | $-264.45 | [ ] Confirm paid | — |
| 8 - 804 | Dickens, Sarah | Current resident | $16.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 8 - 807 | Suarez, Ana C | Current resident | $117.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 8 - 808 | Gonzalez, Lidia | Current resident | $378.00 | $0.00 | $0.00 | [ ] Confirm paid | — |

## Resident Balance Follow-Up — Paid / Zero Balance

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 2 - 202 | Connolly, Janice | Current resident | $36.00 | $36.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 605 | Ramirez, Isabel C | Current resident | $6.00 | $6.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property's supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*