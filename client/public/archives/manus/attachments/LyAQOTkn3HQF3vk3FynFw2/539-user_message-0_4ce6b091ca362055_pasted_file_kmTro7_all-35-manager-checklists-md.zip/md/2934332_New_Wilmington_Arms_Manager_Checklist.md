# New Wilmington Arms — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 2934332**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/05/2026 |
| Property manager | Jose Gomez — wilmington@apartmentcorp.com — (323) 507-5049 |
| Regional manager | Blake Weddington — blake@apartmentcorp.com — (310) 927-0020 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Delinquency spreadsheet | `2934332_New Wilmington Arms_Delinquent - Excel_58.xls` |
| Ledger accounts for review | 309 resident accounts |
| Residents with amount owed | 286 accounts; $1,108,196.52 |
| Prepaid / credit accounts | 22 accounts; $-42,856.51 |
| Availability entries | 0 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit's reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| — | — | No unit-status entries in the selected source export | [ ] Verified | __________________ |

## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| A102 | ANDRUS, THERESE L | Current resident | $18.00 | $2,964.00 | $2,964.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A103 | GOODLOW, ADRIAN L | Former resident | $8,271.00 | $30,596.00 | $22,325.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A103 | RAND, STEVE | Current resident | $82.00 | $2,602.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A104 | WILSON, SHONNEIA C | Former resident | $5,359.00 | $7,625.00 | $2,266.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A104 | WARD, ALIEDA PATRICIA | Former resident | $0.00 | $4,227.00 | $4,227.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A104 | TELLEZ, AURORA Y | Current resident | $0.00 | $5,436.00 | $668.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A105 | MILFORD, STARRKEISHA N | Former resident | $0.00 | $1,256.01 | $1,256.01 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A105 | SCOTT, TIFFANY MK | Former resident | $2,877.00 | $3,533.00 | $656.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A105 | MENDOZA, ELIZABETH | Current resident | $132.00 | $4,941.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A106 | TAFOLLA-VEGA, ANA P | Former resident | $0.00 | $4,051.00 | $4,051.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A106 | RIOS, VERONICA | Current resident | $1,510.00 | $4,496.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A107 | SLAUGHTER, CHRISTINA F | Current resident | $1,641.00 | $8,710.00 | $1,609.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A108 | CASTRO GUTIEREZ, ORLANDO A | Current resident | $2,265.00 | $9,364.00 | $3,186.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A109 | WESTBROOKS, JOJUAN L | Former resident | $0.00 | $939.00 | $939.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A109 | CANO ALVA, EVELYN A | Former resident | $0.00 | $662.00 | $662.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A109 | CALVILLO, MARCOS | Former resident | $3,477.00 | $5,489.00 | $1,554.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A109 | GUEVARA, ZULEMA | Current resident | $49.00 | $1,310.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A211 | LOZANO DE MUNIZ, ANA M | Former resident | $1,279.00 | $2,476.00 | $1,197.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A211 | DAVALOS, ANGELIC J | Current resident | $2.00 | $2,257.00 | $79.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A212 | WILLIAMS, COLETTE D | Current resident | $3,938.00 | $12,031.00 | $2,633.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A213 | TAYLOR, JOSEPH | Current resident | $552.00 | $571.00 | $19.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A214 | POWELL, NIKIA S | Former resident | $0.00 | $3,197.00 | $3,197.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A214 | CALVILLO, AMIE MAXINE | Current resident | $2,242.00 | $5,244.00 | $-514.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A215 | SANCHEZ- ESCOBAR, HENRY A | Former resident | $0.00 | $5,973.00 | $5,973.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A215 | RODRIGUEZ, YESENIA | Current resident | $20.00 | $4,523.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A216 | SMITH, CORA B | Former resident | $0.00 | $972.00 | $972.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A216 | LUGO, ELISA | Former resident | $0.00 | $1,533.00 | $1,533.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A216 | OLIVAS, ALONDRA | Current resident | $0.00 | $1,613.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A217 | PICKERING, JONATHAN N | Current resident | $5,448.00 | $11,898.00 | $2,970.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A218 | MADISON, FALLON G | Current resident | $0.00 | $1,840.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B101 | FERNANDEZ, BEATRIZ | Former resident | $0.00 | $1,012.00 | $1,012.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B101 | FRAIRE VALENZUELA, SANDY | Former resident | $0.00 | $86.00 | $86.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B101 | NAVA-ONTIVEROS, MAYRA L | Current resident | $445.00 | $1,828.00 | $-45.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B102 | HARREL, CELESTINE | Current resident | $1,839.00 | $5,440.00 | $-163.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B103 | OLARTE, DORA MARGARITA | Former resident | $0.00 | $1,214.00 | $1,214.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B103 | MEDRANO, JULISA | Current resident | $183.00 | $3,132.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B104 | GRIFFIN, MARGIE R | Former resident | $0.00 | $2,530.00 | $2,530.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B104 | PADILLA, VANESSA | Current resident | $0.00 | $3,254.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B205 | SPROWSON, TAMMY M | Former resident | $989.00 | $36,275.00 | $35,286.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B205 | RAMIREZ-ORTEGA, KAREN DAPHNE | Current resident | $0.00 | $2,098.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B206 | LOPEZ, VANESSA | Current resident | $11,989.00 | $17,109.00 | $339.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B207 | ANGELES MULATO, ESMERALDA | Current resident | $0.00 | $3,727.00 | $89.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B208 | TAYLOR, MICHAEL V | Former resident | $0.00 | $1,270.00 | $1,270.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B208 | WILSON, ALANNA R | Current resident | $6,789.00 | $8,175.00 | $-367.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C101 | JIMENEZ LUVIANO, NATALY | Current resident | $0.00 | $4,599.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C102 | GRIFFIN, MARCH D | Current resident | $2,001.00 | $7,739.00 | $-127.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C103 | ANGLON, SHARISE R | Current resident | $342.00 | $10,766.00 | $6,996.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C104 | RODRIGUEZ, SAUL | Current resident | $0.00 | $2,912.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C105 | MILNER, LATASHA M | Former resident | $5,591.00 | $7,470.00 | $1,879.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C105 | CASTELAN, JENNIFER | Current resident | $0.00 | $7,500.00 | $2,052.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C106 | HERNANDEZ RODRIGUEZ, MARINA | Current resident | $739.00 | $5,076.00 | $-97.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C207 | SPEARS, IKAHA M | Current resident | $2,127.00 | $10,716.00 | $3,651.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C208 | EDMOND, TANIEL | Former resident | $0.00 | $2,142.00 | $2,142.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C208 | BROMELL, ERVIN | Current resident | $22.00 | $1,883.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C209 | MILES, DENISE W | Former resident | $0.00 | $1,293.00 | $1,293.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C209 | CALVILLO, ELIZABETH | Current resident | $4,440.00 | $6,133.00 | $88.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C210 | WILLIAMS, MARNETTE | Current resident | $259.00 | $4,937.00 | $1,280.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C212 | WILLIAMS, JEAN D | Former resident | $0.00 | $1,978.00 | $1,978.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C212 | SIGALA, BRIAN A | Current resident | $5,154.00 | $8,027.00 | $-28.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D101 | MANN, JERRIE L | Former resident | $0.00 | $4,307.00 | $4,307.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D101 | GARCIA-MARTINEZ, KARINA | Former resident | $0.00 | $5.00 | $5.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D101 | GUTIERREZ, MARGARITA | Current resident | $46.00 | $4,941.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D102 | GARCIA, IBETT E | Current resident | $1,298.00 | $4,341.00 | $-301.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D103 | FRANKLIN, LENNETTE | Current resident | $0.00 | $5,527.00 | $1,258.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D104 | ROSS JR, RAYNONDO C | Former resident | $0.00 | $1,493.00 | $1,493.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D104 | JONES, VERNETTA H | Current resident | $3,990.00 | $8,386.00 | $-168.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D105 | OROZCO-SOTELO, YESENIA | Former resident | $0.00 | $1,257.00 | $1,257.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D105 | HUITRON, MARGARITA Y | Current resident | $8,289.00 | $9,017.00 | $-565.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D106 | Valencia, Maria T | Former resident | $0.00 | $2,505.00 | $2,505.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D106 | CHAVEZ LUVIANO, PAULA | Current resident | $417.00 | $4,001.00 | $-340.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D107 | JONES, MILDRED | Former resident | $500.00 | $1,535.00 | $1,035.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D107 | MENDOZA, CLAUDIA JHANNET | Current resident | $969.00 | $5,615.00 | $-31.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D108 | GILL, ALICE F | Former resident | $0.00 | $2,383.00 | $2,383.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D109 | WALLS, BRENDA | Former resident | $0.00 | $932.00 | $932.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D109 | JOHNSON, LATONTA R | Former resident | $3,981.00 | $11,282.00 | $7,301.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D109 | MCKINNEY, QUAEMIA S | Current resident | $712.00 | $1,819.67 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D110 | HAYNES, JACQUELINE D | Current resident | $5,285.00 | $9,602.00 | $340.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D111 | LAW, SHAKEIA L | Current resident | $3,007.00 | $9,842.00 | $2,363.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D212 | ORTIZ, MATILDE | Current resident | $12,218.00 | $12,745.00 | $527.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D213 | TRUJILLO, YESENIA ARAYENDI | Current resident | $841.00 | $1,552.00 | $-26.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D214 | LAWRENCE, ANGELA F | Former resident | $0.00 | $1,196.00 | $1,196.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D214 | SERRANO-CARBAJAL, RAMON | Current resident | $1,348.00 | $5,568.00 | $-195.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D215 | ENGLISH, ALICE F | Current resident | $1,691.00 | $4,772.27 | $278.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D216 | CHAVEZ, LORENA | Former resident | $3,045.00 | $5,968.00 | $2,923.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D216 | BRISBY, KIARA | Current resident | $119.00 | $1,338.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D217 | BURGER, LAWANDA M | Former resident | $0.00 | $7,931.00 | $7,931.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D217 | HERNANDEZ, JOSEPHINA | Current resident | $1.00 | $3,613.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D218 | CASTRO, SAMANTHA S | Former resident | $40.00 | $1,181.00 | $1,141.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D218 | TACKWOOD, AJSHA S | Former resident | $5,230.00 | $7,742.00 | $2,512.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D218 | JONES, LILLIE | Current resident | $5.00 | $3,375.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D219 | REYES, ALEJANDRO | Current resident | $149.00 | $11,968.00 | $7,651.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D220 | SCARBROUGH, RAECHELLE D | Former resident | $0.00 | $91.00 | $91.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D220 | MACIAS LOPEZ, YOLANDA | Current resident | $5,106.64 | $9,372.00 | $-308.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D221 | ARTEAGA, JAZMYN R | Former resident | $1,474.00 | $1,743.00 | $269.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D221 | MACIAS, ELISABETH | Current resident | $3,538.00 | $11,504.00 | $2,601.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D222 | FIGUEROA, JUANA M | Current resident | $80.00 | $5,559.00 | $792.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E101 | MERRITT, KAI A | Former resident | $0.00 | $1,379.00 | $1,379.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E101 | LUGO-LOPEZ, FATIMA | Former resident | $0.00 | $689.00 | $689.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E101 | HURTADO, VANESSA | Former resident | $0.00 | $21.00 | $21.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E101 | WILLIAMS, TRENAYCE S | Current resident | $814.00 | $4,299.00 | $-678.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E102 | ROBLES, MARIA G | Former resident | $0.00 | $696.00 | $696.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E102 | WINCE, AUDREY DENISE | Former resident | $0.00 | $8,132.00 | $8,132.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E102 | GOMEZ, MARISELA | Current resident | $0.00 | $4,047.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E103 | TAFOLLA-VEGA, ANGELINA | Former resident | $0.00 | $1,287.00 | $1,287.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E103 | CALDERON, MARIA LUISA | Current resident | $785.00 | $3,268.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E104 | JOHNSON, ISGUNEU T | Former resident | $0.00 | $1,251.00 | $1,251.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E104 | BRAY, DENISHA M | Former resident | $0.00 | $1,333.00 | $1,333.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E104 | LEWIS, DANISHA R | Former resident | $4,290.00 | $18,611.00 | $14,321.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E104 | LOPEZ CORONA, LIZBETH | Current resident | $0.00 | $3,546.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E105 | ALFARO, JOSE A | Current resident | $2,559.00 | $11,464.00 | $4,217.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E106 | LOWE, ALANA L | Former resident | $0.00 | $7,210.00 | $7,210.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E106 | WHITAKER, SHEKIA SHREE | Current resident | $4,555.00 | $8,442.97 | $-288.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E107 | GONZALEZ, IRENE E | Former resident | $2,388.00 | $3,790.00 | $1,402.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E107 | ROMERO ESTRADA, FLORINDA ISABEL | Current resident | $551.00 | $2,871.00 | $-92.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E108 | SERRANO, RUBIA | Current resident | $1,131.00 | $7,116.00 | $2,148.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E209 | WALKER, ROCHELLE M | Current resident | $936.00 | $8,273.00 | $3,051.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E210 | SPARKS, CORANDA | Current resident | $461.00 | $4,476.00 | $490.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E211 | RAMSEY, AKEMIA M | Former resident | $0.00 | $6,454.00 | $6,454.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E211 | SPEARS, SHENNA M | Current resident | $305.00 | $3,751.00 | $-151.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E212 | CLAY, PATRICIA A | Former resident | $0.00 | $1,306.00 | $1,306.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E212 | TAFOLLA VEGA, ANGELINA | Former resident | $5,604.00 | $8,445.00 | $2,841.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E212 | FLORES, ANGELICA | Current resident | $1,087.00 | $7,564.00 | $1,017.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E213 | BELL, TRECEE L | Former resident | $0.00 | $1,066.00 | $1,066.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E213 | ROMAN CALVILLO, ISAMAR | Former resident | $0.00 | $91.00 | $91.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E213 | ESTRADA TORRES, DALIA MIRAMA | Current resident | $10,011.00 | $13,867.00 | $784.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E214 | HARRELL, SHANTE L | Former resident | $0.00 | $3,671.00 | $3,671.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E214 | MALDONADO, JUAN L | Current resident | $2,351.00 | $14,729.00 | $6,858.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E215 | HARRIS, STEVE | Former resident | $3,107.00 | $6,407.00 | $873.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E216 | WHITE, KATHERINE L | Current resident | $3,930.00 | $9,452.00 | $62.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F101 | FAIRLEY, TASHON | Current resident | $0.00 | $5,493.00 | $283.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F102 | Johnson, Danesha R | Former resident | $0.00 | $1,207.00 | $1,207.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F102 | MENDOZA, SANDRA J | Current resident | $2,931.00 | $8,022.00 | $-2,284.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F103 | DE LEON, OLGA C | Current resident | $1,607.00 | $7,487.00 | $549.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F104 | HANKEY, DENISE E | Former resident | $0.00 | $1,148.00 | $1,148.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F104 | ROMERO ESTRADA, JOANA | Current resident | $3,792.00 | $5,328.00 | $-382.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F205 | CALVILLO, DAYSI Y | Former resident | $0.00 | $2,402.00 | $2,402.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F205 | GUERRERO, PETER A | Former resident | $0.00 | $37.00 | $37.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F205 | BROWN, KIM R | Current resident | $1,273.00 | $5,565.00 | $-156.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F206 | LAWRENCE, LOSHALL R | Current resident | $312.00 | $5,689.00 | $904.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F207 | DAVENPORT, ANDRE A | Current resident | $0.00 | $7,132.00 | $2,033.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F208 | THOMAS, TREVEN D | Former resident | $0.00 | $3,121.00 | $3,121.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F208 | VIRTO, EVA C | Former resident | $3,163.00 | $3,336.00 | $173.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G101 | RUIZ-MEDINA, ANGELICA | Current resident | $0.00 | $3,732.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G102 | MARTINEZ SOLORIO, JULIO C | Current resident | $7,355.00 | $12,270.50 | $-1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G103 | CHAVAQUE, DAVID I | Former resident | $0.00 | $5,593.00 | $5,593.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G103 | MARTINEZ, BELEN | Current resident | $4,359.00 | $10,255.00 | $1,215.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G104 | HERNANDEZ JULIAN, MAYRA R | Current resident | $2,333.00 | $7,575.00 | $80.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G105 | RODRIGUEZ OCEGUERA, FERNANDO | Current resident | $5.00 | $4,291.00 | $2,662.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G106 | SALCEDA, LA LONIE L | Former resident | $0.00 | $1,210.00 | $1,210.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G106 | MORENO, CECILIA | Current resident | $2,699.00 | $4,870.00 | $-456.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G107 | GANT, SHANIKA L | Current resident | $839.00 | $8,315.00 | $2,544.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G108 | WILLIAMS, MARVINA M | Former resident | $147.00 | $1,365.00 | $1,218.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G108 | GUTIERREZ, JOANNA MARITHZA | Current resident | $2,303.00 | $5,827.00 | $-294.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G109 | AVILA, JUAN ANTONIO | Current resident | $2,472.00 | $10,263.00 | $3,160.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G110 | LOPEZ DURAN, ADRIANA | Current resident | $1,044.00 | $5,949.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G211 | SANCHEZ, YOLANDA | Former resident | $0.00 | $2,818.00 | $2,818.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G211 | CASTILLO, ALMA V | Current resident | $342.00 | $5,404.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G212 | BECERRA, PATRICIA | Current resident | $7,320.00 | $14,084.00 | $6,764.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G213 | MEDINA DE LA PAZ, MIRNA L | Current resident | $2,170.00 | $6,135.00 | $-159.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G214 | Castaneda, Marisela | Former resident | $0.00 | $2,241.00 | $2,241.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G214 | LUVIANO MALDONADO, ESMERALDA E | Current resident | $0.00 | $2,901.00 | $1,133.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G215 | STACY, KARON R | Former resident | $0.00 | $1,207.00 | $1,207.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G215 | BRYAN, JAMES R | Current resident | $2,450.00 | $6,504.00 | $407.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G216 | WILDER, KIM | Current resident | $6,349.00 | $12,228.00 | $1,247.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G217 | Morales, Evelyn Y | Former resident | $0.00 | $4,594.00 | $4,594.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G217 | MENDEZ, GABRIELA | Current resident | $756.00 | $3,160.00 | $-324.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G218 | LOVE, EDITH | Current resident | $5,412.00 | $10,812.25 | $-1,526.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G219 | RODRIGUEZ, MARIA S | Current resident | $4,019.00 | $10,318.00 | $-205.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G220 | BECERRA, BARBARA | Former resident | $0.00 | $1,482.00 | $1,482.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G220 | VARGAS-COLIN, MARIA E | Current resident | $354.00 | $11,951.00 | $5,213.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H101 | FULLENWIDER, SHYEIKA | Former resident | $0.00 | $2,648.00 | $2,648.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H101 | JIMENEZ, RAYMUNDO | Current resident | $660.00 | $3,439.00 | $1,024.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H102 | HILERIO-REYES, BEATRIZ | Former resident | $4,250.00 | $6,231.00 | $1,981.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H102 | MANZO, JOSEFINA | Current resident | $0.00 | $7,735.00 | $2,275.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H103 | JONES, ANGELA D | Former resident | $0.00 | $863.00 | $863.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H103 | PEREZ, CELINDA | Former resident | $2,299.00 | $15,024.00 | $12,725.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H103 | SANCHEZ HERNANDEZ, LUCIA YURI | Current resident | $0.00 | $3,405.00 | $79.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H104 | GORDON, FELICIA D | Former resident | $0.00 | $7,658.00 | $7,658.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H104 | MENDIOLA, GLORIA | Former resident | $5,771.00 | $5,790.00 | $19.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H104 | MENDOZA, MICHELL A | Former resident | $0.00 | $1,594.00 | $1,594.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H104 | CALVO-FAUSTINOS, MA GUADALUPE | Current resident | $758.00 | $2,189.00 | $-209.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H105 | HARRISON, KAYLA M | Former resident | $0.00 | $1,094.00 | $1,094.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H105 | NAULLS, BERNETTA A | Former resident | $0.00 | $5,997.00 | $5,997.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H105 | BEJARANO, MARY | Current resident | $2,619.00 | $37,571.00 | $29,492.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H106 | SELLTTER, JESSICA N | Former resident | $0.00 | $1,128.00 | $1,128.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H106 | BOYLE, KHADI JAH T | Former resident | $0.00 | $314.00 | $314.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H106 | FUENTES APARICIO, ESMERALDA J | Former resident | $2,529.00 | $27,405.50 | $24,876.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H106 | CAMACHO, JASMIN | Current resident | $0.00 | $2,694.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H107 | NELSON, AYANA R | Former resident | $0.00 | $1,212.00 | $1,212.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H107 | RANGEL, JUANA | Current resident | $1,197.00 | $5,834.00 | $-60.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H108 | BELTRAN, ROXANA M | Former resident | $0.00 | $2,988.00 | $2,988.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H108 | MEJIA, MONIQUE M | Current resident | $4,044.00 | $6,506.00 | $-1,546.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H109 | GRANT, ROSIEMARIA A | Former resident | $0.00 | $1,303.00 | $1,303.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H109 | FERGUSON, FLORENCE M | Former resident | $2,422.00 | $3,989.00 | $1,567.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H109 | ROMO, DAVID | Current resident | $0.00 | $3,658.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H110 | LONG, TANGA R | Former resident | $1,736.00 | $3,384.00 | $1,648.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H110 | CARRANZA, RUFINA | Current resident | $3,183.00 | $6,632.00 | $-600.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H111 | POWELL, SHARON M | Former resident | $247.00 | $2,407.00 | $2,160.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H111 | VALENCIA, BEATRICE TERESA | Current resident | $4,903.00 | $10,937.00 | $-160.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H111 | WILLIS, VERONICA M | Former resident | $800.00 | $860.00 | $60.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H112 | HERNANDEZ, JENNIFER C | Former resident | $0.00 | $2,064.00 | $2,064.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H112 | MOLINA, NELLY JEANNETTE | Current resident | $592.00 | $5,815.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H213 | CHAVEZ, JENIFER | Current resident | $1,436.00 | $5,578.00 | $2,115.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H214 | MASON, GENESSE E | Former resident | $0.00 | $914.00 | $914.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H214 | MARTIN, DIONE D | Former resident | $0.00 | $96.00 | $96.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H214 | PAREDES NAVARRO, MARTHA A | Current resident | $1,348.00 | $3,137.00 | $-179.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H215 | BLUMENBERG, SUSIE L | Former resident | $102.00 | $684.00 | $582.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H215 | ANCIRA, AIDEE | Current resident | $1,906.00 | $5,253.00 | $-233.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H216 | DAVIS, KESHIA R | Current resident | $1,557.00 | $12,622.00 | $5,605.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H217 | Jones, Denishay M | Former resident | $2,174.00 | $13,888.00 | $11,714.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H217 | ARIAS, GLORIA M | Current resident | $2,209.00 | $4,315.00 | $-1,935.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H218 | HOWLETT, KEENAN L | Current resident | $5,413.00 | $8,175.00 | $532.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H219 | CELESTINE, SHONDRA M | Former resident | $0.00 | $1,273.00 | $1,273.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H219 | SANCHEZ, JOANA MARLEN | Current resident | $3,643.00 | $11,104.00 | $1,821.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H220 | HOLMAN JR, GREGORY E | Former resident | $1,905.00 | $4,146.00 | $2,241.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H220 | SERRANO, SANDRA JASMIN | Current resident | $3,148.00 | $7,068.00 | $159.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H221 | HOLLEY, FELICIA R | Former resident | $0.00 | $5,307.00 | $5,307.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H221 | WILLIAMS, RESHONDA L | Former resident | $952.00 | $3,512.00 | $2,560.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H221 | ESPARZA, ROSE M | Current resident | $406.00 | $4,635.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H222 | THOMPSON, SHIRLEY E | Former resident | $1,192.00 | $11,481.00 | $10,289.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H222 | WILLIAMS, SUSIE | Current resident | $1,615.00 | $4,947.00 | $-942.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H223 | LUVIANO MALDONADO, MARGARITA | Current resident | $8,076.00 | $20,845.00 | $6,325.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H224 | AVILA, CELIA | Current resident | $5,733.00 | $12,203.00 | $500.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J101 | TAYLOR, BERTHA M | Current resident | $0.00 | $5,754.00 | $1,065.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J102 | LEONARD, MARY G | Former resident | $0.00 | $896.00 | $896.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J102 | HAYES, CRYSTAL W | Current resident | $6,286.00 | $12,045.00 | $710.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J103 | LEWIS JR, ROBERT | Former resident | $0.00 | $141.00 | $141.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J104 | ALVARADO MOLINA, MARIANELA | Current resident | $1,466.00 | $5,057.00 | $200.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J205 | STAPLES, FELICIA | Current resident | $175.00 | $3,373.00 | $643.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J206 | JOHNSON, ROSHAWNDA M | Former resident | $0.00 | $802.00 | $802.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J206 | VALDEZ, JENNIFER | Current resident | $66.00 | $3,355.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J207 | RIVAS, FLORENTINO V | Former resident | $0.00 | $520.00 | $520.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J208 | BLACK, LASONYA Y | Current resident | $4,230.00 | $8,140.00 | $408.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J309 | WOODS, BRITTANIA | Current resident | $2,450.00 | $11,498.98 | $4,359.98 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J310 | MINTZ, DEBORAH a | Current resident | $80.00 | $4,578.00 | $732.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J311 | VALLE, JUANITA | Current resident | $71.03 | $2,690.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J312 | MARTINEZ, OTILIA | Former resident | $1,775.00 | $2,109.00 | $334.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| J312 | IVORY, SHANICE M | Current resident | $0.00 | $4,051.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K101 | KERR, KEYANNA | Current resident | $6,797.00 | $11,225.00 | $737.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K102 | ALVAREZ JUAREZ, MARIA G | Former resident | $0.00 | $776.00 | $776.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K102 | LUNA, STEPHANIE M | Current resident | $0.00 | $4,870.00 | $1,039.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K103 | SALGADO, MANUEL | Former resident | $0.00 | $1,812.00 | $1,812.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K103 | JUAREZ, SOLEDADA | Current resident | $1,965.00 | $4,860.00 | $-768.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K103 | GRIFFIN, BETTY J | Former resident | $0.00 | $798.00 | $798.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K104 | HAGLER, KYNYATA K | Former resident | $0.00 | $740.00 | $740.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K205 | JACOBS, DANTE J | Current resident | $0.00 | $5,166.00 | $880.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K206 | PERDERGROW, LADONNA | Current resident | $2,107.00 | $17,352.00 | $-67.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K206 | JONES, APRIL D | Former resident | $0.00 | $818.00 | $818.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K207 | MCINTOSH II, HENRY E | Former resident | $0.00 | $1,364.00 | $1,364.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K207 | BROWN, REMY R | Current resident | $3,004.00 | $3,875.00 | $-664.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K208 | CORTES, ROSA R | Current resident | $839.00 | $8,852.00 | $3,333.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K309 | RATH HONG, SERENA SOTHEA | Former resident | $638.00 | $4,320.00 | $3,682.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K309 | Lopez, Carmen | Former applicant | $0.00 | $550.00 | $550.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K309 | GIBSON, ROMEL | Current resident | $13.00 | $2,477.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K310 | WILEY, BRANDY RENEE | Current resident | $3,699.00 | $5,783.00 | $-1,416.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K310 | DIGGINS, CATRINA | Former resident | $0.00 | $117.00 | $117.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K310 | MARQUEZ, DALILA | Former resident | $2,498.00 | $6,202.00 | $3,704.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K311 | DUMAS, PATRICIA | Former resident | $0.00 | $821.00 | $821.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K311 | STAFFORD, RONALD | Former resident | $4,213.00 | $22,036.00 | $17,823.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K311 | Williams, ANDREA DANIELA | Current resident | $0.00 | $1,904.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K312 | WRIGHT, RANDISSA D | Former resident | $0.00 | $655.00 | $655.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| K312 | HOLDEN, CORA D | Current resident | $0.00 | $4,315.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L101 | MILLER, JOHNNIE L | Current resident | $312.50 | $3,994.00 | $283.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L102 | ROBINSON, MARY A | Former resident | $1,825.00 | $3,661.00 | $1,836.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L102 | YVANEZ, ANGELICA Y | Current resident | $0.00 | $3,950.00 | $507.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L103 | CHAVEZ, MARINA A | Current resident | $7.00 | $3,300.00 | $522.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L104 | WHITSETT, LAURA J | Former resident | $0.00 | $2,151.00 | $2,151.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L104 | MC CUNE, MARIAN | Current resident | $6.00 | $4,558.00 | $718.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L205 | PATTERSON, KEIRA | Former resident | $0.00 | $2,729.00 | $2,729.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L205 | DIGGINS II, MICHAEL N | Current resident | $480.00 | $2,864.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L206 | FARRIS, AJA R | Former resident | $0.00 | $1,858.00 | $1,858.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L206 | TIPPIN, JUSTICE L | Current resident | $1,209.00 | $4,045.00 | $-980.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L207 | DAVIS, SHAWN D | Former resident | $0.00 | $714.00 | $714.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L207 | HERNANDEZ, JUAN | Former resident | $0.00 | $610.00 | $610.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L207 | JERNIGAN, LYNDON D | Current resident | $0.00 | $2,702.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L208 | HAGLER, LASHANDA A | Former resident | $0.00 | $1,125.00 | $1,125.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L208 | MURPHY, DESHAY L | Current resident | $100.00 | $4,105.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L309 | ALFARO-BELTRAN, EVELYN N | Current resident | $72.00 | $5,428.00 | $1,280.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L310 | BUTLER, TERRY D | Current resident | $72.00 | $4,043.00 | $818.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L310 | COOPWOOD, ERICA | Former resident | $0.00 | $136.00 | $136.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L310 | HALE, DAROL RAYNARD | Former resident | $2,903.00 | $4,913.00 | $2,010.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L311 | GRAJEDA CAMPOS, MARIA I | Former resident | $0.00 | $852.54 | $852.54 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L311 | HUGHES, CHARLES R | Current resident | $352.00 | $2,192.00 | $1,238.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L312 | MILLS, SHANNON M | Former resident | $793.00 | $2,912.00 | $2,119.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L312 | WIDBY, RUBY T | Former resident | $0.00 | $950.00 | $950.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| L312 | DREAR, JAMIE | Current resident | $407.00 | $3,026.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| A215 | ASKEW, TANESA | Former resident | $4,519.00 | $1,234.00 | $-3,285.00 | [ ] Confirm paid | — |
| C211 | GANDY, MACHELLE | Current resident | $333.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| D102 | REESE, TOMIKA C | Former resident | $4,092.00 | $2,813.00 | $-1,279.00 | [ ] Confirm paid | — |
| D108 | FLORES, ELVIA | Current resident | $15,136.00 | $10,725.00 | $-6,231.00 | [ ] Confirm paid | — |
| D218 | GONZALEZ, IVAN R | Former resident | $1,686.00 | $1,591.00 | $-95.00 | [ ] Confirm paid | — |
| D220 | FRAIRE, NANCY | Former resident | $1.00 | $0.00 | $-1.00 | [ ] Confirm paid | — |
| E107 | HILTON, QUAEMIA S | Former resident | $1,844.00 | $1,465.00 | $-379.00 | [ ] Confirm paid | — |
| F208 | GRANT, ROSIEMARIA A | Current resident | $80.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| G101 | SCOTT, JUSTINE A | Former resident | $7,126.00 | $3,538.00 | $-3,588.00 | [ ] Confirm paid | — |
| G101 | SILVA, SUHEY | Former resident | $8,903.00 | $2,319.00 | $-6,584.00 | [ ] Confirm paid | — |
| G217 | MANRIQUEZ, EDITH | Former resident | $7,936.00 | $7,799.50 | $-136.50 | [ ] Confirm paid | — |
| H221 | BOYD, SASHA LATIKA | Former resident | $5,369.00 | $3,457.99 | $-1,911.01 | [ ] Confirm paid | — |
| J103 | LAZARO, ROSA O | Current resident | $7,998.00 | $6,681.00 | $-1,170.00 | [ ] Confirm paid | — |
| J207 | STONE, MICHELLE A | Current resident | $2,242.00 | $1,821.00 | $-783.00 | [ ] Confirm paid | — |
| J309 | RAMIREZ SANCHEZ, GERARDO | Former applicant | $200.00 | $0.00 | $-200.00 | [ ] Confirm paid | — |
| J311 | BRANDON, LINDA | Former resident | $8,725.00 | $7,292.00 | $-1,433.00 | [ ] Confirm paid | — |
| K104 | RISON, DARLENA | Current resident | $1,061.00 | $1,057.00 | $-4.00 | [ ] Confirm paid | — |
| K206 | SERRANO, RAQUEL C | Former resident | $2,247.00 | $1,812.00 | $-435.00 | [ ] Confirm paid | — |
| L206 | ZUNIGA, ITZEL E | Former resident | $2,551.00 | $2,394.00 | $-157.00 | [ ] Confirm paid | — |
| L208 | LIPSEY, FILEENAM | Former resident | $3,508.00 | $2,654.00 | $-854.00 | [ ] Confirm paid | — |
| L312 | HUDSON, KENISHIA DANIELLE | Former resident | $3,224.00 | $2,372.00 | $-852.00 | [ ] Confirm paid | — |
| NONE | HAP common ledger | Misc. Income | $15,101.00 | $0.00 | $0.00 | [ ] Confirm paid | — |

## Resident Balance Follow-Up — Paid / Zero Balance

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| K309 | WRIGHT, LANISHA D | Former resident | $165.00 | $165.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property's supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*