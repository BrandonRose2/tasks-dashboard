# Walnut Hill — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 5414947**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/05/2026 |
| Property manager | Monekia Dabney — walnut@apartmentcorp.com — (686) 205-6694 |
| Regional manager | Johann Armstead — johann@apartmentcorp.com — (804) 481-2503 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Delinquency spreadsheet | `5414947_Walnut Hill_Delinquent - Excel_58.xls` |
| Ledger accounts for review | 235 resident accounts |
| Residents with amount owed | 201 accounts; $613,677.00 |
| Prepaid / credit accounts | 33 accounts; $-20,159.44 |
| Availability entries | 0 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit's reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| — | — | No unit-status entries in the selected source export | [ ] Verified | __________________ |

## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 101 - B | Hampton, Kanesha | Former resident | $0.00 | $1,518.81 | $1,518.81 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 101 - B | Bradshaw, Darrius Terrell | Current resident | $0.00 | $6,555.66 | $1,992.55 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 101 - F | *Hogue, Donna | Former resident | $0.00 | $3,320.48 | $2,883.68 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 101 - I | Ward, Jasmine | Former resident | $0.00 | $1,026.10 | $1,026.10 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 101 - I | Shell, Jamice Cierra | Current resident | $0.00 | $1,531.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 101 - J | Lucas, Ariel | Former resident | $0.00 | $4,119.06 | $4,119.06 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 101 - J | Thomas, Roshawn L | Current resident | $0.00 | $4,825.34 | $135.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 101 - K | Cheathman, Pierre | Former applicant | $0.00 | $3.12 | $3.12 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 101 - L | Humphrey, Phillip | Former resident | $0.00 | $650.65 | $650.65 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 103 - A | Williams, Shamyria | Current resident | $0.00 | $1,531.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 103 - B | Rogers, Bryson | Former resident | $0.00 | $5,692.53 | $5,692.53 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 103 - C | Bright, Brenda | Former resident | $0.00 | $5,391.10 | $5,391.10 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 103 - D | Hamilton, Dania | Former resident | $0.00 | $9,349.78 | $9,349.78 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 103 - E | Coleman, Amiyah | Former resident | $0.00 | $8,782.70 | $8,782.70 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 103 - F | Fitzgerald, Brenda | Current resident | $0.00 | $4,509.15 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 103 - J | Robinson, Marion | Former resident | $0.00 | $2,183.90 | $2,183.90 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 103 - J | Boone, Tiera S | Current resident | $0.00 | $1,400.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 103 - K | Williamson, Abeni | Current resident | $0.00 | $1,457.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 103 - L | Jah, Edna | Former resident | $0.00 | $74.17 | $74.17 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 104 - A | Hill, Nocosia | Former resident | $0.00 | $3,871.92 | $3,871.92 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 104 - A | *Harris, Arkima | Former resident | $0.00 | $5,620.95 | $5,039.15 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 104 - A | Berry, Alisea m | Former applicant | $0.00 | $3.12 | $3.12 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 104 - A | Crittendon, Tiara | Current resident | $0.00 | $911.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 104 - B | Townes, Brena | Former resident | $0.00 | $889.45 | $889.45 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 104 - B | Taylor, Azaria | Former resident | $0.00 | $5,979.78 | $5,979.78 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 104 - C | Green, Stacy | Former resident | $0.00 | $1,614.43 | $1,614.43 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 104 - C | Hines, Andrea | Current resident | $0.00 | $1,695.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 104 - E | Daniels, Garlette | Former resident | $0.00 | $11.44 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 104 - E | Taylor, Juaron Martaze | Current resident | $0.00 | $1,670.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 104 - H | Thompson, Whitney | Current resident | $0.00 | $1,349.53 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 104 - I | Guerrero, Marisa | Current resident | $0.00 | $1,655.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 104 - J | Jackson, Porchelle | NTV | $0.00 | $1,582.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 104 - K | Morgan, Latanya | Current resident | $0.00 | $1,670.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 104 - L | Bonner, Tequitsha | Current resident | $0.00 | $554.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 105 - D | Drake, Jennifer | Current resident | $0.00 | $593.10 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 105 - D | Dudley, Jamil T | Former applicant | $0.00 | $3.12 | $3.12 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 105 - F | Neal, Tequanna | Former resident | $0.00 | $10,157.84 | $10,157.84 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 105 - F | Wyche, Khalilha Mi'yuana Rolinda | Current resident | $0.00 | $5,166.41 | $470.67 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 105 - G | Simms, Eshya | Former resident | $0.00 | $8,786.28 | $8,786.28 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 105 - G | Davis, Cynthia | Current resident | $0.00 | $4,680.36 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 105 - I | Gamble, Kimberley | Former resident | $0.00 | $1,541.86 | $1,541.86 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 105 - K | Williams, Raven | Former resident | $0.00 | $5,339.65 | $5,339.65 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 105 - K | Green, Rena | Former resident | $0.00 | $1,635.82 | $1,635.82 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 105 - K | White, Nejla M | Current resident | $0.00 | $2,391.33 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 201 - B | Hill, Celena | Former resident | $0.00 | $3,989.96 | $3,989.96 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 201 - B | Woodley, Destiny | Former resident | $0.00 | $4,201.82 | $4,201.82 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 201 - B | Johnson, Jamar | Current resident | $100.00 | $2,819.68 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 201 - C | McCoy, Donte | Former resident | $0.00 | $1,423.70 | $1,423.70 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 201 - D | Pyron, Karen | Former resident | $0.00 | $7,614.50 | $7,614.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 201 - D | White, Khi'Zhane Arvey | Current resident | $0.00 | $135.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 201 - E | Byrd-Smith, Royshawnda Leeshae | Current resident | $0.00 | $50.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 201 - F | Dodson, Nyesha | Former resident | $0.00 | $12,337.13 | $12,337.13 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 201 - G | Foster, Amari | Current resident | $0.00 | $5,468.08 | $2,691.14 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 201 - H | Barnes, Ebony | Current resident | $0.00 | $1,402.52 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 201 - I | Thompson, Raven | Former resident | $0.00 | $1,807.53 | $1,807.53 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 201 - I | Cepeda, Kiara N | Former applicant | $0.00 | $3.12 | $3.12 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 201 - I | Wyatt, Tauzhane | Former resident | $0.00 | $3,209.95 | $3,209.95 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 201 - L | Young, Matthew | Former resident | $0.00 | $5,427.33 | $5,427.33 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 201 - L | Hite, Kadijah | Former resident | $0.00 | $7,194.74 | $7,194.74 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 201 - L | Starr, Camille N | Current resident | $0.00 | $2,090.43 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 202 - A | Claiborne, Shirley | Former resident | $0.00 | $2,996.98 | $2,996.98 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 202 - A | Guillory, Tionna | Former resident | $0.00 | $289.59 | $289.59 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 202 - A | Pierce, Datron L | Former resident | $0.00 | $276.81 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 202 - B | King, Delavonte | Current resident | $0.00 | $172.50 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 202 - C | Jackson, Shaunderia | Current resident | $0.00 | $1,480.54 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 202 - D | Alexander, Sharmane D | Current resident | $0.00 | $1,173.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 202 - E | Goode, Corionna | Former resident | $0.00 | $236.19 | $236.19 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 202 - E | Luten-Yates, Kim Denise | Current resident | $0.00 | $236.77 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 202 - F | White, Latasha | Former resident | $0.00 | $13.36 | $13.36 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 202 - F | Booker, Candace Wavekesta | Current resident | $0.00 | $1,526.56 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 202 - G | Williams, Corey | Former resident | $0.00 | $5,291.02 | $5,291.02 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 202 - G | BOYD, JASMINE | Former resident | $0.00 | $3,497.48 | $3,497.48 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 202 - G | Prince, Rahkeem | Former resident | $0.00 | $5,319.21 | $5,319.21 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 202 - I | Shepherd, Joy | Former resident | $0.00 | $522.07 | $522.07 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 202 - J | Cole, Aaron | Current resident | $0.00 | $1,480.65 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 202 - K | Stokes, Tkeira | Former resident | $0.00 | $564.52 | $564.52 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 202 - L | Jackson, Jacqueline | Former resident | $0.00 | $3,861.60 | $3,861.60 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 202 - L | Taylor-McPherson, Aaniyah | Former resident | $0.00 | $6,304.26 | $6,304.26 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 202 - L | Fells, Denisha Shantel | Current resident | $0.00 | $50.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 203 - A | Parham Jr, Berwin | Former resident | $0.00 | $14,694.93 | $14,694.93 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 203 - A | Brown, Delica | Former resident | $0.00 | $4,303.05 | $4,303.05 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 203 - B | Winn, Latoya | Former resident | $0.00 | $1,298.70 | $1,298.70 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 203 - B | sMITH, AUYANA | Current resident | $0.00 | $1,482.87 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 203 - C | Easter, Aaron Dion | Current resident | $0.00 | $1,670.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 203 - D | Jones, Johnaysha Medale | Current resident | $0.00 | $1,550.95 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 203 - E | Johnson III, William | Current resident | $0.00 | $1,014.94 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 203 - F | Ferebee, Davon | Current resident | $0.00 | $1,051.42 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 203 - G | Watson, Brandon | Current resident | $0.00 | $1,840.05 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 203 - I | Braxton, Brittany Marie | Current resident | $0.00 | $49.71 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 203 - J | White, Shameka | Former resident | $0.00 | $673.50 | $673.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 203 - J | Hicks, Sincere | Former resident | $0.00 | $5,900.80 | $5,900.80 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 203 - K | Coleman, Dominic | Former resident | $0.00 | $1,496.84 | $1,346.84 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 203 - L | Humphrey, Jessica | Current resident | $0.00 | $1,680.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 204 - B | Seaborne, Rashaun | Former resident | $0.00 | $12,101.64 | $12,101.64 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 204 - B | Wilson, Deasia | Former resident | $0.00 | $8,380.35 | $8,380.35 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 204 - C | King, Marcus | Former resident | $0.00 | $4,797.99 | $4,797.99 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 204 - C | Hall, Shareeta M | Current resident | $0.00 | $835.79 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 204 - D | Bridgeforth, Roshawnda | Former resident | $0.00 | $8,333.55 | $8,333.55 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 204 - D | Rives, Lakeisha | Former resident | $0.00 | $1,545.79 | $1,545.79 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 204 - D | Hinton, Juanita Y | Current resident | $0.00 | $3,287.23 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 204 - E | McNair, Senethea Vontrese | Current resident | $0.00 | $1,670.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 204 - F | Childs, Tonya | NTV | $0.00 | $1,523.70 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 204 - G | Mitchell, Jasmine | Former resident | $0.00 | $576.15 | $576.15 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 204 - G | Stevenson, Desiree | Current resident | $0.00 | $1,694.97 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 204 - H | Ware, Sharon | Former resident | $0.00 | $8,509.17 | $8,509.17 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 204 - H | Creer, DaVon | Current resident | $0.00 | $1,020.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 204 - I | Parker, Melissa | Current resident | $0.00 | $1,393.75 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 204 - J | Gash, Dominique | Former resident | $0.00 | $646.04 | $646.04 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 204 - K | Tucker, Shonte | Former resident | $0.00 | $900.12 | $900.12 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 204 - L | Rock, Kellye | Former resident | $0.00 | $11,803.56 | $11,803.56 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 204 - L | Smith, Ayanah | Current resident | $0.00 | $1,872.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 301 - B | Etterson, Rickey | Current resident | $0.00 | $709.87 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 301 - C | Turberville, Katrina | Former resident | $0.00 | $68.52 | $68.52 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 301 - D | Dabney, Brandon | Current resident | $0.00 | $1,507.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 301 - F | McLaughlin, TaQuona | Current resident | $94.00 | $714.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 301 - G | Mckeever, Latrice | Former resident | $0.00 | $6,007.63 | $6,007.63 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 301 - G | Lambert, Danielle P | Former applicant | $0.00 | $3.12 | $3.12 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 301 - G | Baugh, Chasity Blair | Current resident | $0.00 | $1,670.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 301 - H | Briggs, Candace | Former resident | $0.00 | $6,359.67 | $6,359.67 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 301 - I | Schehr, Kerry | Former resident | $0.00 | $7,986.45 | $7,986.45 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 301 - I | Pegram, Tonya Chambliss | Current resident | $0.00 | $4,693.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 301 - J | Richardson, DuJuan | Current resident | $0.00 | $1,482.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 302 - A | Taylor, Josephine Rene | Current resident | $0.00 | $4,815.07 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 302 - B | Williams, Jacqueline | Former resident | $0.00 | $300.17 | $300.17 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 302 - C | Hunt, Timothy Lee | Current resident | $0.00 | $1,095.75 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 302 - D | Spence, Kristel | Current resident | $0.00 | $383.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 302 - E | White-Gee, Mariah Mercedes | Current resident | $0.00 | $1,569.29 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 302 - F | Conner, Kiesha | Former resident | $0.00 | $689.10 | $689.10 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 302 - F | Starling, Omar R | Current resident | $0.00 | $1,719.26 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 302 - I | Green, Shernrika | NTV | $0.00 | $176.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 302 - J | Ludlow, Tunisha | Former applicant | $0.00 | $3.12 | $3.12 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 302 - J | Hall, Marvell S | Former resident | $0.00 | $13,515.68 | $13,515.68 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 302 - J | William, Sadiq | Former resident | $0.00 | $4,594.36 | $2,953.46 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 302 - K | Hobson, Latonya | Former resident | $0.00 | $243.47 | $243.47 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 302 - K | Scott, Ashley | Former resident | $0.00 | $8,042.75 | $8,042.75 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 303 - A | Jones-Epps, Sandra | Former resident | $0.00 | $2,033.44 | $2,033.44 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 303 - A | Redwine, Shelly Y | Current resident | $0.00 | $370.80 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 303 - B | Brent, Ashunta | Current resident | $0.00 | $100.12 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 303 - D | McNair, Kim | Former resident | $0.00 | $310.23 | $310.23 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 303 - D | Davis, Elizabeth | Former resident | $0.00 | $1,231.20 | $1,025.28 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 303 - D | Williams, Jada Vachane | Current resident | $0.00 | $988.87 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 303 - F | McDonald, Jasmin | Former resident | $0.00 | $8,895.91 | $8,895.91 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 303 - F | Jones, Jadecca S | Current resident | $0.00 | $1,479.65 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 303 - G | Boone, Karen | Current resident | $0.00 | $1,457.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 303 - I | Chatman, Tierra | Former resident | $0.00 | $12,106.21 | $12,106.21 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 303 - I | Barrett, Kaiyla | Current resident | $0.00 | $303.09 | $55.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 303 - J | Frye, Shauna C | Former applicant | $0.00 | $3.12 | $3.12 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 303 - J | Fells, Rickshell S | Current resident | $0.00 | $1,507.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 303 - K | Brooks, Lakia | NTV | $0.00 | $1,375.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 303 - L | Rice, Tiara | Former resident | $0.00 | $11,669.76 | $11,669.76 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 304 - B | Bailey, Ronece | Former resident | $0.00 | $88.55 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 304 - C | Abbey, Benita | Former resident | $0.00 | $3,627.43 | $3,627.43 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 304 - C | Joye, Dexston | Former resident | $0.00 | $7,665.88 | $7,665.88 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 304 - C | Vaughan, Shannon | Former resident | $0.00 | $6,471.12 | $3,293.87 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 304 - E | Green, Joseph | Current resident | $0.00 | $1,100.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 304 - H | Sumler, Sharronette | Former resident | $0.00 | $1,323.19 | $1,323.19 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 304 - H | Dobson, Sabrina | Current resident | $0.00 | $1,579.60 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 304 - I | King, Dominique | Former resident | $0.00 | $56.16 | $56.16 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 304 - J | Joye, Asia | Former resident | $0.00 | $2,097.62 | $2,097.62 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 304 - J | Kluttz, Darylmoni Taylor | Current resident | $0.00 | $2,360.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 304 - K | Mayers, Biancca | Former resident | $0.00 | $3,418.22 | $3,418.22 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 304 - K | Stallworth Fowlkes, Jalen Alexander | Current resident | $0.00 | $1,670.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 402 - A | Woodley, Destiny | Former applicant | $0.00 | $3.12 | $3.12 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 402 - A | Davis, Mannoote | Former resident | $0.00 | $10,311.60 | $10,311.60 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 402 - A | Desmore, Na'Chelle | Current resident | $0.00 | $2,383.76 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 402 - C | Thomas, Kathy | Former resident | $0.00 | $106.45 | $106.45 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 402 - C | Ridley, Desha | Former resident | $0.00 | $4,617.35 | $4,617.35 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 402 - D | Cox, Barbara | Former resident | $0.00 | $1,537.49 | $1,537.49 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 402 - D | Jones, Jr, Calvin Edward | Current resident | $0.00 | $531.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 402 - E | Mejia, Bryan | Former resident | $0.00 | $6,215.42 | $6,215.42 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 402 - E | Taylor, Jahbriel S | Former applicant | $0.00 | $3.12 | $3.12 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 402 - F | Collazo, Chamara | Former applicant | $0.00 | $3.20 | $3.20 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 402 - F | Seward, Patrice S | Current resident | $0.00 | $4,501.64 | $336.81 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 402 - G | Smith III, Wilbert Lee | Current resident | $0.00 | $514.67 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 402 - H | Davis, Michelle Denise | Current resident | $0.00 | $6,662.43 | $2,165.49 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 402 - I | Milam, Erica | Former resident | $0.00 | $1,003.94 | $1,003.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 402 - I | Taylor, Ashley | Former resident | $0.00 | $7,888.89 | $7,888.89 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 402 - I | Couch, Ty'Neshia Marqushia | Current resident | $0.00 | $1,453.05 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 402 - J | Daniel, Victoria | Former resident | $0.00 | $5,312.23 | $5,312.23 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 402 - J | Day, Ebony A | Current resident | $0.00 | $4,457.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 402 - K | Bland, Octavia | Former resident | $0.00 | $4,495.75 | $4,495.75 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 402 - L | Jackson, Tresor | Former resident | $0.00 | $3,473.01 | $3,473.01 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 402 - L | Pitt, Jasmine | Former resident | $0.00 | $5,496.68 | $5,496.68 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 402 - L | Taylor, Makiyah Kailei | Current resident | $0.00 | $4,794.84 | $280.36 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 501 - A | Ardey, Denise Marie | Current resident | $0.00 | $1,620.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 501 - B | Crenshaw, Daketa | Former resident | $0.00 | $2,270.75 | $2,270.75 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 501 - B | Brown, Gerald Alex | Current resident | $0.00 | $5,702.74 | $527.46 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 501 - D | Wyatt, Marketta | Current resident | $0.00 | $1,568.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 501 - E | Hayman, Jermikaa | Former resident | $0.00 | $1,317.96 | $1,317.96 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 501 - F | Browning, Selena | Former resident | $0.00 | $7,319.67 | $7,319.67 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 501 - G | Rives, Asharma | Former resident | $0.00 | $12,293.28 | $12,293.28 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 501 - H | Richardson, Shaye' | Former resident | $0.00 | $6,936.73 | $6,936.73 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 501 - H | Jordan, Brenda Michelle | Current resident | $0.00 | $1,720.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 501 - I | Mosby, Tierra | Former resident | $0.00 | $2,668.81 | $2,668.81 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 501 - I | Wyatt, Demetria | Former resident | $0.00 | $4,184.56 | $4,184.56 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 501 - K | Reed, Denitra | Former resident | $0.00 | $5,377.97 | $5,377.97 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 501 - K | Whitaker, Crystal | Current resident | $0.00 | $1,873.34 | $41.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 501 - L | Jackson, Vermel | NTV | $0.00 | $2,100.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| WAIT | Adams, Leon D | Applicant | $0.00 | $50.00 | $50.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| WAIT | Powell, Amber M | Applicant | $0.00 | $50.00 | $50.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| WAIT | Rutledge, Irijah A | Applicant | $0.00 | $50.00 | $50.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 101 - D | Fisher, Bryant | Current resident | $23.90 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 101 - E | Mason, Earl | Current resident | $49.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 101 - G | Hayes, Tamara | Current resident | $68.88 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 101 - K | Smith, Tauryn M | Current resident | $1,982.00 | $1,461.81 | $-991.00 | [ ] Confirm paid | — |
| 103 - B | Dudley, Aaron | Applicant | $250.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 105 - B | Johnson, Maurissa | Current resident | $485.21 | $0.00 | $-485.21 | [ ] Confirm paid | — |
| 105 - E | Granderson, Darlean | Current resident | $78.11 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 105 - H | Vaughan, Cynthia | Current resident | $339.14 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 105 - L | Geter, Marche | Current resident | $214.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 201 - A | Smith, Barbara | Current resident | $1,182.00 | $246.60 | $0.00 | [ ] Confirm paid | — |
| 201 - C | Dowe, Brianna | Current resident | $305.58 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 201 - J | Reese, Bonita | Current resident | $100.83 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 202 - I | Hinton, Jermaine | Applicant | $674.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 202 - K | Dishmond, Anjanette Marie | Current resident | $0.18 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 203 - F | Savage, Diangelo | Former applicant | $20.00 | $0.00 | $-20.00 | [ ] Confirm paid | — |
| 203 - J | Hollman, Shakinah Renasha | Current resident | $14.71 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 204 - A | Carroll, April Nancy | Current resident | $86.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 204 - B | Harris, Tashane Ambra | Current resident | $12,268.36 | $0.00 | $-12,268.36 | [ ] Confirm paid | — |
| 301 - A | Jackson, Jenetta | Current resident | $9.97 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 301 - K | Thomas, Shenequel | Current resident | $3,400.00 | $1,254.82 | $0.00 | [ ] Confirm paid | — |
| 301 - L | Leonard, Nija | Current resident | $150.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 302 - B | Turner, Rakawn | Former applicant | $46.88 | $0.00 | $-46.88 | [ ] Confirm paid | — |
| 302 - G | Massenburg, Tenisha | Current resident | $45.76 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 302 - K | Jones, Tierra M | Former applicant | $96.88 | $0.00 | $-96.88 | [ ] Confirm paid | — |
| 302 - L | Pettiford, Gloria | Current resident | $82.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 303 - H | Johnson, Gloria | Current resident | $7.10 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 304 - A | Jones, Jerica | Current resident | $755.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 304 - I | Brown, MarquishaP | Current resident | $0.33 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 304 - L | Medina, Gabriele Stacy | Current resident | $0.50 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 402 - B | Tolson, Vonda | Current resident | $155.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 501 - C | Willis, Lois | Current resident | $117.35 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 501 - G | Serrano Vizcaino, Richerson A | Current resident | $80.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| WAIT | Boyd, Jasmine | Former applicant | $34.00 | $0.00 | $-34.00 | [ ] Confirm paid | — |

## Resident Balance Follow-Up — Paid / Zero Balance

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 302 - C | Jackson, Johnnisa | Former resident | $2,151.00 | $2,151.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property's supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*