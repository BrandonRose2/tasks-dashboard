# Windsor Village — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 4233753**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/05/2026 |
| Property manager | Kimberly Powell — windsor@apartmentcorp.com — (318) 230-0656 |
| Regional manager | Ginger Positerry — ginger@apartmentcorp.com — (985) 637-2128 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Delinquency spreadsheet | `4233753_Windsor Village_Delinquent - Excel_58.xls` |
| Ledger accounts for review | 217 resident accounts |
| Residents with amount owed | 181 accounts; $210,508.75 |
| Prepaid / credit accounts | 36 accounts; $-28,766.69 |
| Availability entries | 0 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit's reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| — | — | No unit-status entries in the selected source export | [ ] Verified | __________________ |

## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - 101 | Mosley, Barbara N | Current resident | $24.00 | $175.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 102 | White, RonaldJay | Former resident | $0.00 | $252.00 | $252.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 102 | Harrison, Caroline Marie | Former resident | $0.00 | $592.00 | $592.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 102 | Marshall, Windy | Former resident | $0.00 | $1,498.00 | $1,498.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 102 | Mccree, Xavier Jamar | Former resident | $300.00 | $1,339.00 | $1,039.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 103 | Bridgewater, Curtis | Former resident | $0.00 | $422.00 | $422.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 103 | Singleton, Ciera T | Former resident | $0.00 | $1,807.00 | $1,807.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 103 | Hill, Joyce Juanita | Current resident | $0.00 | $69.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 104 | Mccullouch, Deborah B | Current resident | $44.00 | $75.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1001 | Murray, Shamonica | Former resident | $0.00 | $59.00 | $59.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1001 | Moore, Stevie | Former resident | $0.00 | $1,954.00 | $1,954.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1001 | Houston, Jermond | Former resident | $0.00 | $1,160.30 | $1,160.30 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1001 | Edwards, Joe Douglas | Former resident | $0.00 | $2,551.00 | $2,551.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1001 | Ivy, Paul Edwin | Former applicant | $0.00 | $60.00 | $60.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1002 | Law, Linda | Former resident | $0.00 | $2,598.74 | $2,598.74 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1002 | Blow, Gary | Former resident | $0.00 | $480.00 | $480.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1002 | Smith, Ladavion | Former resident | $0.00 | $2,774.00 | $2,774.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1003 | Cooper, Jaynie Marie | Former resident | $0.00 | $510.00 | $510.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1003 | Rochelle, Rifka | Former resident | $0.00 | $521.00 | $521.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1003 | Moore, Lashondra C | Former resident | $0.00 | $439.00 | $439.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1003 | Hubbard, Porsha | Former resident | $107.70 | $359.00 | $251.30 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1003 | Harris, Rodney | Former resident | $0.00 | $1,241.00 | $1,241.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1004 | Cornelious, Yosher Hosanna | Former resident | $413.00 | $495.00 | $82.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1004 | Logan, Tro'Nacey Anbrie | Current resident | $0.00 | $866.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1101 | Mccullouch, Frances | Former resident | $0.00 | $1,290.00 | $1,290.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1101 | Jackson, Lamarcus Ray | Former resident | $0.00 | $1,376.00 | $1,376.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1101 | Sullivan, Crystal Gale | Former resident | $822.00 | $901.00 | $79.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1102 | Greathouse, Annette | Former resident | $0.00 | $24.00 | $24.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1103 | Thomas, Clydetra | Former resident | $0.00 | $328.00 | $328.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1103 | James, Ida M | Former resident | $0.00 | $2,427.00 | $2,427.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1103 | Smith, Walter none | Current resident | $0.00 | $777.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1201 | Marshall, Larissa Monea | Former resident | $0.00 | $1,081.00 | $1,081.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1201 | Polk, Clifford | Former resident | $0.00 | $887.00 | $887.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1201 | Thompson, Tony | Former resident | $0.00 | $118.00 | $118.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1201 | Fisher, Mario | Former resident | $0.00 | $792.00 | $792.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1202 | Brown, SharonDenise | Former resident | $0.00 | $344.00 | $344.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1202 | Whitaker, Carrie Michelle | Former resident | $0.00 | $744.00 | $744.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1202 | Burgess, Arthur Byron | Former resident | $0.00 | $392.00 | $392.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1202 | Morris, Christopher | Former resident | $0.00 | $3,046.00 | $3,046.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1202 | Thompson, Izanna | Former resident | $0.00 | $850.00 | $850.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1202 | Smith, Gregory Wayne | Current resident | $0.00 | $2.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1203 | Kelly, Laquita | Former resident | $0.00 | $3,942.00 | $3,942.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1204 | Smith, Cordairo | Former resident | $0.00 | $1,944.50 | $1,944.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1204 | Wallace, Tyketa K | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1204 | Bryant, Antonio | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1204 | Collins, Jamierenee R | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1204 | Stanley, Willie Edward | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1301 | Ross Jr, Albert Earl | Former resident | $0.00 | $1,623.00 | $1,623.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1301 | Love, Shaquita | Former resident | $0.00 | $206.00 | $206.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1301 | Lattin, Jashaylan S | Current resident | $40.00 | $141.00 | $57.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1302 | Johnson, Starleah | Former resident | $0.00 | $955.00 | $955.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1302 | Wright, Felicia | Former resident | $0.00 | $471.00 | $471.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1302 | Mathieu, Shemelia | Former resident | $103.00 | $1,757.58 | $843.58 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1302 | Miller, Brenda | Former resident | $0.00 | $912.00 | $912.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1302 | Jefferson, Kevineshia Roshell | Current resident | $0.00 | $756.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1303 | Brown, Shmaine Dewayne | Former resident | $0.00 | $10,592.00 | $10,592.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1303 | Bryant, Sharandra Chanelle | Former resident | $0.00 | $1,514.00 | $1,514.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1303 | Rasberry, Breonna Shelette | Former resident | $0.00 | $1,245.00 | $1,245.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1303 | Farley, Terriana L | Former resident | $0.00 | $2,195.00 | $2,195.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1303 | Brown, Samuel I | Former resident | $0.00 | $3,603.00 | $3,603.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1303 | Burns, Jackie N | Former resident | $0.00 | $1,625.00 | $1,625.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1303 | Fuller, SanijahS | Current resident | $0.00 | $1,922.98 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1304 | Dyer, Dominique | Former resident | $0.00 | $185.21 | $185.21 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1304 | Parker, Paula | Former resident | $1,006.00 | $1,345.00 | $339.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1304 | Fisher, Irene D | Former resident | $0.00 | $3,149.00 | $3,149.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1304 | Fisher, Mary C | Current resident | $0.00 | $721.10 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1401 | Ware, Jasmine | Former resident | $0.00 | $748.00 | $748.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1401 | Thomas, Cierra Sherrill | Former resident | $6.00 | $661.00 | $655.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1401 | Warren, Anjelica | Former resident | $0.00 | $1,399.00 | $1,399.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1401 | Bolden, Mercy | Former resident | $0.00 | $876.00 | $876.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1401 | Shepard, Shnequia s | Former resident | $0.00 | $1,237.00 | $1,237.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1401 | Jones, Stephen R | Former resident | $0.00 | $2,401.00 | $2,401.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1401 | Barfield, Lakysa S | Current resident | $0.00 | $188.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1402 | Walker, Carolyn | Former resident | $0.00 | $1,233.50 | $1,233.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1402 | Johnson, Joshunda | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1402 | George, Jasmine Denise | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1402 | Hill, Ja'Myrical D | Former resident | $87.00 | $500.50 | $413.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1402 | Prude, Sha' Diamond S | Former resident | $0.00 | $2,033.00 | $2,033.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1402 | Smith, Ke'Leahi | Current resident | $0.00 | $940.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1403 | Kingsley, Jaronika Denise | Former resident | $0.00 | $91.00 | $91.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1403 | Russell, Shamartha Leetaura | Former resident | $1,305.00 | $1,855.86 | $550.86 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1403 | Mathews, Destini J | Former applicant | $0.00 | $75.00 | $75.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1403 | Beverly, Tomesha M | Current resident | $0.00 | $12.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1404 | Bryant, Vivian Ann | Former resident | $0.00 | $1,057.00 | $1,057.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1404 | Johnson, Dominique | Former resident | $0.00 | $2,542.00 | $2,542.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1404 | Mason, Ahmad | Former resident | $0.00 | $3,631.00 | $3,631.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1404 | Horton, Jennifer D | Former resident | $0.00 | $2,943.00 | $2,943.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1404 | Thomas, Latasha Lynette | Former resident | $0.00 | $195.00 | $195.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 201 | Hymes, Erica | Former resident | $0.00 | $866.50 | $866.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 202 | Watkins, Louise | Former resident | $0.00 | $1,973.00 | $1,973.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 202 | Bryant, Lasandra | Former resident | $41.00 | $717.00 | $676.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 202 | Lee, Kelsey R | Former resident | $0.00 | $3,224.00 | $3,224.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 202 | Evans, Shundreka Marquita | Current resident | $0.00 | $143.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 203 | Barrett, Rose | Former resident | $0.00 | $217.00 | $217.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 203 | Jenkins, SanJuan Laques | Former resident | $0.00 | $1,125.00 | $1,125.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 203 | Ellison, Antionette T | Current resident | $0.00 | $60.00 | $24.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 204 | Feaster, Phillys | Former resident | $1,384.00 | $2,356.00 | $972.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 204 | Robinson, Candice Lashay | Former resident | $0.00 | $1,274.00 | $1,274.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 204 | Hogan, Whitney | Former resident | $0.00 | $1,142.00 | $1,142.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 204 | Black, Allisha L | Current resident | $0.00 | $517.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 301 | Brock, Ashley Denise | Former resident | $0.00 | $2,960.29 | $2,960.29 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 301 | Smith, Jerleshia Reshawn | Former resident | $0.00 | $1,398.00 | $1,398.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 301 | Stromile, Clairesia Nicole | Former resident | $0.00 | $885.00 | $885.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 301 | Williams, RuKiya | Former resident | $0.00 | $1,167.00 | $1,167.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 301 | Williams, Brittney L | Former resident | $0.00 | $3,638.00 | $3,638.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 302 | Rachal, Lindsey | Former resident | $0.00 | $5,075.00 | $5,075.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 303 | Lloyd, Sharda | Former resident | $0.00 | $407.00 | $407.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 303 | King, Delexus | Former resident | $0.00 | $173.00 | $173.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 303 | Taylor, Sir Broderick J | Former resident | $0.00 | $1,728.00 | $1,728.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 303 | Simpson, Shania M | Current resident | $0.00 | $116.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 304 | Tillman, Mary | Former resident | $101.00 | $936.00 | $835.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 401 | Johns, Michele | Former resident | $0.00 | $1,202.00 | $1,202.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 401 | Miller, Veleka | Former resident | $0.00 | $109.00 | $109.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 401 | Owens, Kimbria Dorcia | Former resident | $0.00 | $1,831.05 | $1,831.05 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 401 | Hampton, Beverly | Former resident | $0.00 | $2,105.00 | $2,105.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 401 | Lane, Valerie A | Former resident | $0.00 | $1,143.00 | $1,143.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 401 | Kelly, Jimmika Shenay | Former resident | $0.00 | $4,091.45 | $4,091.45 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 401 | Henderson, Wanda L | Current resident | $0.00 | $1,140.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 402 | Collins, LoisMarie | Former resident | $0.00 | $894.00 | $894.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 402 | Jewitt, Sheiliviyette Y | Former resident | $0.00 | $309.00 | $309.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 402 | Davis, Shacora R | Former resident | $0.00 | $2,409.99 | $2,409.99 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 402 | Bates, Destiny S | Former resident | $649.50 | $1,392.13 | $742.63 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 402 | Smith, Ashley Latoya Charee | Former resident | $0.00 | $1,124.31 | $1,124.31 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 402 | Tooke, James A | Current resident | $0.00 | $1,042.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 501 | Wynn, Juarnette | Former resident | $90.00 | $1,751.00 | $1,661.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 501 | Brown, Crystal Green | Former resident | $0.00 | $777.00 | $777.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 501 | Howard, Roshunda Denise Lane | Former resident | $0.00 | $1,101.00 | $1,101.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 501 | Jackson, Donna S | Current resident | $158.00 | $769.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 502 | Morris, Demario | Former resident | $0.00 | $1,562.00 | $1,562.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 502 | Driver, Jenita Vernay | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 601 | Walker, Loretha Rochelle | Former resident | $0.00 | $1,100.00 | $1,100.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 601 | Stewart, Labrinthany | Former resident | $0.00 | $1,943.00 | $1,943.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 601 | Wallace, Tyketa Kenee | Former resident | $0.00 | $3,478.00 | $3,478.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 602 | Flowers, Tia Lashay | Former resident | $550.00 | $1,535.00 | $985.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 602 | McCray, LaTonya Monique | Former resident | $0.00 | $406.00 | $406.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 602 | Robinson, Niasia S | Former resident | $0.00 | $1,379.00 | $1,379.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 602 | Fuggins, Kenyana Lashay | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 701 | Harmon, LaQuawndria Tashaye | Former resident | $396.00 | $534.00 | $138.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 701 | Pierce, Georgetta Nequa | Former resident | $0.00 | $1,925.00 | $1,925.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 701 | Reed, Deandra | Former resident | $0.00 | $855.00 | $855.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 701 | Logan, Tracy N | Former resident | $0.00 | $1,299.00 | $1,299.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 701 | Norman, Duane | Former resident | $0.00 | $4,452.73 | $4,452.73 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 701 | Palmer, LaShana Rene | Former resident | $0.00 | $2,458.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 702 | Knuckles, Devin | Former resident | $0.00 | $455.00 | $455.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 702 | Netter, Patricia Fay | Former resident | $0.00 | $274.00 | $274.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 702 | Cain, Kalena Lorraine | Former resident | $0.00 | $2,624.30 | $2,624.30 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 702 | Loud, Arlinda | Former resident | $0.00 | $217.00 | $217.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 702 | Jones, Lakeiveya B | Former resident | $0.00 | $4,022.00 | $4,022.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 702 | Williams, Ciarra | Former resident | $0.00 | $2,072.50 | $2,072.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 702 | Jones, Justine | Former resident | $0.00 | $1,811.00 | $1,811.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 702 | Jones, Erica L | Current resident | $0.00 | $2,851.43 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 801 | Grace, Ashley | Former resident | $0.00 | $382.00 | $382.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 801 | Morris, Ladarius Jovaughn | Former resident | $234.00 | $3,904.00 | $3,670.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 803 | Nelson, Tonya | Former resident | $0.00 | $2,101.00 | $2,101.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 803 | Morgan, Wernquanita | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 803 | Mack, Tevin Christphor | Former applicant | $0.00 | $60.00 | $60.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 803 | Mosley, A'Sharie J | Former resident | $0.00 | $1,161.00 | $1,161.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 803 | Snow, Christina | Former resident | $610.00 | $2,378.00 | $1,768.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 803 | Haynes, LaTia Deshay | Current resident | $0.00 | $238.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 804 | Bolden, Khaliah | Former resident | $0.00 | $1,494.00 | $1,494.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 804 | Feaster, Precious R | Current resident | $0.00 | $60.25 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 901 | Campbell, Kevanna A | Former resident | $0.00 | $188.00 | $188.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 901 | Parker, O'Parra | Former resident | $0.00 | $2,466.00 | $2,466.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 901 | Persley, Leeshuntania | Former resident | $182.25 | $1,458.00 | $1,275.75 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 901 | Nard, Carrie | Former resident | $0.00 | $49.00 | $49.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 901 | Criner, Maiya Taneall | Current resident | $0.00 | $2,566.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 902 | Charles, Doris | Former resident | $0.00 | $101.00 | $101.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 902 | Smith, Arica Resean | Former resident | $0.00 | $803.00 | $803.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 902 | Ealy, Jacqueline Nicole | Former resident | $0.00 | $96.00 | $96.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 902 | Smith, LaChrystal | Former resident | $0.00 | $621.00 | $621.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 902 | Mays, Martha Shayron | Current resident | $0.00 | $853.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 903 | Barrett, Zackery | Current resident | $0.00 | $1,357.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 904 | Baker, Takiya T | Current resident | $0.00 | $536.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| WAIT | Jackson, Jimmie L | Former applicant | $0.00 | $192.00 | $192.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| WAIT | Egans, Katrina L | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| WAIT | Polk, Moeisha C | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| WAIT | Henderson, Davilon A | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| WAIT | Jordan, Shyan | Former applicant | $0.00 | $5.00 | $5.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| WAIT | Oneal, Johnneisha Tachina | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| WAIT | Coleman, Briana | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| WAIT | Whitaker, Jameria F | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - 102 | Mccoy, Terrell L | Former resident | $4,466.00 | $510.00 | $-3,956.00 | [ ] Confirm paid | — |
| 1 - 102 | Minniefield, Preston Malaki | Current resident | $64.02 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 103 | Willis, Felicia Ann | Former resident | $3,738.00 | $2,099.00 | $-1,639.00 | [ ] Confirm paid | — |
| 10 - 1001 | Moore, Lashanno Lakey | Current resident | $29.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 10 - 1002 | James, Tameka Shuntell | Former resident | $393.00 | $16.00 | $0.00 | [ ] Confirm paid | — |
| 10 - 1003 | Stanford-Reed, Brittany Loleta | Current resident | $16.00 | $0.00 | $-16.00 | [ ] Confirm paid | — |
| 10 - 1004 | Hill, Shelia | Former resident | $607.00 | $0.00 | $-607.00 | [ ] Confirm paid | — |
| 10 - 1004 | Hubbard, Trina E | Former resident | $2,405.00 | $194.00 | $-2,211.00 | [ ] Confirm paid | — |
| 11 - 1101 | Collins, Carl D | Current resident | $2,890.00 | $0.00 | $-139.00 | [ ] Confirm paid | — |
| 11 - 1102 | Mitchell, Javelle Jashaun | Current resident | $190.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 11 - 1104 | Davis, Theodore | Current resident | $369.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 12 - 1201 | Ryed, Dangelo | Current resident | $6.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 12 - 1204 | Collins, Elizabeth Janet | Former resident | $4,156.00 | $1,725.00 | $-2,431.00 | [ ] Confirm paid | — |
| 14 - 1403 | Lashley, Sha'Erika S | Former resident | $966.00 | $225.00 | $-741.00 | [ ] Confirm paid | — |
| 14 - 1404 | Hinton, Victoria | Former resident | $461.00 | $45.58 | $-415.42 | [ ] Confirm paid | — |
| 2 - 203 | Richardson, Sharon L | Former resident | $2,936.00 | $0.00 | $-2,936.00 | [ ] Confirm paid | — |
| 2 - 204 | Butler, Lashieka Cherelle | Former resident | $762.00 | $80.00 | $-682.00 | [ ] Confirm paid | — |
| 3 - 301 | Cockerham Jr, John H | Current resident | $1,135.00 | $0.00 | $-871.00 | [ ] Confirm paid | — |
| 3 - 302 | Gray, Jacqueline | Former resident | $1,861.00 | $1,078.00 | $-783.00 | [ ] Confirm paid | — |
| 3 - 302 | Green, Xavier D | Current resident | $5.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 303 | Jones, Zelwanica S | Former resident | $2,307.00 | $246.00 | $-2,061.00 | [ ] Confirm paid | — |
| 3 - 304 | Edwards, Janice | Current resident | $301.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 502 | Johnson, Raquel Shaniana | Current resident | $326.00 | $74.00 | $38.00 | [ ] Confirm paid | — |
| 6 - 602 | Reed, David Adair | Current resident | $277.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 8 - 801 | Bates, Tyra T | Former resident | $513.00 | $0.00 | $-513.00 | [ ] Confirm paid | — |
| 8 - 801 | Scott, Patricia Ann | Former resident | $1,208.00 | $1.00 | $0.00 | [ ] Confirm paid | — |
| 8 - 802 | Howard, Ertis Lee | Current resident | $33.79 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 9 - 901 | Mack, TiffanyNicole | Former resident | $1,487.00 | $934.00 | $-553.00 | [ ] Confirm paid | — |
| 9 - 901 | Harvey, Leeterica | Former applicant | $200.00 | $0.00 | $-200.00 | [ ] Confirm paid | — |
| 9 - 901 | McClinton, Sha'Wrane D | Former resident | $525.00 | $0.00 | $-525.00 | [ ] Confirm paid | — |
| 9 - 901 | Lewis, Cassandra A | Former applicant | $170.00 | $0.00 | $-170.00 | [ ] Confirm paid | — |
| 9 - 902 | Bluford, Felicia Niccole | Former resident | $1,579.00 | $1,055.00 | $-524.00 | [ ] Confirm paid | — |
| 9 - 904 | Thomas, Margaret | Former resident | $984.00 | $426.54 | $-557.46 | [ ] Confirm paid | — |
| WAIT | Washington, Terry | Former applicant | $30.00 | $0.00 | $-30.00 | [ ] Confirm paid | — |
| WAIT | Williams, Kimberly | Former applicant | $30.00 | $0.00 | $-30.00 | [ ] Confirm paid | — |
| WAIT | Smith, Walter none | Former applicant | $50.00 | $0.00 | $-50.00 | [ ] Confirm paid | — |

## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.

## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property's supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*