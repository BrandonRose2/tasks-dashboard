# Cumberland Apartments — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 3156041**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/04/2026 |
| Property manager | Kiara Brown — cumberland@apartmentcorp.com — (601) 327-1853 |
| Regional manager | JR Rolon — jrrolon@apartmentcorp.com — (941) 716-1665; Leslie Rolon — leslie@apartmentcorp.com — (504) 247-3813 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Delinquency spreadsheet | `3156041_Cumberland Apartments_Delinquent - Excel_58.xls` |
| Ledger accounts for review | 108 resident accounts |
| Residents with amount owed | 75 accounts; $56,041.22 |
| Prepaid / credit accounts | 33 accounts; $-11,174.36 |
| Availability entries | 0 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit's reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| — | — | No unit-status entries in the selected source export | [ ] Verified | __________________ |

## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| A01 | HINTON, MELODY | Former resident | $0.00 | $12.00 | $12.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A02 | Mickles, Harriet J | Former resident | $0.00 | $1,229.41 | $1,229.41 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A02 | HOWELL, BARBARA A | Former resident | $0.00 | $17.00 | $17.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A03 | WILLIAMS, GLADYS | Former resident | $0.00 | $860.00 | $860.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A03 | WOLFE, THOMAS E | Former resident | $0.00 | $95.77 | $95.77 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A03 | GILMORE, SHALANDRIA S | Former resident | $0.00 | $584.39 | $584.39 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A03 | Mickle, Raven | Former resident | $0.00 | $90.00 | $90.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A04 | AYERS, MARSHALL | Former resident | $0.00 | $258.00 | $258.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A05 | ROBINSON, HENRY L | Former resident | $0.00 | $639.00 | $639.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A05 | Smiley, Kenric M | Former resident | $0.00 | $289.00 | $289.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A06 | WILLIS, ELLA | Former resident | $0.00 | $264.00 | $264.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A07 | BROWN, Amanda M | Former resident | $0.00 | $910.21 | $910.21 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A07 | ANDERSON, TIMOTHY | Former resident | $0.00 | $157.00 | $157.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A07 | WOODARD, ERMA S | Former resident | $0.00 | $45.52 | $45.52 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| A07 | Willis, Krystal C | Former resident | $0.00 | $671.00 | $671.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B10 | MORRIS, KIMBERLY | Former resident | $0.00 | $65.59 | $65.59 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B10 | POWELL, MARVASHA J | Former resident | $0.00 | $460.02 | $460.02 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B11 | JOHNSON, SHEENA L | Former resident | $0.00 | $2,587.35 | $2,587.35 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B11 | GARRETT, HARLAND D | Former resident | $0.00 | $239.00 | $239.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B11 | Kendrick, Timothy Bernard | Former resident | $0.00 | $740.00 | $740.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B11 | Gibbs, Dajaunique | Former resident | $0.00 | $174.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B12 | JOHNSON, MARSHONDA L | Former resident | $0.00 | $815.16 | $815.16 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| B12 | WILSON, ALANDRIA N | Former resident | $0.00 | $44.00 | $44.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C14 | CRISLER, ASHLEY | Former resident | $0.00 | $1,945.92 | $1,945.92 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C14 | MOORE, LESLIE L | Current resident | $256.55 | $1,829.00 | $-0.55 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C15 | DOVE, LATOYA L | Former resident | $0.00 | $2,688.00 | $2,688.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C15 | Cooper, Renata M | Former resident | $1.00 | $100.00 | $99.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C17 | JENKINS, ANNASTASSIA c | Former resident | $0.00 | $100.00 | $100.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C17 | Bailey, Laqueisha Garnett | Former resident | $0.00 | $109.01 | $109.01 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C18 | JONES, LELA D | Former resident | $0.00 | $88.00 | $88.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C19 | REED, KIMBERLY L | Former resident | $0.00 | $15.19 | $15.19 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C20 | Davis, Tanesha | Former resident | $0.00 | $101.00 | $101.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| C20 | Williams, Tonyae' | Former resident | $1.00 | $75.00 | $74.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D21 | HYATT, ALTHEA | Former resident | $0.00 | $112.00 | $112.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D23 | WILLIAMS, JESSICA A | Former resident | $0.00 | $91.00 | $91.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D23 | Cooper, Krystal Keyauna | Former resident | $0.00 | $99.00 | $99.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D24 | JENKINS, CHEYENNE TATIANNE | Former resident | $1.00 | $76.00 | $75.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D26 | REED, JANIE C | Former resident | $0.00 | $430.00 | $430.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D27 | WILLIAMS, DESHONDA | Former resident | $0.00 | $114.00 | $114.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D27 | LOWERY HARPER, JANICE | Former resident | $0.00 | $149.00 | $149.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| D28 | ROBINSON, SHUWANDA | Former resident | $0.00 | $41.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E30 | JOHNSON, GENELLER | Former resident | $0.00 | $2,256.99 | $2,256.99 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E30 | JOHNSON, TARSHA R | Former resident | $0.00 | $1.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E30 | MARTIN, SONJA | Former applicant | $137.00 | $910.00 | $773.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E34 | DANIELS, LATRINA | Former resident | $0.00 | $2,901.00 | $2,901.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E34 | POWELL, JALISA | Former resident | $3.00 | $100.18 | $97.18 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E35 | MINOR, ASHLEY LASHAWN | Former resident | $155.00 | $4,126.00 | $3,971.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E36 | Dixon, Tracy L | Former resident | $0.00 | $114.00 | $114.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| E36 | Smith, Danielle Latrice | Former resident | $0.00 | $5.00 | $5.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F37 | BROWN, KENYA K | Former resident | $0.00 | $754.65 | $754.65 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F39 | BRENT, NATARSHA | Former resident | $0.00 | $918.00 | $918.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F39 | Davenport, Chrishauda Lajeaneia | Former resident | $0.00 | $94.00 | $94.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F40 | BANKS, NIKETA | Former resident | $0.00 | $38.00 | $38.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F43 | TERRELL, STACEY | Former resident | $0.00 | $2,509.70 | $2,509.70 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F43 | GARRETT, SHEREKIA S | Former resident | $0.00 | $478.00 | $478.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| F44 | POWELL, VITA | Former resident | $0.00 | $2,039.56 | $2,039.56 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G47 | Murray, Natassia k | Former resident | $0.00 | $853.74 | $853.74 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G47 | POWELL, SHAWANNA R | Former resident | $0.00 | $1,202.04 | $1,202.04 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G48 | Skaggs, Altranesia Lasha | Former resident | $0.00 | $20.00 | $20.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G48 | Smith, Tytianna Latrice | Former resident | $0.00 | $735.00 | $735.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G49 | COOPER, ANNIE | Former resident | $0.00 | $109.00 | $109.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G50 | Walker, Lachandra c | Former resident | $0.00 | $1,687.00 | $1,687.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G50 | BRENT, DOMINIQUE L | Former resident | $0.00 | $956.00 | $956.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G51 | GRAHAM, MATHEW | Former resident | $0.00 | $2,096.99 | $2,096.99 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G51 | JOHNSON, CHASTITY Y | Former resident | $0.00 | $996.00 | $996.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| G51 | Johnson, Jerry R | Current resident | $0.00 | $541.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H54 | KENDRICK, EARL | Former resident | $0.00 | $1,577.90 | $1,577.90 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H57 | WILSON, TERESA | Former resident | $0.00 | $1,432.85 | $1,432.85 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H57 | MOORE, TRAVELL K | Former resident | $0.00 | $865.00 | $865.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H58 | Buck, Alfred | Former resident | $0.00 | $1,990.00 | $1,990.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H59 | ANDERSON, TYRECIA I | Former resident | $0.00 | $694.00 | $694.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H60 | BUIE, LAMESHIA | Former resident | $0.00 | $3,831.49 | $3,831.49 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H60 | AYERS, JAKEMA C | Former resident | $0.00 | $0.14 | $0.14 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| H60 | EVANS-PALMER, LAKESHA M | Former resident | $94.00 | $133.00 | $39.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| NONE | Laundry room income | Misc. Income | $0.00 | $312.00 | $312.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| A01 | PRUITT, ANAICE S | Current resident | $164.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| A02 | BRENT, ETONYA MICHELLE | Current resident | $11.00 | $0.00 | $-11.00 | [ ] Confirm paid | — |
| A06 | Willis, Jennifer | Current resident | $360.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| B09 | FRANKLIN, MONICA | Former resident | $129.00 | $40.00 | $-89.00 | [ ] Confirm paid | — |
| B09 | Willis, Sara | Current resident | $121.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| B11 | Culver, Johnny | Current resident | $123.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| B12 | POWELL, ZARRKHAVOIE X | Former resident | $1,261.00 | $299.00 | $-962.00 | [ ] Confirm paid | — |
| C16 | TAYLOR, MICHELLE | Current resident | $6.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| C17 | CRISLER, KESHA M | Former resident | $604.00 | $130.08 | $-473.92 | [ ] Confirm paid | — |
| C18 | ADAMS, MONICA L | Current resident | $247.00 | $0.00 | $-1.00 | [ ] Confirm paid | — |
| C19 | ALLEN, AIESHIA M | Current resident | $69.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| D24 | POWELL, SHERRY A | Current resident | $181.00 | $12.00 | $-1.00 | [ ] Confirm paid | — |
| D25 | Bailey, Jasmine Lavett | Current resident | $1,412.00 | $0.00 | $-692.00 | [ ] Confirm paid | — |
| D26 | Rhymes, Ahliyah | Current resident | $893.00 | $0.00 | $-173.00 | [ ] Confirm paid | — |
| D27 | Eisenbrandt, Kimberly Ann | Current resident | $858.00 | $24.00 | $0.00 | [ ] Confirm paid | — |
| D28 | WILLIAMS, LAQUITA | Former resident | $305.00 | $3.00 | $-302.00 | [ ] Confirm paid | — |
| D28 | Smiley, Schulus | Current resident | $180.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| E29 | WILLIAMS, KIMBERLY | Former resident | $306.00 | $23.00 | $-283.00 | [ ] Confirm paid | — |
| E29 | Johnson, Jeremy | Current resident | $350.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| E31 | WILLIAMS, VIRGIE | Former resident | $3,184.00 | $1,833.00 | $-1,351.00 | [ ] Confirm paid | — |
| E31 | Neal, Laronda Michelle | Current resident | $419.00 | $0.00 | $-87.00 | [ ] Confirm paid | — |
| E32 | WILSON, PATIENCE R | Former resident | $936.00 | $627.01 | $-308.99 | [ ] Confirm paid | — |
| E33 | CLAIBORNE, NATASHA | Current resident | $2.00 | $0.00 | $-2.00 | [ ] Confirm paid | — |
| E34 | HACKETT, YASMINE L | Former resident | $306.00 | $0.00 | $-306.00 | [ ] Confirm paid | — |
| E34 | ALEXANDER, LINDA F | Current resident | $8.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| F37 | MORRIS, KEYLA Y | Current resident | $609.91 | $0.91 | $-117.00 | [ ] Confirm paid | — |
| F41 | CLARK, KENYA | Current resident | $56.00 | $0.00 | $-56.00 | [ ] Confirm paid | — |
| F44 | KENDRICK, KIMALISHA S | Current resident | $371.00 | $125.00 | $1.00 | [ ] Confirm paid | — |
| G45 | CRISLER, CLAUDETTE | Current resident | $23.45 | $0.00 | $0.00 | [ ] Confirm paid | — |
| G50 | Carter, William J | Current resident | $280.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| H54 | Barnes, Johnny Harold | Current resident | $190.00 | $0.00 | $-8.00 | [ ] Confirm paid | — |
| H57 | JENKINS, SURESH | Current resident | $213.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| H60 | MCDANIEL, RACHEAL S | Former resident | $142.00 | $29.00 | $-113.00 | [ ] Confirm paid | — |

## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.

## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property's supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*