# Grove Park Terrace — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 4679872**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/05/2026 |
| Property manager | Nikki Moreno — grovepark@apartmentcorp.com — (945) 271-5639 |
| Regional manager | Leslie Rolon — leslie@apartmentcorp.com — (504) 247-3813 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Delinquency spreadsheet | `4679872_Grove Park Terrace_Delinquent - Excel_58.xls` |
| Ledger accounts for review | 136 resident accounts |
| Residents with amount owed | 83 accounts; $40,725.34 |
| Prepaid / credit accounts | 52 accounts; $-11,165.84 |
| Availability entries | 0 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit's reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| — | — | No unit-status entries in the selected source export | [ ] Verified | __________________ |

## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 01 - 02 | McGee, Kaquiala K | Former resident | $0.00 | $666.23 | $666.23 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 01 - 02 | Camacho, MariaCristina | Former resident | $0.00 | $1,084.19 | $1,084.19 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 01 - 03 | Anderson, Kia K | Former resident | $0.00 | $507.08 | $507.08 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 01 - 04 | Howard, Nekia T | Former resident | $0.00 | $987.00 | $987.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 01 - 04 | Sauceda, BrendaCastillo | Former resident | $0.00 | $370.46 | $370.46 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 01 - 04 | Gutierrez, Jessive | Former resident | $0.00 | $0.90 | $0.90 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 01 - 04 | Southern, Amaya Grace | Current resident | $0.87 | $810.10 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 01 - 05 | Troupe, Khira A | Former resident | $0.00 | $2,814.68 | $2,814.68 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 01 - 05 | Morato, Alexia Nicole | Former resident | $0.00 | $12.65 | $12.65 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 01 - 06 | Shaw, Ebony B | Former resident | $0.00 | $33.11 | $33.11 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 01 - 06 | Escalante, Amanda Sepeda | Former resident | $0.00 | $0.03 | $0.03 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 01 - 06 | Valerio, Marla Lucero | Former resident | $0.00 | $413.86 | $413.86 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 01 - 06 | Venegas, Zitlaly | Former resident | $0.71 | $21.86 | $21.15 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 01 - 06 | Gonzales, Daniella | Current resident | $0.61 | $300.97 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 01 - 07 | Spurlock, James Phillip | Former resident | $0.00 | $642.40 | $642.40 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 01 - 08 | Ramirez, Zenaida | Former resident | $0.00 | $222.00 | $222.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 01 - 08 | Travis, Kayla L | Former resident | $0.00 | $694.53 | $694.53 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 01 - 08 | Garcia, Vanessa | Former resident | $0.00 | $135.75 | $135.75 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 01 - 08 | Whitehead, Shmayia Sentrail | Current resident | $0.03 | $0.39 | $0.39 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 01 - 10 | De Leon, Leslie Ruby | Former resident | $0.00 | $0.16 | $0.16 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 01 - 11 | Williams, Adriana K | Former resident | $0.00 | $737.60 | $737.60 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 01 - 11 | Castillo, Joshua E | Current resident | $0.88 | $49.88 | $10.88 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 01 - 12 | Carson, Taisha | Former resident | $15.48 | $418.33 | $402.85 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 01 - 12 | Arciba, JoAnn | Current resident | $1.87 | $1.93 | $1.93 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02 - 13 | Ontiveros, Antonio | Former resident | $0.00 | $1,237.40 | $1,237.40 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02 - 14 | Washington, Latorasha | Former resident | $0.00 | $191.00 | $191.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02 - 14 | Holt, Reginal D | Former resident | $0.00 | $778.47 | $778.47 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02 - 14 | Martinez, Penny L | Former resident | $0.00 | $0.07 | $0.07 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02 - 15 | Schlottman, Tiffany R | Current resident | $0.00 | $432.50 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02 - 20 | Turner, Antone | Current resident | $0.00 | $48.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02 - 21 | White, Jada N | Former resident | $0.00 | $0.07 | $0.07 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02 - 23 | Cook, Charmaine J | Current resident | $5.99 | $125.23 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02 - 24 | Reyes, Jasmine | Former resident | $0.00 | $139.96 | $139.96 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02 - 24 | Arreola, Zenaida | Current resident | $0.00 | $5.00 | $5.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 03 - 30 | Morin, Jesusa | Current resident | $0.00 | $24.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 03 - 30 | Campos, Brandy Evette | Former resident | $0.00 | $470.87 | $470.87 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 03 - 31 | Brown, Monica | Former resident | $34.00 | $3,115.63 | $3,081.63 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 03 - 31 | Pyburn, Judaea M | Former resident | $0.00 | $1,070.09 | $1,070.09 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 03 - 32 | Cash, Ka'Derricka; Cash, Kadien | Former resident | $0.00 | $1.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 03 - 32 | McCowan, Chassidy C | Former resident | $8.00 | $697.00 | $689.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 03 - 32 | Aguilar, Amanda | Former resident | $0.00 | $633.00 | $633.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 03 - 36 | Hogan, LeSaundra M | Current resident | $0.00 | $4.75 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04 - 37 | Carrillo, Alexis B | Former resident | $0.00 | $819.97 | $819.97 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04 - 37 | Estrada, Alysa M | Former resident | $0.00 | $0.87 | $0.87 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04 - 37 | Martinez, Elvira | Current resident | $0.00 | $0.19 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04 - 37 | Copeland, Robin D | Former applicant | $0.00 | $19.00 | $19.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04 - 38 | Henley, Holly C | Former resident | $0.00 | $178.81 | $178.81 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04 - 38 | Zapata, Heven Lye | Former resident | $0.00 | $0.33 | $0.33 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04 - 39 | Washington, Destini M | Former resident | $0.00 | $684.05 | $684.05 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04 - 40 | Garcia, Lacy | Former resident | $0.00 | $263.52 | $263.52 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04 - 40 | Martinez, Elvia | Current resident | $0.03 | $1,659.81 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04 - 41 | Leija, AlexandreaM | Former resident | $0.00 | $559.04 | $559.04 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04 - 41 | Villatoro, Sayra Anahi | Current resident | $230.90 | $1,270.07 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04 - 42 | Moreno, Amber D | Former resident | $0.00 | $713.52 | $713.52 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04 - 42 | Rodriguez, Arissa N | Former resident | $0.00 | $274.16 | $274.16 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04 - 42 | Marrugo, Eternity Ines | Former resident | $0.00 | $5.32 | $5.32 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04 - 43 | Lacey, Jurnee O | Former resident | $64.45 | $684.50 | $620.05 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04 - 43 | Arteaga, Erianna L | Former resident | $0.00 | $0.32 | $0.32 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04 - 43 | Valenzuela, Gissel Marlene | Current resident | $40.32 | $2,083.06 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04 - 44 | MCQUAY, KARISSA D | Former resident | $0.00 | $10.23 | $10.23 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04 - 44 | Sanchez, Karina L | Current resident | $0.00 | $22.20 | $21.40 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04 - 45 | Jiles, Shavaire | Former resident | $0.00 | $352.00 | $352.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04 - 45 | Morin, Isabel | Former resident | $0.00 | $1,388.95 | $1,388.95 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04 - 45 | Vidrio, Anthony s | Former resident | $0.00 | $0.85 | $0.85 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04 - 45 | Escamilla, Jasmine C | Former resident | $0.00 | $322.14 | $322.14 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04 - 45 | Banda, Brianna Nichole | Current resident | $0.73 | $237.20 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04 - 46 | Wilborn, Candice J | Former resident | $589.90 | $827.85 | $237.95 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04 - 48 | Ransom, Sharita D | Former resident | $0.07 | $181.52 | $181.45 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05 - 49 | Fleming, Wanda G | Former resident | $0.00 | $516.89 | $516.89 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05 - 49 | Pecina, Veronica | Current resident | $0.74 | $14.74 | $14.74 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05 - 50 | Sanchez, Hiladio | Former resident | $0.00 | $1.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05 - 50 | Sepeda, Desiree | Former resident | $0.40 | $162.80 | $162.40 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05 - 53 | Williams, Lakaisha N | Former resident | $0.00 | $1,361.10 | $1,361.10 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05 - 53 | Alvarez, Vanessa A | Current resident | $0.68 | $656.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05 - 54 | Ramirez, Kimberly N | Former resident | $0.00 | $1,710.82 | $1,710.82 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05 - 54 | SALINAS, ERIN G | Former resident | $0.00 | $0.06 | $0.06 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05 - 54 | Gutierrez, Nicole L | Former resident | $0.00 | $685.29 | $685.29 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05 - 55 | Washington, Samara R | Former resident | $0.00 | $70.65 | $70.65 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05 - 57 | Garcia, Meily J | Current resident | $0.00 | $42.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05 - 58 | Sargent, Shabria M | Former resident | $0.00 | $891.00 | $891.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05 - 58 | LILLIE, BRANDIE M | Current resident | $0.83 | $323.83 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05 - 59 | Johnson, K'Wytasha | Former resident | $0.00 | $1,473.14 | $1,473.14 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05 - 60 | Cornejo, Francine A | Former resident | $0.29 | $1,354.19 | $1,353.90 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 01 - 02 | Chambers, Katherine L | Current resident | $753.25 | $152.58 | $0.00 | [ ] Confirm paid | — |
| 01 - 03 | Guerrero, Ileana M | Current resident | $31.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 01 - 05 | Garcia, Katina | Current resident | $4.00 | $0.00 | $-4.00 | [ ] Confirm paid | — |
| 01 - 07 | Edwards, Veronica L | Former resident | $272.74 | $0.16 | $-272.58 | [ ] Confirm paid | — |
| 01 - 07 | Griggers, Krystal Lenee | Current resident | $7.33 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 01 - 08 | Rivera, Jewliana R | Former resident | $0.10 | $0.00 | $-0.10 | [ ] Confirm paid | — |
| 01 - 09 | Daniels, Barbara A | Current resident | $21.00 | $6.00 | $0.00 | [ ] Confirm paid | — |
| 02 - 13 | Jones, Ciosha B | Former resident | $353.00 | $0.00 | $-353.00 | [ ] Confirm paid | — |
| 02 - 13 | Noble, MyKasey Adarria | Current resident | $44.33 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 02 - 14 | Anderson, Jalishia La Dawn | Current resident | $14.00 | $0.00 | $-14.00 | [ ] Confirm paid | — |
| 02 - 16 | Perez, Carolina Alicia | Former resident | $0.10 | $0.00 | $-0.10 | [ ] Confirm paid | — |
| 02 - 16 | Anderson, AlyciaVirginia | Current resident | $165.47 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 02 - 17 | Watts, Belzoria | Current resident | $82.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 02 - 18 | Coronado, Braulia | Current resident | $18.04 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 02 - 19 | Taylor, Mary L | Current resident | $54.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 02 - 21 | Almaguer, Frank | Current resident | $9.00 | $0.00 | $-9.00 | [ ] Confirm paid | — |
| 02 - 22 | Gonzales, Cynthia Ledesma | Current resident | $0.55 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 03 - 25 | Jones, Keanna J | Current resident | $11.00 | $0.00 | $-11.00 | [ ] Confirm paid | — |
| 03 - 26 | Torres, Monica | Current resident | $29.00 | $0.00 | $-28.53 | [ ] Confirm paid | — |
| 03 - 27 | Chandler, Regena | Current resident | $97.00 | $0.00 | $-97.00 | [ ] Confirm paid | — |
| 03 - 28 | Durham, Ashley | Former resident | $1,176.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 03 - 29 | Parks, Lashanda | Former resident | $456.00 | $0.00 | $-456.00 | [ ] Confirm paid | — |
| 03 - 29 | Ortega, Viola E | Current resident | $192.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 03 - 31 | Cortez, Destiny Marie | Current resident | $0.04 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 03 - 32 | Rivera, Anneliese Marie | Current resident | $4.26 | $0.00 | $-3.87 | [ ] Confirm paid | — |
| 03 - 33 | Lopez, Karissa R | Current resident | $12,091.27 | $11,529.67 | $-4,664.27 | [ ] Confirm paid | — |
| 03 - 34 | Valdez, Hipolita G | Former resident | $108.81 | $0.98 | $-107.83 | [ ] Confirm paid | — |
| 03 - 34 | Mckenzie, Shanika N | Current resident | $0.97 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 03 - 35 | Gonzales, Audryana Celeste | Current resident | $22.13 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 04 - 37 | Williams, La'Queshia | Former resident | $1.00 | $0.00 | $-1.00 | [ ] Confirm paid | — |
| 04 - 38 | Pipkins, Stephanie A | Former resident | $0.55 | $0.00 | $-0.55 | [ ] Confirm paid | — |
| 04 - 38 | Sanchez, Gabriella Renae | Current resident | $0.47 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 04 - 39 | Delgado, Richard L | Current resident | $6.74 | $0.10 | $-6.74 | [ ] Confirm paid | — |
| 04 - 42 | Conner, Carolyn | Current resident | $63.12 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 04 - 43 | Arevalo, Bianka A | Former resident | $263.32 | $0.35 | $-262.97 | [ ] Confirm paid | — |
| 04 - 43 | Barajas, Mireya | Former resident | $0.65 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 04 - 44 | Waites, Kashayla B | Former resident | $0.84 | $0.00 | $-0.84 | [ ] Confirm paid | — |
| 04 - 44 | Pena, Eugene | Former resident | $0.57 | $0.00 | $-0.57 | [ ] Confirm paid | — |
| 04 - 46 | Ortiz, Carmelin A | Current resident | $10.54 | $0.00 | $-10.00 | [ ] Confirm paid | — |
| 04 - 47 | Lopez, Michelle | Former resident | $0.26 | $0.00 | $-0.26 | [ ] Confirm paid | — |
| 04 - 47 | Garza, Lazette Marie | Current resident | $19.87 | $0.00 | $-19.52 | [ ] Confirm paid | — |
| 04 - 48 | Alvarez, Desarie A | Current resident | $31.13 | $0.67 | $0.00 | [ ] Confirm paid | — |
| 05 - 50 | Artega, Erianna Lynn | Current resident | $7.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 05 - 51 | Jones, Shakeidra A | Current resident | $53.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 05 - 52 | Hernandez, Jackie | Current resident | $2,869.00 | $0.00 | $-1,087.00 | [ ] Confirm paid | — |
| 05 - 54 | Escamilla, Jasmine C | Former resident | $0.52 | $0.00 | $-0.52 | [ ] Confirm paid | — |
| 05 - 54 | Holbert, Jalishia Nashae | Current resident | $54.90 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 05 - 55 | Morin, Maria | Former resident | $0.48 | $0.00 | $-0.48 | [ ] Confirm paid | — |
| 05 - 55 | Johnson, LaQuincia Shardae | Current resident | $1,076.29 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 05 - 56 | Deleon, Leslie | Current resident | $548.00 | $353.00 | $8.00 | [ ] Confirm paid | — |
| 05 - 59 | Marrugo, Eternity Ines | Current resident | $2,040.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 05 - 60 | Gonzalez, Vida J | Current resident | $142.77 | $0.06 | $-142.77 | [ ] Confirm paid | — |

## Resident Balance Follow-Up — Paid / Zero Balance

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 01 - 10 | Stone, Emilee Elizabeth | Current resident | $0.03 | $0.03 | $-0.03 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property's supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*