# Grace Townhomes — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 3835626**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/05/2026 |
| Property manager | Susan Lopez — susan@apartmentcorp.com — (214) 431-7769 |
| Regional manager | Leslie Rolon — leslie@apartmentcorp.com — (504) 247-3813 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Delinquency spreadsheet | `3835626_Grace Townhomes_Delinquent - Excel_58.xls` |
| Ledger accounts for review | 345 resident accounts |
| Residents with amount owed | 278 accounts; $532,202.21 |
| Prepaid / credit accounts | 67 accounts; $-21,380.72 |
| Availability entries | 15 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit's reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| 12-1214 | C1 | Vacant Not Leased Ready | [ ] Verified | __________________ |
| 17-1713 | B1H | Vacant Not Leased Ready | [ ] Verified | __________________ |
| 1-122 | C1 | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 4-414 | A1 | NTV Not Leased | [ ] Verified | __________________ |
| 8-814 | B1 | NTV Not Leased | [ ] Verified | __________________ |
| 13-1311 | C1 | NTV Not Leased | [ ] Verified | __________________ |
| 16-1611 | B1 | NTV Not Leased | [ ] Verified | __________________ |
| BREAK20-2013 | A1 | NTV Not Leased | [ ] Verified | __________________ |
| 21-2113 | B1 | NTV Not Leased | [ ] Verified | __________________ |
| 22-2214 | B1 | NTV Not Leased | [ ] Verified | __________________ |
| 9-912 | B1 | NTV Leased | [ ] Verified | __________________ |
| 18-1812 | A1 | Vacant Leased Ready | [ ] Verified | __________________ |
| 21-2112 | B1 | Vacant Leased Ready | [ ] Verified | __________________ |
| 5-514 | B1 | Vacant Leased Not Ready | [ ] Verified | __________________ |
| BREAK20-2013 | A1 | NTV Not Leased | [ ] Verified | __________________ |

## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - 112 | Nelson (EHA), Pat Leon-(EHA) | Former resident | $0.00 | $287.71 | $287.71 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 114 | Bautista, Leonardo Angel | Former resident | $0.00 | $145.00 | $145.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 122 | Caldwell, Arthur Dewayne | Former resident | $0.00 | $2,644.16 | $2,644.16 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 123 | *Villa, Liliana | Former resident | $0.00 | $1,891.03 | $1,891.03 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 123 | Simmons, Ashley | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1011 | Davis, Shalonda | Former resident | $0.00 | $2,059.27 | $2,059.27 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1013 | Burley, Travis Lynn | Former resident | $0.00 | $2,333.18 | $2,333.18 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1013 | Kidd, Raven Jonae | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1013 | *Faz, Veronica Elaine | Former resident | $0.00 | $2,877.17 | $2,877.17 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1014 | Martinez, Sontino | Former resident | $0.00 | $2,064.68 | $2,064.68 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1014 | Piper (EHA), Tandra | Former resident | $0.00 | $418.83 | $418.83 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1111 | Kelley, ZacharyJustin | Former resident | $0.00 | $1,727.12 | $1,727.12 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1111 | Shook, Desiree | Former resident | $0.00 | $1,413.70 | $1,413.70 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1111 | Schmucker, Amber Michelle | Current resident | $0.00 | $1,364.39 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1113 | Hesus, Engracia | Former resident | $0.00 | $2,450.47 | $2,450.47 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1114 | Morris, Jeannine | Former resident | $0.00 | $1,463.75 | $1,463.75 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1114 | Wilson, Larry Dean | Former resident | $0.00 | $3,527.41 | $3,527.41 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1114 | *McMillion (JR), James V | Former resident | $0.00 | $2,870.82 | $2,870.82 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1211 | Holiday, Lois | Former resident | $0.00 | $2,557.14 | $2,557.14 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1211 | Reyes, Samantha | Former resident | $0.00 | $1,498.29 | $1,498.29 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1212 | Rodriquez, Marlene | Former resident | $0.00 | $1,171.12 | $1,171.12 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1212 | Teal, Rickey Lynn | Former resident | $0.00 | $3,521.92 | $3,521.92 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1212 | Banks, April Lee | Former resident | $0.00 | $1,053.12 | $1,053.12 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1212 | Kelton-Thomason, Linda Jean | Former resident | $0.00 | $2,999.30 | $2,999.30 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1213 | Becks (GPHA), Latoya Shunte | Former resident | $0.00 | $350.93 | $350.93 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1213 | Gonzales, Julie Ann | Former resident | $0.00 | $2,847.67 | $2,847.67 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1213 | Alvarado, Maria Maria | Former resident | $0.00 | $5,760.57 | $5,760.57 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1214 | Garcia-Lopez, Rufina | Former resident | $0.00 | $2,314.51 | $2,314.51 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1214 | SIerra, Leonor Urania | Former resident | $0.00 | $1,336.02 | $1,336.02 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1214 | Flynn, Austin Shane | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1214 | Martinez-Alvarado, Maria Ilda | Former resident | $0.00 | $1,610.55 | $1,610.55 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1214 | Hogan, Breanna | Former resident | $0.00 | $3,639.95 | $3,639.95 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1214 | Elliott, Brandon Okeith | Former resident | $0.00 | $2,625.81 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1222 | Sauceda (EHA), Summer Mandline | Former resident | $0.00 | $1,375.83 | $1,375.83 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1222 | Betts(DHA), Delisa Rochelle | Former resident | $0.00 | $1,805.00 | $1,805.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1222 | McNeal-Young, Brittani Shavonne | Former resident | $0.00 | $974.00 | $974.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1222 | Jones, Tanger | Former resident | $0.00 | $6,312.50 | $6,312.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1223 | Copeland, Jonathan Taylor | Former resident | $0.00 | $920.83 | $920.83 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1223 | Flowers (EHA), Katharena A | Former resident | $0.00 | $598.20 | $598.20 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1223 | *Waddle, Lynnsey Kay | Former resident | $0.00 | $3,586.20 | $3,586.20 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1223 | Nash, Shanice(GPHA) | Former resident | $0.00 | $1,261.33 | $1,261.33 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1223 | Albarran, Summer | Former resident | $0.00 | $3,766.72 | $3,766.72 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1311 | Burley, Jordan-DHA Denea | Former resident | $0.00 | $842.56 | $842.56 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1311 | Ovalle, Erika Gabriela | Former resident | $0.00 | $2,161.53 | $2,161.53 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1311 | *Reyes, Makenzie Rosa | Former resident | $0.00 | $4,523.25 | $4,523.25 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1311 | Fulcher, LaShandra Tynette | Former resident | $0.00 | $4,035.34 | $4,035.34 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1311 | Webb, Brian Erik | NTV | $0.00 | $1,679.81 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1312 | Simmons (EHA), Ashley Renea | Former resident | $0.00 | $620.39 | $620.39 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1312 | Franklin, Shamika S. | Former resident | $0.00 | $2,135.26 | $2,135.26 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1313 | Runnels, Kenneth DHA | Former resident | $416.00 | $834.15 | $418.15 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1313 | Vandergriff, Heather Dawn | Former resident | $0.00 | $1,052.05 | $1,052.05 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1313 | Washington-GPH, Laquesha | Former resident | $0.00 | $439.53 | $439.53 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1313 | Farsee, Jennifer Nicole | Former resident | $0.00 | $3,720.60 | $3,720.60 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1313 | Reeves, Victoria Sernice | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1313 | *Yellowfish, Deserray Nicole | Former resident | $0.00 | $2,684.78 | $2,684.78 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1313 | Velaquez, Ruben Hernandez | Current resident | $0.00 | $1,706.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1321 | Garrett (DHA), Tabria | Former resident | $0.00 | $24.23 | $24.23 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1321 | Lacey, Jurnee Oshaki | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1321 | Turner(DHA), Thomesha | Former resident | $0.00 | $2,999.40 | $2,999.40 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1322 | *Rahmaan, Teresa | Former resident | $0.00 | $3,244.68 | $3,244.68 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1322 | *Anderson, Tynepa B | Former resident | $0.00 | $9,397.91 | $9,397.91 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1322 | Tucker, Mitchell | Former resident | $0.00 | $2,459.92 | $2,459.92 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1323 | Walker (EHA), Tiffany | Former resident | $0.00 | $3,114.68 | $3,114.68 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1324 | Mason, Robin | Former resident | $0.00 | $1,515.50 | $1,515.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1411 | Reagor, Tae-Marshonna Danyelle | Former resident | $0.00 | $3,638.10 | $3,638.10 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1412 | Johnson, Camelia | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1412 | King, Tekentria | Former resident | $0.00 | $5,186.31 | $5,186.31 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1412 | *Vann, Latarra Trielle | Former resident | $0.00 | $5,293.40 | $5,293.40 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1412 | *Phillips, Susan | Former resident | $0.00 | $5,812.13 | $5,812.13 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1413 | Struggs(EHA), Shaquiel | Former resident | $154.77 | $1,698.91 | $1,544.14 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1414 | Carrillo, Alicia | Former resident | $0.00 | $2,956.50 | $2,956.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1414 | *Munoz, Rosa Maria | Former resident | $0.00 | $1,973.18 | $1,973.18 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1414 | *McKnight, Diana Lynn | Former resident | $0.00 | $13,057.80 | $13,057.80 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1422 | Ortega, Daniel | Former resident | $0.00 | $1,840.00 | $1,840.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1423 | Richardson (EHA), Malitha Ann | Former resident | $0.00 | $444.79 | $444.79 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1423 | Beasly, Larry Myers | Former resident | $0.00 | $2,000.34 | $2,000.34 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1423 | High Jr, Robert | Former resident | $0.00 | $2,488.83 | $2,488.83 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1423 | Delgado-Aveldano, Jesus Armando | Current resident | $0.00 | $1,525.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15 - 1511 | *Brooks Jr, James Earl | Former resident | $0.00 | $2,404.96 | $2,404.96 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15 - 1511 | Jackson, Arietta Jean | Current resident | $0.00 | $164.46 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15 - 1512 | Barker, Hope | Former resident | $0.00 | $6.94 | $6.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15 - 1512 | Alvarado, Esperana | Former resident | $0.00 | $973.82 | $973.82 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15 - 1512 | Lopez, Florentina | Former resident | $0.00 | $862.26 | $862.26 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15 - 1512 | Taylor (EHA), Waneshia | Former resident | $0.00 | $25.54 | $25.54 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15 - 1514 | Teague, Ryan | Former resident | $0.00 | $1,774.23 | $1,774.23 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15 - 1514 | Roybal, Tommy | Former resident | $0.00 | $1,049.94 | $1,049.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15 - 1514 | Swindle, Byron Hampton | Former resident | $0.00 | $1,417.84 | $1,417.84 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15 - 1514 | Sloan, Undra Davis | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 1611 | McDonald (GPHA), Rosalyn | Former resident | $0.00 | $2,588.86 | $2,588.86 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 1611 | *Silva, Jasmine Chavira | Former resident | $0.00 | $3,810.33 | $3,810.33 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 1612 | Harbert, Jasmine Lashae | Former resident | $0.00 | $1,864.85 | $1,864.85 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 1612 | Green-DHA, Keandra T | Former resident | $0.00 | $1,201.56 | $1,201.56 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 1612 | Asher, Vincent Edward | Former resident | $0.00 | $3,122.72 | $3,122.72 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 1612 | Guevara, Cecilia Esteffy | Former resident | $0.00 | $2,619.71 | $2,619.71 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 1612 | Peoples, Shaquite | Former resident | $0.00 | $7,982.53 | $7,982.53 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 1613 | Thompson(GPHA), SharonDenise | Former resident | $0.00 | $26.52 | $26.52 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 1613 | Jeter, Chyneal B | Former resident | $0.00 | $1,916.01 | $1,916.01 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 1613 | *Hearne Jr, Timothy Delane | Former resident | $0.00 | $4,239.74 | $4,239.74 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 1613 | Campbell, Jamie Nicole | Former resident | $0.00 | $3,573.33 | $3,573.33 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 1614 | Randle, Queanna Quinshea | Former resident | $0.00 | $2,135.47 | $2,135.47 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 1614 | Wright, Megan Nichole | Former resident | $0.00 | $702.50 | $702.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 1614 | *Larkins, Cory Lynn | Former resident | $0.00 | $4,795.94 | $4,795.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16 - 1614 | Ramos, Christian Gage | Former resident | $0.00 | $2,033.07 | $2,033.07 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 1711 | Winkelman, Catrina Marie | Former resident | $0.00 | $1,628.31 | $1,628.31 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 1711 | Casares, Lorena Olvera | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 1711 | Eckert, Theodore L | Former resident | $0.00 | $1,145.49 | $1,145.49 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 1711 | Polk(DHA), Shunda | Former resident | $0.00 | $335.48 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 1712 | Wade (EHA), Latasha Rowena | Former resident | $0.00 | $108.53 | $108.53 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 1712 | Combs, Chandra Lee | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 1712 | Sacharko, Mistty Lynn | Former resident | $0.00 | $2,611.00 | $2,611.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 1712 | *Gabriele, Nakeesha Tyree | Former resident | $0.00 | $4,068.00 | $4,068.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 1713 | Hoffmeister, Kaylee A | Former resident | $0.00 | $1,127.34 | $1,127.34 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17 - 1713 | Perry, Fairlye Stogner | Former resident | $0.00 | $622.48 | $622.48 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18 - 1811 | Gutierrez, Susan | Former resident | $0.00 | $1,759.83 | $1,759.83 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18 - 1811 | Wooden, Justin Ray | Former resident | $0.00 | $1,018.34 | $1,018.34 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18 - 1811 | Jones, Megan Shunee | Former resident | $0.00 | $1,739.55 | $1,739.55 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18 - 1812 | *Thacker, Robbie Markise | Former resident | $0.00 | $1,831.55 | $1,831.55 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18 - 1812 | *Dixon, Ashley | Former resident | $0.00 | $2,675.94 | $2,675.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18 - 1812 | Dunn, Diamond Shepree | Former resident | $0.00 | $744.23 | $744.23 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18 - 1812 | Wilson, LaQuinqua | Former resident | $0.00 | $1,184.47 | $1,184.47 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18 - 1812 | Cox, Jalcolby | Former resident | $0.00 | $3,518.61 | $1,533.61 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18 - 1813 | Jamerson, Mercesdes Lashay | Former resident | $0.00 | $2,103.87 | $2,103.87 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18 - 1813 | Williams (EHA), Alexus Ryaisha | Former resident | $0.00 | $4,799.49 | $4,799.49 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18 - 1813 | Johnson, Zandreaya Tayvion | Current resident | $0.00 | $627.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19 - 1913 | Fulcher, Cory | Former resident | $0.00 | $666.49 | $666.49 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19 - 1913 | Steptoe, Jannetta Latrice | Former resident | $0.00 | $5,846.77 | $5,846.77 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19 - 1914 | Stalley, William Henry | Current resident | $0.00 | $1,538.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 211 | Adams, Victoria Lynn | Former resident | $0.00 | $14.14 | $14.14 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 211 | Hobbs, Gay Lynn | Former resident | $0.00 | $4,412.38 | $4,412.38 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 212 | Cooper, Connie Denise | Former resident | $0.00 | $1,689.48 | $1,689.48 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 212 | Paul, Kowame Gaynell | Former resident | $0.00 | $2,041.97 | $2,041.97 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 212 | *Davis, Christian Dvan | Former resident | $0.00 | $3,108.96 | $3,108.96 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 213 | *Ramirez, AlfonsoC | Former resident | $0.00 | $2,686.23 | $2,686.23 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 213 | Speight, Kadrain Nicole | Former resident | $0.00 | $3,196.13 | $3,196.13 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 214 | Stevens, Kendrae | Former resident | $0.00 | $126.00 | $126.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 214 | Hanks, Brittany Dane | Former resident | $0.00 | $317.00 | $317.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 223 | Blacknall, Shawanna | Former resident | $0.00 | $1,635.40 | $1,635.40 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 223 | Borden, Michael Lance | Former resident | $0.00 | $3,219.35 | $3,219.35 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 223 | Bullock, Erica | Former resident | $0.00 | $2,105.83 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20 - 2011 | Brazell, Chasmine Dominiqueka | Former resident | $0.00 | $995.61 | $995.61 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20 - 2011 | Garrett, Deborah | Former resident | $0.00 | $1,987.35 | $239.35 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20 - 2012 | Duhon, Eva | Former resident | $0.00 | $380.99 | $380.99 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20 - 2012 | Holiday, Lois Pearl | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20 - 2013 | Brown, Tiffany | Former resident | $0.00 | $1,702.87 | $1,702.87 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20 - 2013 | Douglas(DHA), Tamara Ladale | Former resident | $0.00 | $416.00 | $416.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20 - 2013 | *Waters, Natasha Marsha | NTV | $0.00 | $2,952.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20 - 2014 | Cline, Brandon | Former resident | $0.00 | $529.10 | $529.10 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20 - 2014 | Dinney, Ilonder | Former resident | $0.00 | $585.32 | $585.32 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20 - 2014 | Wood, Devin Shane | Former resident | $0.00 | $475.30 | $475.30 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20 - 2014 | Mikel, Joseph Alan | Former resident | $0.00 | $1,758.56 | $1,758.56 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20 - 2014 | *King, Charles Ray | Former resident | $0.00 | $3,583.30 | $3,583.30 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 21 - 2111 | Cervantes (Montemayor), Beatrice | Former resident | $0.00 | $1,201.34 | $1,201.34 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 21 - 2111 | Gomez, Guadalupe Jimena | Former resident | $0.00 | $1,525.00 | $1,525.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 21 - 2111 | *Hernandez, Rebecca | Former resident | $0.00 | $1,609.25 | $1,609.25 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 21 - 2111 | Reyes, Erica Buenfil | Former resident | $0.00 | $2,611.51 | $2,611.51 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 21 - 2112 | Rico-Cruces, Alicia | Former resident | $0.00 | $801.50 | $801.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 21 - 2112 | Kyser, John Jacob | Former resident | $0.00 | $910.00 | $910.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 21 - 2112 | Ross, Gabriela | Former resident | $0.00 | $111.63 | $111.63 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 21 - 2112 | Loredo, Amparo | Former resident | $0.00 | $1,180.18 | $1,180.18 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 21 - 2112 | Miley, Tina Michelle | Former resident | $0.00 | $2,521.44 | $1,629.77 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 21 - 2114 | Aguilar, Blanca Regina | Former resident | $0.00 | $1,516.68 | $1,516.68 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 21 - 2114 | Caudle, AmbreLynn | Former resident | $0.00 | $192.00 | $192.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 21 - 2114 | *Lockett, Lamreanna Carendoshna | Former resident | $0.00 | $2,651.29 | $2,651.29 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 22 - 2211 | Frazier-Myers (GPHA), Glenda | Former resident | $0.00 | $95.00 | $95.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 22 - 2211 | *Harris, Tamasha Lavetta | Former resident | $0.00 | $3,444.26 | $3,444.26 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 22 - 2211 | McIntyre(Endevours), Leticia | Former resident | $45.83 | $5,263.00 | $5,217.17 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 22 - 2211 | Bradley, Collin Demar | Current resident | $0.00 | $30.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 22 - 2212 | Botello, Erika | Former resident | $0.00 | $716.33 | $716.33 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 22 - 2212 | Keith, Crystal Dawn | Former resident | $0.00 | $702.65 | $702.65 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 22 - 2212 | Plainbull, Talitha(DHA) Marie | Former resident | $0.00 | $490.49 | $490.49 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 22 - 2213 | Ngirucherong, Harrita | Former resident | $0.00 | $1,265.94 | $1,265.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 22 - 2213 | Anani, Cynthia-DHA | Former resident | $0.00 | $1,448.53 | $1,448.53 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 22 - 2214 | Padron, Silvia | Former resident | $0.00 | $1,508.75 | $1,508.75 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 22 - 2214 | Smith, LoganRussell | Former resident | $0.00 | $3,539.25 | $3,539.25 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 23 - 2311 | Thomas, Casey Jo | Former resident | $0.00 | $1,479.79 | $1,479.79 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 23 - 2311 | Key, Christina Lynn | Former resident | $0.00 | $2,724.39 | $2,724.39 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 23 - 2311 | Udeh(DHA), Eboni Nicole | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 23 - 2311 | *Hullett, Donald James | Current resident | $0.00 | $3,360.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 23 - 2312 | *Coleman, Lisha Ann | Former resident | $0.00 | $8,155.13 | $8,155.13 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 23 - 2312 | Moore-Evans, Amber Nicole | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 23 - 2312 | *Greenwood, Jyzharnae Anique | Former resident | $0.00 | $3,010.64 | $3,010.64 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 23 - 2312 | Elliott, Delisa | Former resident | $0.00 | $601.00 | $601.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 23 - 2312 | Harris, Alice Mae | Current resident | $0.00 | $1,555.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 23 - 2313 | Walker, Lakisha Rochelle | Former resident | $0.00 | $1,119.42 | $1,119.42 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 23 - 2313 | Ballard, Qandreka Monique | Current resident | $0.00 | $494.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 23 - 2314 | Chapman, Sharon | Former resident | $0.00 | $904.27 | $904.27 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 23 - 2314 | Salas, Kimberly | Former resident | $0.00 | $882.58 | $882.58 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 23 - 2314 | Apple, Cierra Dawn | Former resident | $0.00 | $580.52 | $580.52 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 24 - 2411 | Jackson, Travon Darnell | Former resident | $0.00 | $1,533.84 | $1,533.84 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 24 - 2411 | Cooper, Crysteena J | Former resident | $0.00 | $664.82 | $664.82 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 24 - 2411 | White, Yolanda T | Current resident | $0.00 | $1,605.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 24 - 2412 | Aguilar, Diego | Former resident | $0.00 | $1,330.24 | $1,330.24 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 24 - 2412 | Dickens, Whitney Michelle | Current resident | $0.00 | $1,480.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 24 - 2413 | Woods (DHA), Tamaira Mercedes | Former resident | $0.00 | $2,034.88 | $2,034.88 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 24 - 2414 | Williams, Kellyp | Former resident | $0.00 | $2,648.94 | $2,648.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 24 - 2414 | Castle, Jacobe Deandre | Former resident | $0.00 | $5,439.48 | $5,439.48 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 24 - 2414 | *Mack, Nicole Rene | Former resident | $0.00 | $3,383.77 | $3,383.77 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 24 - 2414 | *Cooper, Jayla Lacoile | Former resident | $0.00 | $4,080.43 | $4,080.43 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 24 - 2414 | Cantu, Bobbi Lou | Former resident | $0.00 | $1,792.94 | $1,792.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 24 - 2414 | Worlds, Tawanna Jeanice | Former resident | $0.00 | $1,847.18 | $1,847.18 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 24 - 2414 | Harris, Samonya Sachet | Current resident | $0.00 | $1,633.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 25 - 2511 | Federick, Lashante | Former resident | $0.00 | $1,032.21 | $1,032.21 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 25 - 2512 | Thornton, Elaine | Former resident | $0.00 | $1,122.62 | $1,122.62 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 25 - 2512 | Cruz, Jocelyn a | Former resident | $0.00 | $1,628.29 | $1,628.29 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 25 - 2512 | Sallie, Bertha B | Former resident | $0.00 | $732.39 | $732.39 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 25 - 2512 | Hill, DeAnquaneice | Former resident | $0.00 | $123.21 | $123.21 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 25 - 2512 | Hill, Jazianiah Denise | Current resident | $0.00 | $1,386.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 25 - 2513 | *Richardson, Valencia Jantrell | Former resident | $0.00 | $4,485.00 | $4,485.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 25 - 2513 | Blackshire, Shakayla Renee | Former resident | $0.00 | $4,237.19 | $4,237.19 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 25 - 2513 | Henson, Samantha Jean | Current resident | $0.00 | $1,490.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 25 - 2514 | Wilhoite, Robbie Lee | Former resident | $0.00 | $1,700.00 | $1,700.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 25 - 2514 | Harris, Leah L | Former resident | $0.00 | $2,338.17 | $2,338.17 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 25 - 2514 | *Stickel, Theresa Rose | Former resident | $0.00 | $2,588.75 | $2,588.75 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 25 - 2514 | Warren, Cody Max | Former resident | $0.00 | $3,775.81 | $3,775.81 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 25 - 2514 | Cuellar, Victor | Former resident | $0.00 | $2,877.17 | $2,877.17 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 25 - 2514 | Campbell, KeMari Jalyl | Current resident | $0.00 | $1,555.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 312 | Green, Lanitha(GPHA) N | Current resident | $0.00 | $982.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 313 | Oliver, Tamara | Former resident | $0.00 | $1,078.94 | $1,078.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 313 | Christensen, Eric s | Former resident | $0.00 | $1,463.40 | $1,463.40 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 314 | Lara, Serena Marie | Former resident | $0.00 | $2,611.07 | $2,611.07 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 314 | Brown, Feindi R | Former resident | $0.00 | $2,485.15 | $2,485.15 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 411 | Gamino, Gabriella | Former resident | $0.00 | $799.52 | $799.52 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 411 | Vessels, Teresa | Former resident | $0.00 | $2,295.34 | $2,295.34 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 413 | McCullar, Brenda | Former resident | $0.00 | $361.48 | $361.48 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 413 | Rudd(DHA), Shuntia Leatreas | Former resident | $0.00 | $368.71 | $368.71 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 414 | Beecham (DHA), Dejuanna | Former resident | $65.29 | $1,164.85 | $1,099.56 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 511 | Townsend, Paris | Former resident | $0.00 | $894.73 | $894.73 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 513 | Jackson, Laquinta Deshawn | Former resident | $0.00 | $1,283.75 | $1,283.75 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 513 | Pineda, Gilda | Former resident | $0.00 | $3,206.69 | $3,206.69 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 513 | Loper, Amber Lynn | Former resident | $0.00 | $2,124.49 | $2,124.49 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 513 | Abdelaal, Elsayed Rashed | Former resident | $0.00 | $1,016.73 | $1,016.73 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 514 | Castillo, Guadalupe | Former resident | $0.00 | $3,127.59 | $3,127.59 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 514 | Nash, Kelyn C | Former resident | $0.00 | $946.41 | $946.41 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 514 | Jones, Kamesha (Lazarus House)Danielle | Former resident | $0.00 | $1,607.25 | $1,607.25 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 514 | Blair, Suzanne Kay | Former resident | $0.00 | $1,576.81 | $1,576.81 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 514 | Brunk, Stacy | Former resident | $0.00 | $3,862.61 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 611 | Gibson (EHA), Mary S | Former resident | $0.00 | $187.37 | $187.37 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 611 | *King, Antonio Eugene | Former resident | $0.00 | $3,084.35 | $3,084.35 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 612 | Esparza, Cirila Gabrielle | Former resident | $0.00 | $3,750.00 | $3,750.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 612 | Delgadillo, Marchel | Former resident | $0.00 | $3,014.25 | $1,055.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 613 | Miranda-Roman, Yomar Efrain | Former resident | $0.00 | $2,115.96 | $2,115.96 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 614 | Keel, Sandy | Former resident | $0.00 | $1,009.27 | $1,009.27 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 614 | Jones, Jessica | Former resident | $0.00 | $3,428.08 | $3,428.08 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 711 | Moore-GPH, Donteria Shavon | Former resident | $0.00 | $23.81 | $23.81 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 711 | Hawkins, Christopher Laroyce | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 711 | Steptoe, Raymond Lavelle | Former resident | $0.00 | $2,185.73 | $2,185.73 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 712 | Phillip, Sherlyn | Former resident | $0.00 | $2,467.28 | $2,467.28 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 712 | Strong, Liza Kendra Marie | Former resident | $0.00 | $1,835.63 | $1,835.63 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 712 | Jones, LaQuetta(GPHA) | Former resident | $409.94 | $1,139.56 | $729.62 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 713 | Ngiraked, Kent | Former resident | $0.00 | $885.35 | $885.35 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 713 | Miller (EHA), Tara | Former resident | $0.00 | $238.00 | $238.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 713 | Chavez, Alejandra G | Former resident | $0.00 | $1,242.78 | $1,242.78 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 713 | Rocha, Tomas Alejandro | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 713 | *Johnson, Brittany Shantel | Former resident | $0.00 | $2,751.33 | $2,751.33 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 714 | Lambert (EHA), Rhonda | Former resident | $0.00 | $66.48 | $66.48 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 811 | McDavid, Flodine Broadnax | Former resident | $0.00 | $483.48 | $483.48 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 811 | *Hutchins, Chemequa DNAE | Former resident | $0.00 | $4,434.05 | $4,434.05 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 811 | Washington, Carmen Nicole | Former resident | $0.00 | $3,438.35 | $3,438.35 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 812 | *Sebring, Crystal Renee | Former resident | $0.00 | $1,749.68 | $1,749.68 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 813 | Cleveland, Adrian | Former resident | $0.00 | $2,499.75 | $2,499.75 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 813 | Phillips (DHA), Felicha | Former resident | $0.00 | $915.02 | $915.02 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 814 | James, Shatoya latavian | Former resident | $0.00 | $573.42 | $573.42 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 814 | Williams (DHA), Tiffany Devone | NTV | $0.00 | $800.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 911 | Edwards, Erica | Former resident | $0.00 | $457.67 | $457.67 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 911 | Heil, Trista Lynn | Former resident | $0.00 | $1,743.49 | $1,743.49 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 911 | *Caldwell, George L | Former resident | $0.00 | $1,838.97 | $1,838.97 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 911 | Moore, Samantha | Former resident | $0.00 | $2,877.56 | $2,877.56 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 911 | Monroy, Lourdes | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 912 | Durate, Beatrice | Former resident | $0.00 | $1,961.89 | $1,961.89 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 912 | Armstrong(DHA), Cathy | Former resident | $0.00 | $91.30 | $91.30 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 913 | Arias, Jose | Former resident | $0.00 | $819.20 | $819.20 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 913 | Alexander-GPH, Raquel Y | Former resident | $0.00 | $65.73 | $65.73 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 913 | Williams(DHA), LaDasha Shadean | Former resident | $0.00 | $1,775.80 | $1,775.80 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 913 | Hicks, Ashley Lee Ann | Former resident | $0.00 | $3,698.29 | $3,698.29 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 913 | *Collins, Jacobie Montrell | Former resident | $0.00 | $3,479.78 | $3,479.78 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 913 | Hall, Eddie Lee | Former applicant | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 914 | Maxwell, Courtney leigh | Former resident | $0.00 | $2,211.15 | $2,211.15 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 914 | Fuller (GPHA), Tiesha S | Former resident | $0.00 | $21.39 | $21.39 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - 111 | Miller (EHA), Shatarika Bonae | Former resident | $32.67 | $0.00 | $-32.67 | [ ] Confirm paid | — |
| 1 - 123 | McMiller (DHA), LaSheeka Shermain | Former resident | $704.00 | $0.00 | $-704.00 | [ ] Confirm paid | — |
| 10 - 1013 | Showers, Mary Lockridge | Current resident | $0.84 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 10 - 1014 | Kirk, Deshoun Charles | Current resident | $0.74 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 11 - 1112 | McBride (DHA), Ernest George | Current resident | $126.50 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 11 - 1113 | Smith (EHA), Jessie M. | Current resident | $754.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 11 - 1114 | Johnson, Veronica Denise | Current resident | $711.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 12 - 1213 | Gabriel (EHA), Shaniqua | Former resident | $0.50 | $0.00 | $-0.50 | [ ] Confirm paid | — |
| 12 - 1213 | Hernandez, Edgar Isidro | Current resident | $0.33 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 13 - 1312 | Potter (EHA), Tosha | Former resident | $308.75 | $0.00 | $-308.75 | [ ] Confirm paid | — |
| 13 - 1312 | Calhoun, Seth Leric | Current resident | $0.17 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 13 - 1313 | Acy(EHA), Kristi Nicole | Former resident | $124.39 | $0.00 | $-124.39 | [ ] Confirm paid | — |
| 13 - 1321 | Grant, Zantrell-DHA | Former resident | $851.00 | $0.00 | $-851.00 | [ ] Confirm paid | — |
| 13 - 1321 | Gonzalez, Zenofia Marie | Current resident | $1,015.00 | $435.00 | $0.00 | [ ] Confirm paid | — |
| 13 - 1322 | Lewis, Tamara Alisha | Current resident | $0.67 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 13 - 1323 | Bailey, Genise GPHA | Former resident | $172.00 | $0.00 | $-172.00 | [ ] Confirm paid | — |
| 13 - 1323 | Hall, Sharmaine Nicolette | Current resident | $40.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 13 - 1324 | Smith, Terena Jena | Current resident | $30.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 14 - 1412 | Seamster (GPHA), Sasha Revay | Former resident | $1,084.35 | $0.00 | $-1,084.35 | [ ] Confirm paid | — |
| 14 - 1412 | Valerio, Briana Angelica | Former applicant | $5.00 | $0.00 | $-5.00 | [ ] Confirm paid | — |
| 14 - 1422 | Tutson (DHA), Timika Disha | Current resident | $2.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 15 - 1512 | Burley(EHA), Mary Hall | Current resident | $5.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 15 - 1513 | Gardner EHA, Thelma A | Former resident | $1,000.00 | $737.20 | $-262.80 | [ ] Confirm paid | — |
| 16 - 1613 | St. John (GPHA), Robin | Former resident | $277.74 | $0.00 | $-277.74 | [ ] Confirm paid | — |
| 17 - 1711 | McCants, Shanleatha Latonya | Current resident | $10.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 17 - 1712 | Calhoun, Barbara J | Current resident | $3.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 17 - 1713 | Taylor (DHA), LaPorchal | Former resident | $1,152.00 | $1,094.57 | $-57.43 | [ ] Confirm paid | — |
| 17 - 1714 | Linville, Dameon Wayne | Current resident | $33.59 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 18 - 1811 | Martinez (EHA), Augustin | Former resident | $119.33 | $0.00 | $-119.33 | [ ] Confirm paid | — |
| 18 - 1811 | Sheffield, Carolyn Ann | Current resident | $60.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 18 - 1814 | Martin, Mickey(DHA) Dejahn | Former resident | $783.00 | $303.74 | $-479.26 | [ ] Confirm paid | — |
| 19 - 1912 | Watkins (DHA), Isacar | Former resident | $307.00 | $0.00 | $-307.00 | [ ] Confirm paid | — |
| 19 - 1912 | Cunningham, Laura J | Current resident | $8.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 19 - 1913 | Robinson, Shanitra(EHA) Bronta | Current resident | $71.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 211 | Pinkard(DHA), Deonne Necolle | Former resident | $1,572.00 | $0.00 | $-1,572.00 | [ ] Confirm paid | — |
| 2 - 211 | Green, Maia (GPHA) Lacole | Current resident | $289.00 | $0.00 | $-289.00 | [ ] Confirm paid | — |
| 2 - 212 | Rhone EHA, Natasha | Former resident | $1,840.00 | $0.00 | $-1,840.00 | [ ] Confirm paid | — |
| 2 - 212 | Henderson, Verlean Evella Marie | Current resident | $0.13 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 222 | Smith (DHA), Schawanda | Current resident | $44.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 20 - 2012 | Douglas, Tamara (EHA)Ladale | Current resident | $416.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 20 - 2014 | Spencer, Jkolby D | Current resident | $0.61 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 21 - 2113 | Williams, Brittanie Lanette | NTV | $5.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 22 - 2212 | Hamilton, Shalita Lashea | Current resident | $0.61 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 22 - 2213 | Ngercheluur, Termeteet | Current resident | $179.50 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 23 - 2313 | Jordan-DHA, Kierra | Former resident | $2,434.00 | $0.00 | $-2,434.00 | [ ] Confirm paid | — |
| 23 - 2314 | Potter (EHA), Akida | Former resident | $211.00 | $0.00 | $-211.00 | [ ] Confirm paid | — |
| 23 - 2314 | Myers (DHA), Patricia Brion | Former resident | $1,105.40 | $133.40 | $-972.00 | [ ] Confirm paid | — |
| 24 - 2412 | Smith (DHA), Bernita | Former resident | $1,625.00 | $0.00 | $-1,625.00 | [ ] Confirm paid | — |
| 24 - 2413 | Palacios (DHA), Felicia Veronica | Former resident | $45.81 | $0.00 | $-45.81 | [ ] Confirm paid | — |
| 24 - 2414 | Moore(EHA), Tiera Lashae | Former resident | $29.00 | $0.00 | $-29.00 | [ ] Confirm paid | — |
| 25 - 2514 | Jackson-DHA, Brittany C | Former resident | $1,048.96 | $290.65 | $-758.31 | [ ] Confirm paid | — |
| 3 - 311 | Crawford (EHA), Damenion T | Former resident | $75.00 | $0.00 | $-75.00 | [ ] Confirm paid | — |
| 3 - 313 | Anderson, Byron Level | Current resident | $0.75 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - 411 | Benson, Cameron Michael | Current resident | $4.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - 413 | Johnson(DHA), Bridgett Shanise | Current resident | $8.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 514 | Dominguez, Nicole (DHA) | Former resident | $381.00 | $0.00 | $-381.00 | [ ] Confirm paid | — |
| 6 - 611 | Lopez-Jimenez, Miguel Angel | Current resident | $15.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 7 - 711 | Manning, Jacobie(EHA) Jeneil | Current resident | $7.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 7 - 712 | Rodriguez, Ivan | Current resident | $25.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 7 - 713 | Square, La'Sharia-DHA S | Former resident | $745.00 | $0.00 | $-745.00 | [ ] Confirm paid | — |
| 8 - 811 | Johnson (GPHA), Retina | Former resident | $85.00 | $0.00 | $-85.00 | [ ] Confirm paid | — |
| 8 - 812 | Moore (EHA), Tiera | Former resident | $678.00 | $0.00 | $-678.00 | [ ] Confirm paid | — |
| 8 - 812 | Fulford, Mercedez(DHA) Lynette | Current resident | $5.00 | $0.00 | $-5.00 | [ ] Confirm paid | — |
| 8 - 813 | Brisco (DHA), Priscillia Jean | Former resident | $921.53 | $0.00 | $-921.53 | [ ] Confirm paid | — |
| 9 - 912 | Jordan (EHA), Harolyn | Former resident | $777.00 | $0.00 | $-777.00 | [ ] Confirm paid | — |
| 9 - 913 | Crise, Perry Duane | Current resident | $0.13 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 9 - 914 | Ellis(DHA), Shelinda | Current resident | $8.28 | $0.00 | $0.00 | [ ] Confirm paid | — |

## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.

## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property's supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*