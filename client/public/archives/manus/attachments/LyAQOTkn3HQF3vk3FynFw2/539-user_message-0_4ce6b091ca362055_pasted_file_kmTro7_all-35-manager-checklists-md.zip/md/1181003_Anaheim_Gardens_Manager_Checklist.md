# Anaheim Gardens — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 1181003**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/05/2026 |
| Property manager | Priscilla Walters — priscilla@apartmentcorp.com — (310) 480-6375 |
| Regional manager | Blake Weddington — blake@apartmentcorp.com — (310) 927-0020 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Delinquency spreadsheet | `1181003_Anaheim Gardens_Delinquent - Excel_58.xls` |
| Ledger accounts for review | 214 resident accounts |
| Residents with amount owed | 201 accounts; $1,099,741.08 |
| Prepaid / credit accounts | 12 accounts; $-9,973.31 |
| Availability entries | 1 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit's reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| 108 | 1X1STD | Admin | [ ] Verified | __________________ |

## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| AA | JENKINS, SHUPREE | Former resident | $0.00 | $114.80 | $114.80 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| AA | MOSLEY, EBONY | Former resident | $0.00 | $6,724.04 | $6,724.04 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| AA | PALMER, SONJA JOLAINE | Current resident | $4,587.00 | $15,485.88 | $-733.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| AB | MEDINA ZAPATA, MARCO A | Former resident | $4,527.00 | $18,872.92 | $14,345.92 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| AB | THORNTON, TAMALA S | Current resident | $191.53 | $5,402.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| AC | WADELTON, ROBERT | Former resident | $25.00 | $228.16 | $203.16 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| AC | Ragland, Angela V | Current resident | $0.00 | $8,656.96 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| AD | VALDEZ, ELIZABETH | Current resident | $9.00 | $8,044.00 | $460.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| AE | AVILA, PEDRO M | Current resident | $5,131.00 | $15,818.88 | $-315.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| AF | Exlerova, Martina | Former resident | $0.00 | $1,686.08 | $1,686.08 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| AF | WARMACK, JUNE | Former resident | $0.00 | $72.52 | $72.52 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| AF | CHUNG, KEITH J | Current resident | $0.00 | $6,708.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| AG | GORMAN, PATRICK | Former resident | $0.00 | $1,029.00 | $1,029.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| AG | WHITE, SCOTT | Former resident | $0.00 | $863.88 | $863.88 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| AG | WILLIAMS, GILLIAN M | Former resident | $0.00 | $62.00 | $62.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| AG | CARRENA, VERONICA DEYSY | Current resident | $3,348.00 | $10,417.96 | $-400.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| AH | MILLAN, LOURDES | Former resident | $0.00 | $908.88 | $908.88 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| AH | Flores, Martin | Former resident | $0.00 | $1,816.00 | $1,816.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| AH | MURILLO HERNANDEZ, VICTOR | Former resident | $0.00 | $49.00 | $49.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| AH | SANTIAGO, JOSE | Former resident | $0.00 | $119.06 | $119.06 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| AH | SPARKLE, CHARLIE | Former resident | $0.00 | $33.17 | $33.17 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| AH | DURU, LAURETTA | Current resident | $0.00 | $7,947.80 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| BE | DONALD, ARCETT L | Former resident | $0.00 | $1,158.00 | $1,158.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| BE | BOWEN, SHANNON | Former resident | $0.00 | $7,142.00 | $7,142.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| BE | SIMPSON, THEODORE L | Current resident | $937.02 | $34,543.00 | $31,788.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| BF | AGUILAR, MARIA | Former resident | $0.00 | $775.64 | $775.64 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| BF | Morales, Roberto | Current resident | $800.00 | $10,389.00 | $192.12 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| BG | CAMARENA, ARTURO | Former resident | $0.00 | $496.85 | $496.85 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| BG | Freeman, Kevin | Former resident | $0.00 | $3,466.48 | $3,466.48 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| BG | GALLARDO, JONATHAN C | Current resident | $3,177.92 | $8,380.00 | $-568.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| BH | BULLOCK, LINDA R | Former resident | $0.00 | $3,592.02 | $3,592.02 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| BH | LINARES, IDALIA M | Current resident | $1,434.60 | $10,066.00 | $-690.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| BM | Perez, Araceli | Former resident | $0.00 | $2,710.20 | $2,710.20 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| BM | Antar, Khadijah | Current resident | $7,968.24 | $16,217.00 | $-339.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| BN | *CARTER, DAVID | Former resident | $0.00 | $1,499.40 | $1,499.40 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| BN | Roberts, Harmony R | Former resident | $0.00 | $971.72 | $971.72 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| BN | MATANGI, ELISHAM | Former resident | $45.00 | $693.00 | $648.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| BN | EDWARDS, APRI TANISH | Current resident | $757.04 | $7,670.00 | $-176.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| BO | WRIGHT, LA'NISHA D | Current resident | $160.88 | $7,324.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| BP | DOMINGUEZ, PEDRO L | Current resident | $189.26 | $9,324.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| CA | NEGRETE, MARIA | Former resident | $0.00 | $2,252.00 | $2,252.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| CA | NAGRONE, NEIL | Former resident | $0.00 | $2,289.84 | $2,289.84 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| CA | Patterson, Robert | Former resident | $3.00 | $6,432.28 | $6,429.28 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| CA | GARNER, MAISHA | Former resident | $0.00 | $6,773.00 | $6,773.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| CA | BYRD, GWENDOLYN | Former resident | $0.00 | $5,021.00 | $5,021.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| CA | AGUIRRE, SALIN DOMINIQUE | Current resident | $0.00 | $1,922.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| CB | Holland, Joseph | Former resident | $0.00 | $3,118.88 | $3,118.88 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| CB | ROBERSON, JASMINE S | Former resident | $1,986.00 | $6,137.88 | $4,151.88 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| CB | LUEVANOS, EMILY | Current resident | $545.14 | $7,352.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| CC | RUBIO, JOSEFINA | Former resident | $0.00 | $3,963.88 | $3,963.88 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| CC | Li, Bo | Former resident | $0.00 | $2,222.00 | $2,222.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| CC | WILLIAMS, AUJON B | Current resident | $3,524.00 | $13,472.52 | $-85.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| CD | ORTA, ARIEL | Current resident | $13,102.00 | $18,878.96 | $-582.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| CI | CARRANZA, LEONEL | Former resident | $0.00 | $1,729.84 | $1,729.84 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| CI | DOMINGUEZ, JAIME | Former resident | $0.00 | $297.94 | $297.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| CI | STEIN, IESHA S | Former resident | $740.00 | $39,269.16 | $38,529.16 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| CI | MARTINEZ, ADRIANA | Current resident | $0.00 | $8,491.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| CJ | JUAREZ, MARIA M | Former resident | $0.00 | $734.00 | $734.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| CJ | HARPER, DENIKA C | Current resident | $1,397.00 | $7,984.48 | $-138.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| CK | COLLINS, LAVERNE | Former resident | $0.00 | $1,030.36 | $1,030.36 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| CK | Pitchford, Cornelia | Former resident | $0.00 | $834.77 | $834.77 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| CK | SAUNDERS, TSHAYE | Former resident | $0.00 | $314.72 | $314.72 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| CK | FARRIS, JANIKKA S | Former resident | $6,078.00 | $7,422.20 | $1,344.20 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| CK | KING, WILLIAM C | Current resident | $172.19 | $7,676.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| CL | VANN, ERIKA | Former resident | $0.00 | $2,583.90 | $2,583.90 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| CL | Alvarez, Nancy | Former resident | $0.00 | $1,422.16 | $1,422.16 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| CL | SNEAD, GABRIELLE | Former resident | $0.00 | $350.90 | $350.90 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| CL | POSADAS MEJIA, NANCY C | Former resident | $2,873.00 | $3,450.96 | $577.96 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| CL | PEREIRA, JOHANA STEPHANI | Former resident | $0.00 | $19,863.56 | $19,863.56 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| CL | LAGUNAS, IRENE | Current resident | $36.89 | $12,874.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| DA | CORRAL, OSCAR | Former resident | $0.00 | $346.00 | $346.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| DA | JONES, TIAUNA P | Current resident | $14,870.00 | $27,852.76 | $3,998.88 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| DB | FAVELA, MYRNA | Former resident | $0.00 | $3,027.80 | $3,027.80 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| DB | OLAOSE, OLUWAFUNMILOLA | Former resident | $0.00 | $1,490.04 | $1,490.04 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| DB | SIMPSON, NICOLE | Current resident | $2,861.00 | $9,975.48 | $-492.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| DC | ZENDEJAS, JOAQUIN | Current resident | $0.00 | $7,999.88 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| DD | HECTOR, IRIBE | Former resident | $0.00 | $6,895.00 | $6,895.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| DD | PADILLA, NOELIA | Current resident | $0.00 | $1,700.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| DE | FRANCO, NADIA | Former resident | $1.00 | $57.00 | $56.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| DE | WILLIS, SHARRON | Current resident | $182.55 | $7,716.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| DF | CAMARENA, CARLA | Former resident | $0.00 | $1,244.76 | $1,244.76 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| DF | ORTIZ, ONDRIA R | Former resident | $1.00 | $1,964.20 | $1,963.20 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| DF | FLYNN, SHAMEKA S | Former resident | $4,227.00 | $10,476.92 | $6,249.92 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| DF | SCOTT, DELORES D | Current resident | $0.00 | $7,500.44 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| DG | MCGRUE, CATHY | Former resident | $0.00 | $197.40 | $197.40 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| DG | Soriano, Blanca | Former resident | $0.00 | $1,955.56 | $1,955.56 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| DG | DELONEY, QUINISHA | Current resident | $4.28 | $5,524.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| DH | GANAS, JOHN B | Former resident | $0.00 | $2,800.90 | $2,800.90 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| DH | HERNANDEZ, ANGELICA | Former resident | $404.00 | $474.48 | $70.48 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| DH | WOODMAN, TEYA YVETTE | Former resident | $1,517.00 | $1,904.24 | $387.24 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| DH | HERNANDEZ, CAROLINA ELIZABETH | Current resident | $0.00 | $9,705.80 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| EA | MOLINA, OFELIA D | Current resident | $252.51 | $8,617.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| EB | MEDINA, JOSE D | Current resident | $5,133.00 | $13,149.96 | $-566.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| EC | BURGESS, SOLEDAD | Current resident | $3.20 | $7,913.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| EC | SERVIN, IRMA C | Former resident | $0.00 | $1,404.80 | $1,404.80 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| ED | Tinoco, Maria | Current resident | $0.00 | $18,115.00 | $15,882.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| EE | PETTAWAY, JESSIE J | Current resident | $5,760.56 | $8,216.00 | $-3,180.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| EE | THOMPSON, CHRISTOPHER | Former resident | $0.00 | $74.99 | $74.99 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| EE | Bueno, Evelyn | Former resident | $0.00 | $664.98 | $664.98 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| EE | Menarde, Jonas | Former resident | $60.00 | $81.12 | $21.12 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| EF | LOPEZ, JOSEFINA | Current resident | $1,642.00 | $9,956.00 | $-182.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| EG | Alas, ANA G | Current resident | $3,256.84 | $10,112.00 | $-155.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| EH | GUZMAN PARRA, MANUEL | Former resident | $0.00 | $2,028.00 | $2,028.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| EH | AVILA, IVY BEATRIZ | Current resident | $4,426.00 | $14,585.88 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| FA | Garcia, Guadalupe | Former resident | $0.00 | $2,663.53 | $2,663.53 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| FA | Flores, Orlando | Former resident | $0.00 | $1,714.60 | $1,714.60 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| FA | TAYLOR, MARY | Former resident | $0.00 | $4,138.00 | $4,138.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| FA | SPRIGGS, JONATHAN | Former resident | $0.00 | $1,415.00 | $1,415.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| FA | KASHIF, UME | Former resident | $0.00 | $3,083.00 | $3,083.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| FA | GHAZOULI, MHDAITHAM ADNAN | Former resident | $0.00 | $4,502.00 | $4,502.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| FA | BARBIC, SAMANTHA KRISTINA | Former resident | $0.00 | $4,077.00 | $4,077.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| FA | CANNON, ERIN RAE | Current resident | $0.00 | $54,629.00 | $48,575.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| FB | WILLIS, SHAREY A | Former resident | $2,455.00 | $100,316.90 | $97,861.90 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| FB | CORLEY, LARENCIA A | Current resident | $39.42 | $7,635.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| FC | MOLINA, ROSA M | Current resident | $7,448.00 | $10,116.00 | $-2,076.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| FD | CARRILLO, CARMEN C | Former resident | $0.00 | $1,681.00 | $1,681.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| FD | MATTHIS, DAWNTASIA D | Former resident | $976.00 | $1,295.84 | $319.84 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| FD | GONZALEZ MATEO, MARIA DEL CARMEN | Current resident | $0.00 | $7,682.81 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| FE | CAMPOS, MARIA I | Current resident | $2,874.00 | $13,418.44 | $32.56 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| FF | VENTURA LARA, MARIA S | Current resident | $3,647.00 | $11,768.94 | $-599.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| FG | ARCEO, ROSARIO | Former resident | $0.00 | $2,469.00 | $2,469.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| FG | FLYNN, CHERRELL A | Current resident | $3,096.00 | $9,173.93 | $-158.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| FH | OLAYA, CLAUDIA F | Former resident | $0.00 | $1,740.48 | $1,740.48 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| FH | Lamar, Tiffani D | Former resident | $0.00 | $798.92 | $798.92 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| FH | BELT, PATRICE LATICIA | Current resident | $644.00 | $6,610.84 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| GA | *THOMAS, VANESSA | Former resident | $0.00 | $2,115.72 | $2,115.72 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| GA | Lozano, Lupita | Former resident | $0.00 | $3,028.28 | $3,028.28 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| GA | HEATH, MERCEDES | Former resident | $777.00 | $7,934.32 | $7,157.32 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| GA | GLOVER, DONYELLE RAESHAUN | Current resident | $217.00 | $6,543.24 | $-217.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| GB | *KOONCE, JACQUEL | Former resident | $0.00 | $1,527.28 | $1,527.28 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| GB | Jenkins, Stephen J | Current resident | $368.88 | $9,115.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| GC | ALAVAREZ, FRANCIS | Former resident | $7.00 | $549.96 | $542.96 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| GC | DURONTE, ROCHELLE L | Current resident | $0.00 | $9,284.80 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| GD | West, Keisha | Former resident | $0.00 | $347.00 | $347.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| GD | JENKINS, AYISHA NC | Former resident | $0.00 | $1,939.86 | $1,939.86 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| GD | ROBINSON, TROIESHA P | Current resident | $2,799.00 | $12,081.78 | $-541.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| GE | CARRILLO, ANTONIA | Former resident | $0.00 | $8,300.96 | $8,300.96 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| GE | ADAMS, LAQUIDA S | Former resident | $5,677.00 | $9,198.50 | $3,521.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| GE | YOON, SUK | Current resident | $0.00 | $7,345.40 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| GF | *LESCAILLE, DAISY | Former resident | $0.00 | $215.40 | $215.40 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| GF | Badmus, Rasheed B | Former resident | $0.00 | $1,415.00 | $1,415.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| GF | COTTON, MAYA L | Former resident | $1,392.00 | $1,688.60 | $296.60 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| GF | ANDERSON, ECOLA C | Current resident | $1,579.00 | $9,521.16 | $-124.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| GG | FIGUEROA, DEBBIE | Former resident | $0.00 | $7,929.60 | $7,929.60 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| GG | PRUITT, TANASHA S | Current resident | $150.76 | $7,542.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| GH | LOPEZ NAVARRO, JOSE A | Current resident | $33.04 | $8,709.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| HA | THOMPSON, WANDA | Former resident | $0.00 | $4,880.46 | $4,880.46 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| HA | GUIJARRO VALENCIA, HIDALIA | Former resident | $1,195.00 | $2,717.14 | $1,522.14 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| HA | LEE, BRITNEY LA SHAE | Former resident | $0.00 | $4.28 | $4.28 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| HA | JOSHUA, NECOLE D | Current resident | $1,760.00 | $10,245.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| HB | ARROYO, DOLORES | Former resident | $0.00 | $1,403.00 | $1,403.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| HB | OLAOSE, OLU DAMON O | Current resident | $490.00 | $5,769.80 | $-329.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| HC | RODERICK, PATRICIA | Former resident | $0.00 | $809.96 | $809.96 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| HC | REYES, MILENA | Current resident | $66.00 | $7,247.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| HC | Palmer, Okang | Former resident | $0.00 | $1,597.78 | $1,597.78 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| HG | May, Byron | Former resident | $1,467.00 | $3,008.28 | $1,541.28 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| HG | GARCIA, PATRICIA ELENA | Current resident | $7,984.36 | $12,422.00 | $-247.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| HH | VALDEZ, KATHERINE | Current resident | $0.00 | $7,444.78 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| HI | MCGREW, RAYMOND | Former resident | $0.00 | $2,219.56 | $2,219.56 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| HI | LANGSTON, JESSICA | Former resident | $784.00 | $2,906.64 | $2,122.64 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| HI | Hernandez, Felipe | Current resident | $0.00 | $6,858.44 | $35.56 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| JD | CORRAL, PAULA Z | Current resident | $0.00 | $7,392.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| JE | WRIGHT, MELBA | Former resident | $0.00 | $1,394.00 | $1,394.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| JE | CARR, MICHAEL W | Current resident | $424.06 | $6,008.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| JF | ORTIZ-LECHUGA, EDUARDO | Former resident | $0.00 | $292.00 | $292.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| JF | ALAS TORRES, ANA | Current resident | $1,250.00 | $8,652.00 | $-80.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| JJ | MOORE, DEREK | Former resident | $0.00 | $125.88 | $125.88 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| JJ | WILLIAMS, RODERICK | Former resident | $0.00 | $12.44 | $12.44 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| JJ | HINDS, FRANCHESKA H | Current resident | $0.02 | $6,044.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| JK | Olmos, Virginia | Former resident | $0.00 | $1,976.20 | $1,976.20 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| JK | MYERS, PAMELA G | Current resident | $0.00 | $5,816.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| JL | MENDOZA, MARIA DORA | Current resident | $8.04 | $8,938.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| KA | CARRILLO, ANITA | Former resident | $0.00 | $1,725.96 | $1,725.96 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| KA | SMITH, SOMMER D | Former resident | $725.00 | $1,359.84 | $634.84 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| KA | PEREZ, MAYRA L | Current resident | $1,202.00 | $5,177.00 | $-477.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| KB | FLORES, JACQUELINE | Former resident | $0.00 | $1,667.20 | $1,667.20 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| KB | Greene, Lance | Former resident | $0.00 | $415.00 | $415.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| KB | COLEMAN, JUNIPER D | Current resident | $0.00 | $6,645.23 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| KC | BLALOCK, EFFIE M | Former resident | $0.00 | $6,628.84 | $6,628.84 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| KC | MATTHIS, MICHELLE D | Current resident | $0.00 | $6,248.56 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| KG | CORPUS, JESSE | Former resident | $0.00 | $1,026.80 | $1,026.80 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| KG | KING, VIRGINIA | Former resident | $0.00 | $961.00 | $961.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| KG | STEVENS, BRANDY | Former resident | $0.00 | $678.96 | $678.96 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| KG | WATKINS, DELASHAWN ELISA | Current resident | $3,311.00 | $10,431.80 | $-609.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| KH | WHITE, BRENDA | Current resident | $0.42 | $7,325.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| KI | KERR, BALFORD | Current resident | $0.00 | $7,954.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| MD | AGUILERA, MARIA | Former resident | $0.00 | $1,518.80 | $1,518.80 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| MD | BUTTS, LATOYA | Former resident | $1.00 | $1,228.52 | $1,227.52 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| MD | VERNON, ASPEN | Former resident | $0.00 | $117.00 | $117.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| MD | JASPER, LATISHA R | Current resident | $0.00 | $7,076.95 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| MD | SOTO, MAYTEE GUADALUPE | Former resident | $0.00 | $608.20 | $608.20 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| ME | CARDENAS, RUTH | Current resident | $15.00 | $7,446.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| MF | GARCIA, PATRICIA | Former resident | $0.00 | $1,527.68 | $1,527.68 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| MF | FREW, SANDRA | Former resident | $1,213.00 | $5,122.92 | $3,909.92 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| MF | BAIRD, VIRGIL WARREN | Current resident | $157.04 | $9,296.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| MJ | FOREST, LOLITA | Former resident | $0.00 | $23,811.88 | $23,811.88 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| MJ | SCOTT, ML | Current resident | $0.00 | $6,238.96 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| MK | LEWIS, CAROLYN | Former resident | $0.00 | $2,919.85 | $2,919.85 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| MK | RAMIREZ, JOHN HENRY | Current resident | $0.00 | $6,700.73 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| ML | BUENO, ALEJANDRINA L | Former resident | $835.00 | $2,855.00 | $2,020.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| ML | GUERRA, TANIA ELIZABETH | Current resident | $0.00 | $7,622.48 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| BH | HERNANDEZ, ROSIO | Former resident | $7,356.00 | $6,336.32 | $-1,019.68 | [ ] Confirm paid | — |
| BN | MORGAN, CIERRA | Former resident | $1,179.00 | $137.00 | $-1,042.00 | [ ] Confirm paid | — |
| BO | PASCUAL, CRISTINA A | Former resident | $2,208.00 | $1,289.33 | $-918.67 | [ ] Confirm paid | — |
| BP | CARDENAS, GONZALO | Former resident | $2,166.04 | $0.00 | $-2,166.04 | [ ] Confirm paid | — |
| CB | KENNYBREW, SHARI | Former resident | $7,377.00 | $5,137.00 | $-2,240.00 | [ ] Confirm paid | — |
| CJ | ROSS, SHAMIERE NATE | Former resident | $1,194.00 | $1,014.00 | $-180.00 | [ ] Confirm paid | — |
| DB | KING, VIRGINIA | Former resident | $307.96 | $0.00 | $-307.96 | [ ] Confirm paid | — |
| DG | BUSTILLOS, DENISE | Former resident | $12,403.00 | $11,117.00 | $-1,286.00 | [ ] Confirm paid | — |
| HI | MCFARLAND, SHANDRIKA D | Former resident | $461.00 | $34.28 | $-426.72 | [ ] Confirm paid | — |
| JJ | DURONTE, ROCHELLE | Former resident | $26.00 | $0.00 | $-26.00 | [ ] Confirm paid | — |
| JK | BATES, MARCUS | Former resident | $224.00 | $65.76 | $-158.24 | [ ] Confirm paid | — |
| MF | BROOKS, BROOK ASHLEY | Former resident | $2,798.00 | $2,596.00 | $-202.00 | [ ] Confirm paid | — |

## Resident Balance Follow-Up — Paid / Zero Balance

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| AH | GOLDEN, JASMINE VICTORIA | Former resident | $806.00 | $806.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property's supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*