# Arbor Crest — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 4304099**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/05/2026 |
| Property manager | Erica Finch — arborcrest@apartmentcorp.com — (850) 459-9201 |
| Regional manager | JR Rolon — jrrolon@apartmentcorp.com — (941) 716-1665; Leslie Rolon — leslie@apartmentcorp.com — (504) 247-3813 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Delinquency spreadsheet | `4304099_Arbor Crest_Delinquent - Excel_58.xls` |
| Ledger accounts for review | 569 resident accounts |
| Residents with amount owed | 504 accounts; $2,365,584.13 |
| Prepaid / credit accounts | 61 accounts; $-10,865.91 |
| Availability entries | 0 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit's reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| — | — | No unit-status entries in the selected source export | [ ] Verified | __________________ |

## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - 1101 | Jackson, Jessica | Former resident | $0.00 | $273.21 | $273.21 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1101 | Mosley*, Ashley | Former resident | $1,201.00 | $9,520.00 | $8,319.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1101 | Jackson, Quineldra | Former resident | $0.00 | $5,979.00 | $5,979.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1101 | Scott, Sharda Latrell | Former resident | $0.00 | $5,255.81 | $5,255.81 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1101 | Bailey, Kevin | Former resident | $0.00 | $1,743.94 | $1,743.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1101 | Barnes, Vanessa | Current resident | $0.00 | $1,372.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1102 | Stevens, Derrick | Former resident | $0.00 | $11,500.00 | $11,500.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1102 | Akins, Zola Maria | Former resident | $0.00 | $2,693.21 | $2,693.21 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1102 | Pearson, Quintaria Manuel | Former resident | $0.00 | $6,206.00 | $6,206.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1102 | Alexis, Lillie Rean | Former resident | $0.00 | $7,757.81 | $7,757.81 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1103 | Davis, Terasie D | Former resident | $0.00 | $25.00 | $25.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1103 | Harper, Dustin | Former resident | $0.00 | $1,435.00 | $1,435.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1103 | Mixon, Miracle | Former resident | $0.00 | $2,016.29 | $2,016.29 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1103 | Davis, Treyondria Quarya | Former resident | $0.00 | $5,621.83 | $5,621.83 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1103 | Wilford*, Keanah | Former resident | $1,130.00 | $7,370.00 | $6,240.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1104 | Mitchell, Courtney | Former resident | $0.00 | $13,550.00 | $13,550.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1104 | Lee, Darius | Former resident | $0.00 | $6,667.00 | $6,667.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1104 | Johnson, Sunshine | Former resident | $0.00 | $3,226.00 | $3,226.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1104 | Jones, Jamya Shanice | Former resident | $0.00 | $6,772.00 | $6,772.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1104 | Crews, Briahnana Renee | Former resident | $0.00 | $6,117.15 | $6,117.15 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1104 | Gavin, Latavia T | Former resident | $0.00 | $8,007.00 | $8,007.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1104 | Williams, Breona Denise | Former resident | $0.00 | $10,219.83 | $10,219.83 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1104 | Johnson, Beulah | Current resident | $0.00 | $508.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1105 | Redding, Tiffany L | Former resident | $0.00 | $4,851.26 | $4,851.26 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1105 | Ward, Kimberly Demetrius | Former resident | $0.00 | $1,256.45 | $1,256.45 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1105 | Harris, Littian | Former resident | $0.00 | $5,491.93 | $5,491.93 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1105 | Jennings, Derrick | Former resident | $0.00 | $9,974.06 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1105 | Smith, Simone | Current resident | $0.00 | $1,356.94 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1107 | Jackson*, Brittany | Former resident | $648.60 | $3,636.80 | $2,988.20 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1107 | Colston*, Artesheia Diane | Former resident | $358.29 | $1,274.29 | $916.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1107 | Oliver, Jenise | Former resident | $0.00 | $9,702.00 | $9,702.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1107 | Hover, Christina | Former resident | $0.00 | $7,156.24 | $7,156.24 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1107 | Wilson, Jamia Quinisha | Former resident | $0.00 | $14,531.83 | $14,531.83 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1107 | Ford, Demetrice Renea | Current resident | $0.00 | $1,372.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1107 | Guzman Nogales, Alexis A | Former resident | $0.00 | $1,350.00 | $1,350.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1107 | Owens, Aziza | Former resident | $0.00 | $11,085.52 | $11,085.52 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1108 | Ward, Patti | Former resident | $0.00 | $4,674.00 | $4,674.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1108 | Davis, Quianna Daneka | Former resident | $0.00 | $4,607.00 | $4,607.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1109 | Wilford**, Tony | Former resident | $0.00 | $4,132.92 | $4,132.92 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1109 | Crawford, Jasmine Latoya | Former resident | $0.00 | $8,020.86 | $8,020.86 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1109 | Forward, Jamiya Jaiden Shante | Former resident | $0.00 | $11,037.55 | $11,037.55 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1109 | Grimes, Jasmine Savonna | Former resident | $0.00 | $2,804.00 | $2,804.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1109 | Lockwood, Nikitra Shandrea | Former resident | $0.00 | $5,884.00 | $5,884.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1109 | Stanly, Curtis Lewis | Current resident | $0.00 | $11.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1110 | Walker, Brenda J | Former resident | $0.00 | $1,000.05 | $1,000.05 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1110 | Gavin, Camela | Former resident | $0.00 | $6,622.97 | $6,622.97 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1111 | *Green, CierraShante | Former resident | $0.00 | $525.00 | $525.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1111 | Wood, Tiffani Danielle | Former resident | $0.00 | $2,612.52 | $2,612.52 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1111 | Green, Delisia Redazia | Former resident | $0.00 | $3,619.20 | $3,619.20 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1111 | Jackson, Nyasia Aleigh | Former resident | $0.00 | $5,167.82 | $5,167.82 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1111 | Pruitt, Makiyah LinNekqua | Current resident | $0.00 | $1,210.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1113 | Ana Ibarra | Former resident | $0.00 | $924.01 | $924.01 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1113 | Perkins, Sheena | Former resident | $0.00 | $1,467.97 | $1,467.97 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1114 | Hodges, Deborah | Former resident | $0.00 | $1,761.28 | $1,761.28 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1114 | Goodson, Jacquelyn | Former resident | $0.00 | $9,044.20 | $9,044.20 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1115 | Creal, Rachael | Former resident | $0.00 | $1,080.00 | $1,080.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1115 | Matthews, Praziyo D | Former resident | $0.00 | $3,049.00 | $3,049.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1115 | James, Essie | Former resident | $0.00 | $4,601.00 | $4,601.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1115 | Kilroy, Patricia Ann | Former resident | $0.00 | $7,004.06 | $7,004.06 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1116 | Carr*, Terra | Former resident | $30.66 | $4,019.98 | $-30.66 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1116 | Robinson, Grady | Former resident | $0.00 | $20,272.48 | $20,272.48 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1117 | Ragin, Mercedes Trenae | Current resident | $0.00 | $1,722.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1118 | McCall, Edricka J | Former resident | $0.00 | $1,883.51 | $1,883.51 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1119 | Knox, Felicia | Former resident | $0.00 | $609.87 | $609.87 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1119 | Bell, Tremek | Former resident | $0.00 | $8,242.80 | $8,242.80 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1119 | Woods Dubose, Martha Rena | Former resident | $0.00 | $8,349.56 | $8,349.56 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1120 | *Smith, Tracy | Current resident | $0.00 | $2,496.00 | $226.46 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1201 | Byrd, Krunetta M | Former resident | $0.00 | $6,738.23 | $6,738.23 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1201 | Simpson, Doris Anits | Former resident | $0.00 | $7,946.33 | $7,946.33 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1201 | Small*, Keyshonna Lashawn | Former resident | $409.00 | $1,889.00 | $1,480.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1201 | Garcia, Alexis | Former resident | $0.00 | $5,283.06 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1202 | Pruitt*, Sonja | Former resident | $0.00 | $235.07 | $235.07 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1202 | Livingston, Jessica | Former resident | $0.00 | $8,689.58 | $8,689.58 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1202 | Williams, Deja | Former resident | $0.00 | $5,669.20 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1202 | Deans, Sherrie | Current resident | $0.00 | $1,329.97 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1203 | Daniels, Derrick | Former resident | $0.00 | $442.83 | $442.83 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1203 | McClain, Latrell | Former resident | $0.00 | $882.24 | $882.24 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1203 | Howard*, Monica | Former resident | $1.37 | $699.51 | $698.14 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1203 | Lindsey, Jada | Former resident | $0.00 | $1,108.81 | $1,108.81 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1203 | *Boyd, Shaqualia Monique | Former resident | $0.00 | $6,205.20 | $6,205.20 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1203 | Russ, Alane | Former resident | $0.00 | $8,851.67 | $8,851.67 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1203 | Robinson, Mary | Former resident | $0.00 | $4,138.87 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1204 | Williams, Shatisha Tirs | Former resident | $0.00 | $1,832.57 | $1,832.57 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1205 | Sheffield*, Latyria L | Former resident | $0.00 | $4,259.36 | $4,259.36 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1205 | Brown, Kaleycia Yolanda | Former resident | $0.00 | $17.61 | $17.61 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1205 | Oliver O'Neal, A'Shaydrian Nicole | Former resident | $0.00 | $2,561.97 | $2,561.97 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1205 | Addison, Erica Danielle | Former resident | $0.00 | $5,176.77 | $5,176.77 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1206 | Williams, Jamie Salome | Former resident | $0.00 | $7,031.94 | $7,031.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1206 | Woods, Shakia Nicole | Former resident | $0.00 | $10,834.44 | $10,834.44 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1206 | Green, Davontraiz | Current resident | $0.00 | $2,744.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1207 | Hill**, Jasmine A | Former resident | $417.81 | $800.00 | $382.19 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1207 | Jackson*, Latoya | Former resident | $1,337.00 | $5,542.00 | $4,205.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1207 | Senior, Chakita Diane | Former resident | $0.00 | $4,164.98 | $4,164.98 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1207 | Parris, Khadijah Nikia | Former resident | $0.00 | $11,343.23 | $11,343.23 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1207 | Gibson, Gwennisha | Current resident | $0.00 | $1,347.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1208 | Highman**, Keshandra | Former resident | $136.53 | $500.00 | $363.47 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1208 | Butler, Azua | Former resident | $0.00 | $5,680.54 | $5,680.54 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1208 | Black*, Audora Regina | Current resident | $0.00 | $5.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1209 | Doyle*, Briana Dantice | Former resident | $0.00 | $3,200.00 | $3,200.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1209 | Graham, Domonique Jaytashia | Former resident | $0.00 | $1,149.74 | $1,149.74 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1209 | Pearson, Antonette L | Former resident | $0.00 | $3,976.10 | $3,976.10 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1209 | Cannon, Brianna Dell | Current resident | $0.00 | $1,210.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1210 | Spann, Pearl | Former resident | $0.00 | $8,892.13 | $8,892.13 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1210 | Copeland, Carol | Former resident | $431.13 | $3,457.74 | $3,026.61 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1210 | Stanley, Lauren | Former resident | $0.00 | $6,184.14 | $6,184.14 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1212 | Baldwin, Karl | Former resident | $0.00 | $1,150.40 | $1,150.40 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1212 | Moore, Sierra | Former resident | $0.00 | $2,796.20 | $2,796.20 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1212 | Allen, Angelica Na'shae | Former resident | $0.00 | $8,273.78 | $8,273.78 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1212 | Robinson, Michael | Former resident | $0.00 | $5,021.91 | $5,021.91 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1212 | McNare, Naesha | Former resident | $0.00 | $12,574.26 | $12,574.26 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1212 | *Casas, Izabel | Former resident | $0.00 | $5,122.21 | $5,122.21 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1212 | Faulk*, Dionna | Former resident | $0.00 | $7,779.26 | $1,123.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1213 | Sanchez, Jorge T | Former resident | $0.00 | $657.78 | $657.78 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1213 | Sweet, Sandra | Former resident | $0.00 | $1,640.00 | $1,640.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1213 | Jordan, Tyesha | Former resident | $0.00 | $6,235.59 | $6,235.59 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1213 | Daniels, LeAndrea | Former resident | $0.00 | $1,742.39 | $1,742.39 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1213 | Chambers, Marquiesha Rochelle | Former resident | $0.00 | $7,050.80 | $7,050.80 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1213 | Young, Kawambee Denise | Former resident | $0.00 | $11,743.79 | $11,743.79 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1214 | Howard, Shawnette Tressilian | Former resident | $0.00 | $4,411.88 | $4,411.88 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1214 | Graddy, Leslie Lynette | Former resident | $0.00 | $5,463.70 | $5,463.70 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1215 | Stypinski, Nicole | Former resident | $0.00 | $9,847.84 | $9,847.84 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1215 | Washington, Shalaunna Shante | Former resident | $0.00 | $103.00 | $103.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1216 | Green, Cassandra* | Former resident | $0.00 | $3,534.95 | $3,534.95 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1216 | Mcintosh, Quanisha | Former resident | $0.00 | $4,799.53 | $4,799.53 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1216 | James, RaUni Akiliy Sa'myni | Former resident | $0.00 | $5,130.03 | $5,130.03 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1216 | Brown, Kadiedra | Former resident | $0.00 | $7,103.83 | $7,103.83 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1216 | Manning, Kenya T | Former resident | $0.00 | $4,877.14 | $4,877.14 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1217 | Pearson, Derrick Leon | Former resident | $0.00 | $465.00 | $465.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1217 | McMullen, Crystal | Former resident | $0.00 | $1,377.10 | $1,377.10 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1217 | Ward, Jessica | Former resident | $0.00 | $651.10 | $651.10 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1217 | Baker, Carla | Former resident | $0.00 | $7,692.00 | $7,692.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1217 | Hannah, Dontareka | Former resident | $0.00 | $9,373.80 | $1,609.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1218 | Berry, Antwanda Deambernique | Former resident | $0.00 | $5,394.00 | $5,394.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1218 | Foreman*, Barbara Jean | Former resident | $0.00 | $2,772.01 | $2,772.01 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1218 | Jefferson, Latisha Nicole | Former resident | $0.00 | $2,932.58 | $2,932.58 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1218 | McMillon, Sydni | Former resident | $0.00 | $1,728.00 | $1,728.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1218 | Jackson, Latonia | Current resident | $0.00 | $1,206.81 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1219 | Pride, Priscilla | Former resident | $0.00 | $8,165.00 | $8,165.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1219 | Atherton, Makayla | Current resident | $0.00 | $1,395.03 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1220 | Wilson, Brittanica | Former resident | $0.00 | $32.19 | $32.19 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1220 | Galloway, Sharria | Former resident | $0.00 | $5,488.92 | $5,488.92 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1301 | Akins**, Chessica M | Former resident | $1,268.00 | $3,337.78 | $2,069.78 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1301 | Johnson, Bershawn | Former resident | $0.00 | $1,371.00 | $1,371.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1301 | Anthony, Shainitra | Former resident | $0.00 | $7,826.53 | $7,826.53 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1301 | Thomas, Michelle Lashae | Former resident | $0.00 | $8,572.82 | $8,572.82 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1301 | Cargile, Tiaisha | Former resident | $0.00 | $7,017.15 | $7,017.15 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1301 | Sailor, Keymiria | Current resident | $0.00 | $1,372.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1302 | Bibbins, Wendy Renee | Former resident | $0.00 | $9,487.42 | $9,487.42 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1302 | Muhammad*, Kameelah Sadiyyah Marsha | Former resident | $0.00 | $3,838.75 | $3,838.75 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1302 | Mathis, Adrienne | Former resident | $0.00 | $5,432.74 | $5,432.74 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1302 | Cook, Valencia | Former resident | $0.00 | $7,170.00 | $7,170.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1302 | Senior, Amber Tanille | Current resident | $0.00 | $1,372.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1303 | Harley-Flowers*, Cathy A | Former resident | $305.60 | $4,955.78 | $4,650.18 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1303 | White, Jamal | Former resident | $0.00 | $4,833.02 | $4,833.02 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1303 | Gilbert Rumph, Nayleena Marie | Former resident | $0.00 | $5,662.18 | $5,662.18 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1303 | Burke, Teresa | Former resident | $0.00 | $4,808.63 | $4,808.63 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1303 | Byrd, Likazia | Former resident | $0.00 | $8,859.15 | $2,809.71 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1304 | Davis, Shazet | Former resident | $0.00 | $1,162.90 | $1,162.90 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1304 | Wood, Tiffani | Former resident | $0.00 | $227.91 | $227.91 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1304 | Manzano, Marisela | Former resident | $0.00 | $5,663.00 | $5,663.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1304 | Jones, Bryan Lamonte | Former resident | $0.00 | $4,209.52 | $4,209.52 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1304 | Williams, Tina Annnell | Former resident | $0.00 | $11,961.11 | $11,961.11 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1304 | Peterson, Felicia | Former resident | $0.00 | $7,737.00 | $7,737.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1304 | Johnson, Vicki | Former resident | $0.00 | $8,342.60 | $8,342.60 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1305 | Brown, Tavon | Former resident | $0.00 | $1,584.16 | $1,584.16 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1305 | Bradley, Alexandria Paige | Former resident | $280.11 | $9,052.26 | $8,772.15 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1305 | Anderson, Tamiki | Former resident | $0.00 | $7,298.64 | $7,298.64 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1305 | Rogers, Sadoreia | Former resident | $0.00 | $7,425.00 | $7,425.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1305 | Bush, Quateria Ronta | Former resident | $0.00 | $11,553.12 | $11,553.12 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1305 | Bridges, Denise | Former resident | $348.40 | $7,367.80 | $7,019.40 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1306 | Blanks, Isiah | Former resident | $0.00 | $1,070.00 | $1,070.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1306 | Blount, Ladrica Lashay | Former resident | $127.63 | $6,594.03 | $6,466.40 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1307 | Hardeman, Patty Dawn | Former resident | $0.00 | $16,098.94 | $16,098.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1307 | Davis, Alyson | Former resident | $0.00 | $4,712.00 | $4,712.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1307 | Reynolds, Reeshara | Former resident | $0.00 | $13,691.00 | $13,691.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1307 | Thomas, Sierra Shantaye | Former resident | $0.00 | $10,370.66 | $10,370.66 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1307 | Wilson, Benia | Former resident | $0.00 | $7,538.06 | $7,538.06 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1307 | McCray, Shanterria Shirna | Former resident | $0.00 | $7,553.83 | $7,553.83 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1308 | Ash*, Jessica Livett | Former resident | $0.00 | $6,463.73 | $6,463.73 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1308 | Hall, Sharmeika D | Former resident | $0.00 | $11,759.15 | $11,759.15 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1308 | Jean, Wadson | Former resident | $0.00 | $1,774.13 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1309 | Hill, Massa | Former resident | $0.00 | $2,479.03 | $2,479.03 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1309 | Johnson, Monkiara | Former resident | $0.00 | $6,326.00 | $6,326.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1309 | Cobb, Xavier | Former resident | $0.00 | $574.74 | $574.74 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1309 | Robinson, Latoya | Former resident | $0.00 | $1,361.55 | $1,361.55 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1309 | Butler, Ke'Aria Nikya | Former resident | $0.00 | $6,717.07 | $6,717.07 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1309 | Barber, Sadie | Former resident | $0.00 | $7,828.61 | $7,828.61 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1309 | McCloud, Deneka Lashuanda | Former resident | $0.00 | $10,332.50 | $10,332.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1309 | Johnson, Trina | Former resident | $0.00 | $11,092.00 | $11,092.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1309 | Jones, Vikeria | Former resident | $0.00 | $11,204.84 | $11,204.84 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1309 | Smith, Darren | Former resident | $0.00 | $6,417.75 | $6,417.75 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1309 | *Horne, Felicity Avanti | Current resident | $0.00 | $2,705.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1310 | Fain*, Christopher Antwone | Former resident | $0.00 | $7,641.60 | $7,641.60 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1310 | Grant, Raushanah Sheriece | Former resident | $0.00 | $3,814.97 | $3,814.97 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1310 | Smith, Lizzie Lashae | Former resident | $0.00 | $10,577.00 | $10,577.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1310 | Dawson, Shantavia C | Former resident | $0.00 | $6,593.80 | $6,593.80 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1310 | Wilford, Andricka | Former resident | $0.00 | $3,100.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1311 | Russ, Adrienne | Former resident | $0.00 | $2,715.00 | $2,715.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1311 | Alford, Asia | Former resident | $0.00 | $1,933.09 | $1,933.09 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1311 | McCray, Brittney Utethia | Former resident | $0.00 | $4,768.77 | $4,768.77 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1311 | Estelle, Valencia | Former resident | $0.00 | $4,437.00 | $4,437.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1311 | Tarver, Tahreeka Timon | Former resident | $0.00 | $6,584.27 | $6,584.27 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1311 | Brown, Kaleycia Yolanda | Former resident | $0.00 | $7,702.44 | $7,702.44 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1311 | *Parker, Jaylon | Current resident | $0.00 | $2,825.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1312 | Thomas, Niresha L | Former resident | $0.00 | $36.20 | $36.20 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1312 | Dennis, Te'Aira | Former resident | $0.00 | $4,788.23 | $4,788.23 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1312 | Howard, Teresa | Former resident | $0.00 | $4,308.23 | $4,308.23 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1312 | Copeland, Aniyah Julannia | Current resident | $0.00 | $1,210.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1313 | Holmes, Natasha | Former resident | $0.00 | $1,947.00 | $1,947.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1313 | Smart, Dayatra | Former resident | $0.00 | $1,110.00 | $1,110.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1313 | Watson, Cierra | Former resident | $0.00 | $5,199.52 | $5,199.52 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1313 | Wilford, Tenesha Lashaye | Former resident | $0.00 | $11,759.00 | $11,759.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1313 | Flemming, Chantel | Former resident | $0.00 | $10,094.37 | $10,094.37 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1313 | Kendrid, Dion | Former resident | $0.00 | $6,031.27 | $6,031.27 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1313 | Hicks, Tymia Janeka | Former resident | $0.00 | $9,771.65 | $9,771.65 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1313 | Eummer, Shanteka Ashawn | Former resident | $0.00 | $12,353.55 | $12,353.55 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1313 | Grant*, Nigeria | Former resident | $0.00 | $3,740.35 | $3,740.35 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1314 | Bostick, Tyquione J | Former resident | $0.00 | $942.00 | $942.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1314 | Hannah, Keanna | Former resident | $0.00 | $5,600.10 | $5,600.10 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1314 | Edward, Lettesea Chanel | Former resident | $0.00 | $6,081.36 | $6,081.36 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1315 | Vann, Keandra Denise | Former resident | $0.00 | $1,372.26 | $1,372.26 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1315 | Wells, Cathy | Current resident | $0.00 | $1,102.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1316 | Jackson, Sylvia | Former resident | $0.00 | $1,503.20 | $1,503.20 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1316 | Jackson, Denisia | Former resident | $0.00 | $1,588.00 | $1,588.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1316 | McCloud, Terika | Former resident | $0.00 | $4,695.61 | $4,695.61 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1316 | Smith, Shameshia Shantel | Former resident | $0.00 | $13,816.83 | $13,816.83 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1316 | Hinson, Chrishanna Brejae | Current resident | $0.00 | $1,210.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1318 | Chestnut, Sabrina | Former resident | $0.00 | $4,412.00 | $4,412.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1318 | Lockwood, Kanisha Lafaye | Former resident | $0.00 | $5,694.26 | $5,694.26 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1318 | Kenon, Jada D'Ericka | Former resident | $0.00 | $4,594.67 | $4,594.67 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1318 | Woods, Anautica | Former resident | $0.00 | $7,863.83 | $7,863.83 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1318 | Hollis, Shavonte | Former resident | $0.00 | $6,168.00 | $6,168.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1318 | Senior, Chakeriah Yalinie | Current resident | $0.00 | $1,210.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1319 | Mitchell, Jamara Denise | Former resident | $0.00 | $6,522.00 | $6,522.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1319 | Donaldson, Shelia Lewis | Former resident | $0.00 | $5,978.35 | $5,978.35 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1319 | Jones, Aerial | Former resident | $0.00 | $7,295.00 | $7,295.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1319 | Lane, Aziah | Current resident | $0.00 | $1,209.37 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1320 | Alford*, Chyrl Dorsey | Former resident | $134.98 | $660.34 | $525.36 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1320 | Geathers, KeAndra Lafaye | Former resident | $0.00 | $4,300.00 | $4,300.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1320 | Austin*, Demario Devontae | Former resident | $209.75 | $5,885.94 | $5,676.19 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2101 | Clayton, DorothyL | Former resident | $0.00 | $3,340.50 | $3,340.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2102 | Lewis*, Barbara | Former resident | $1,027.26 | $2,614.03 | $1,586.77 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2102 | Williams, Toshia Lanette | Former resident | $0.00 | $1,805.67 | $1,805.67 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2102 | Barr, Ly'Tyianna | Former resident | $0.00 | $4,977.87 | $4,977.87 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2102 | Budd, Serinity | Current resident | $0.00 | $912.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2103 | Force*, Gary W | Former resident | $0.00 | $4,607.00 | $4,607.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2103 | Krugman, Jason | Former resident | $0.00 | $1,260.00 | $1,260.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2103 | Chandler*, Mary | Former resident | $205.87 | $235.00 | $29.13 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2103 | Hall, Takiyah Monyeih | Former resident | $0.00 | $6,700.36 | $6,700.36 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2104 | Robinson, Shantoria Beonshayne | Former resident | $0.00 | $701.40 | $701.40 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2104 | Lightfoot, Gatrues | Former resident | $0.00 | $1,680.00 | $1,680.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2104 | Dubose, Yasmin | Former resident | $0.00 | $2,642.10 | $2,642.10 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2104 | McKeever, Carla Christina | Former resident | $0.00 | $10.86 | $10.86 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2104 | Hinson, Brianna | Former resident | $0.00 | $4,523.61 | $4,523.61 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2104 | Adderley, Najee | Former resident | $0.00 | $4,253.83 | $4,253.83 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2104 | Wooden, Lula | Former resident | $0.00 | $12,620.00 | $12,620.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2104 | Thomas, Ke'Ariya Shanbrea | Current resident | $0.00 | $1,032.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2105 | Thurman, Shunterrica L | Former resident | $0.00 | $522.81 | $522.81 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2105 | Gurly, Chimere | Former resident | $0.00 | $2,171.83 | $2,171.83 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2105 | Highman, Cortessia | Former resident | $0.00 | $2,961.20 | $2,961.20 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2105 | Weston, Margo | Former resident | $0.00 | $6,938.87 | $6,938.87 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2105 | Branch, Tominiqua | Former resident | $0.00 | $4,663.70 | $4,663.70 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2106 | Rittman, Timmisha | Former resident | $0.00 | $1,952.67 | $1,952.67 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2106 | Green, Jaddia Latia | Former resident | $0.00 | $1,191.68 | $1,191.68 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2106 | Ash, Tiffany | Former resident | $0.00 | $1,579.60 | $1,579.60 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2106 | Senior, Ciara Marie | Current resident | $0.00 | $1,210.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2107 | Williams, LonieceDixon | Former resident | $0.00 | $1,160.58 | $1,160.58 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2107 | Davis, Vivian Mandrell | Former resident | $816.34 | $3,502.47 | $2,686.13 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2107 | Johnson, Kimberly | Former resident | $0.00 | $3,971.07 | $3,971.07 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2107 | Dixon, Camilia | Former resident | $0.00 | $10,451.65 | $10,451.65 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2107 | Kenon, Jennie Delois | Former resident | $0.00 | $3,625.31 | $3,625.31 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2107 | Tiggle, Christine H | Former resident | $0.00 | $3,976.10 | $3,976.10 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2108 | Collier, Sarena | Former resident | $0.00 | $11,019.80 | $11,019.80 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2108 | Cannon, Shaterrica Rockal | Former resident | $0.00 | $3,294.00 | $3,294.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2108 | Lewis*, Latoya Shrelle | Former resident | $0.05 | $11,100.48 | $11,100.43 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2108 | Allen, Daeshaneik | Former resident | $0.00 | $8,101.75 | $8,101.75 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2108 | Travis, Morrissa | Former resident | $0.00 | $7,672.75 | $2,657.75 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2108 | Byrd, Kutiner | Former resident | $0.00 | $13,435.01 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2109 | Jackson, Felicia A | Former resident | $0.00 | $2,443.35 | $2,443.35 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2109 | Smith, Simone | Former resident | $0.00 | $10,946.55 | $10,946.55 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2109 | Leland Early, Chrishenda Lafaye | Former resident | $35.21 | $2,267.00 | $2,231.79 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2109 | Winbush, Shirley Ann | Former resident | $0.00 | $6,997.74 | $6,997.74 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2109 | Jordan*, Tercina Senita | Former resident | $0.00 | $1,350.00 | $1,350.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2109 | Senior, Sharika L | Former resident | $0.00 | $15,170.00 | $15,170.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2109 | Sandidge, Tony A | Current resident | $0.00 | $1,372.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2110 | Blanding, Tashonna | Former resident | $0.00 | $1,590.90 | $1,590.90 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2110 | James, Felicia | Former resident | $0.00 | $5,495.00 | $5,495.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2110 | Durden, Lucinda Johnson | Former resident | $0.00 | $10,934.02 | $10,934.02 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2110 | Murray, Beverly | Former resident | $0.00 | $4,153.13 | $4,153.13 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2110 | Jeune, Heberson | Former resident | $0.00 | $6,162.83 | $6,162.83 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2110 | Gurley, Chimere Latisha | Former resident | $0.00 | $5,298.67 | $5,298.67 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2110 | Ross, Shadonna Lafaye | Current resident | $0.00 | $1,372.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2112 | Simmons, Delicia Nishae | Former resident | $0.00 | $1,623.00 | $1,623.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2113 | Pride, Clarence | Former resident | $0.00 | $13,132.84 | $13,132.84 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2113 | Borden, Janease Nicole | Former resident | $0.00 | $7,880.47 | $7,880.47 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2113 | Taylor*, Walkiki Tashawn | Former resident | $343.12 | $1,594.00 | $1,250.88 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2113 | Lovett, Jessica Denise | Former resident | $0.00 | $7,195.00 | $7,195.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2113 | Walker, Ayanna | Former resident | $0.00 | $11,424.00 | $11,424.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2113 | Mitchell*, Fredricka | Current resident | $0.00 | $12.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2114 | Olivera, Luis | Former resident | $0.00 | $441.10 | $441.10 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2114 | Hall, Laticia S | Former resident | $0.00 | $1,350.00 | $1,350.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2114 | Hyman, Ebony Tyrese | Former resident | $0.00 | $3,652.52 | $3,652.52 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2114 | Mitchell*, Kia | Former resident | $0.00 | $3,480.00 | $3,480.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2114 | Jones, Shiyania Detoria | Former resident | $0.00 | $3,835.44 | $3,835.44 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2114 | Reed, Debbie | Former resident | $0.00 | $5,018.29 | $5,018.29 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2115 | Denmark, Sharita | Former resident | $0.00 | $8,541.61 | $8,541.61 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2115 | Bell, Shaderica | Former resident | $0.00 | $8,967.03 | $8,967.03 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2115 | Casas, Shanzenyetta Shontae Marie | Former resident | $0.00 | $6,578.60 | $6,578.60 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2115 | McMillon, Latajha Jaquette | Former resident | $0.00 | $6,901.70 | $6,901.70 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2116 | Britt, Renee | Former resident | $0.00 | $8,074.40 | $8,074.40 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2116 | Green, Octavia Renee | Former resident | $0.00 | $8,561.97 | $8,561.97 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2116 | Gilbert, Justin | Former resident | $0.00 | $1,025.00 | $1,025.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2201 | McDonald, Tonica C | Former resident | $0.00 | $905.79 | $905.79 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2201 | Helms*, Tracy | Former resident | $0.00 | $106.20 | $106.20 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2201 | Gipson, Rhonda | Former resident | $0.00 | $370.60 | $370.60 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2201 | Johnson, Amya Nicole | Former resident | $0.00 | $5,193.36 | $5,193.36 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2202 | Showers, Deandre Darrell | Former resident | $0.00 | $444.33 | $444.33 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2202 | Phillips, Tyrannda | Former resident | $0.00 | $357.45 | $357.45 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2202 | Baker, Ka'nijah Monay | Former resident | $0.00 | $6,675.86 | $6,675.86 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2202 | Kirkland, Lakresha T | Former resident | $0.00 | $5,016.83 | $5,016.83 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2202 | Williams, Mishaela | Former resident | $0.00 | $7,181.78 | $7,181.78 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2202 | Jenkins-Collins, Shamina | Former resident | $0.00 | $4,542.93 | $4,542.93 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2202 | Peterson, Tyron | Current resident | $0.00 | $1,032.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2203 | Jones, Tonya | Former resident | $0.00 | $823.06 | $823.06 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2203 | Lewis, Radshida | Former resident | $0.00 | $937.88 | $937.88 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2203 | Smith, Shaundrekeya | Former resident | $0.00 | $2,132.97 | $2,132.97 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2203 | Muhammeds*, Judah | Former resident | $1.35 | $570.00 | $568.65 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2203 | Reggins, Debra Ann | Former resident | $0.00 | $6,705.86 | $6,705.86 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2204 | *Caldwell, Nicole Lashun | Former resident | $0.00 | $1,340.00 | $1,340.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2204 | Moore, Padre | Current resident | $0.00 | $6.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2206 | Williams, Martha | Former resident | $0.00 | $2,782.65 | $2,782.65 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2206 | Thomas*, Niresha Lashaye | Former resident | $108.33 | $5,469.28 | $5,360.95 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2206 | Conway, Jasmeen G | Former resident | $0.00 | $5,689.88 | $5,689.88 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2206 | Akins, Demaja | Former resident | $0.00 | $8,985.40 | $8,985.40 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2206 | Cobbs, India | Former resident | $0.00 | $5,591.52 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2207 | Marshall, Shavetrice | Former resident | $0.00 | $1,409.77 | $1,409.77 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2207 | Blair, Ambrea | Former resident | $0.00 | $1,334.48 | $1,334.48 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2207 | Smith, Jakayla | Former resident | $0.00 | $2,850.00 | $2,850.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2208 | Kenon, Brittany | Former resident | $0.00 | $862.86 | $862.86 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2208 | Young, Yasmin | Former resident | $0.00 | $1,528.19 | $1,528.19 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2208 | Shaw, Courtney | Former resident | $0.00 | $589.47 | $589.47 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2208 | Davis, Sheronda | Former resident | $0.00 | $6,297.25 | $6,297.25 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2208 | Palmer, Shakayla Elease | Former resident | $0.00 | $10,374.16 | $10,374.16 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2208 | Jones, Waleyshen | Current resident | $0.00 | $1,210.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2209 | Bowen**, Deshuntaye L | Former resident | $0.00 | $629.06 | $629.06 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2209 | Butler, Alondria | Former resident | $0.00 | $2,703.11 | $2,703.11 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2209 | McCray, Sharmiar | Former resident | $0.00 | $28.35 | $28.35 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2209 | Moore, Colisha E | Former resident | $0.00 | $4,412.55 | $4,412.55 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2209 | Smith, Aundrea Elaine | Former resident | $0.00 | $7,086.61 | $7,086.61 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2209 | Bell, Time'Shekka | Former resident | $0.00 | $8,207.84 | $8,207.84 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2209 | Sam*, Ciera | Current resident | $9.00 | $922.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2210 | Pride, Shanika | Former resident | $0.00 | $3,976.59 | $3,976.59 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2210 | Warren*, Tiffany D | Former resident | $107.71 | $8,217.86 | $8,110.15 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2210 | Williams, Sabrina Denise | Former resident | $117.16 | $1,035.29 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2212 | Callaway*, AruchaFranchel | Former resident | $0.00 | $807.67 | $807.67 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2212 | Barber, Joyce | Former resident | $0.00 | $5,002.60 | $5,002.60 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2212 | Riggins, Ereka Sa'Mone | Former resident | $0.00 | $4,989.91 | $4,989.91 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2212 | Daniels, Shawntavia | Former resident | $0.00 | $14,311.39 | $14,311.39 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2212 | Cobbs, Edelphia Janai | Current resident | $0.00 | $1,120.16 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2213 | Owens, Tiffany Lashay | Former resident | $0.00 | $1,006.03 | $1,006.03 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2213 | Andrews, Isaac | Former resident | $0.00 | $4,040.28 | $4,040.28 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2213 | Davis, Aquaneisha | Former resident | $115.76 | $3,604.36 | $3,488.60 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2213 | *Alford*, Kelia Monae | Former resident | $154.20 | $4,404.12 | $4,249.92 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2213 | Galloway, Antonio | Former resident | $0.00 | $10,250.00 | $10,250.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2213 | Frierson, Kashara N | Former resident | $0.00 | $9,646.00 | $9,646.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2213 | Woods, Tanga Evette | Current resident | $0.00 | $1,372.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2214 | Stephens, Derek Love | Former resident | $0.00 | $579.00 | $579.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2214 | Green, Jessica s. | Former resident | $0.00 | $1,010.70 | $1,010.70 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2214 | Jones, Ashley | Former resident | $0.00 | $3,696.57 | $3,696.57 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2214 | Johnson, Lacey Ann | Former resident | $0.00 | $6,589.20 | $6,589.20 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2214 | Rowe, Portia | Former resident | $0.00 | $13,725.00 | $13,725.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2214 | Burns, Shyniese Lafaye | Former resident | $0.00 | $4,973.60 | $4,973.60 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2214 | Hodo, Chassity Semone | Former resident | $0.00 | $12,575.61 | $12,575.61 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2215 | Pride* Powell, Sharine H | Former resident | $218.81 | $3,661.61 | $3,442.80 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2215 | Fowler, Ciera Shantel | Former resident | $0.00 | $4,030.56 | $4,030.56 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2215 | Dixon*, Eric | Former resident | $74.14 | $6,406.55 | $6,332.41 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2215 | Jerger, Auj'Nae | Former resident | $0.00 | $4,212.18 | $4,212.18 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2215 | Reed, Sharicka | Former resident | $0.00 | $5,178.49 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2216 | Alford*, Keila Monae | Former resident | $0.00 | $76.99 | $76.99 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2216 | Diaz, Nemessis Enith Rivera | Former resident | $0.00 | $150.00 | $150.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2216 | *Faulk, Sheniqua Renae | Former resident | $0.00 | $7,163.64 | $7,163.64 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2216 | Hunter*, Ashley Monique | Former resident | $60.47 | $16,461.60 | $16,401.13 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2216 | Davis, Tiffany | Current resident | $0.00 | $1,372.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2301 | Eutsay, Ebony T | Former resident | $0.00 | $1,570.00 | $1,570.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2301 | Manzano, Marisol | Former resident | $0.00 | $678.42 | $678.42 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2301 | Wilson, Demarcus Shawntel | Former resident | $0.00 | $4,023.67 | $4,023.67 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2301 | Moore, Rondarius | Former resident | $0.00 | $2,070.00 | $2,070.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2301 | Evans, Layla Janessa | Former resident | $0.00 | $6,263.30 | $6,263.30 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2302 | Baker, Chavien | Former resident | $0.00 | $711.84 | $711.84 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2302 | Pollock, Tammie | Former resident | $487.00 | $3,625.00 | $3,138.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2302 | Jones, Chaniquia | Former resident | $0.00 | $3,938.84 | $3,938.84 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2303 | Carter*, Bobby Ray | Former resident | $30.00 | $1,251.13 | $1,221.13 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2303 | Murray, Erin Elizabeth | Former resident | $0.00 | $6,965.70 | $6,965.70 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2303 | Anderson, Juanita | Former resident | $0.00 | $5,089.00 | $5,089.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2303 | Jordan, Raquel Monshae | Former resident | $0.00 | $6,995.55 | $6,995.55 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2303 | Byrd, Shanna Jana | Former resident | $0.00 | $14,899.89 | $14,899.89 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2303 | Allen, Hunter | Former resident | $0.00 | $13,561.49 | $13,561.49 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2303 | Watson, Shamya Deija Naye | Current resident | $0.00 | $1,032.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2305 | Chiquillo, Edwin | Former resident | $0.00 | $1,532.00 | $1,532.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2305 | Brown, Jemecia | Former resident | $0.00 | $736.54 | $736.54 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2305 | Doyle, Mikeyecia | Former resident | $0.00 | $1,205.48 | $1,205.48 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2305 | Gilyard, Christina | Former resident | $0.00 | $4,876.39 | $4,876.39 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2305 | Stinson, Jimmie | Former resident | $0.00 | $4,593.81 | $4,593.81 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2305 | Atkins, Zandavian Smarterrious | Former resident | $0.00 | $6,158.50 | $6,158.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2306 | Cladd, Travis | Former resident | $0.00 | $13,998.87 | $13,998.87 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2306 | Hannah, Sheletha | Former resident | $0.00 | $10,337.40 | $10,337.40 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2307 | Hernandez, Maria S | Former resident | $0.00 | $414.00 | $414.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2307 | Scott, Brandon | Former resident | $0.00 | $3,047.88 | $3,047.88 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2307 | Little, Austin | Former resident | $0.00 | $2,480.10 | $2,480.10 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2307 | Denson, Mytreal | Former resident | $0.00 | $7,156.87 | $7,156.87 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2308 | Pinkney, Ronald | Former resident | $0.00 | $951.58 | $951.58 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2308 | James, Shayla | Former resident | $0.00 | $6,289.60 | $6,289.60 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2308 | Phillips, Shemerria Belinda | Former resident | $0.00 | $6,422.00 | $6,422.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2308 | Skipper, Lamonica | Former resident | $0.00 | $2,943.48 | $2,943.48 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2308 | Johnson, De'Asia Dominique | Former resident | $0.00 | $2,891.74 | $2,891.74 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2308 | Jenkins*, Kesous | Former resident | $226.58 | $12,924.13 | $12,697.55 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2308 | Calloway, Nqwesha | Former resident | $0.00 | $6,596.77 | $1,485.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2309 | Lavertris Thomas | Former resident | $0.00 | $941.62 | $941.62 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2309 | Paris, Elizabeth | Former resident | $0.00 | $1,910.73 | $1,910.73 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2309 | Hearn, Tamadrea | Former resident | $0.00 | $6,152.00 | $6,152.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2309 | Williams, Christina Lachae | Former resident | $722.00 | $1,950.00 | $1,228.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2309 | Smith, Jessica Denise | Former resident | $0.00 | $6,904.65 | $6,904.65 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2309 | Thomas***, Nekiya Jena | Former resident | $0.00 | $8,439.83 | $8,439.83 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2309 | Hall**, Audrey | Current resident | $0.00 | $668.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2310 | Holloman, Shirley A | Former resident | $0.00 | $3,675.00 | $3,675.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2310 | Bowen, Deshuntaye Lequeseia | Former resident | $0.07 | $7,781.00 | $7,780.93 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2310 | Hearn, Alesha | Former resident | $0.00 | $4,134.03 | $4,134.03 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2310 | Sailor*, Latonya | Former resident | $0.00 | $9,867.83 | $9,867.83 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2311 | Byrd, Ashanti | Former resident | $0.00 | $8,230.52 | $8,230.52 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2311 | Anderson, Sadie | Former resident | $0.00 | $14,053.20 | $14,053.20 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2312 | Davis**, Brittany S | Current resident | $0.01 | $680.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2312 | Davis, Keturah | Former resident | $0.00 | $2,858.56 | $2,858.56 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2312 | Atkins, Monique Shayonta | Former resident | $0.00 | $6,207.54 | $6,207.54 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2312 | Cherry, Tikieria | Former resident | $0.00 | $12,177.75 | $12,177.75 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2312 | Tarver, Tabitha Sheryln | Former resident | $0.00 | $5,627.84 | $5,627.84 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2312 | Tribue, Jamichael Shamon | Former resident | $0.00 | $8,855.25 | $8,855.25 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2312 | Bush, Nakendra L | Former resident | $0.00 | $10,021.94 | $10,021.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2313 | Anderson*, Lenece | Former resident | $652.86 | $6,462.97 | $5,810.11 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2313 | Robinson, Ashley | Former resident | $0.00 | $4,505.07 | $4,505.07 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2313 | Bostick, Shaterika Shantorria | Former resident | $0.00 | $5,392.97 | $5,392.97 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2313 | Alexander, Sheneka Danyel | Former resident | $0.00 | $3,239.84 | $3,239.84 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2313 | Gosa*, Jessica Lauren | Former resident | $0.01 | $2,018.35 | $2,018.34 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2313 | Hinson, Kaliyah Valli | Former resident | $0.00 | $9,692.00 | $9,692.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2313 | Stephens, Brenda | Former resident | $0.00 | $3,734.71 | $2,759.71 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2314 | Miller*, Shenika Shantate | Former resident | $1,268.00 | $1,536.20 | $268.20 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2314 | Pride, Miriam | Former resident | $0.00 | $4,878.62 | $4,878.62 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2314 | Hebert, Lacy | Former resident | $0.00 | $2,326.53 | $2,326.53 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2314 | Jones, Dana L | Current resident | $0.00 | $1,372.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2315 | Matthews, Natalie | Former resident | $0.00 | $1,032.42 | $1,032.42 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2315 | Ming, Anna | Former resident | $0.00 | $1,554.06 | $1,554.06 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2315 | McMillian*, Brittany | Former resident | $0.00 | $3,217.00 | $3,217.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2316 | Brooks**, Omesha Shampresse | Former resident | $0.00 | $4,023.00 | $4,023.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2316 | Jackson, Nickaiya | Former resident | $0.00 | $5,295.29 | $5,295.29 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2316 | *Jackson, Samara Denise | Former resident | $0.00 | $4,923.60 | $4,923.60 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2316 | Reed, Devron Rashaun | Former resident | $0.00 | $4,920.00 | $4,920.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2316 | Williams, Zie'Keriya | Former resident | $0.00 | $12,074.00 | $12,074.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3101 | Norwood, Michael Laguan | Former resident | $0.00 | $620.65 | $620.65 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3101 | Lovett, Eddie | Former resident | $0.00 | $10.89 | $10.89 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3102 | Grimes*, Sebrina | Former resident | $0.00 | $3,645.00 | $3,645.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3103 | Johnson, Shunqueshaya | Former resident | $0.00 | $766.00 | $766.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3104 | Bilal, Brian | Former resident | $0.00 | $1,368.32 | $1,368.32 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3104 | McNealy, Dequanesha | Former resident | $0.00 | $2,039.41 | $2,039.41 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3104 | Weaver, Demetriuce Antonio | Former resident | $0.00 | $3,039.17 | $3,039.17 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3104 | Carroll, Cher'trevin | Current resident | $0.00 | $100.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3201 | Deavens*, Sheonte | Former resident | $266.93 | $2,910.00 | $2,643.07 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3201 | Anthony, Asha | Former resident | $0.00 | $5,150.00 | $5,150.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3201 | Campbell, Quiana | Former resident | $0.00 | $4,696.00 | $4,696.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3201 | Miller, Yatesha Renaye | Former resident | $0.00 | $1,605.00 | $1,605.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3202 | Russ, Jakwanza | Former resident | $0.00 | $1,519.86 | $1,519.86 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3202 | Neal, Gloria | Former resident | $0.00 | $5,513.93 | $5,513.93 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3203 | James, Tremayne | Former resident | $0.00 | $535.48 | $535.48 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3203 | Gilyard, Dewanda | Former resident | $0.00 | $1,536.00 | $1,536.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3203 | Wynn, Ke'Amber | Former resident | $0.00 | $1,483.53 | $1,483.53 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3203 | Jackson, Destinee' | Former resident | $0.00 | $3,755.00 | $3,755.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3204 | Johnson**, Sabrina Renea | Former resident | $377.00 | $380.32 | $3.32 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3204 | Donaldson, Breanna | Former resident | $0.00 | $3,998.71 | $3,998.71 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3204 | Dubose, Jasmine | Former resident | $0.00 | $5,017.24 | $5,017.24 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3204 | Brown, Jaleen Sheuette | Former resident | $0.00 | $5,179.04 | $5,179.04 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3204 | Wilkins, Trenesia | Former resident | $0.00 | $6,016.53 | $6,016.53 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3204 | Martin, Kaliyah M | Former resident | $0.00 | $4,753.70 | $4,753.70 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3204 | *Graddy, Antonio | Former resident | $0.00 | $3,028.68 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3301 | Howard**, Jessica | Former resident | $1,026.00 | $3,825.00 | $2,799.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3301 | Sailor, Jakai | Former resident | $0.00 | $5,519.51 | $5,519.51 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3301 | Hicks, Michelle | Former resident | $0.00 | $7,717.76 | $7,717.76 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3301 | Miller, Cleve Lenorris | Former resident | $0.00 | $6,001.29 | $6,001.29 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3301 | Dubose, Jasmine | Former resident | $0.00 | $5,986.83 | $5,986.83 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3302 | Williams, Dekendrick | Former resident | $0.00 | $63.07 | $63.07 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3302 | McMillan, Darron | Former resident | $0.00 | $2,211.49 | $2,211.49 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3302 | Jackson, Ronterrius Reshard | Former resident | $0.00 | $475.00 | $475.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3303 | Moore, Lakesha Renee | Former resident | $0.00 | $200.00 | $200.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3303 | Gilcrest, Wanda | Former resident | $0.00 | $1,865.13 | $1,865.13 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3303 | Robinson, Shantassia | Former resident | $0.00 | $5,865.05 | $5,865.05 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3303 | Hebert, Landon | Former resident | $0.00 | $277.47 | $277.47 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3303 | Denmark, Tamiramah | Former resident | $359.62 | $8,391.00 | $8,031.38 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3303 | Haynes, Larmarcus Kariel | Former resident | $0.00 | $2,971.60 | $2,971.60 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3303 | Brown, Ja'leycia Natasha | Former resident | $0.00 | $7,418.03 | $7,418.03 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3303 | Richardson, Jacoya | Former resident | $0.00 | $6,540.20 | $1,585.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3304 | Washington, Trina | Former resident | $0.00 | $1,995.16 | $1,995.16 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3304 | Scott, Jakari | Former resident | $0.00 | $1,779.31 | $1,779.31 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3304 | Andersen, Gregory James | Former resident | $0.00 | $3,743.00 | $3,743.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3304 | Carter, Jamih S | Former resident | $0.00 | $14,867.16 | $14,867.16 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3304 | Gibson, Michael | Former resident | $0.00 | $2,919.82 | $2,919.82 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3304 | Mason, Shavonda | Former resident | $0.00 | $5,144.66 | $5,144.66 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 3304 | Byrd, Antraveon | Former resident | $0.00 | $2,938.68 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - 1102 | Smith, Mary Fulton | Former applicant | $500.00 | $0.00 | $-500.00 | [ ] Confirm paid | — |
| 1 - 1106 | Shaw**, Keshondra S | Current resident | $295.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1109 | Lodman**, Briuna S | Former resident | $447.00 | $6.06 | $-440.94 | [ ] Confirm paid | — |
| 1 - 1110 | Lifherd*, Kimberly M | Current resident | $590.00 | $330.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1111 | Northwest Florida Housing | Former resident | $2,308.25 | $700.00 | $-1,608.25 | [ ] Confirm paid | — |
| 1 - 1112 | Neverson**, Christine Delores | Current resident | $61.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1113 | Charles Ranson | Former resident | $271.00 | $0.00 | $-271.00 | [ ] Confirm paid | — |
| 1 - 1113 | Donaldson*, Sarah | Current resident | $0.05 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1114 | Bullock*, Florence P | Current resident | $500.00 | $161.00 | $161.00 | [ ] Confirm paid | — |
| 1 - 1115 | Donald*, Shameca Shontell | Current resident | $896.80 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1116 | Robinson, Alisia | Current resident | $32.80 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1118 | Baker, Tamekio | Current resident | $2.93 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1119 | Peoples*, Jacquelyn | Current resident | $24.05 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1204 | Kirkland*, Tekeysha L | Current resident | $0.33 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1210 | Mitchell, Cynthia H | Current resident | $100.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1213 | Clark, Devonte | Current resident | $81.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1214 | Miller, Shenika | Current resident | $4.60 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1215 | Shaw, Courtney Renee | Former resident | $500.00 | $0.00 | $-500.00 | [ ] Confirm paid | — |
| 1 - 1216 | Allen, Tawanea | Current resident | $2.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1217 | Brown-Reid, Keneisha Natoya | Current resident | $57.55 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1220 | Poole, Shatina Lanay | Current resident | $5.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1303 | Brooks, Shenqualia | Current resident | $61.87 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1304 | Baskin**, Myra K | Former resident | $0.18 | $0.00 | $-0.18 | [ ] Confirm paid | — |
| 1 - 1304 | Thomas, Caprice Danielle | Current resident | $2.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1305 | Williams, Shareka | Current resident | $120.55 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1306 | Johnson, Harriet Lee | Current resident | $18.32 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1307 | Shaw, Tierra Alexus | Current resident | $40.71 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1310 | Cheese, Kaylacia | Current resident | $13.32 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1313 | Shaw, Verron Tanesha | Current resident | $9.48 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1314 | Collins*, Paula | Former resident | $770.00 | $103.01 | $-666.99 | [ ] Confirm paid | — |
| 1 - 1314 | Jones*, Scherryl | Former resident | $3,546.97 | $2,860.00 | $-686.97 | [ ] Confirm paid | — |
| 1 - 1314 | Berry, Tim'mia Quinshay | Current resident | $419.57 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1317 | Wilson*, Bobby | Current resident | $593.76 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 1320 | Hicks, Dorothy | Current resident | $86.55 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 2101 | Mobley, Verna | Current resident | $0.71 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 2103 | O'Neal*, Mildred Christine | Current resident | $14.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 2108 | Pride**, MiriamD | Former resident | $326.00 | $35.00 | $-291.00 | [ ] Confirm paid | — |
| 2 - 2111 | Williams, Pamela | Current resident | $16.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 2114 | Thompson, Keisha | Former applicant | $205.95 | $0.00 | $-205.95 | [ ] Confirm paid | — |
| 2 - 2114 | Jackson, Tenisha Lafaye | Current resident | $24.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 2115 | Minor, Delores | Current resident | $9.33 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 2201 | Maples*, Timbernique | Former resident | $652.00 | $0.00 | $-652.00 | [ ] Confirm paid | — |
| 2 - 2201 | Belford, Alandria Makayla | Current resident | $2.16 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 2207 | Grimes*, Resherricka L | Current resident | $15.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 2215 | Torres, Ruddy Joselyn | Former resident | $500.00 | $0.00 | $-500.00 | [ ] Confirm paid | — |
| 2 - 2301 | Johnson, Sabrina | Current resident | $23.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 2302 | King, Randa | Current resident | $8.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 2303 | Jenkins, Alfred | Former resident | $0.16 | $0.00 | $-0.16 | [ ] Confirm paid | — |
| 2 - 2303 | Breedlove*, Christopher | Former resident | $37.16 | $0.00 | $-37.16 | [ ] Confirm paid | — |
| 2 - 2305 | Youmans, Stacy Rechelle | Current resident | $0.64 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 2307 | Harris, Crystal | Current resident | $53.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 2308 | Bailey, Keisha | Current resident | $0.32 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 2310 | Williams, Crystal | Current resident | $18.13 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 2313 | Clemons, Moses | Current resident | $226.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 2315 | Rumph, Zykeriah Denise | Current resident | $79.94 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 3103 | Zackery**, Verdine Saulters | Current resident | $69.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 3201 | Wilson, Patrice | Current resident | $0.60 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 3301 | Davis-Brown, Tanella Marlett | Former resident | $276.90 | $0.00 | $-276.90 | [ ] Confirm paid | — |
| 3 - 3301 | Lodman, Yolanda | Current resident | $30.57 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 3302 | Starke, Brittany Preanna | Current resident | $14.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 3303 | Byrd, Sharell | Current resident | $95.77 | $0.00 | $0.00 | [ ] Confirm paid | — |

## Resident Balance Follow-Up — Paid / Zero Balance

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - 1103 | Blackstock Spencer, Yashemia | Current resident | $61.78 | $61.78 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1120 | Oswalt, DominiqueMesha | Former resident | $25.00 | $25.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 1210 | Hall, BrandonMalik | Former resident | $500.00 | $500.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2304 | Bryant, James Edward | Current resident | $8.84 | $8.84 | $8.84 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property's supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*