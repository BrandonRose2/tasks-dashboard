# Fairfax Sr Apartments — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 1181004**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/05/2026 |
| Property manager | Shraga Kurs — — — (818) 235-3588 |
| Regional manager | Blake Weddington — blake@apartmentcorp.com — (310) 927-0020 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Delinquency spreadsheet | `1181004_Fairfax Sr Apartments_Delinquent - Excel_58.xls` |
| Ledger accounts for review | 90 resident accounts |
| Residents with amount owed | 87 accounts; $423,444.35 |
| Prepaid / credit accounts | 3 accounts; $-6,407.96 |
| Availability entries | 0 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit's reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| — | — | No unit-status entries in the selected source export | [ ] Verified | __________________ |

## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 101 | AZER, IREN | Current resident | $0.00 | $5,853.96 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 103 | MAGANA, MARTHA | Former resident | $0.00 | $4,929.00 | $4,929.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 103 | KIREMIDZHYAN, STEPAN | Former resident | $0.00 | $14.71 | $14.71 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 103 | AKODES, OLGA | Current resident | $0.00 | $5,982.96 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 104 | NICKERSON, FRANCES | Former resident | $0.00 | $3,317.54 | $3,317.54 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 104 | AVETIKOV, MIKHAIL G | Current resident | $0.00 | $5,751.96 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 106 | WEDDINGTON, BLAKE | Former resident | $0.00 | $2,325.01 | $2,325.01 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 106 | NIMAN, ANATOLY | Current resident | $0.00 | $5,653.96 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 108 | SAUNDERS, MARION | Former resident | $0.00 | $1,058.00 | $1,058.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 108 | kharitnov, roman | Former resident | $0.00 | $3,248.20 | $3,248.20 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 108 | NEMIROVSKAYA, ALLA | Current resident | $0.00 | $8,428.66 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 109 | KOSTENITSKAYA, NINA | Current resident | $0.00 | $9,129.96 | $999.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 110 | BABICH, BORIS | Former resident | $0.00 | $399.00 | $399.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 110 | DENISOFF, IRINA | Current resident | $0.00 | $8,111.96 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 111 | GUDALI, DUMITRU | Former resident | $0.00 | $2,675.00 | $2,675.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 111 | IGNATY, ALEXANDER | Current resident | $0.00 | $5,774.96 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 112 | RIMER, KLARISA | Current resident | $0.00 | $9,058.96 | $991.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 113 | GAZAN, MINNIE | Former resident | $0.00 | $1,050.88 | $1,050.88 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 113 | orlova, stalina | Former resident | $0.00 | $3,250.00 | $3,250.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 113 | YANKOVSKIY, NICK | Current resident | $0.00 | $5,848.96 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 114 | SHLENSKAYA, RAISA | Former resident | $62.00 | $1,905.00 | $1,843.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 114 | ROSOVSKY, INNA | Current resident | $19.94 | $5,961.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 115 | GLICKMAN, RALPH | Former resident | $0.00 | $3,465.00 | $3,465.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 115 | RAIBURG, EUGENIA | Current resident | $0.00 | $5,848.96 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 116 | FELDMAN, ERINA | Former resident | $0.00 | $1,171.00 | $1,171.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 116 | ROMANOVA, NATALYA | Current resident | $0.00 | $9,110.96 | $999.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 201 | NILVA, LEONID | Former resident | $0.00 | $2,675.00 | $2,675.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 201 | KOFT, ALEXANDRA | Current resident | $0.00 | $4,431.88 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 202 | BEAUMONT, DANIEL | Former resident | $0.00 | $3,274.96 | $3,274.96 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 202 | PINHASSI, INA | Current resident | $0.00 | $5,845.94 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 203 | FILEN, NAUM | Former resident | $0.00 | $3,403.96 | $3,403.96 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 203 | JOVAN, SLAVITZA J | Current resident | $0.00 | $5,791.01 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 204 | ISAEVA, KLARA E | Current resident | $0.00 | $11,276.97 | $3,146.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 205 | SHKOLNIK, YELIZAVETA | Former resident | $0.00 | $3,355.00 | $3,355.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 205 | FUKS, ALEKSEY | Current resident | $0.00 | $5,434.96 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 206 | GOLBERG, MARKUS | Former resident | $0.00 | $3,215.00 | $3,215.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 206 | RUBINOV, BORIS | Current resident | $0.00 | $5,854.96 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 207 | FLORES, MARIA | Current resident | $295.60 | $8,926.00 | $1,132.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 208 | BERMAN, RACHEL | Former resident | $0.00 | $1,237.96 | $1,237.96 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 208 | SHERSHER, ZINOVY | Current resident | $0.00 | $8,102.04 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 209 | BABICH, IZRAIL | Former resident | $0.00 | $3,632.96 | $3,632.96 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 209 | FUKS, IRINA | Current resident | $0.00 | $5,614.88 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 210 | KRASS, SAZI | Former resident | $0.00 | $3,275.00 | $3,275.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 210 | KAGAN, MAYA | Current resident | $0.00 | $5,848.96 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 211 | TSIPKIS, RACHEL | Former resident | $0.00 | $3,289.04 | $3,289.04 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 211 | YOFFE, BENJAMIN | Current resident | $0.00 | $4,814.96 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 212 | CHERNYAVSKYA, LIDIYA | Current resident | $0.00 | $9,129.96 | $999.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 213 | CHERNYAVSKAYA, MARIYA | Current resident | $0.00 | $9,124.96 | $999.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 214 | BIANCONI, AMELIA L | Former resident | $0.00 | $3,760.88 | $3,760.88 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 214 | SHUMIN, LIOUDMILA | Current resident | $0.00 | $5,848.97 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 215 | CUELLAR, JUANA | Former resident | $0.00 | $625.92 | $625.92 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 215 | Agrachov, Margarita | Current resident | $0.00 | $6,878.96 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 216 | NEYDLIN, SIMON | Former resident | $0.00 | $933.00 | $933.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 216 | GERASYMOVA, NADIYA | Current resident | $0.00 | $8,133.05 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 301 | ADKINS, FANNY | Former resident | $0.00 | $1,134.00 | $1,134.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 301 | Iosifovna, Yelizaveta | Former resident | $0.00 | $3,290.24 | $3,290.24 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 301 | LURYE, IOSIF | Current resident | $0.00 | $5,520.96 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 302 | KAGAN, SAUL | Former resident | $0.00 | $3,297.00 | $3,297.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 302 | NAGIBINA, MARGARITA | Current resident | $0.00 | $9,143.98 | $1,017.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 303 | Kharchenko, Natalya | Current resident | $0.00 | $8,386.90 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 304 | ROZMAN, NEMA | Former resident | $0.00 | $157.04 | $157.04 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 304 | OBUKHOVSKY, KATHRINE | Former resident | $0.00 | $3,330.00 | $3,330.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 304 | LISITSA, TATYANA | Current resident | $0.00 | $5,873.96 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 305 | KAPLAN, LARRY | Former resident | $44.96 | $983.00 | $938.04 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 305 | BRAND, ANNA | Current resident | $0.00 | $8,337.21 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 306 | GARBER, BELLA | Current resident | $137.00 | $9,145.00 | $961.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 307 | MARDAKHAYEV, MATATYA | Former resident | $0.00 | $3,306.88 | $3,306.88 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 307 | KURS, SHRAGA | Current resident | $0.00 | $7,669.00 | $1,212.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 308 | HENRIQUEZ, ROSA | Former resident | $0.00 | $436.91 | $436.91 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 308 | MEFODEVA, ALEVTINA | Former resident | $0.00 | $3,389.00 | $3,389.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 308 | LANDA, MARINA | Former resident | $0.00 | $14.00 | $14.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 308 | KANTER, BELA | Current resident | $0.00 | $5,075.91 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 309 | FURMAN, SERAFIMA | Former resident | $0.00 | $3,385.00 | $3,385.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 309 | KHLEVINSKY, LEONID | Current resident | $0.00 | $5,718.96 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 310 | ELIYANOV, ESFIR | Former resident | $0.00 | $2,675.00 | $2,675.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 310 | HAKHAM, MARGRID | Current resident | $0.00 | $5,849.96 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 311 | ROGOVOY, LYUBOV | Former resident | $0.00 | $26.00 | $26.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 311 | Rovinsky, Svetlana | Current resident | $0.00 | $8,919.96 | $838.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 312 | BULKIN, ETLYA | Former resident | $0.00 | $1,013.09 | $1,013.09 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 312 | PEKAR, MIKHAIL | Current resident | $0.00 | $8,154.96 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 313 | HWANGBO, SUN H | Former resident | $0.00 | $3,289.04 | $3,289.04 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 313 | OVSEPIAN, RAISA | Current resident | $0.00 | $5,843.96 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 314 | GIVENTER, TAMARA | Current resident | $0.00 | $8,946.01 | $929.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 315 | MARTINEZ, DIGNA G | Former resident | $0.00 | $3,994.32 | $3,994.32 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 315 | GEZEL, REGINA | Current resident | $0.00 | $5,809.88 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 316 | NARODITSKAYA, FLORIDA | Current resident | $0.00 | $8,920.02 | $616.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3A | Palmer, Greg | Current resident | $0.00 | $9,904.00 | $5,659.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 106 | WIESMAN, ERIC | Former resident | $4,063.00 | $0.00 | $-4,063.00 | [ ] Confirm paid | — |
| 108 | YEGUDKIN, ZINAIDA | Former resident | $2,302.00 | $116.04 | $-2,185.96 | [ ] Confirm paid | — |
| 303 | SAAKOV, ROMEN | Former resident | $159.00 | $0.00 | $-159.00 | [ ] Confirm paid | — |

## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.

## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property's supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*