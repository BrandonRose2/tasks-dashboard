# Midtown Manor — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 1181005**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/05/2026 |
| Property manager | Steve Rand — — — (323) 456-7800 |
| Regional manager | Blake Weddington — blake@apartmentcorp.com — (310) 927-0020 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Delinquency spreadsheet | `1181005_Midtown Manor_Delinquent - Excel_58.xls` |
| Ledger accounts for review | 137 resident accounts |
| Residents with amount owed | 104 accounts; $189,367.54 |
| Prepaid / credit accounts | 33 accounts; $-36,554.88 |
| Availability entries | 0 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit's reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| — | — | No unit-status entries in the selected source export | [ ] Verified | __________________ |

## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 101A | WILSON, AUDREY M | Former resident | $0.00 | $695.92 | $695.92 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 101A | MILLER JACKSON, KINITA | Current resident | $36.70 | $3,942.00 | $228.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 101B | WILKES, KRISTOFFERt | Former resident | $0.00 | $894.99 | $894.99 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 101B | VELASQUEZ, CONNIE MARIE | Former resident | $1,100.00 | $13,801.44 | $12,701.44 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 101B | PACHECO RAMOS, KARLA | Former resident | $172.00 | $605.18 | $-172.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 101B | COURTNEY, TREVON | Current resident | $0.00 | $1,789.15 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 102A | VALDEZ, ELDA | Former resident | $0.00 | $861.00 | $861.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 102A | *Daniel, Dominique | Former resident | $636.00 | $866.00 | $230.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 102A | Johnson, LaToshi | Former resident | $0.00 | $597.00 | $597.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 102A | MUHAMMAD, VERNON C | Former resident | $0.00 | $7,341.91 | $7,341.91 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 102A | JONES, HAROLD | Current resident | $49.29 | $4,884.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 102B | ATKINS, BRIAN | Former resident | $0.00 | $507.91 | $507.91 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 102B | MCCOY, SHERRY | Current resident | $0.00 | $4,345.21 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 103A | HERNANDEZ, NELSON | Former resident | $0.00 | $1,261.53 | $1,261.53 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 103A | SMITH, TRAVELL | Former resident | $0.00 | $280.36 | $280.36 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 103B | Bromell, Evineveh | Former resident | $0.00 | $727.10 | $727.10 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 103B | LINDO, KEITH WASHINGTON | Former resident | $0.00 | $96.82 | $96.82 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 103B | MATTHEWS, SANDRA | Current resident | $64.00 | $2,162.44 | $-64.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 104A | Wells, Gilbert | Former resident | $0.00 | $385.00 | $385.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 104A | STRONG, SHEILA R | Current resident | $0.00 | $3,311.18 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 104B | Pryer, Jennifer | Former resident | $0.00 | $7.00 | $7.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 104B | Greenhoward, Queenesta | Former resident | $0.00 | $433.00 | $433.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 104B | PAYNE, LEONDRA | Former resident | $96.00 | $365.00 | $-96.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 104B | MC LEMORE, DONTA | Current resident | $0.00 | $1,735.06 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 105A | Gordon, Thomas | Former resident | $0.00 | $424.92 | $424.92 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 105A | LOVE, ERIC R | Current resident | $0.00 | $3,590.12 | $468.24 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 105B | BURROWS, CHARLOTTE | Former resident | $0.00 | $726.00 | $726.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 105B | Gonzalez, Erika M | Former resident | $0.00 | $569.12 | $569.12 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 105B | STANLEY, DAVID K | Current resident | $0.00 | $3,255.84 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 106A | WARMACK, DEANNDREA | Former resident | $0.00 | $5.00 | $5.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 106A | Whitehead, Thomas | Former resident | $435.00 | $1,096.79 | $661.79 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 106A | AJAYI, LATEEF | Current resident | $0.00 | $4,230.35 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 106B | REDDEN, JESSE | Former resident | $0.00 | $578.00 | $578.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 106B | MASON, TONIA | Former resident | $0.00 | $1,282.38 | $1,282.38 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 106B | SIMMS, KAMMIE | Former resident | $0.00 | $317.14 | $317.14 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 106B | BRADFORD, KENNETH | Current resident | $158.19 | $4,866.00 | $-78.19 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 107A | MCRAE, CLEMENSTINE | Former resident | $0.00 | $233.00 | $233.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 107A | Ford, Ayaliah | Former resident | $0.00 | $462.00 | $462.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 107A | MOLINA, CARLO MA | Former resident | $60.00 | $608.59 | $548.59 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 107A | TAYLOR, ASHLEY | Former resident | $0.00 | $618.77 | $618.77 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 107A | MARTINEZ, JERMAMAYA | Current resident | $0.00 | $1,844.15 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 107B | Torres Ruiz, Sayra E | Former resident | $0.00 | $491.00 | $491.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 107B | TRAVIS, FELIX D | Current resident | $3.04 | $4,012.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 108A | LOVE, ALINE | Former resident | $0.00 | $31.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 108A | FRANCIS, JEROME | Current resident | $0.00 | $1,789.15 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 108B | SALINAS, VICTORIANA | Current resident | $0.00 | $3,553.76 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 201A | ROSADO LOPEZ, LUIS R | Current resident | $0.00 | $5,716.12 | $1,288.24 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 201B | RODGERS, JOHNNIE | Former resident | $0.00 | $1,461.00 | $1,461.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 201B | JONES, ROY | Former resident | $0.00 | $100.00 | $100.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 201B | BENTON, JASON | Current resident | $0.00 | $5,073.90 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 202A | *PATRICK, ATARSHISH | Former resident | $0.00 | $558.84 | $558.84 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 202A | Knox, Douglas | Former resident | $0.00 | $805.00 | $805.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 202A | ROBINSON, ARAMIE | Former resident | $0.00 | $98.00 | $98.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 202A | BAKER, KIMBERLEY | Former resident | $0.00 | $5.96 | $5.96 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 202A | BROWN, WILLIE | Former resident | $0.00 | $155.75 | $155.75 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 202A | HUNTER, RUBY J | Former resident | $1,907.00 | $7,295.72 | $5,388.72 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 202A | COLORADO, ROSARIO MARGOTH | Current resident | $0.00 | $3,204.96 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 202B | MARTIN, RAKEYA | Former resident | $0.00 | $578.00 | $578.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 202B | Elkhayat, Haythem | Former resident | $0.00 | $1,023.00 | $1,023.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 202B | GASTON, STEPHINE S | Former resident | $524.00 | $641.34 | $117.34 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 202B | MARABLE, JARA KR | Former resident | $4,389.00 | $19,386.66 | $14,997.66 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 202B | Jone, Donna Marie Dockory | Current resident | $0.00 | $4,322.39 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 203A | HAYES, TALMADGE | Former resident | $206.00 | $610.72 | $404.72 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 203A | Souice, Antanisha | Former resident | $0.00 | $311.00 | $311.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 203A | Pascascio, Enice | Former resident | $0.00 | $319.90 | $319.90 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 203A | SCOTT II, DAWYNE | Former resident | $1,173.00 | $2,972.82 | $1,799.82 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 203A | COOPER, JIMMY | Former resident | $0.00 | $1,918.47 | $1,918.47 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 203A | WHALEY, KIMON | Current resident | $0.00 | $4,415.42 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 203B | KODAMA, AVAN | Former resident | $0.00 | $647.88 | $647.88 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 203B | OVERSTREET, REGINALD | Former resident | $0.00 | $16.55 | $16.55 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 203B | SHANNON, TRAVIS | Current resident | $1,366.00 | $3,021.92 | $114.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 204A | Olaose, Oluwanumilola | Former resident | $0.00 | $649.00 | $649.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 204A | SHACKLES, JOMAU | Former resident | $0.00 | $349.60 | $349.60 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 204A | DORANTES, BLANCA I | Former resident | $0.00 | $469.98 | $469.98 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 204A | CATHY, LARAYA M | Former resident | $0.00 | $4,456.86 | $4,456.86 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 204A | ORTIZ CANALES, CARLOS | Current resident | $0.00 | $4,362.79 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 204B | HENRY, ROY | Former resident | $0.00 | $631.00 | $631.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 204B | SANDERS, BELINDA | Former resident | $247.00 | $1,473.35 | $1,226.35 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 204B | TIPPIN, JUSTICE L | Former resident | $0.00 | $1,656.00 | $1,656.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 204B | LYLES, WALTER | Current resident | $0.84 | $2,554.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 205A | BROWN, TROY | Former resident | $0.00 | $996.96 | $996.96 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 205A | MCMILLIAN, DARNESHA | Former resident | $0.00 | $62.86 | $62.86 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 205A | WHITE, MARQUETT D | Former resident | $0.00 | $47.92 | $47.92 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 205A | WEBB, PHILLIP | Current resident | $0.00 | $3,476.96 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 205B | BRYANT, MYSHAWNA | Former resident | $0.00 | $281.31 | $281.31 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 205B | Lewis, Laniesia | Former resident | $0.00 | $813.00 | $813.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 205B | COE, NORMAN | Former resident | $0.00 | $43.70 | $43.70 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 205B | WEST, LATASHA L | Current resident | $0.00 | $3,290.56 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 206A | HANSON, MAURICE | Former resident | $0.00 | $738.52 | $738.52 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 206A | TEKESTE, RAHEL T | Former resident | $0.00 | $555.04 | $555.04 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 206A | GARCIA, MIGUEL | Former resident | $0.00 | $1,644.42 | $77.36 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 206B | HINTON, KYESHIA L | Former resident | $0.00 | $704.12 | $704.12 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 206B | DIXON, ANTHONY | Current resident | $0.00 | $3,460.84 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 207A | Barker, Oral R | Former resident | $0.00 | $338.40 | $338.40 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 207A | MITCHELL, INA | Former resident | $0.00 | $14.40 | $14.40 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 207A | DORANTES, AURORA | Current resident | $0.00 | $4,949.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 207B | Moye, Yvonne | Former resident | $0.00 | $16.32 | $16.32 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 207B | Yell, Zenda | Former resident | $0.00 | $599.00 | $599.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 207B | WILLIAMS, VANESSA | Former resident | $0.00 | $246.84 | $246.84 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 207B | DONNELL, TRINA E | Current resident | $5.00 | $3,177.52 | $-5.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 208A | MALOY, FRANK | Current resident | $0.00 | $4,270.23 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 208B | Favors, Rena | Former resident | $0.00 | $590.74 | $590.74 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 208B | BUGGS, MONIQUE LS | Former resident | $0.00 | $897.84 | $897.84 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 208B | ROBERTS, GRAHAME | Current resident | $0.00 | $3,033.92 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 102A | Anderson, Adrian | Former resident | $1,181.00 | $12.96 | $-1,168.04 | [ ] Confirm paid | — |
| 102A | Culliver, Pamela | Former resident | $6,431.00 | $0.00 | $-6,431.00 | [ ] Confirm paid | — |
| 102B | BENSON, GWENDOLYN | Former resident | $935.00 | $0.00 | $-935.00 | [ ] Confirm paid | — |
| 103A | BALL III, ROY DELL | Current resident | $3,975.00 | $197.88 | $-3,975.00 | [ ] Confirm paid | — |
| 103B | POWELL, WILLIS | Former resident | $362.00 | $0.00 | $-362.00 | [ ] Confirm paid | — |
| 103B | TAYLOR, ALTHENA Y | Former resident | $903.00 | $320.55 | $-582.45 | [ ] Confirm paid | — |
| 104A | YOUNG, PRECIOUS | Former resident | $731.00 | $119.92 | $-611.08 | [ ] Confirm paid | — |
| 104A | Williams, Cynthia | Former resident | $477.00 | $74.00 | $-403.00 | [ ] Confirm paid | — |
| 104B | Kamal, NADIA Y | Former resident | $495.00 | $0.00 | $-495.00 | [ ] Confirm paid | — |
| 104B | BINGHAM, BERNICE | Former resident | $433.00 | $7.68 | $-425.32 | [ ] Confirm paid | — |
| 105A | LAMAR, TIFFANI | Former resident | $473.00 | $142.76 | $-330.24 | [ ] Confirm paid | — |
| 105B | Branch, William | Former resident | $920.00 | $30.00 | $-890.00 | [ ] Confirm paid | — |
| 106B | Nicholson, Tomineka | Former resident | $786.00 | $0.00 | $-786.00 | [ ] Confirm paid | — |
| 106B | HARPER, JAMES | Former resident | $364.00 | $0.00 | $-364.00 | [ ] Confirm paid | — |
| 106B | CANNON, AMUNIQUE ELLESSE | Former resident | $1,106.00 | $106.00 | $-1,000.00 | [ ] Confirm paid | — |
| 107A | HENDERSON, ALPHONSE | Former resident | $988.00 | $0.00 | $-988.00 | [ ] Confirm paid | — |
| 107B | HEADSPETH, TIMICKA | Former resident | $948.00 | $379.68 | $-568.32 | [ ] Confirm paid | — |
| 108A | BOONE, AVA | Former resident | $458.00 | $77.00 | $-381.00 | [ ] Confirm paid | — |
| 108A | Alexander, Devin | Former resident | $599.00 | $0.00 | $-599.00 | [ ] Confirm paid | — |
| 201A | BOONE, CHARLES | Former resident | $62.00 | $0.00 | $-62.00 | [ ] Confirm paid | — |
| 201A | Hauck, Tonieka | Former resident | $485.00 | $105.50 | $-379.50 | [ ] Confirm paid | — |
| 201B | RAND, STEVE | Former resident | $728.00 | $0.00 | $-728.00 | [ ] Confirm paid | — |
| 204A | WISDOM, PATRICK | Former resident | $151.00 | $0.00 | $-151.00 | [ ] Confirm paid | — |
| 204A | ODOM, JAMIE | Former resident | $902.00 | $0.00 | $-902.00 | [ ] Confirm paid | — |
| 204B | Washington, Travis | Former resident | $8,509.00 | $60.72 | $-8,448.28 | [ ] Confirm paid | — |
| 206B | ROBINSON, TRENATI T | Former resident | $324.00 | $131.55 | $-192.45 | [ ] Confirm paid | — |
| 207A | BLACKMON, JAI-MEL | Former resident | $146.00 | $26.16 | $-119.84 | [ ] Confirm paid | — |
| 207A | FLYNN, CHERRELL A | Former resident | $960.00 | $0.00 | $-960.00 | [ ] Confirm paid | — |
| 207B | *BENTLEY, ALICIA | Former resident | $952.00 | $517.76 | $-434.24 | [ ] Confirm paid | — |
| 208A | DORTCH, HAROLD | Former resident | $362.00 | $0.00 | $-362.00 | [ ] Confirm paid | — |
| 208A | Harris, Jonanni | Former resident | $744.00 | $1.00 | $-743.00 | [ ] Confirm paid | — |
| 208B | *GREEN, SHARON | Former resident | $1,074.00 | $0.00 | $-1,074.00 | [ ] Confirm paid | — |
| 208B | STERLING, WILFRED | Former resident | $902.00 | $0.00 | $-902.00 | [ ] Confirm paid | — |

## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.

## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property's supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*