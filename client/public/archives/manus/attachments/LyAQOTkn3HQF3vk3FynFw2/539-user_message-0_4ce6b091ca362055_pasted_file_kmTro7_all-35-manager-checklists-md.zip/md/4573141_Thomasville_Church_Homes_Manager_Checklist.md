# Thomasville Church Homes — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 4573141**. Update the checkboxes and notes during or immediately after the manager call.

> **Note:** No named manager on file in Company Contacts for this property — only a shared mailbox (thomasville@apartmentcorp.com).

| Call details | Manager update |
|---|---|
| Availability report as of | 08/03/2026 |
| Property manager | _No contact on file in Company Contacts — confirm with regional manager._ |
| Regional manager | Johann Armstead — johann@apartmentcorp.com — (804) 481-2503 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Delinquency spreadsheet | `4573141_Thomasville Church Homes_Delinquent - Excel_58.xls` |
| Ledger accounts for review | 236 resident accounts |
| Residents with amount owed | 172 accounts; $251,711.19 |
| Prepaid / credit accounts | 61 accounts; $-25,031.62 |
| Availability entries | 0 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit's reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| — | — | No unit-status entries in the selected source export | [ ] Verified | __________________ |

## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1000-B | Shannon, Kina L | Former resident | $110.00 | $5,207.42 | $5,097.42 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1000-B | Adams, Charlene Nicole | Former resident | $0.00 | $1.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1000-B | Green, Keiosha B | Former resident | $0.00 | $125.00 | $125.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1000-B | Hamlin, Madisyn Michelle | Former resident | $0.00 | $5,341.00 | $5,341.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1000-C | Grays, Kimberly A | Current resident | $1.00 | $384.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1000-D | Bunch, Alyssa C | Former resident | $0.00 | $1,161.00 | $1,161.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1000-D | Allen, Arreanna S | Former resident | $1.00 | $501.00 | $-1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1000-E | Jones, Cheyenne M | Former resident | $0.00 | $426.00 | $426.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1000-E | Huntley, Stacie Nicole | Former resident | $27.00 | $756.00 | $729.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1000-E | Foddrell, Naquida | Current resident | $2,093.00 | $2,553.00 | $15.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1000-F | Ali Saibou, Fatimah A | Former resident | $0.00 | $18.20 | $18.20 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1001-C | Smith, Kesha P | Former resident | $76.00 | $1,384.85 | $1,308.85 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1001-C | Tuttle, Zamaria N | Former resident | $0.00 | $2,915.00 | $2,915.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1001-C | McClure, Meagan Elizabeth | Former resident | $0.00 | $110.00 | $110.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1001-E | JUNCO, MARIA A | Former resident | $38.00 | $3,010.00 | $2,972.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1001-F | Villaman, Rosa E | Former resident | $76.00 | $88.02 | $12.02 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1001-F | Adams, Lynda N | Former resident | $0.00 | $2,615.00 | $2,615.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1001-F | Parker, Aretha | Former resident | $120.00 | $533.00 | $413.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1002-A | Comer, Tatum L | Former resident | $334.50 | $449.00 | $114.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1002-B | Redmon, Martha J | Former resident | $0.00 | $2,959.09 | $2,959.09 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1002-B | Medley, Lashia Soboure | Former resident | $0.00 | $909.00 | $909.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1002-C | Marion, Amanda Louise | Former resident | $0.00 | $6,716.89 | $6,716.89 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1002-C | Parker, Kanesheia | Former resident | $0.00 | $3,932.00 | $936.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1002-D | *Losinger, Stacy A | Former resident | $0.00 | $1,742.03 | $1,742.03 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1002-D | Schmidt, Cheyenne V | Current resident | $0.00 | $1,312.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1002-E | Plata, Kayla M | Former resident | $110.00 | $695.00 | $585.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1002-F | Hodnett, Shonie | Former resident | $0.00 | $657.00 | $657.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1003-A | Georgia, Darlene | Former resident | $0.00 | $337.00 | $337.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1003-B | Harter, Brittany Leigh | Former resident | $0.00 | $805.42 | $805.42 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1003-D | Macias, Janie L | Former resident | $0.00 | $1.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1003-D | Garcia, Victor | Former resident | $1.00 | $28.00 | $27.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1003-F | Adams, Michele Y | Former resident | $0.00 | $640.00 | $640.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1003-F | Adams, Glennda Diane | Current resident | $0.00 | $2,172.00 | $15.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1004-A | Singleton Epps, Tanashia D | Former resident | $0.00 | $175.00 | $175.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1004-A | McMillan, Venica Santrelle | Former resident | $0.00 | $1,484.43 | $1,484.43 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1004-B | Bryant-McCall, Melody L | Former resident | $194.00 | $300.00 | $106.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1004-B | Johnson, Brandy N | Former resident | $0.00 | $4,882.00 | $4,882.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1004-C | Pegues, Shawnee | Former resident | $546.00 | $2,082.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1004-D | ALFORD, TAYSIA A | Former resident | $110.00 | $1,287.50 | $1,177.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1004-E | Barnes, Keanu M | Former resident | $0.00 | $2,352.00 | $2,352.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1004-F | McCray, LaShawnda A | Former resident | $110.00 | $1,542.00 | $1,432.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1004-F | Parkes, Danielle M | Former resident | $0.00 | $2,025.84 | $2,025.84 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1004-F | Davis, Ashley D | Former resident | $237.00 | $575.00 | $338.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1004-F | Nelson, Kimyia Nitajza Diomonique | Former resident | $0.00 | $5,706.07 | $5,706.07 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1004-F | *Bradley, Calleasha | Current resident | $815.00 | $8,928.00 | $4,084.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1005-A | McCullen, Shanon L | Former resident | $0.00 | $65.22 | $65.22 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1005-A | Shipwash, Savannah L | Former resident | $0.00 | $2,174.10 | $2,174.10 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1005-A | Lowe, Hillary Dawn | Former resident | $0.00 | $658.49 | $658.49 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1005-B | *Hamilton, Bria L | Current resident | $0.00 | $6,312.00 | $3,105.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1005-C | Wint, Cassandra V | Former resident | $0.00 | $1.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1005-C | Pierce, Olivia Zykia | Former resident | $0.00 | $68.00 | $68.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1005-D | Williams, Tara N | Former resident | $0.00 | $2,113.00 | $2,113.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1005-D | GADDY, KIONNA | Former resident | $0.00 | $1,066.00 | $1,066.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1005-F | Hoy, Shainita N | Former resident | $0.00 | $393.70 | $393.70 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1005-F | Peace, Nola A | Former resident | $0.00 | $2,092.50 | $0.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1005-F | Smith, Robert | Current resident | $0.00 | $1,103.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1006-A | Linton, Angela D | Former resident | $0.00 | $2,371.62 | $2,371.62 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1006-B | Ramos, Esmeralda H | Former resident | $83.00 | $5,082.99 | $4,999.99 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1006-B | Taylor, Tiffany R | Current resident | $737.00 | $3,073.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1006-C | *Duflo, Gena M | Former resident | $0.00 | $631.00 | $631.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1006-C | TILLERY, TYESHA SHA'NEIL LYNETTE | Former resident | $0.00 | $2,396.78 | $2,396.78 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1006-C | *KEENE, SKYLA | Former resident | $1,137.00 | $1,432.00 | $538.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1006-D | McCain, Demetris N | Former resident | $0.00 | $193.00 | $193.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1006-D | May, Sarah Ashley | Former resident | $1.00 | $20.00 | $19.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1006-D | Williams-Pratt, Alexus | Current resident | $0.00 | $1,020.00 | $1,020.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1006-E | Bruner, Whitney N | Former resident | $110.00 | $577.28 | $467.28 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1006-E | Harrison, Shawntell A | Former resident | $0.00 | $4.00 | $4.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1006-E | Hardaway, Kwanish Danquie | Former resident | $0.00 | $610.00 | $610.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1006-E | Gibbons, Alexis | Current resident | $0.00 | $427.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1006-F | White, Myron D | Current resident | $100.00 | $757.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1007-A | Hogan, April | Former resident | $0.00 | $498.00 | $498.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1007-B | Gilbert, Felicia J | Current resident | $0.00 | $794.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1007-C | Nelson, Margaret | Former resident | $0.00 | $456.00 | $456.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1007-C | Huntley, Pavla J | Former resident | $694.00 | $3,332.00 | $2,638.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1007-E | Kearns, Cheryl | Current resident | $1.00 | $1,054.00 | $214.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1007-E | Sutton, Alane | Former resident | $18.30 | $61.00 | $42.70 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1009-A | DAVIS, TIARA A | Former resident | $0.00 | $234.00 | $234.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1009-A | Jordan, Queen-Deauje D | Former resident | $0.00 | $10.70 | $10.70 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1009-A | Ramirez, Evelyn | Current resident | $37.00 | $1,964.00 | $1,964.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1009-B | KINDLEY, DANIEL M | Former resident | $0.00 | $1,285.00 | $1,285.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1009-B | Poovey, Madison Jo | Former resident | $1,044.00 | $1,670.29 | $626.29 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1009-B | Legrand, Kelly | Current resident | $0.00 | $256.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1009-C | Pohlman, Kaitlyn M | Current resident | $0.00 | $160.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1009-D | Leach, Daquana S | Former resident | $0.00 | $1,741.60 | $1,741.60 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1009-D | Neal, Jocelyn B | Former resident | $0.00 | $1,088.00 | $1,088.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1009-D | PAEZ HERNANDEZ, ALUNDRA | Former resident | $0.00 | $16.00 | $16.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1009-E | Bell, Leslie A | Former resident | $0.00 | $43.00 | $43.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1009-F | Allen, Janiyah L | Former resident | $6.00 | $53.91 | $47.91 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1009-G | Rich, Evie Maria | Former resident | $0.00 | $49.00 | $49.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1009-G | BONAPARTE- HUNT, SHARELL TANASH | Former resident | $0.00 | $1,225.49 | $1,225.49 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1011-A | Hoagland, Kirsten M | Former resident | $0.00 | $2,798.00 | $2,798.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1011-B | Lyons, Kenya L | Former resident | $1,762.00 | $5,061.85 | $3,299.85 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1011-B | Terry, Owennetra K | Former resident | $0.00 | $1,708.00 | $1,708.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1011-B | Medley, Shtimeko | Current resident | $0.00 | $895.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1011-C | McClure, Jeremiah T | Former resident | $9.00 | $1,033.00 | $1,024.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1011-D | Wilder, Alma L | Former resident | $0.00 | $5,429.61 | $5,429.61 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1011-D | Riddick, Kim Y | Former resident | $0.00 | $2,081.27 | $2,081.27 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1011-D | Rivera, Montana Breeza | Current resident | $0.00 | $179.65 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1011-F | Davis, Shyasia M | Former resident | $0.00 | $1,404.50 | $1,404.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1011-F | Montgomery, Shaidashia D | Former resident | $0.00 | $947.20 | $947.20 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1011-F | Flores, Estela Garcia | Former resident | $0.00 | $487.00 | $487.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1011-F | Baxter, Nolan Wayne | Former resident | $0.00 | $5,543.00 | $5,543.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1013-A | Williams, Neosho Y | Former resident | $0.00 | $1,585.00 | $1,585.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1013-A | Martin, Shaneeta | Former resident | $0.00 | $2,403.00 | $35.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1013-B | Rodway, Nicole S | Former resident | $0.00 | $3,263.00 | $3,263.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1013-C | Broadley, Angela M | Former resident | $0.00 | $3,739.00 | $3,739.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1013-C | Creech, Christina L | Former resident | $0.00 | $1,659.00 | $1,659.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1013-C | Schaffer, Cheryl | Current resident | $0.00 | $1,655.00 | $287.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1013-D | MARTINEZ, JESSY D | Former resident | $171.00 | $1,012.00 | $841.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1013-D | Williams, Amy Nicole | Former resident | $0.00 | $1,054.00 | $1,054.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1013-D | Berrier, Tamara E | Former resident | $0.00 | $864.00 | $864.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1013-D | NEALEY, CIERRA BROOKE | Former resident | $0.00 | $3,945.00 | $3,945.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1015-A | NELSON, KIMBERLY M | Former resident | $0.00 | $2,213.29 | $2,213.29 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1015-A | Marion, Jessica J | Former resident | $0.00 | $1,429.00 | $1,429.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1015-A | Castoire, Sarah Elizabeth | Former resident | $0.00 | $55.00 | $55.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1015-A | Washington, Crystal | Current resident | $998.00 | $4,775.00 | $2,861.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1015-B | Marion, Samantha C | Former resident | $0.00 | $41.00 | $41.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1015-C | Bauer, Karyssia L | Former resident | $0.00 | $894.49 | $894.49 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1015-C | Shue, Crystal Rena | Former resident | $0.00 | $290.18 | $290.18 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1015-C | *Knight, Shaquaya O | Current resident | $2,755.00 | $4,101.00 | $1,473.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1015-C | White, Courtney Precria Renee | Former resident | $0.00 | $374.00 | $374.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1015-D | Wardlaw, Joseph P | Former resident | $52.00 | $1,927.00 | $1,875.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1015-D | Whitener, Hannah Paige | Current resident | $135.00 | $1,137.00 | $541.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1015-E | Heller, Rachel A | Former resident | $0.00 | $4,029.50 | $4,029.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1015-E | Black, Nicole R | Current resident | $0.00 | $5,047.00 | $3,661.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1015-F | Maule, Christina M | Former resident | $0.00 | $8,361.00 | $8,361.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1015-F | Ball, Amber N | Former resident | $0.00 | $1,472.00 | $1,472.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1015-F | Motes, Darlene Faye | Current resident | $0.00 | $236.00 | $82.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 807-A | Galloway, Noshaba S | Current resident | $0.00 | $454.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 807-B | Johnson, Jessica L | Former resident | $0.00 | $643.00 | $643.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 807-B | Burton, Ryan Breshun | Former resident | $0.00 | $14.00 | $14.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 807-B | Turner, Cheyenne R | Former resident | $1.00 | $1,078.00 | $1,077.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 807-B | Nieves, Maricelys Flores | Former resident | $0.00 | $33.60 | $33.60 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 807-C | Vasquez, Ana P | Former resident | $0.00 | $52.00 | $52.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 807-C | Scott, Elizabeth Mae | Current resident | $1.00 | $26.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 807-F | Thomas, Taylor N | Former resident | $0.00 | $3,018.00 | $3,018.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 807-F | BENEFIELD, REGINALD | Former resident | $0.00 | $1,019.00 | $1,019.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 807-F | Withers, Essence | Former resident | $0.00 | $904.00 | $904.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 809-A | GARCIA NIEVES, GIOVANNA M | Former resident | $70.00 | $916.64 | $846.64 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 809-B | Guadarrama, Tonya O | Former resident | $0.00 | $908.00 | $908.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 809-B | Mitchell, Liyah M | Former resident | $0.00 | $38.00 | $38.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 809-B | Brown, Toni M | Former resident | $309.00 | $1,825.21 | $1,516.21 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 809-B | Wright, Cheresa | Current resident | $0.00 | $775.98 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 809-D | Willitts, Brittany L | Former resident | $0.00 | $671.00 | $671.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 809-D | Little, Quasilyn Venise | Former resident | $0.00 | $2,761.00 | $2,761.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 809-D | Austin, Kimberly A | Former resident | $0.00 | $1,338.69 | $1,338.69 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 809-E | Hairston, Omegza D | Former resident | $0.00 | $2,624.00 | $2,624.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 809-F | Cole, Davesha T | Former resident | $0.00 | $3,326.24 | $3,326.24 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 809-F | Hemrick, Regina R | Current resident | $0.00 | $107.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 811-C | Mobley, Sarah D | Former resident | $0.00 | $133.00 | $133.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 811-C | Blackwell, McKenzie B | Former resident | $0.00 | $1,708.82 | $1,708.82 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 811-D | Black, Janet | Former resident | $0.00 | $1,496.00 | $1,496.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 811-D | Johnson, Kelly Jo | Current resident | $72.00 | $637.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 811-E | Griffin, Jamarri | Former resident | $35.00 | $56.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 813-B | HALL, VIRGINIA S | Former resident | $59.00 | $567.00 | $508.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 813-B | Baxter, Keana M | Former resident | $1.00 | $754.00 | $753.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 813-C | Johnson, Diosha J | Former resident | $0.00 | $1,773.98 | $1,773.98 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 813-C | Ramirez, Alicia | Former resident | $0.00 | $2,654.01 | $2,654.01 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 813-D | Wood, Zoiee | Former resident | $0.00 | $564.00 | $564.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 813-E | Pierce, Lauren E | Former resident | $12.00 | $774.38 | $762.38 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 813-F | Gordon, Joyce P | Former resident | $0.00 | $5.00 | $5.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 815-A | Haney, Cameron J | Former resident | $0.00 | $585.34 | $585.34 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 815-A | Conley, Mckenzie | Former resident | $0.00 | $934.00 | $934.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 815-B | McCurdy, MaSean C | Former resident | $0.00 | $3,251.00 | $3,251.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 815-C | Osborne, Miranda Lynette | Former resident | $854.00 | $4,260.10 | $3,406.10 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 815-D | Hairston, Cadosgi C | Former resident | $0.00 | $3,757.00 | $3,757.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 815-D | Romero, Betsy | Former resident | $0.00 | $42.00 | $42.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 815-E | Jones, Raven Sean Janet | Former resident | $0.00 | $713.00 | $713.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 815-E | Graham, Tierra L | Former resident | $0.00 | $20.03 | $20.03 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 815-F | Tuttle, Tydarius D | Former resident | $0.00 | $36.00 | $36.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 815-F | McCollum, Heather Rae | Former resident | $0.00 | $2,251.00 | $2,251.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 815-F | Threadgill, Constance | Current resident | $0.00 | $880.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1000-A | Lopez, Fatima L | Current resident | $1,636.00 | $0.00 | $-1,570.00 | [ ] Confirm paid | — |
| 1000-B | Cockrane, Ziyahta Ariel Kesha | Former resident | $696.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1000-C | Carmon, Latoya A | Former resident | $712.61 | $143.61 | $-569.00 | [ ] Confirm paid | — |
| 1000-F | Hagar, Crystal M | Former resident | $110.00 | $26.00 | $-84.00 | [ ] Confirm paid | — |
| 1000-F | Mota-Torres, Edith | Former resident | $994.00 | $44.00 | $-950.00 | [ ] Confirm paid | — |
| 1000-F | Valentino, Diezal | Current resident | $182.00 | $137.00 | $0.00 | [ ] Confirm paid | — |
| 1001-A | BILLINGS, KATHERINE L | Former resident | $76.00 | $0.00 | $-76.00 | [ ] Confirm paid | — |
| 1001-A | Mitchell, Stacy A | Current resident | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1001-B | Monk, Tiffany L | Current resident | $12.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1001-C | Monge-Lopez, Nachaly | Current resident | $87.00 | $0.00 | $-27.00 | [ ] Confirm paid | — |
| 1001-E | Squires, Victoria | Current resident | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1002-A | Hunt, Elizabeth | Current resident | $155.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1002-C | JONES, DESTINY C | Former resident | $1,345.00 | $1,257.50 | $1,147.50 | [ ] Confirm paid | — |
| 1002-E | EARL, KIMBERLY LATRICE | Current resident | $135.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1002-F | Jackson, Twanetta D | Former resident | $80.00 | $0.00 | $-80.00 | [ ] Confirm paid | — |
| 1002-F | Lafosse, Monae Alexandria | Former resident | $63.00 | $0.00 | $-63.00 | [ ] Confirm paid | — |
| 1002-F | Thomas, Elshukee | Current resident | $139.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1003-A | Hopper, Hannah Marie | Former resident | $1,646.00 | $0.00 | $-1,646.00 | [ ] Confirm paid | — |
| 1003-B | Wiggins, Alea Zhane | Current resident | $496.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1003-D | Norris, Sena | Former applicant | $266.00 | $0.00 | $-266.00 | [ ] Confirm paid | — |
| 1003-D | Ledbetter, Darryl | Current resident | $110.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1003-E | Ledbetter, Annie T | Current resident | $66.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1004-A | Bumgardner, Christina M | Current resident | $740.00 | $40.00 | $0.00 | [ ] Confirm paid | — |
| 1004-B | Aguilar, Cornelio Carbajal | Former resident | $837.00 | $25.00 | $-812.00 | [ ] Confirm paid | — |
| 1004-E | Macias, Janie | Current resident | $195.00 | $170.00 | $0.00 | [ ] Confirm paid | — |
| 1005-C | Davis, QuSawna | Current resident | $930.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1005-D | Green, Sarah | Current resident | $72.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1006-A | Negron, Francheska M | Former resident | $1,007.00 | $210.00 | $-797.00 | [ ] Confirm paid | — |
| 1006-A | Davidson, Krystal Beth | Current resident | $672.00 | $0.00 | $-672.00 | [ ] Confirm paid | — |
| 1006-F | LeGrand, Kelly C | Former resident | $110.00 | $0.00 | $-110.00 | [ ] Confirm paid | — |
| 1007-A | Williams, Candice N | Current resident | $928.00 | $484.00 | $0.00 | [ ] Confirm paid | — |
| 1007-C | Pearson, Gladys Williams | Current resident | $67.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1007-D | Porter, Larry R | Current resident | $63.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1009-D | Henderson, Shykiria | Former resident | $2,454.00 | $774.00 | $0.00 | [ ] Confirm paid | — |
| 1009-E | Colbert, Dandra Conyetta | Current resident | $255.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1009-F | Brink, Gina Marie | Former resident | $1,095.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1009-G | Nelson, Angella L | Former resident | $126.00 | $125.07 | $125.07 | [ ] Confirm paid | — |
| 1009-G | Gregorio, Bonnie | Current resident | $103.80 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1011-A | Carmichael, Kerriayna Dejaha | Current resident | $112.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1011-C | Smith, Willie | Current resident | $108.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1011-E | Jones, Carmen A | Current resident | $5.50 | $0.00 | $-5.50 | [ ] Confirm paid | — |
| 1011-F | Martell, Adreunna | Current resident | $1,088.00 | $6.00 | $0.00 | [ ] Confirm paid | — |
| 1013-A | Bradshaw, Tammy Annette | Current resident | $79.00 | $12.00 | $0.00 | [ ] Confirm paid | — |
| 1013-B | Rookard, Ahminah A | Current resident | $556.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 807-D | Emmerson, Nikita Shada | Former resident | $543.00 | $183.00 | $-360.00 | [ ] Confirm paid | — |
| 807-D | Lee, Demarcus Rasheed | Current resident | $32.00 | $0.00 | $-32.00 | [ ] Confirm paid | — |
| 807-E | Dunlap, Steven | Current resident | $140.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 809-A | Davis, Tomeka E | Current resident | $16.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 809-C | Burgess, Essince | Current resident | $180.00 | $0.00 | $-5.00 | [ ] Confirm paid | — |
| 809-E | Bryant, Pamela L | Current resident | $24.00 | $0.00 | $-24.00 | [ ] Confirm paid | — |
| 811-A | Johnson, Kiana Evone | Current resident | $18.89 | $0.00 | $-18.89 | [ ] Confirm paid | — |
| 811-B | Sloane, Debbie J | Current resident | $141.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 811-C | Worley, Jayden Raye | Current resident | $1,050.00 | $0.00 | $-1,050.00 | [ ] Confirm paid | — |
| 811-E | FLORES NIEVES, NEISHKA T | Former resident | $143.00 | $61.00 | $-82.00 | [ ] Confirm paid | — |
| 811-F | Norris, Willis James | Current resident | $140.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 813-A | Mims, Ashley | Former resident | $191.00 | $16.00 | $-165.00 | [ ] Confirm paid | — |
| 813-A | Covington, Anton | Current resident | $2,288.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 813-B | Smith, Danasia Shannail | Current resident | $22.00 | $1.00 | $-22.00 | [ ] Confirm paid | — |
| 813-C | Guillen Gutierrez, Isabella | Current resident | $562.00 | $0.00 | $-10.00 | [ ] Confirm paid | — |
| 815-B | ROBERTS, AMANDA | Current resident | $556.00 | $0.00 | $-481.00 | [ ] Confirm paid | — |
| 815-D | Harrison, Erika Lynn | Former resident | $2,088.00 | $0.00 | $-39.00 | [ ] Confirm paid | — |

## Resident Balance Follow-Up — Paid / Zero Balance

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1001-C | Stamps, Navayia Shaneice | Former resident | $2.00 | $2.00 | $2.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 807-D | Gadson, Geraldine L | Former resident | $570.00 | $570.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 813-D | Wade, Nautica R | Former resident | $945.50 | $945.50 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property's supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*