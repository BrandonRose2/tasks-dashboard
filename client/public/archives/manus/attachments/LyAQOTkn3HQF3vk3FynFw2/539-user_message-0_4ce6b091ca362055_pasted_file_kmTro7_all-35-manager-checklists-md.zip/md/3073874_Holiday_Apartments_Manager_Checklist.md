# Holiday Apartments — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 3073874**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/05/2026 |
| Property manager | Arlene Vinson — holiday@apartmentcorp.com — (318) 758-4043 |
| Regional manager | JR Rolon — jrrolon@apartmentcorp.com — (941) 716-1665; Leslie Rolon — leslie@apartmentcorp.com — (504) 247-3813 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Delinquency spreadsheet | `3073874_Holiday Apartments_Delinquent - Excel_58.xls` |
| Ledger accounts for review | 368 resident accounts |
| Residents with amount owed | 284 accounts; $226,518.86 |
| Prepaid / credit accounts | 81 accounts; $-22,926.09 |
| Availability entries | 1 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit's reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| 02A | 3BR | Vacant Not Leased Not Ready | [ ] Verified | __________________ |

## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 01D | WILLIAMS, FRANKIE L | Former resident | $0.00 | $2,307.00 | $2,307.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02A | SHEPPARD, LATONYA | Former resident | $0.00 | $716.00 | $716.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02A | AS-SABOR, BRANDI | Former resident | $0.00 | $129.00 | $129.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02A | GREEN, ROQUANTA S | Former resident | $0.00 | $212.00 | $212.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02A | Holmes, Lakisha J | Former resident | $0.00 | $46.00 | $46.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02A | Johnson, Destiny Nicole | Former resident | $0.00 | $100.00 | $100.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02A | Washington, Desmond Darrell | Former resident | $0.00 | $56.00 | $56.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02A | HALL, YOLANDA | Current resident | $0.00 | $900.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02B | Carver, Mia H | Former resident | $0.00 | $108.00 | $108.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02C | HUGHES, ECKWANISE | Former resident | $0.00 | $445.00 | $445.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02C | GREEN, ROSHELL R | Former resident | $0.00 | $158.00 | $158.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02C | ROSS, HILDA ELAINE | Former resident | $0.00 | $239.00 | $239.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02D | COATES, TABATHA | Former resident | $589.00 | $1,233.00 | $644.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02D | Walls, Alayshia R | Former resident | $0.00 | $36.00 | $36.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02D | LOPEZ, MARCELINA MARIE | Former resident | $0.00 | $752.00 | $752.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02D | JOHNSON, JAMESHIA | Former resident | $0.00 | $136.00 | $136.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02E | Puckett, Jasmine Tiakeesha | Former resident | $0.00 | $1,848.00 | $1,848.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02E | Smith, Tatanya | Former resident | $0.00 | $657.00 | $657.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02F | WILLIAMS, DIANA | Former resident | $0.00 | $1,954.00 | $1,954.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 02F | MCGUIRE, DANTERIA M | Former resident | $0.00 | $293.00 | $293.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 03B | HARTWELL, LINDA K | Former resident | $480.00 | $650.00 | $170.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 03B | Nelson, LaCrystal G | Former resident | $0.00 | $560.00 | $560.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 03B | CAULEY, JORDAN ISAIAH | Former resident | $0.00 | $8.00 | $8.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 03C | Mason, Alexus Sarahlique | Former resident | $0.00 | $1.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 03C | JOHNSON, ERICA | Former resident | $0.00 | $54.00 | $54.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 03C | OQUINN, T'SHAWNA | Former resident | $0.00 | $100.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 03C | KING, ANNA | Current resident | $0.00 | $1.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 03D | HALL, MARILYN ANTOINETTE | Former resident | $0.00 | $413.00 | $413.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 03D | Jones, Syritta T | Former resident | $0.00 | $1.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 03D | JOHNSON, BENJAMIN H | Former resident | $0.00 | $1,812.00 | $1,812.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 03E | BAILEY, JEMINAH | Former resident | $0.00 | $345.00 | $345.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 03E | HUNT, DAQUIRIA V | Former resident | $0.00 | $400.00 | $400.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 03E | TYLER, BILLIE | Current resident | $0.00 | $74.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 03F | FELIX, SHEKITA RENAY | Former resident | $0.00 | $817.00 | $817.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04A | BANKS, KIMBERLY | Former resident | $0.00 | $95.00 | $95.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04A | WILLIAMS, CARMEN C | Former resident | $0.00 | $252.00 | $252.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04A | Glover, Valencia Cherie | Former resident | $0.00 | $6.00 | $6.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04A | STUMPS, JESSICA denise | Former resident | $0.00 | $164.00 | $164.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04A | HARRIS, KELLY LESHA | Current resident | $0.00 | $80.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04B | GREEN, JESSICA | Former resident | $0.00 | $66.00 | $66.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04B | COATES, SHAUNDERKA R | Former resident | $0.00 | $643.00 | $643.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04B | NICHOLS, CARRIEL | Former resident | $0.00 | $100.00 | $100.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04B | Green, Shmeen Tera | Former resident | $0.00 | $369.00 | $369.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04B | BELTON, SABRINA RENEE | Current resident | $0.00 | $3.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04C | MOBLEY, DEBRA LEE | Former resident | $0.00 | $100.00 | $100.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04D | CURTIS, JAVETTE | Former resident | $502.00 | $638.00 | $136.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04E | LUSTER, YOLANDA | Former resident | $0.00 | $1,784.00 | $1,784.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04F | Johnson, Patrice Olan | Former resident | $0.00 | $1,772.30 | $1,772.30 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 04F | ANDERSON, SABRINA MARIE | Former resident | $0.00 | $364.00 | $364.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05A | BATES, PAMELA | Former resident | $6.00 | $52.91 | $46.91 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05A | HENRY, DIANE | Current resident | $0.00 | $129.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05B | BELTON, LAKENDA S | Former resident | $0.00 | $1.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05B | LYONS, JASMINE DENISE | Former resident | $0.00 | $12,943.00 | $12,943.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05C | DAVIS, ROBERT L | Former resident | $105.00 | $418.00 | $313.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05C | HAYWOOD, JOHNIEKIAH LATRICE | Former resident | $0.00 | $683.00 | $683.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05C | Green, Tina Mae | Former resident | $0.00 | $16.00 | $16.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05C | COATES, ALAIJA RENAE | Current resident | $0.00 | $224.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05D | RIVERA JR., CARMELO | Former resident | $0.00 | $29.00 | $29.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05D | Jones, Gabrielle N | Former resident | $0.00 | $8,615.00 | $8,615.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05E | DAVIS, RESHONDA | Former resident | $0.00 | $2,477.00 | $2,477.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05F | WATSON, ZUNDRA | Former resident | $0.00 | $23.00 | $23.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05F | MINOR, DANIELLA M | Former resident | $0.00 | $43.00 | $43.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05F | Rice, Lakrystal | Current resident | $0.00 | $270.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 06A | LAWERENCE, ERNESTINE | Former resident | $0.00 | $135.00 | $135.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 06A | Mcknight, Shawn Nekeshia | Former resident | $0.00 | $1.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 06A | Jenkins, Carlisha | Former resident | $0.00 | $100.00 | $100.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 06B | Kennedy, Shanice | Former resident | $0.00 | $900.00 | $900.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 06B | Ray, Morgan B | Former resident | $0.00 | $151.00 | $151.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 06B | JENKINS, CARLISHA | Former resident | $0.00 | $129.00 | $129.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 06C | WADE, AMETHA | Former resident | $0.00 | $129.00 | $129.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 06C | JONES, BARBARA A | Current resident | $0.00 | $40.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 06C | CARRADIN, CHRISTIAN JOHNTESE | Former resident | $119.00 | $793.68 | $674.68 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 06D | MORALES, INDIA PHARRA | Former resident | $1.00 | $538.00 | $537.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 06E | DOSS, VIVIAN | Former resident | $0.00 | $401.00 | $401.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 06E | SMITH, CHELSEA SADE | Former resident | $0.00 | $523.00 | $523.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 06E | Butler, Breante Kesha | Former resident | $0.00 | $53.00 | $53.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 06E | DOBBINS, JAHEEM DEE'ANDRE | Former resident | $1.00 | $150.00 | $149.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 06F | Davis, Amber | Former resident | $0.00 | $873.00 | $873.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 06F | WASHINGTON, LATRISHA | Former resident | $0.00 | $102.00 | $102.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 07A | Carter, Ariana | Former resident | $0.00 | $392.00 | $392.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 07A | WILEY CARVER, KEYANTE LASHAE | Former resident | $0.00 | $18.00 | $18.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 07A | CHEST, KAWANDA LEE | Current resident | $0.00 | $996.00 | $633.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 07B | BROWN, FILYNTHIA M | Former resident | $0.00 | $69.00 | $69.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 07B | Hawkins, Arricka Arniesha | Former resident | $0.00 | $4.00 | $4.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 07B | DAVIS, TIRA LASHAY | Former resident | $0.00 | $1.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 07B | Smith, Corban S | Former resident | $0.00 | $24.00 | $24.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 07B | Frazier, Kenisha L | Former resident | $0.00 | $12.00 | $12.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 07C | Jackson, Calin S. | Former resident | $0.00 | $9.00 | $9.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 07D | ROBINSON, LEAH | Former resident | $0.00 | $5,012.00 | $5,012.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 07E | ROBINSON, JAMES OTIS | Current resident | $0.00 | $103.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 07F | BROWN, LASONYA | Former resident | $8.00 | $348.72 | $340.72 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 07F | Baker, Heather A | Former resident | $0.00 | $1,153.25 | $1,153.25 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 08A | BEVERLY, ROSLAND | Former resident | $0.00 | $623.00 | $623.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 08A | King, Brandi Nicole | Former resident | $0.00 | $245.00 | $245.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 08A | Bates, Leresa Janel | Former resident | $0.00 | $5,804.00 | $5,804.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 08A | WHITE, JESSECCA FLORIA ALUCCIANA MORALES | Current resident | $0.00 | $1,297.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 08B | CARTER, ETHEL M | Former resident | $0.00 | $5.00 | $5.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 08B | Stumps, Jessica D | Former resident | $0.00 | $1.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 08B | Moore, Princess N | Former resident | $0.00 | $1,096.00 | $1,096.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 08C | CRAIG, JANNIE M | Former resident | $89.00 | $288.00 | $199.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 08C | Short, Edna | Former resident | $0.00 | $317.00 | $317.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 08E | CARTER, REVA S | Former resident | $0.00 | $215.00 | $215.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 08E | Shelton, Carolyn Victoria | Former resident | $50.00 | $159.00 | $109.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 08E | Anderson, Sabrina | Former resident | $0.00 | $83.00 | $83.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 08E | JOHNSON, JAMESHIA LASHAI | Current resident | $0.00 | $1,975.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 08F | Snyder, Shemeka Lashun | Former resident | $0.00 | $542.00 | $542.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 08F | Lucas, Shameka K | Former resident | $0.00 | $777.00 | $777.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10A | King, Florida M | Former resident | $0.00 | $76.00 | $76.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10B | WILLIAM, BRIDGET D | Former resident | $0.00 | $2,625.00 | $2,625.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10B | GRIFFIN, TANGELA A | Former resident | $0.00 | $125.00 | $125.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10B | Bradley, Jonquille A | Former resident | $0.00 | $10.00 | $10.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10B | Trapp, Heather | Former resident | $0.00 | $1.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10C | McKnight, Shawn Nekesia | Former resident | $0.00 | $203.00 | $203.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10C | GREEN, JEREMIAH | Former resident | $0.00 | $221.00 | $221.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10D | PRATER, KEYRHONDA D | Former resident | $0.00 | $1,550.00 | $1,550.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10D | SMITH, YOLANDA | Former resident | $0.00 | $1,050.00 | $1,050.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10D | THORNBURG, MARQUITA V | Former resident | $0.00 | $50.00 | $50.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10D | White, JesseccaFloria A | Former resident | $0.00 | $568.10 | $568.10 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10D | BASS, JACCACIA T | Former resident | $0.00 | $41.00 | $41.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10D | SHEPPARD, MYEAH JHARNAI | Former resident | $0.00 | $100.00 | $100.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10D | WILSON, TROY DEWAYNE | Current resident | $0.00 | $1.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10E | FINISKER, SHALAY | Former resident | $599.00 | $2,472.00 | $1,873.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10E | BURNS, CIERRA | Former resident | $0.00 | $462.00 | $462.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10E | King, Anionette Andrea | Former resident | $0.00 | $440.00 | $440.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10E | Howell, James T | Former resident | $0.00 | $29.00 | $29.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10F | THOMPSON, BARBARA J | Former resident | $0.00 | $164.00 | $164.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10F | Myles, Jaykala | Former resident | $159.00 | $160.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11A | HARRIS, APRIL L | Former resident | $0.00 | $356.56 | $356.56 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11A | WILLIAMS, ALRIANNE | Former resident | $6.00 | $45.00 | $39.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11A | Johnson, Cadisia Alexandrea | Current resident | $0.00 | $126.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11A | PUCKETT, DAMISHA MONIQUE | Former resident | $0.00 | $1.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11B | WIMBERLY - KING, BRANDI N | Former resident | $89.00 | $426.00 | $337.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11B | O'NEAL, PATRICIA | Former resident | $0.00 | $3,394.00 | $3,394.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11B | Davis, Tira L | Former resident | $0.00 | $224.00 | $224.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11B | Thomas, JaBreunna Mo'Nae | Former resident | $1.00 | $90.00 | $89.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11B | McGruder, Allison | Current resident | $0.00 | $1.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11C | LEWIS, BEVERLY RUTH | Former resident | $0.00 | $78.00 | $78.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11C | DONALDSON, ADRIONNA CHARLESIA | Former resident | $0.00 | $102.00 | $102.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11C | SMITH, RONNIE L | Current resident | $0.00 | $1,786.00 | $480.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11D | HUNT, MARQUERITE J | Former resident | $0.00 | $1,428.00 | $1,428.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11D | SEWELL, PATINA | Former resident | $0.00 | $1.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11E | BLANTON, RACHAEL B | Former resident | $0.00 | $6,539.00 | $6,539.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11E | MCGOWAN, FANTAISA ENSHAUNTE | Current resident | $151.00 | $190.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11F | WILLIAMS, ORSHAWNDA N | Former resident | $0.00 | $931.50 | $931.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11F | JOHNSON, NAKINYA L | Former resident | $0.00 | $445.00 | $445.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11F | Rimer, Yholanda Marie | Former resident | $0.00 | $205.00 | $205.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11F | Denegall, RaseanS | Former resident | $0.00 | $1,007.00 | $1,007.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12D | HENCE, STEPHANIE N | Current resident | $0.00 | $145.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12D | BACON, PATRICIA A | Former resident | $0.00 | $1,273.00 | $1,273.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12D | SHEPPARD, MYEAH JHARNAI | Former resident | $0.00 | $1.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12D | ROBINSON, LATASHA LENORA | Former resident | $0.00 | $100.00 | $100.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12D | MCCOY, DAVEYON | Former resident | $0.00 | $1.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12E | TYLER, MARY A | Former resident | $135.00 | $7,736.90 | $7,601.90 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12E | HAWKINS, JUAN | Former resident | $0.00 | $94.00 | $94.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12E | FITZGERALD, LAMONICA | Current resident | $0.00 | $600.00 | $600.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12F | SMOOT, LORRAINE A | Former resident | $0.00 | $128.00 | $128.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12F | Foster, Crystal Le | Former resident | $0.00 | $1,699.00 | $1,699.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12F | Dunmore, Rochelle L | Former resident | $0.00 | $271.00 | $271.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12F | Pullins, Helen Denise | Former applicant | $0.00 | $849.00 | $849.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13A | Lewis, Louvinia | Former resident | $0.00 | $409.00 | $409.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13A | HUMPHRIES, DINNA | Current resident | $0.00 | $1.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14B | MURRELL, CRYSTAL E | Former resident | $0.00 | $993.00 | $993.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14B | ROBINSON, NATASHA S | Former resident | $0.00 | $5.00 | $5.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14B | SPANN, JESSICA DAWN | Former resident | $0.00 | $100.00 | $100.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14B | JACKSON, CALIN S | Former resident | $0.00 | $109.00 | $109.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14B | Taylor, Khedra | Former resident | $0.00 | $56.50 | $56.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14B | Cade, Roshinda | Former resident | $0.00 | $508.00 | $508.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14B | Franklin, LaChelle Briane | Former resident | $0.00 | $4,892.00 | $4,892.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14B | GREEN, CHRISTIANA NICOLE | Former resident | $0.00 | $1.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14C | DOSS, TADRIA | Former resident | $0.00 | $30.90 | $30.90 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14D | FULLER, NATASHA C | Former resident | $0.00 | $73.00 | $73.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14D | Dunmore, Keyundea Tyeasha | Former resident | $0.00 | $210.00 | $210.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14E | LONG, MOLLIE | Former resident | $0.00 | $635.00 | $635.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14E | Jones, Mary D | Current resident | $0.00 | $5.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14F | HOLMES, LAKISHA | Former resident | $0.00 | $28.00 | $28.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14F | MCMORRIS, SHAMEAKI | Former resident | $0.00 | $43.00 | $43.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14F | CHATMAN, JACQUELINE RENE | Former resident | $0.00 | $331.00 | $331.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14F | Haynes, TaQushia L | Former resident | $0.00 | $3,463.00 | $3,463.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15A | WILLIAMS, ANTONNIA EXNIRA | Former resident | $0.00 | $56.00 | $56.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15A | ALBERT, JALIYAH | Former resident | $0.00 | $703.00 | $703.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15A | MCGUIRE, DANTERIA | Current resident | $12.00 | $1,642.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15B | WHITE, CAROLYN L | Former resident | $0.00 | $599.00 | $599.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15B | GREEN, CHRISTINA | Former resident | $0.00 | $386.00 | $386.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15B | THOMAS, STEPHANIE YOLANDA | Former resident | $0.00 | $229.00 | $229.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15B | Sullivan, Destiney N | Former resident | $0.00 | $1.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15B | Anderson, Shalonda | Former resident | $0.00 | $214.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15C | BELTON, KARISSA | Former resident | $0.00 | $735.00 | $735.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15C | Williams, Lavada Michelle | Former resident | $0.00 | $8,842.00 | $8,842.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15C | WILLIAMS, LAKHYRA RYQUEL | Former resident | $0.00 | $17.00 | $17.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15C | WRIGHT, DEXTER AARON | Former resident | $0.00 | $100.00 | $100.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15C | JONES, JOSEPH | Current resident | $0.00 | $127.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15E | ALLEN, PATRICIA | Former resident | $0.00 | $49.00 | $49.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15E | Mays, Takeyan L | Former resident | $0.00 | $709.00 | $709.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15E | MALONE, MYTRELL | Former resident | $0.00 | $580.00 | $580.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 15F | JENKINS, TALISHA MARIA | Former resident | $0.00 | $100.00 | $100.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16B | BROWN, ANGELA J | Former resident | $0.00 | $13,379.00 | $13,379.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16C | WALKER, VIRGINIA L | Former resident | $86.00 | $1,582.00 | $1,496.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16C | Felton, Juantavias Quadrikus | Former resident | $0.00 | $5.00 | $5.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16C | GRIFFIN, TAMMICKA LYSHAWN | Former resident | $0.00 | $1.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16C | JOHNSON, MALISHA | Current resident | $0.00 | $1,961.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16D | PHIPPS, KARLA B | Former resident | $4.00 | $635.00 | $631.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16D | RILEY, WHITLEY C | Former resident | $0.00 | $172.00 | $172.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 16D | Allen, Patricia k | Current resident | $0.00 | $155.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17B | WALKER, BRENDA | Former resident | $413.00 | $3,388.00 | $2,975.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17C | JONES, STELLA K | Former resident | $199.00 | $1,020.00 | $821.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17C | BELTON, KARISSA | Former resident | $0.00 | $1,178.00 | $1,178.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 17D | LEWIS, TONISHA L | Former resident | $1.00 | $265.00 | $264.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18A | TENNER, BERTINA | Former resident | $0.00 | $1,512.00 | $1,512.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18A | Young, Tiffany Nicole | Former resident | $0.00 | $1,908.00 | $1,908.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18A | Chatman, Trevante' Rashard | Former resident | $0.00 | $336.00 | $336.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18A | DAVIS, LADONNA MARIA | Former applicant | $37.00 | $1,557.00 | $1,520.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18A | BELTON, LAKENDA SHUNTA | Current resident | $0.00 | $230.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18B | JACKSON, ROSIE | Former resident | $0.00 | $269.00 | $269.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18B | ROBINSON, LATRICE Y | Former resident | $0.00 | $1,059.00 | $1,059.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18B | Houseworth-Carver, Raven Tamira | Former resident | $0.00 | $569.00 | $569.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18B | Dunmore, Taquania Sade | Former resident | $0.00 | $150.00 | $150.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18B | Shelton, Carolyn V | Former resident | $0.00 | $1.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18B | SWAZY, MALIKA | Former resident | $0.00 | $275.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18C | SMITH, CHELSEA | Former resident | $298.00 | $395.00 | $97.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18C | KING, IESHA ROCHELLE | Former resident | $0.00 | $627.19 | $627.19 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18D | BOOKER, YOLANDA | Former resident | $0.00 | $185.00 | $185.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18D | WOODFORK, SHERATON R | Former resident | $0.00 | $5.00 | $5.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18D | Carver, Keyante L | Former resident | $0.00 | $33.00 | $33.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18D | Queen, Jorita | Former resident | $1.00 | $6.00 | $5.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18D | Coates, Ariel Raesean | Former resident | $0.00 | $6,398.00 | $6,398.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18D | Hence, Debra L | Current resident | $0.00 | $761.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18E | DOBBINS, INDIA | Former resident | $9.00 | $99.00 | $90.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18E | Green, Crystal Marshal | Former resident | $0.00 | $113.00 | $113.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18E | Williams, Bre'Anna L | Former resident | $0.00 | $1,718.00 | $1,718.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18E | ALLEN, KYRAH DANYEL | Former resident | $0.00 | $101.00 | $101.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18E | DAVIS, JASMINE ALANTAE | Former resident | $0.00 | $1,000.00 | $1,000.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18F | NOBLE, VALENCIA | Former resident | $0.00 | $654.00 | $654.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18F | Wilson, Deneka R | Former resident | $0.00 | $100.00 | $100.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18F | WHITE, ELIZABETH | Former resident | $0.00 | $167.00 | $167.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 18F | SMITH, KEMARIA | Current resident | $0.00 | $557.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19A | WOODS GINES, CELMETHA F | Former resident | $0.00 | $1,356.00 | $1,356.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19A | JONES, DENEISHIO L | Former resident | $0.00 | $15.00 | $15.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19A | Jackson, Brittany L | Current resident | $0.00 | $547.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19A | Hartfield, Kimberly E | Former resident | $0.00 | $1.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19B | CHAMP, KATRINA J | Former resident | $0.00 | $4,873.06 | $4,873.06 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19B | BRADY, CRISTINA L | Former resident | $0.00 | $761.00 | $761.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19B | DAVIS, JATRONNE | Former resident | $0.00 | $2.00 | $2.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19B | WEBBER, EBONY DINEKA | Former resident | $0.00 | $100.00 | $100.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19B | FRANKLIN, AALIYAH | Former resident | $0.00 | $591.00 | $591.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19C | WASHINGTON, CARONDA | Former resident | $0.00 | $1,437.00 | $1,437.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19C | Reed, Sandra Shantell | Former resident | $0.00 | $138.00 | $138.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19D | HUNTER, TERENA | Former resident | $0.00 | $1,527.68 | $1,527.68 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 19D | Cade, Shavetry Y | Former resident | $0.00 | $600.00 | $600.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20A | FRYE, IESHA | Former resident | $0.00 | $599.00 | $599.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20A | JEFFERSON, D'SIR LASHAWN | Current resident | $0.00 | $532.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20B | SCOTT, BRENIYA | Current resident | $0.00 | $154.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20C | Tenner, Rashanika n | Former resident | $1.00 | $1,328.78 | $1,327.78 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20D | JEFFERSON, ALEXIS ANDREAL | Former resident | $0.00 | $637.00 | $637.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20D | ANDERSON, SHALANDRA MONIQUE | Former resident | $0.00 | $26.00 | $26.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20D | Strauder, Terri | Former resident | $15.00 | $50.00 | $35.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20D | Evans, Laketha M | Former resident | $0.00 | $73.00 | $73.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20E | Hickombottom, Shirley Keona Latrice | Former resident | $0.00 | $469.00 | $469.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20F | JACKSON, TRACI N | Former resident | $1,058.00 | $2,456.59 | $1,398.59 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20F | Thompson, Sanqueshae | Former resident | $455.00 | $2,867.00 | $2,412.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20F | Hartwell, AlfredFred | Former resident | $0.00 | $365.00 | $365.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 21A | Chatman, Keisha S | Former resident | $0.00 | $533.19 | $533.19 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 21A | Woodfork, Stephanie D | Former resident | $0.00 | $1,525.00 | $1,525.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 21A | JONES, ADAIJA | Former resident | $0.00 | $1.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 21A | WILLIAMS, VICKIE | Current resident | $0.00 | $1,132.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 21B | CAMPBELL, EBONI | Current resident | $5.00 | $172.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 22A | MILLER, CLAUDIA M | Former resident | $0.00 | $284.00 | $284.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 23A | MASON, ALICIAA | Former resident | $0.00 | $286.00 | $286.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 23A | Mackles, Ashley A | Former resident | $0.00 | $2,725.00 | $2,725.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 23A | Fleming, Wilneisha Jevonda | Current resident | $0.00 | $475.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 23A | JEFFERSON, ALEXIS ANDREAL | Former resident | $0.00 | $7.00 | $7.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 24A | MEARDAY, KYERA N | Former resident | $0.00 | $471.06 | $471.06 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 24B | SMITH, VALARIE D | Former resident | $0.00 | $5,812.00 | $5,812.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 24B | SCOTT, BRENIYA | Former resident | $0.00 | $387.00 | $387.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 25A | PERRY, CANDICE | Former resident | $50.00 | $1,644.00 | $1,594.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 25A | Green, Jessica Renae | Former resident | $1.00 | $2,048.00 | $2,047.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 25B | Pierre, Guerline | Former resident | $0.00 | $1.00 | $1.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 26A | Green, Roquanta Sh'Fawn | Former resident | $1.00 | $2,166.00 | $2,165.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 26B | HAMILTON, AMANDA | Former resident | $629.00 | $1,473.99 | $844.99 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 26B | DAVIS, BRANDY J | Former resident | $0.00 | $792.00 | $792.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 27A | BROWN, ALENA | Former resident | $0.00 | $528.00 | $528.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 27A | Jones, Crystal Danielle | Former resident | $0.00 | $149.00 | $149.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 27A | Holmes, Latoria L | Former resident | $0.00 | $52.00 | $52.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 27B | HUNT, TOSHA L | Former resident | $170.00 | $205.00 | $35.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 27B | Foster, Terri Lynn | Former resident | $0.00 | $39.00 | $39.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 01A | TOWNSEND, SHARON D | Current resident | $54.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 01B | KING, AUDREY | Current resident | $5.00 | $0.00 | $-5.00 | [ ] Confirm paid | — |
| 01C | FARMER, BRIANNA NICOLE | Current resident | $374.00 | $0.00 | $-2.00 | [ ] Confirm paid | — |
| 02A | SCOTT, MALEIJHANE | Former resident | $1,935.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 02B | White, Shannon | Current resident | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 02C | Anderson, Taneasha Lashell | Former resident | $655.00 | $351.00 | $-304.00 | [ ] Confirm paid | — |
| 02C | BARBER, MICHELLE | Current resident | $33.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 02E | BROADUS, MAKAILA | Former resident | $1.00 | $0.00 | $-1.00 | [ ] Confirm paid | — |
| 03A | HAYNES, LILA R | Current resident | $63.00 | $0.00 | $-5.00 | [ ] Confirm paid | — |
| 03B | DAVIS, CRYSTAL DANIELLE | Current resident | $143.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 03C | HAWKINS, ARRICKA ARNEISHA | Former resident | $1.00 | $0.00 | $-1.00 | [ ] Confirm paid | — |
| 03F | CREWS, TAMIKA D | Former resident | $507.00 | $38.00 | $-469.00 | [ ] Confirm paid | — |
| 04A | CARROLL, ALEXIS | Former resident | $1.00 | $0.00 | $-1.00 | [ ] Confirm paid | — |
| 04A | Queen, Keyshonda K | Former resident | $1.00 | $0.00 | $-1.00 | [ ] Confirm paid | — |
| 04C | SMITH, TYLON | Current resident | $20.00 | $0.00 | $-20.00 | [ ] Confirm paid | — |
| 04D | Brown, Shantasia Toneya | Current resident | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 05B | BOSTIC, ZELMA | Current resident | $403.00 | $205.00 | $0.00 | [ ] Confirm paid | — |
| 05D | Williams, Dorothy A | Former resident | $1.00 | $0.00 | $-1.00 | [ ] Confirm paid | — |
| 05D | BOSTIC, THELMA | Current resident | $17.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 05E | GLENN, AUDREYANA NICOLE | Current resident | $341.00 | $0.00 | $-19.00 | [ ] Confirm paid | — |
| 05F | WILLIAMS, DOROTHY A | Former resident | $1.00 | $0.00 | $-1.00 | [ ] Confirm paid | — |
| 06B | HARDY, THELMA | Current resident | $22.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 06F | Hunt, Yana Nictoria | Former resident | $1.00 | $0.00 | $-1.00 | [ ] Confirm paid | — |
| 06F | WHITE, TRAVIS | Current resident | $146.00 | $25.00 | $-17.00 | [ ] Confirm paid | — |
| 07A | THOMPSON, LATASHIA G | Former resident | $52.00 | $16.00 | $-36.00 | [ ] Confirm paid | — |
| 07B | HEARD, TIANA | Current resident | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 07C | BROWN, LAKISHA | Former resident | $227.00 | $0.00 | $-227.00 | [ ] Confirm paid | — |
| 07C | MCGRUDEN, ALLISON | Former resident | $1.00 | $0.00 | $-1.00 | [ ] Confirm paid | — |
| 07C | Bacon, Denyria | Former resident | $12.00 | $0.00 | $-12.00 | [ ] Confirm paid | — |
| 07E | TENNESSEE, SONYA | Former resident | $865.00 | $84.00 | $-781.00 | [ ] Confirm paid | — |
| 07E | Brown, Candi M | Former resident | $1.00 | $0.00 | $-1.00 | [ ] Confirm paid | — |
| 07F | Smith, KeMaria J | Former resident | $1.00 | $0.00 | $-1.00 | [ ] Confirm paid | — |
| 07F | SMITH, MARQUITA LASHAY | Current resident | $7.00 | $0.00 | $-7.00 | [ ] Confirm paid | — |
| 08B | BRIGANCE, CHRISTY | Former resident | $651.00 | $448.00 | $-203.00 | [ ] Confirm paid | — |
| 08C | Williams, Oliver Junior | Current resident | $18.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 08E | Holmes, Brionna S | Former resident | $1.00 | $0.00 | $-1.00 | [ ] Confirm paid | — |
| 08E | Jones, Debbie | Former resident | $2,015.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 08F | MARTIN, DEBRA M | Former resident | $129.00 | $0.00 | $-129.00 | [ ] Confirm paid | — |
| 08F | PERRY, SHAKEYRA | Current resident | $5.00 | $0.00 | $-5.00 | [ ] Confirm paid | — |
| 10A | JONES, CASSANDRA L | Former resident | $109.00 | $68.00 | $-41.00 | [ ] Confirm paid | — |
| 10C | BLAKLEY, RENEE H | Former resident | $465.00 | $183.00 | $-282.00 | [ ] Confirm paid | — |
| 10E | TOLBERT, LITUNTRAY SHUNETTE | Current resident | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 11B | Brown, Valencia Danielle | Former resident | $1.00 | $0.00 | $-1.00 | [ ] Confirm paid | — |
| 11C | TENNER, SHANDRA D | Former resident | $28.00 | $0.00 | $-28.00 | [ ] Confirm paid | — |
| 12A | FELTS, ANGELA | Current resident | $28.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 12F | PULLINS, HELEN DENISE | Current resident | $52.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 14A | Knight, SHEMEKA | Current resident | $618.99 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 14B | MCKNIGHT, SHAWN | Current resident | $36.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 14C | KNIGHT, CAROLYN | Current resident | $44.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 14D | BACON, SHAWANDA L | Former resident | $1,179.00 | $0.00 | $-1,179.00 | [ ] Confirm paid | — |
| 15A | JONES, RHONDA | Former resident | $1,797.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 15B | MILES, KEYIIRA | Current resident | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 15C | CHATMAN, JAHLESSIA D | Former resident | $475.00 | $150.00 | $-325.00 | [ ] Confirm paid | — |
| 15E | HUNT, YANA | Current resident | $5.00 | $0.00 | $-5.00 | [ ] Confirm paid | — |
| 16A | HUTCHINS, MORRISA V | Current resident | $36.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 16B | LEE, ASHLEY S | Current resident | $21.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 16C | JACKSON, BRYANNA | Former resident | $2,343.00 | $753.00 | $0.00 | [ ] Confirm paid | — |
| 17A | MINOR, MAMIE K | Current resident | $49.00 | $1.00 | $0.00 | [ ] Confirm paid | — |
| 17C | FRANCIS, VE'RANEC | Former resident | $1,648.00 | $89.00 | $-1,559.00 | [ ] Confirm paid | — |
| 17C | MINOR, TARA | Current resident | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 17D | SMITH, JALA PRISCILLA | Current resident | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 18A | DAVIS, LADONNA MARIA | Former resident | $868.00 | $0.00 | $-868.00 | [ ] Confirm paid | — |
| 18B | MOORE, TIERRA | Current resident | $253.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 18C | McGuire, Laverne | Current resident | $320.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 19C | Williams, Stella Y | Current resident | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 19D | WHITMORE, ROCHELLE | Former resident | $1,346.00 | $0.00 | $-1,346.00 | [ ] Confirm paid | — |
| 19D | TOLLIVER, GLADYS MARIE | Current resident | $360.00 | $122.00 | $0.00 | [ ] Confirm paid | — |
| 20A | COATES, MICHELLE K | Former resident | $101.00 | $0.00 | $-101.00 | [ ] Confirm paid | — |
| 20C | Knight, Daisy Bell | Current resident | $27.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 20E | WINDING, FELICIA | Former resident | $35.00 | $0.00 | $-35.00 | [ ] Confirm paid | — |
| 21A | DAWSON, FRANCES | Former resident | $49.00 | $0.00 | $-49.00 | [ ] Confirm paid | — |
| 22B | JONES, BRENELL | Current resident | $127.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 23A | JONES, AMELIA | Former resident | $396.00 | $0.00 | $-396.00 | [ ] Confirm paid | — |
| 24A | BRADLEY, JONQUILL BARNES | Current resident | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 25A | MILES, KYMNBERLY LASHUN | Current resident | $49.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 25B | PARKER, LATOYA K | Former resident | $23.00 | $9.90 | $-13.10 | [ ] Confirm paid | — |
| 26A | LEWIS, LAQUANDA | Former resident | $220.00 | $0.00 | $-220.00 | [ ] Confirm paid | — |
| 26A | DUNMORE, RICHARD | Current resident | $9.00 | $0.00 | $-3.00 | [ ] Confirm paid | — |
| 26B | DAVIS, ANGELICA RENA | Current resident | $219.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 27A | WILLIAMS, NICHELLE R | Current resident | $42.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| NONE | HAP common ledger | Misc. Income | $3,371.00 | $0.00 | $0.00 | [ ] Confirm paid | — |

## Resident Balance Follow-Up — Paid / Zero Balance

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 04A | Anderson, Shalonda Latrica | Former resident | $41.00 | $41.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 05B | Johnson, Malisha L | Former resident | $932.00 | $932.00 | $932.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 20C | HENRY, DIANE H | Former resident | $1,067.00 | $1,067.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property's supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*