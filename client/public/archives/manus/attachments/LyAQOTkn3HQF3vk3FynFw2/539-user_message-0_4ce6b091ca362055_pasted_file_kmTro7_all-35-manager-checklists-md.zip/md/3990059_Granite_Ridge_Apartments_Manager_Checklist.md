# Granite Ridge Apartments — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 3990059**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/04/2026 |
| Property manager | James Abeyta — james@apartmentcorp.com — (209) 688-3980 |
| Regional manager | Blake Weddington — blake@apartmentcorp.com — (310) 927-0020 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Delinquency spreadsheet | `3990059_Granite Ridge Apartments_Delinquent - Excel_58.xls` |
| Ledger accounts for review | 150 resident accounts |
| Residents with amount owed | 99 accounts; $141,288.55 |
| Prepaid / credit accounts | 49 accounts; $-14,183.45 |
| Availability entries | 5 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit's reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| 1-73 | 2B1B | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 4-32 | 1B1B | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 1-78 | 1B1B | NTV Not Leased | [ ] Verified | __________________ |
| 3-60 | 2B1B | NTV Not Leased | [ ] Verified | __________________ |
| 3-64 | 1B1B | NTV Not Leased | [ ] Verified | __________________ |

## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - 65 | Lahaie, Helen | Former resident | $0.00 | $0.50 | $0.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 65 | Osano, Eddie | Former resident | $0.00 | $78.00 | $78.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 65 | Robinson, Jacqueline Kay | Former resident | $13.00 | $532.00 | $519.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 65 | Andrade, Maria | Current resident | $0.00 | $44.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 66 | Hoskins, Timothy Lee | Former resident | $0.00 | $1,371.00 | $1,371.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 68 | Glover, Dwayne | Former resident | $0.00 | $1,745.00 | $1,745.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 70 | Gordo, Cassandra | Former resident | $0.00 | $6.00 | $6.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 70 | Meza, Maria Viridiana | Current resident | $0.00 | $1,067.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 71 | Harris, Patricia | Former resident | $0.00 | $310.00 | $310.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 71 | Demattei, Anthony | Former resident | $0.00 | $80.00 | $80.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 71 | Son, Chanmara | Former resident | $0.00 | $2,644.00 | $2,644.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 72 | Green, Danielle | Former resident | $0.00 | $139.00 | $139.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 72 | Avelino, Efrain | Former resident | $167.00 | $167.44 | $0.44 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 73 | Lopez, Ruth | Former resident | $0.00 | $2,266.00 | $2,266.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 74 | Loza, Noe | Former resident | $0.00 | $1,185.00 | $1,185.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 74 | Barakat, Ashadieeyah | Current resident | $0.00 | $1,592.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 75 | Burse, Monique | Former resident | $0.00 | $499.00 | $499.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 76 | Williams, larry | Former resident | $0.00 | $19.00 | $19.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 78 | Pham, Sally | Former resident | $0.00 | $157.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 80 | Johnson, Stephen | Former resident | $0.00 | $200.30 | $200.30 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 1 | Baker, Ronald Keith | Former resident | $0.00 | $28.00 | $28.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 10 | Graber, Sarah Danielle | Former resident | $101.00 | $1,231.00 | $1,130.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 10 | Dominguez, Tonya Rosemarie | Current resident | $0.00 | $45.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 11 | Khamsa, Andy | Former resident | $0.00 | $4,299.00 | $4,299.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 12 | Vaughn, Melissa | Former resident | $0.00 | $2,870.00 | $2,870.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 12 | Thayer, Tina L | Former resident | $0.00 | $699.00 | $699.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 12 | Graft, Annerica Patricia Rose | Former resident | $0.00 | $277.00 | $277.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 12 | Monserrat, Rosalie M | Current resident | $0.00 | $512.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 13 | Adams, Betty | Current resident | $0.00 | $461.65 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 14 | Britton, Mabel | Former resident | $0.00 | $4,454.00 | $4,454.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 14 | Thayer, Tina | Current resident | $0.00 | $50.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 16 | Cooper, Debbie | Former resident | $0.00 | $33.00 | $33.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 16 | Bottley, Grace | Former resident | $0.00 | $30.00 | $30.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 2 | Owens Jr, John | Former resident | $1.00 | $2,361.00 | $2,360.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 4 | Leary, Patricia | Former resident | $0.00 | $2,093.00 | $2,093.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 7 | Thayer, Heather | Current resident | $0.00 | $1,362.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 9 | Franklin, Paris | Former resident | $0.00 | $250.15 | $250.15 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 49 | Durham, Earl | Former resident | $0.00 | $683.00 | $683.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 49 | Avey, Jacqueline Kelly | Current resident | $0.00 | $91.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 50 | Fane, Faye | Former resident | $0.00 | $83.00 | $83.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 51 | Nguyen, Hong | Former resident | $20.00 | $127.00 | $107.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 51 | Harris, Alvin Rudolph | Current resident | $0.00 | $39.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 53 | Peoples, TaJon Samone | Former resident | $0.00 | $9,901.00 | $9,901.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 53 | Stevenson, Marguerite Lavenia | Former resident | $0.00 | $31.00 | $31.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 53 | Lancaster, Brian M | Former resident | $0.00 | $1,485.00 | $1,485.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 54 | Winn Jr, Samuel | Former resident | $0.00 | $1,319.00 | $1,319.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 55 | Huerta, Cherish | Former resident | $0.00 | $1,331.00 | $1,331.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 56 | Martinez, Anthony | Former resident | $0.00 | $3,182.00 | $3,182.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 56 | Gutierrez, Jessica Annalinda | Current resident | $0.00 | $49.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 57 | Magana, Maribel | Former resident | $0.00 | $13,885.00 | $13,885.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 58 | Naranjo, Viviana | Former resident | $0.00 | $100.00 | $100.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 60 | Robinson, Celena | NTV | $0.00 | $5,485.00 | $2,936.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 62 | Turbin, Lloyd | Former resident | $0.00 | $915.00 | $915.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 63 | Bui, Bong Thi | Former resident | $0.00 | $2,937.00 | $2,937.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 63 | Nguyen, Thanh | Former resident | $0.00 | $7,396.00 | $7,396.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 64 | Suggs, Oscar | NTV | $0.00 | $9,489.00 | $6,003.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 17 | Walker, Willie | Former resident | $0.00 | $601.00 | $601.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 17 | Thomas, Retha A | Former resident | $18.00 | $428.00 | $410.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 17 | Routt, Mark William | Former resident | $0.00 | $4,529.00 | $4,529.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 18 | Le, Thuyet | Former resident | $0.00 | $5.50 | $5.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 18 | Quintana, Mayra | Former resident | $0.00 | $6,069.00 | $6,069.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 18 | Cook, James | Current resident | $0.00 | $50.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 19 | Rosas, Debra | Current resident | $0.00 | $6.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 21 | Lewis, Patricia | Former resident | $0.00 | $912.00 | $912.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 23 | Ebhote, Delores | Former resident | $0.00 | $377.00 | $377.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 23 | Blood, Kristyn | Former resident | $0.00 | $1,079.00 | $1,079.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 23 | Bragg, Ukenia Unique | Former resident | $0.00 | $2,338.00 | $2,338.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 23 | Montez, Rebecca Ashley | Former resident | $0.00 | $69.00 | $69.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 25 | Chappell, Latonya | Former resident | $0.00 | $427.00 | $427.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 25 | Johnson, Stephen Marcel | Former resident | $0.00 | $7,487.00 | $7,487.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 25 | Noakolo, Renee | Former resident | $0.00 | $1,779.00 | $1,779.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 25 | Evans, Ebony Nichole | Current resident | $0.00 | $194.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 27 | Beisner, Eva | Former resident | $0.00 | $880.00 | $880.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 27 | Sison, Maria B | Former resident | $0.00 | $485.00 | $485.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 28 | Chester, Alicia | Former resident | $0.00 | $977.00 | $977.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 28 | Barlay, Lucy | Former resident | $0.00 | $261.00 | $261.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 28 | Olaso, Anthony Eugene | Former resident | $0.00 | $9,108.01 | $9,108.01 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 30 | Nguyen, Lam | Former resident | $0.00 | $2.00 | $2.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 32 | Walls, Karen | Former resident | $0.00 | $72.00 | $72.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 33 | McDonald, Darlene | Former resident | $0.00 | $548.00 | $548.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 34 | Ramirez, Beverly | Former resident | $0.00 | $436.00 | $436.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 39 | Lampley, Merilynn | Former resident | $0.00 | $462.00 | $462.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 39 | cathey, sabrina lorraine | Former resident | $0.00 | $26.00 | $26.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 39 | Vandyke, Brenda Lee | Former resident | $0.00 | $549.00 | $549.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 39 | Plancarte, Sara Lily | Current resident | $0.00 | $203.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 40 | Lathan, Thomas | Former resident | $0.00 | $22.00 | $22.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 40 | Ross, Ashley | Former resident | $0.00 | $14.00 | $14.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 41 | Hour, Savoeuth | Current resident | $0.00 | $963.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 42 | Robinson Jr, Richard | Former resident | $0.00 | $236.00 | $236.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 42 | Neri, Kristen L | Former resident | $0.00 | $722.00 | $722.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 42 | Bongcaron, Shari | Current resident | $0.00 | $50.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 43 | Foster, Lagretha | Former resident | $0.00 | $792.00 | $792.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 43 | Dansby, Mary | Former resident | $4.00 | $62.00 | $58.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 44 | Bahnmiller, Charles William | Former resident | $0.00 | $525.00 | $525.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 44 | Ojeda, Valentino A | Current resident | $0.00 | $62.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 45 | Gitthens, Jacobe | Former resident | $0.00 | $681.00 | $681.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 45 | Zanini, Dino Frank | Current resident | $0.00 | $496.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 47 | Richardson, Marcos Edwin | Former resident | $0.00 | $285.00 | $285.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 48 | Dewater, Helena | Former resident | $0.00 | $2,657.00 | $2,657.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - 66 | Ortiz, Berta Lila | Former resident | $131.00 | $0.00 | $-131.00 | [ ] Confirm paid | — |
| 1 - 67 | Williams, Brenda | Current resident | $5.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 72 | McKay, Mikalei Helena | Current resident | $39.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 75 | Wakefield, Kim | Current resident | $4,065.00 | $0.00 | $-246.00 | [ ] Confirm paid | — |
| 1 - 77 | Mai, Phung | Current resident | $6.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 79 | Golden, Chistopher | Current resident | $13.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 80 | Wilson, Tracy | Former resident | $79.00 | $0.00 | $-79.00 | [ ] Confirm paid | — |
| 1 - 80 | Griffin Jr, Richard Lee | Current resident | $78.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 1 | Brooks, Jerome Reginald | Current resident | $0.25 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 2 | Williams, Laverne Marie | Current resident | $55.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 3 | Sauter, Deborah | Current resident | $28.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 4 | Gooden, Joanne Rochelle | Current resident | $10.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 5 | Mainopaz, Ermele | Current resident | $15.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 6 | Lent, Rachael Marie | Current resident | $2,151.00 | $1,324.00 | $-2,151.00 | [ ] Confirm paid | — |
| 2 - 8 | Nickerson, Ella | Current resident | $2.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 9 | Ramsey, Tearesa Luvenia | Current resident | $2,414.00 | $1,242.00 | $-1,375.00 | [ ] Confirm paid | — |
| 3 - 50 | Moore, Telisa Lanette | Current resident | $205.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 52 | Enriquez, Celeste Renee | Current resident | $530.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 57 | Segura Ochoa, Maribel | Current resident | $117.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 59 | Roman, Kaori | Current resident | $169.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 62 | Williams, Lavon | Former resident | $154.00 | $0.00 | $-154.00 | [ ] Confirm paid | — |
| 3 - 62 | Hunt, Steven Eugene | Current resident | $32.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 63 | Nguyen, Mai | Current resident | $186.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - 17 | Mack, Debra Lynn | Current resident | $106.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - 18 | Cumbry, Nelson Junior | Former resident | $4.00 | $0.00 | $-4.00 | [ ] Confirm paid | — |
| 4 - 20 | Gaines, Snorah | Current resident | $50.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - 21 | Flores, Vanessa Irene | Current resident | $183.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - 22 | Nguyen, Thien | Current resident | $61.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - 23 | Macalisang, Remely | Former applicant | $800.00 | $0.00 | $-800.00 | [ ] Confirm paid | — |
| 4 - 23 | Lopez, Irene Marie | Current resident | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - 24 | Williams, Georgneshia | Current resident | $215.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - 26 | Smith, Oscar | Current resident | $5.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - 27 | Macaraeg, Rolando Abolencia | Current resident | $221.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - 28 | Johnny, Binta | Former resident | $730.00 | $0.00 | $-730.00 | [ ] Confirm paid | — |
| 4 - 28 | Spencer, Cynthia Lania | Current resident | $2,085.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - 29 | Marshall, Jeff | Current resident | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - 31 | Hunter, Pernell | Current resident | $203.00 | $0.00 | $-150.00 | [ ] Confirm paid | — |
| 5 - 33 | Rodriguez, Tammy Lynn | Current resident | $10.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 34 | Blount, Demetria deshawn | Current resident | $297.30 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 35 | Odom, Deborah | Current resident | $14.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 36 | Johnson, Jimmie | Current resident | $261.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 38 | Ingham, Sean | Current resident | $55.40 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 40 | Durham, Tonya Lee | Current resident | $95.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 41 | Pinnace, Alexandras | Former resident | $28.00 | $0.00 | $-28.00 | [ ] Confirm paid | — |
| 5 - 43 | Coleman, Elizabeth | Former resident | $175.00 | $0.00 | $-175.00 | [ ] Confirm paid | — |
| 5 - 45 | Whyte, Stephen | Former resident | $694.00 | $113.00 | $-581.00 | [ ] Confirm paid | — |
| 5 - 46 | Lo, Chong | Current resident | $24.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 47 | Villanueba, Yolanda May | Current resident | $49.50 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 48 | Sandoval, Steve | Current resident | $10.00 | $0.00 | $0.00 | [ ] Confirm paid | — |

## Resident Balance Follow-Up — Paid / Zero Balance

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - 66 | Hawthorne, Ludawn | Former resident | $100.00 | $100.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 39 | Bahnmiller, Charles | Former resident | $2,100.00 | $2,100.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property's supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*