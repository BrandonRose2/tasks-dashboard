# Pelican Bay — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 5313976**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/04/2026 |
| Property manager | Dequanta Sutherland — pelican@apartmentcorp.com — (504) 351-0597 |
| Regional manager | Ginger Positerry — ginger@apartmentcorp.com — (985) 637-2128 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Delinquency spreadsheet | `5313976_Pelican Bay_Delinquent - Excel_58.xls` |
| Ledger accounts for review | 251 resident accounts |
| Residents with amount owed | 221 accounts; $365,549.85 |
| Prepaid / credit accounts | 27 accounts; $-6,101.27 |
| Availability entries | 13 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit's reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| 1-106 | 2A | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 7-703 | 3A | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 11-1104 | 3A | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 11-1106 | 3A | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 12-1205 | 3A | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 12-1208 | 3A | Vacant Not Leased Not Ready | [ ] Verified | __________________ |
| 3-316 | 4B | NTV Not Leased | [ ] Verified | __________________ |
| 7-709 | 3A | NTV Not Leased | [ ] Verified | __________________ |
| 6-602 | 4A | Vacant Leased Not Ready | [ ] Verified | __________________ |
| 7-711 | 3A | Vacant Leased Not Ready | [ ] Verified | __________________ |
| 8-806 | 3A | Vacant Leased Not Ready | [ ] Verified | __________________ |
| 12-1202 | 3A | Vacant Leased Not Ready | [ ] Verified | __________________ |
| 14-1407 | 4A | Vacant Leased Not Ready | [ ] Verified | __________________ |

## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - 101 | Walker, Kewana | Former resident | $0.00 | $4,708.19 | $4,708.19 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 101 | Hawkins, Shalonda | Current resident | $0.00 | $161.58 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 102 | Moore, Debbie | Former resident | $0.00 | $1,523.63 | $1,523.63 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 102 | Christian, Francis | Former resident | $1,465.97 | $1,473.10 | $987.03 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 104 | WILLIAMS, GLORIA | Former resident | $0.00 | $450.00 | $450.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 104 | Harris, Kir'Deja | Former resident | $0.00 | $1,317.38 | $1,317.38 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 104 | Knight, Willard | Current resident | $0.00 | $60.00 | $24.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 106 | Porter, Erica | Former resident | $0.00 | $1,540.00 | $1,540.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 106 | Williams, Lashanta | Former resident | $0.00 | $1,781.19 | $1,781.19 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 106 | Johnson, Dondrika J | Former resident | $0.00 | $135.61 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 109 | Robinson, Demitrius | Former resident | $233.00 | $1,412.32 | $1,179.32 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 109 | Pittman, Antorne | Current resident | $0.00 | $512.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 110 | Miller, Sabrika | Former resident | $0.00 | $3,521.16 | $3,521.16 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 110 | Pointer, Rhesa | Current resident | $0.00 | $1,010.00 | $24.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 111 | Durand, Daisy | Former resident | $0.00 | $1,043.61 | $1,043.61 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 111 | Harbor, Julia | Current resident | $0.00 | $1,151.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 112 | Richardson, Patrice Y | Former resident | $0.00 | $2,104.00 | $2,104.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 1 - 112 | Bess, JamalT | Current resident | $0.00 | $1,151.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1001 | Jackson, Deloris D | Former resident | $0.00 | $935.00 | $935.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1001 | Barrow, Stephanie | Former resident | $0.00 | $1,840.00 | $1,840.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1001 | Mouton, Shaquila | Former resident | $0.00 | $2,808.97 | $1,687.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1002 | Haynes, Alicia | Former resident | $0.00 | $1,375.00 | $1,375.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1002 | Simpson, Ashley | Former resident | $0.00 | $1,723.20 | $1,723.20 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1002 | Williams, Mikayla | Former resident | $0.00 | $132.30 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1002 | Brown, Sharlissa | Current resident | $0.00 | $200.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1003 | Johnson, Brandi M | Former resident | $0.00 | $1,665.00 | $1,665.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1004 | Wilson, Laquinn | Former resident | $0.00 | $1,416.07 | $1,416.07 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1004 | Stewart, Sabrina | Current resident | $0.00 | $34.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1005 | Davis, Joseph | Former resident | $0.00 | $1,747.94 | $1,747.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1007 | Wilson, James | Former resident | $0.00 | $1,364.29 | $1,364.29 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1007 | Bland, Deiondra Daltrese | Former resident | $0.00 | $2,416.70 | $2,416.70 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1007 | Doyle, Shelita | Former resident | $0.00 | $974.00 | $974.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1007 | Wilson, Rebecca | Current resident | $0.00 | $24.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1007 | White, Oscar | Former resident | $0.00 | $2,234.77 | $2,234.77 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1008 | Stokes, Aliyah | Current resident | $0.00 | $986.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1008 | Treadwell, Arneda | Former resident | $0.00 | $80.40 | $80.40 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1008 | Archangel, Venus | Former resident | $0.00 | $3,298.00 | $3,298.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1009 | Kirby, Taylor | Former resident | $0.00 | $1,724.52 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1010 | Mayfield, Kyranetria Nashay | Former resident | $0.00 | $3,070.32 | $3,070.32 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1010 | Parker, Sharlissa | Current resident | $0.00 | $1,151.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1012 | Woods, Rae | Former resident | $0.00 | $2,818.68 | $2,818.68 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 10 - 1012 | Guillard, Lakiesha | Current resident | $0.00 | $503.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1101 | Smith, Christopher Ramone | Former resident | $0.00 | $1,950.55 | $1,950.55 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1101 | Harris, Charnissa | Former resident | $0.00 | $3,190.19 | $3,190.19 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1101 | Stewart, KeltonD | Current resident | $0.00 | $1,572.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1102 | Fields, Theresa | Current resident | $0.00 | $96.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1104 | Mullins, Joydellal | Former resident | $0.00 | $2,768.00 | $2,768.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1104 | Carrion, Karla | Former resident | $0.00 | $1,439.09 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1105 | Jackson, Rodneasya D | Former resident | $0.00 | $1,723.78 | $1,723.78 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1105 | White, William E | Former resident | $0.00 | $4,865.94 | $4,865.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1105 | Lynute, Tysheria | Current resident | $0.00 | $1,307.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1106 | Clark, Charles | Former resident | $0.00 | $3,790.19 | $3,790.19 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1106 | *Walton, Jayla | Former resident | $0.00 | $3,199.62 | $3,199.62 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1107 | Guss, Adrian | Current resident | $0.00 | $100.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1108 | Thomas, Lawanda | Former resident | $0.00 | $3,196.00 | $3,196.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1108 | Hausey, Annie | Former resident | $0.00 | $2,385.60 | $2,385.60 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 11 - 1108 | Jarvis, Jasmine | Former resident | $0.00 | $1,955.18 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1201 | Thomas, Jamel D | Former resident | $0.00 | $5,557.48 | $5,557.48 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1201 | Knox, Shandra | Former resident | $0.00 | $3,707.21 | $3,707.21 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1201 | Cushingberry, Amandac | Current resident | $0.00 | $1,411.86 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1202 | *McCray, Lenard | Former resident | $0.00 | $3,510.65 | $1,306.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1203 | Slaine, Belta Sterling | Former resident | $0.00 | $2,643.61 | $2,643.61 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1204 | Judson, Shavonne | Former resident | $0.00 | $1,837.94 | $1,837.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1204 | Bell, Dana | Current resident | $0.00 | $1,604.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1205 | Johnson, Tracy | Former resident | $0.00 | $1,167.42 | $1,167.42 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1205 | *Lang, Terry | Former resident | $0.00 | $1,588.97 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1206 | Locure, DawannaM | Current resident | $543.00 | $1,929.03 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1207 | Davis, Michael | Current resident | $0.00 | $76.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1207 | Nevis, Shenna | Former resident | $0.00 | $4,325.60 | $4,325.60 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1207 | Allen, Stella | Former resident | $0.00 | $2,200.55 | $2,200.55 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 12 - 1208 | Moore, Kelli | Former resident | $0.00 | $497.16 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1301 | Coleman, Carl C | Current resident | $0.00 | $886.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1304 | Cummings, Kim | Former resident | $0.00 | $495.33 | $395.33 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1305 | Braud, Michael | Current resident | $0.00 | $10.86 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1306 | Jarvis, Roxanne | Former resident | $0.00 | $1,333.87 | $1,333.87 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1306 | White, Jamario | Former resident | $0.00 | $1,290.65 | $1,290.65 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1307 | Forcell, Brittney | Former resident | $0.00 | $77.10 | $77.10 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 13 - 1307 | Phillips, Tykeia | Former resident | $0.00 | $2,809.00 | $2,809.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1401 | Chews, Dewayne A | Former resident | $0.00 | $1,187.06 | $1,187.06 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1402 | Slaine, Shilyn M | Former resident | $0.00 | $1,468.67 | $1,468.67 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1402 | Hart, Monique | Former resident | $0.00 | $3,099.68 | $3,099.68 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1403 | Givens, Salimah | Former resident | $0.00 | $5,128.98 | $5,128.98 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1403 | Spurlock, Marcus | Current resident | $0.00 | $122.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1404 | Winborne, Dewayne | Former resident | $0.00 | $1,427.93 | $1,427.93 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1404 | Payton, Bryce | Former resident | $0.00 | $850.33 | $500.33 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1405 | Ware, Janette | Current resident | $0.00 | $11.61 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1406 | Ely, Breanna A | Former resident | $0.00 | $3,256.65 | $3,256.65 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1407 | Mills, Siobhan | Former resident | $0.00 | $6,195.35 | $6,195.35 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1407 | Fleming, AntoinetteM | Former resident | $0.00 | $702.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1408 | LeBlanc, Lakisha | Former resident | $0.00 | $1,958.00 | $1,958.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1408 | Joseph, Nakia | Current resident | $0.00 | $172.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1409 | Beasley, Mickala Charelle | Former resident | $0.00 | $2,014.84 | $2,014.84 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1409 | Devezin, Courtney | Former resident | $0.00 | $3,555.53 | $3,555.53 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1409 | Gray, Tyra | Former resident | $0.00 | $1,907.71 | $1,907.71 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1410 | Vaughn, Karen | Former resident | $0.00 | $1,505.32 | $1,505.32 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1411 | Howard, Kevin | Current resident | $0.00 | $12.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1412 | DOUGLASS, NICOLE | Former resident | $0.00 | $1,726.61 | $1,726.61 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1412 | Bell, Lequesha | Former resident | $0.00 | $1,550.09 | $1,550.09 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 14 - 1412 | Bryant, Gloria. | Current resident | $0.00 | $1,027.57 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 202 | Crockett, Kim Evette | Current resident | $0.00 | $13.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 205 | Williams, Sharniece | Former resident | $0.00 | $2,116.00 | $2,116.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 205 | Preston, Teresa L | Current resident | $0.00 | $1,186.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 206 | Taylor, Charisma | Former resident | $0.00 | $1,050.00 | $1,050.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 206 | Anderson, Aaliyah | Current resident | $0.00 | $5.45 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 207 | Carter, Jennifer Nicole | Former resident | $0.00 | $435.50 | $435.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 207 | Myles, Jon'Trail | Former resident | $0.00 | $3,659.87 | $3,659.87 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 207 | Brown, Sabrian | Former resident | $0.00 | $2,558.53 | $2,558.53 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 207 | Reams, TalishaM | Current resident | $0.00 | $1,040.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 208 | Riley, David | Former resident | $0.00 | $1,913.43 | $1,913.43 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 208 | Sampson, Maude | Former resident | $0.00 | $1,441.14 | $1,441.14 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 209 | Parker, Shemar | Former resident | $0.00 | $3,099.07 | $3,099.07 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 301 | Searcy, Sheqwana | Current resident | $0.00 | $951.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 302 | Smothers, Vishante | Former resident | $0.00 | $1,801.19 | $1,801.19 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 302 | Curtis, Shanetria | Current resident | $0.00 | $1,433.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 304 | Wilson, Lakeidria D | Former resident | $0.00 | $1,100.00 | $1,100.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 304 | Lynute, Latara | Former resident | $32.00 | $1,881.74 | $1,849.74 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 304 | Gray, Nija | Former resident | $0.00 | $108.32 | $108.32 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 304 | *Tumblin, Kenkari | Former resident | $0.00 | $1,327.19 | $1,327.19 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 304 | Byrd, Tyre'yona | Current resident | $0.00 | $1,255.58 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 305 | Payton, Valerie | Former resident | $0.00 | $7,648.55 | $7,648.55 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 305 | Douglas, Wynona | Current resident | $0.00 | $1,139.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 307 | Everson, Seleaka | Current resident | $0.00 | $1,433.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 308 | Pleasant, Dekisha | Former resident | $0.00 | $1,003.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 311 | Gibson, Linda D | Current resident | $0.00 | $9.86 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 312 | Winters, Tiara Nicole | Former resident | $0.00 | $1,583.50 | $1,583.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 312 | Onu, Ihouma | Former resident | $0.00 | $1,759.93 | $1,759.93 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 312 | Clarke, Jalaycia | Former resident | $0.00 | $1,312.52 | $1,312.52 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 312 | Douglas, Brandon | Current resident | $0.00 | $1,151.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 314 | Baye, Mary | Former resident | $0.00 | $634.00 | $634.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 315 | Richardson, Flora M | Current resident | $0.00 | $12.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 316 | Bird, Angela | Former resident | $0.00 | $610.64 | $610.64 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 3 - 316 | Isaac, Francesca | NTV | $0.00 | $591.90 | $555.90 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 401 | James, Sherina Angelina | Former resident | $0.00 | $250.00 | $250.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 402 | Richardson, Larry | Former resident | $0.00 | $20.57 | $20.57 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 402 | Montgomery, Jobori | Former resident | $0.00 | $34.63 | $34.63 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 406 | Perkins, Laurice L | Former resident | $0.00 | $33.52 | $33.52 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 406 | Johnson, Susan | Former resident | $0.00 | $1,635.71 | $1,635.71 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 406 | Eastwood, Jennifer | Current resident | $0.00 | $12.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 407 | Davis, Cierra | Former resident | $0.00 | $75.00 | $75.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 408 | Luke, Patricia Ann | Former resident | $0.00 | $326.61 | $326.61 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 408 | Watson, Phylicia | Former resident | $0.00 | $1,128.58 | $1,128.58 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 408 | Williams, Theresa | Current resident | $0.00 | $1,159.43 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 408 | *Smith, Krystle | Former resident | $0.00 | $2,292.06 | $2,292.06 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 409 | Reams, Myisha | Former resident | $0.00 | $3,575.73 | $2,826.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 410 | Curtis, Erica T | Current resident | $0.00 | $986.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 411 | Preston, Gregory | Former resident | $0.00 | $1,091.39 | $1,091.39 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 4 - 411 | Williams, Carlos | Former resident | $0.00 | $2,650.30 | $2,650.30 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 501 | Veal, Nora | Current resident | $0.00 | $12.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 503 | Givens, Shanette N | Current resident | $0.00 | $25.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 504 | Moore, Joycelyn | Current resident | $0.00 | $12.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 505 | Cyres, Briironna | Former resident | $0.00 | $2,042.00 | $2,042.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 506 | Latoya Pickett | Former resident | $0.00 | $295.20 | $295.20 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 506 | *Fletcher, Jessica | Former resident | $0.00 | $1,786.48 | $1,786.48 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 506 | Bell, Tatyana | Former resident | $0.00 | $1,883.10 | $1,883.10 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 507 | Green, Remonica | Former resident | $0.00 | $3,247.68 | $3,247.68 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 507 | Hebert, Kenywatta | Current resident | $0.00 | $479.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 508 | Kimble, Shirley M | Former resident | $0.00 | $20.66 | $20.66 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 509 | Hunter, DestineeSequoa | Former resident | $0.00 | $2,395.60 | $2,395.60 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 509 | Alexander, Chandricka N | Former resident | $0.00 | $2,188.82 | $2,188.82 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 509 | Jolla, Sha'Tijah | Former resident | $0.00 | $3,227.42 | $3,227.42 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 509 | Manuel, Lionel | Current resident | $0.00 | $81.86 | $45.86 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 510 | Knight, Passion | Former resident | $0.00 | $4,743.94 | $4,743.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 511 | Boulanger, St Theresa | Former resident | $0.00 | $503.62 | $503.62 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 511 | Mack, Bobby | Current resident | $0.00 | $546.73 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 5 - 512 | Mumphrey, Margaret | Current resident | $0.00 | $60.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 601 | Thomas, Maynard | Former resident | $0.00 | $2,433.33 | $2,433.33 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 601 | Chiszle, Anna | Former resident | $0.00 | $4,114.33 | $4,114.33 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 602 | Abram, Natasha | Former resident | $0.00 | $3,618.71 | $3,618.71 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 602 | Butler, Sandrena | Former resident | $0.00 | $444.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 603 | Washington, Tonya | Current resident | $0.00 | $1,565.86 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 605 | Jones, Sholanda | Current resident | $0.00 | $24.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 606 | Follins, Shermaine | Former resident | $0.00 | $1,425.52 | $1,425.52 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 607 | Holmes, De'Nyha L | Former resident | $0.00 | $5,671.54 | $5,671.54 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 607 | Cossett, Michelle | Former resident | $0.00 | $4,845.80 | $4,845.80 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 607 | Adkins, Kia | Former resident | $0.00 | $7,342.00 | $7,342.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 607 | Stewart, Brittany | Current resident | $0.00 | $1,333.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 6 - 608 | Holmes, Marcia | Former resident | $0.00 | $4,563.00 | $4,563.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 702 | Jackson, Keith L | Current resident | $0.00 | $1,306.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 703 | Thompkins, Tillman | Former resident | $0.00 | $5,112.87 | $5,112.87 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 703 | Jackson, Ralph | Former resident | $0.00 | $644.65 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 704 | Conner, Brittany | Former resident | $0.00 | $8,861.77 | $8,861.77 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 704 | Stewart, Tyshun | Current resident | $0.00 | $1,355.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 705 | Gilmore, Akeitha | Former resident | $0.00 | $3,527.11 | $3,527.11 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 705 | Conrad, Angelica | Current resident | $0.00 | $84.00 | $48.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 706 | Devezin, Shaundreika | Former resident | $0.00 | $1,773.33 | $1,773.33 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 706 | Edwards, Crystal | Former resident | $0.00 | $3,454.00 | $3,454.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 708 | Harris, Lisa | Current resident | $0.00 | $12.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 709 | Williams, Cynthia | NTV | $0.00 | $12.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 709 | Green, Courtney T | Former resident | $0.00 | $100.00 | $100.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 711 | Smith, Shandria L | Former resident | $0.00 | $2,272.61 | $2,272.61 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 711 | *Brooks, Tamyra | Former resident | $0.00 | $1,865.02 | $1,865.02 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 712 | Givens, Joanie | Current resident | $0.00 | $12.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 7 - 712 | Greely, Kate | Former resident | $0.00 | $730.81 | $730.81 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 801 | Foster, Valencia M | Former resident | $0.00 | $1,461.29 | $1,461.29 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 801 | Flenoid, Louis | Former resident | $0.00 | $150.00 | $150.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 802 | Hogan, Kenneth | Former resident | $0.00 | $364.44 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 802 | Moses, Larry D | Former resident | $0.00 | $2,052.60 | $2,052.60 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 803 | Gray, Nealester | Current resident | $0.00 | $24.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 805 | Franklin, Terreka L | Former resident | $0.00 | $2,532.35 | $2,532.35 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 806 | Carter, Erica L | Former resident | $0.00 | $2,289.81 | $2,289.81 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 806 | Stampley, Sheila | Former resident | $0.00 | $1,463.00 | $1,463.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 806 | Oliney, AlariousDavon | Former resident | $0.00 | $3,209.61 | $2,587.01 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 807 | Sparrow, Debra | Current resident | $0.00 | $46.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 808 | Williams, Keyonna | Former resident | $0.00 | $4,100.29 | $4,100.29 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 808 | Jones, Dessalynn | Current resident | $0.00 | $986.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 904 | Green, Charlotte | Former resident | $0.00 | $719.84 | $719.84 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 904 | Morgan, Rocquel | Former resident | $0.00 | $503.22 | $503.22 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 904 | Davis, Katarra | Current resident | $0.00 | $1,306.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 905 | Rowe, Lartika K | Current resident | $0.00 | $613.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 907 | Billie, Madeline | Former resident | $0.00 | $949.60 | $949.60 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 907 | Lloyd, Imari | Current resident | $0.00 | $1,306.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 908 | Ware, Janette J | Former resident | $0.00 | $430.00 | $430.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 909 | Washington, Kurstin | Former resident | $0.00 | $1,584.17 | $1,584.17 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 909 | Gaines, D'Andray | Former resident | $0.00 | $3,769.45 | $3,769.45 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 909 | Jackson, Katoya | Former resident | $0.00 | $3,430.51 | $3,430.51 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 909 | Jackson, NormaD | Current resident | $0.00 | $512.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 911 | Scott, Charles | Former resident | $0.00 | $2,727.61 | $2,727.61 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 911 | Clark, Frances | Former resident | $0.00 | $2,190.00 | $2,190.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 912 | Taylor, Kenyodia | Former resident | $0.00 | $1,737.93 | $1,737.93 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 9 - 912 | Bell, Jader | Current resident | $0.00 | $1,306.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| WAIT | Fielding, Janae | Applicant | $0.00 | $509.00 | $509.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 1 - 103 | Hill, Patricia | Current resident | $2.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 108 | Frazier, Shirley | Current resident | $56.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 1 - 109 | Wilson, Rhonda | Former resident | $950.00 | $102.12 | $-847.88 | [ ] Confirm paid | — |
| 10 - 1005 | Armstrong, William. | Current resident | $47.14 | $0.00 | $-47.14 | [ ] Confirm paid | — |
| 12 - 1202 | Mitchell, Lakecha | Applicant | $600.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 13 - 1303 | Rowe, AprilLynn | Current resident | $4.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 14 - 1404 | Wagner, Latonya | Current resident | $2.26 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 14 - 1405 | Foret, Michelle | Former resident | $2,733.39 | $2,501.31 | $2,188.92 | [ ] Confirm paid | — |
| 14 - 1409 | Carey, Antoinette | Current resident | $329.32 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 14 - 1410 | Cardona, BritneyL | Current resident | $403.14 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 201 | Allen, Arthur | Current resident | $18.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 2 - 207 | Toquasha Ratcliff | Former resident | $175.00 | $0.00 | $-175.00 | [ ] Confirm paid | — |
| 2 - 212 | Chenier, Viola | Current resident | $9.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 308 | Jones, LAkeisha | Current resident | $41.84 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 3 - 310 | Williams, Diedra | Former resident | $586.55 | $241.55 | $-345.00 | [ ] Confirm paid | — |
| 3 - 314 | Smith, Debra | Current resident | $70.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - 402 | Weatherspoon, Lisa | Current resident | $0.99 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - 407 | Williams, Ruby | Current resident | $0.14 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 4 - 409 | Green, Rojeanique | Current resident | $600.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 5 - 508 | Goss, Lakida | Current resident | $2.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 6 - 602 | Dalcourt, Amber | Applicant | $600.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 6 - 604 | Ciyanne Chiszele; Anna Chiszle | Former resident | $1,059.00 | $0.00 | $-1,059.00 | [ ] Confirm paid | — |
| 8 - 801 | Pennywell, Ryan | Current resident | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 8 - 805 | Davis, Laquita | Former resident | $4.48 | $0.00 | $-4.48 | [ ] Confirm paid | — |
| 8 - 806 | Selvage, Derrick | Applicant | $600.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 9 - 906 | Tookes, Samantha L | Current resident | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| WAIT | Robinson, Markeitha | Applicant | $50.00 | $0.00 | $-50.00 | [ ] Confirm paid | — |

## Resident Balance Follow-Up — Paid / Zero Balance

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 14 - 1401 | Scott, ErnestW. | Current resident | $10.00 | $10.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 2 - 203 | Dore, Katherine | Current resident | $12.00 | $12.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8 - 802 | Mason, LaQuandria. | Current resident | $50.00 | $50.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property's supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*