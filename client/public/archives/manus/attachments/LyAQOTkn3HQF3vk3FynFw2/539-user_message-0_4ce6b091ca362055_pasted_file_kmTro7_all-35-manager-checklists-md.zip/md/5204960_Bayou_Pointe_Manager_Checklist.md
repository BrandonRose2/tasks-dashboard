# Bayou Pointe — Manager Delinquency & Availability Checklist

> **Confidential manager working document.** This checklist cross-references the delinquency ledger and Availability report provided for **Property ID 5204960**. Update the checkboxes and notes during or immediately after the manager call.

| Call details | Manager update |
|---|---|
| Availability report as of | 08/04/2026 |
| Property manager | Jennifer Frederick — bayou@apartmentcorp.com — (318) 440-6712 |
| Regional manager | Ginger Positerry — ginger@apartmentcorp.com — (985) 637-2128 |
| Manager contacted | [ ] Yes  [ ] Voicemail  [ ] Follow-up required |
| Call date / time | ______________________________ |
| Next commitment date | ______________________________ |

## Source Cross-Reference

| Source / validation | Result |
|---|---|
| Delinquency spreadsheet | `5204960_Bayou Pointe_Delinquent - Excel_58.xls` |
| Ledger accounts for review | 98 resident accounts |
| Residents with amount owed | 80 accounts; $104,942.40 |
| Prepaid / credit accounts | 18 accounts; $-9,948.18 |
| Availability entries | 6 unit-status entries |

## Availability Follow-Up

- [ ] Confirm each listed unit's reported status remains accurate today.
- [ ] Confirm ready / not-ready condition, make-ready scope, and target availability date.
- [ ] Confirm leasing, prelease, or move-in commitment where applicable.
- [ ] Escalate any vacancy or non-revenue status lacking a committed action and date.

| Unit | Floor plan | Reported status | Manager verification | Follow-up / target date |
|---|---|---|---|---|
| 8139-8139 | office | Vacant Not Leased Ready | [ ] Verified | __________________ |
| 722-722 | 3 | NTV Not Leased | [ ] Verified | __________________ |
| 754-754 | 3 | NTV Leased | [ ] Verified | __________________ |
| 758-758 | 3 | Vacant Leased Not Ready | [ ] Verified | __________________ |
| 8038-8038 | 3 | Vacant Leased Not Ready | [ ] Verified | __________________ |
| 8042-8042 | 4 | Vacant Leased Not Ready | [ ] Verified | __________________ |

## Resident Balance Follow-Up — Amount Owed

> **Priority:** Confirm contact, payment status, payment arrangement, and escalation needs for every account with a positive current net balance.

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 714 - 714 | Kellum, Shatori | Former resident | $0.00 | $1,859.00 | $1,859.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 714 - 714 | Allen, Brittney L | Former resident | $0.00 | $1,162.00 | $1,162.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 714 - 714 | Gilbert, Marshavia | Former resident | $0.00 | $6,919.50 | $3,520.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 714 - 714 | Caldwell, Chiro | Current resident | $0.00 | $1,210.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 715 - 715 | O'neal, Otis | Former resident | $0.00 | $289.42 | $289.42 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 715 - 715 | Freeman, Shadell, | Former resident | $0.00 | $372.13 | $372.13 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 715 - 715 | Kelly, Sierra | Former resident | $0.00 | $2,140.94 | $2,140.94 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 715 - 715 | O'Neal, Crystal | Current resident | $0.00 | $1,140.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 719 - 719 | Johnson, Shawanda | Former resident | $0.00 | $1,365.55 | $1,365.55 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 719 - 719 | Hayes, Kimberly | Current resident | $0.00 | $1,238.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 722 - 722 | Clark, Jabronica | Former resident | $0.00 | $1,307.73 | $1,307.73 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 722 - 722 | Blagley, Moesha | NTV | $0.00 | $97.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 723 - 723 | Hinton, Lucretia | Former resident | $0.00 | $1,478.00 | $1,478.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 723 - 723 | McKinney, Megan Octavious | Current resident | $122.00 | $1,669.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 726 - 726 | Starks, Sonya | Former resident | $0.00 | $739.00 | $739.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 727 - 727 | Richardson, Alicia | Former resident | $0.00 | $542.84 | $542.84 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 727 - 727 | Stepens, Zournesha | Current resident | $0.00 | $1,326.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 727 - 727 | Lanne, Valerie Ann | Former resident | $0.00 | $490.35 | $490.35 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 730 - 730 | Mingo, Monte D | Current resident | $0.00 | $1,576.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 734 - 734 | Cooksey, Tomika | Current resident | $0.00 | $1,140.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 738 - 738 | Johnson, Srada | Former resident | $0.00 | $113.19 | $113.19 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 738 - 738 | Mester, Gwendolyn Yvette | Current resident | $0.00 | $269.68 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 742 - 742 | Freeman, Sandra | Former resident | $0.00 | $272.00 | $272.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 742 - 742 | Price, Dyniqua | Current resident | $0.00 | $740.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 750 - 750 | Johnson, Camron D | Former resident | $1,066.29 | $2,207.87 | $1,141.58 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 750 - 750 | Jackson, Cassandra P | Current resident | $0.00 | $1,215.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 754 - 754 | Carey, Shelonda | NTV | $0.00 | $1,140.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 758 - 758 | *Lewis, Mashonda | Former resident | $0.00 | $3,107.11 | $1,038.50 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 762 - 762 | Smith, Gabrielle | Former resident | $0.00 | $142.00 | $142.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 762 - 762 | Giff Jr, Willie | Current resident | $0.00 | $1,140.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 766 - 766 | Lockett, Kari | Current resident | $0.00 | $1,140.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 767 - 767 | Como, Courtney | Former resident | $0.00 | $478.19 | $478.19 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 767 - 767 | Haywood, Brandyse s | Current resident | $0.00 | $140.93 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 770 - 770 | Covington, Zatoria | Current resident | $0.00 | $239.00 | $128.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 777 - 777 | Jones, Tanyell | Former resident | $0.00 | $1,979.60 | $1,979.60 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 777 - 777 | Anderson, Demarcus R | Current resident | $0.00 | $1,239.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8001 - 8001 | Johnson, Andrea | Current resident | $0.00 | $12.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8005 - 8005 | Atkins, Veronica | Current resident | $0.00 | $1,140.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8006 - 8006 | James, Lashunda | Current resident | $0.00 | $1,575.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8009 - 8009 | Brown, Grady | Former resident | $0.00 | $182.13 | $182.13 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8010 - 8010 | Myles, Angela | Current resident | $0.00 | $1,140.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8013 - 8013 | Simpson, Breanca | Former resident | $0.00 | $1,064.00 | $1,064.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8017 - 8017 | Gray, Kalaseay S | Former resident | $0.00 | $627.77 | $627.77 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8017 - 8017 | McBride, Kaitlin N | Current resident | $0.00 | $1,048.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8018 - 8018 | Mccoy, Lasambreon | Former resident | $0.00 | $385.00 | $385.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8018 - 8018 | Davis, DorothyJ | Current resident | $0.00 | $1,048.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8021 - 8021 | Gant, Sonya | Former resident | $0.00 | $148.65 | $148.65 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8021 - 8021 | White, Kori Sherrell | Former resident | $224.00 | $1,020.55 | $796.55 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8022 - 8022 | Baker, Quennsha | Current resident | $0.00 | $148.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8025 - 8025 | Williams, Tamika | Former resident | $0.00 | $2,008.00 | $2,008.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8025 - 8025 | Caldwell, Timberly T | Current resident | $0.00 | $75.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8026 - 8026 | Debose, Katyetta | Former resident | $110.71 | $3,598.35 | $3,487.64 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8026 - 8026 | Simpson, Breanca N | Current resident | $0.00 | $1,137.60 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8030 - 8030 | Allen, Paulette | Former resident | $0.00 | $660.00 | $660.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8030 - 8030 | Washington, Shaterrica | Current resident | $0.00 | $1,468.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8033 - 8033 | Taylor, Toshiba | Current resident | $0.00 | $1,140.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8034 - 8034 | Harris, Alice | Former resident | $0.00 | $2,982.00 | $2,982.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8034 - 8034 | Coleman, Sha'Dyamond K | Current resident | $0.00 | $1,048.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8037 - 8037 | Hughes, Erika | Former resident | $0.00 | $2,276.22 | $2,276.22 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8038 - 8038 | Anderson, Christine L | Former resident | $0.00 | $5,998.78 | $5,998.78 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8038 - 8038 | *Goff, Shakavious E | Former resident | $0.00 | $2,769.71 | $375.26 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8041 - 8041 | Hunter, Rose | Current resident | $0.00 | $99.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8042 - 8042 | *Ford, Lagina | Former resident | $0.00 | $3,530.38 | $1,071.25 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8045 - 8045 | Fisher, Jasmine | Former resident | $0.00 | $343.00 | $343.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8045 - 8045 | Moore, Keteara N | Former resident | $0.00 | $3,251.39 | $3,251.39 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8103 - 8103 | Guillory, Amanda | Former resident | $38.13 | $1,020.80 | $982.67 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8104 - 8104 | White, Kori | Former resident | $0.00 | $1,600.00 | $1,600.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8107 - 8107 | James, Robbin | Current resident | $0.00 | $160.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8108 - 8108 | Nash, Willie Pearl | Former resident | $0.00 | $1,340.16 | $1,340.16 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8111 - 8111 | Reed, Elizabeth | Former resident | $0.00 | $2,510.63 | $2,510.63 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8115 - 8115 | Bryant, Cordie | Current resident | $118.45 | $595.00 | $-118.45 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8116 - 8116 | Taylor, Meschelle | Current resident | $0.00 | $1,239.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8119 - 8119 | Pason, Cheyenne | Former resident | $0.00 | $932.00 | $932.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8119 - 8119 | Washington, DevinLamario | Current resident | $0.00 | $570.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8127 - 8127 | Taylor, Dorothy | Former resident | $0.00 | $589.00 | $589.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8127 - 8127 | Evans, Ninya Sacardro | Former resident | $0.00 | $4,207.27 | $4,207.27 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8127 - 8127 | Marshall, Kristina M | Current resident | $0.00 | $2,500.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8131 - 8131 | Ray, Anjelique | Former resident | $0.00 | $1,429.00 | $1,429.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8131 - 8131 | Thomas, Latia S | Current resident | $0.00 | $1,139.56 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |
| 8135 - 8135 | Daniels, Brittany | Current resident | $0.00 | $1,239.00 | $0.00 | [ ] Contacted  [ ] Arrangement  [ ] Escalate | — |

## Resident Balance Follow-Up — Prepaid / Credit

| Unit | Resident | Ledger status | Prepaid / credit | Owed | 90+ days | Manager follow-up | Notes |
|---|---|---|---:|---:|---:|---|---|
| 710 - 710 | Harris, Victoria | Current resident | $11.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 718 - 718 | Simpson, Latekika | Current resident | $2.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 719 - 719 | Mitchell, Felicia | Former resident | $3,019.00 | $0.00 | $-3,019.00 | [ ] Confirm paid | — |
| 726 - 726 | Claiborne, Annette | Former applicant | $30.00 | $0.00 | $-30.00 | [ ] Confirm paid | — |
| 730 - 730 | Cotton, Cabria | Former resident | $45.53 | $0.00 | $-45.53 | [ ] Confirm paid | — |
| 750 - 750 | Williams, Samantha | Former resident | $1,286.62 | $0.00 | $-1,286.62 | [ ] Confirm paid | — |
| 8002 - 8002 | Henderson-Mcdonald, Laquila | Current resident | $1.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 8009 - 8009 | Thomas, XavierD | Current resident | $5.04 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 8014 - 8014 | Byrd, Betty | Former resident | $345.33 | $153.00 | $-192.33 | [ ] Confirm paid | — |
| 8017 - 8017 | Sibley, Lakareya | Former resident | $614.19 | $0.00 | $-614.19 | [ ] Confirm paid | — |
| 8021 - 8021 | Miller, Shaejaunekyue D | Current resident | $181.67 | $0.00 | $-181.67 | [ ] Confirm paid | — |
| 8038 - 8038 | Robinson, Darian | Former resident | $1,440.00 | $466.00 | $-974.00 | [ ] Confirm paid | — |
| 8042 - 8042 | Jones, Shiterria | Applicant | $600.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 8045 - 8045 | Hopkins, KamariaK | Current resident | $1.05 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 8104 - 8104 | Terrell, Kissy M | Current resident | $14.00 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 8108 - 8108 | Sneed, Abouya M | Current resident | $1.30 | $0.00 | $0.00 | [ ] Confirm paid | — |
| 8135 - 8135 | Williams, Felicia | Former resident | $1,459.19 | $19.74 | $-1,439.45 | [ ] Confirm paid | — |
| 8139 - 8139 | Lott, Latoya L | Former applicant | $1,530.00 | $0.00 | $-1,530.00 | [ ] Confirm paid | — |

## Resident Balance Follow-Up — Paid / Zero Balance

No resident ledger entries were detected in the selected source export.

## Manager Summary & Commitments

- **Availability status / blockers:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Delinquency commitments / payment arrangements:**
  - [ ] Reviewed with manager
  - Notes: ____________________________________________________________________________

- **Escalations requiring regional or corporate support:**
  - [ ] None
  - [ ] Escalation required: ___________________________________________________________

- **Next manager follow-up date:** ______________________________

---

*Generated from the property's supplied Availability PDF and Delinquent and Prepaid spreadsheet(s). The manager must validate current operational status before acting on any resident account.*