ONESITE LOCAL FILING RELAY — WINDOWS PILOT

1. Keep this folder together in a location you control.
2. Double-click “Start OneSite Filing Relay.cmd”. No terminal command is required.
3. Open the OneSite Reporting Hub > Import Data. The Installed local relay card should change from “Relay not detected” to “Relay detected”.
4. Click “Connect this device” only when you are ready to file one specifically authorized completed workbook.

The relay creates a dedicated “OneSite Filing Inbox” folder in your Windows home directory. A browser download must be intentionally sent to that inbox. The relay files only one exact portal-authorized Delinquent and Prepaid Excel workbook after portal preflight succeeds.

It never reads or stores provider passwords, cookies, MFA codes, browser profiles, or report-generation settings. It does not log in, run reports, or retry an uncertain handoff.

PILOT NOTICE: This Windows executable is not Authenticode-signed yet. Windows may show a reputation/security warning. Do not bypass a warning unless you received this folder directly from the authorized OneSite Reporting Hub deployment process and have verified the relay’s filename and checksum in the portal pilot record.
