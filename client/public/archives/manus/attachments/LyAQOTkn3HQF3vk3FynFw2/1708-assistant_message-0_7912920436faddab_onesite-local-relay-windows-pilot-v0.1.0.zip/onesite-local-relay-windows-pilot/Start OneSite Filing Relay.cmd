@echo off
start "OneSite Filing Relay" /D "%~dp0" "%~dp0onesite-filing-relay-windows.exe"
