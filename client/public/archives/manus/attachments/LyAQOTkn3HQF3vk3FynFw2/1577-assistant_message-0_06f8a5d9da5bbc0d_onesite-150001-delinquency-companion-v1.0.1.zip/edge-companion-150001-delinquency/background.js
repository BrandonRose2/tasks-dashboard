const CHANNEL = "onesite-150001-delinquency-companion";
const PROVIDER_ORIGIN = "https://www.realpage.com";
const PORTAL_ORIGIN = "https://onesiterepor-tsrr864t.manus.space";
const ENDPOINT = "/api/edge-filing/onesite-150001-delinquency";

function isPortal(url) { return typeof url === "string" && url.startsWith(`${PORTAL_ORIGIN}/`); }
function isProvider(url) { return typeof url === "string" && url.startsWith(`${PROVIDER_ORIGIN}/reporting/my-reports`); }

chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (message?.channel !== CHANNEL) return;
  if (message.type === "ONESITE_150001_DELINQUENCY_COMPANION_PAIR" && isPortal(sender.url) && typeof message.capability === "string" && message.portalOrigin === PORTAL_ORIGIN) {
    chrome.storage.session.set({ pair: { capability: message.capability, portalOrigin: PORTAL_ORIGIN } }).then(() => respond({ ok: true })).catch(error => respond({ ok: false, error: String(error) }));
    return true;
  }
  if (message.type === "ONESITE_150001_DELINQUENCY_COMPANION_STATUS" && isProvider(sender.url)) {
    chrome.storage.session.get("pair").then(({ pair }) => respond({ paired: Boolean(pair?.capability && pair.portalOrigin === PORTAL_ORIGIN) }));
    return true;
  }
});

chrome.runtime.onConnect.addListener(port => {
  if (port.name !== CHANNEL || !isProvider(port.sender?.url)) return;
  let transfer = null;
  port.onMessage.addListener(async message => {
    try {
      if (message?.type === "START") {
        if (!message.transferId || !message.propertyName || !message.filename || !Number.isInteger(message.byteLength) || message.byteLength < 1 || message.byteLength > 25 * 1024 * 1024 || message.reportName !== "Delinquent and Prepaid (Excel)" || message.completedDatePrefix !== "09/02/2026") throw new Error("The approved delinquency workbook metadata is invalid.");
        transfer = { id: message.transferId, propertyName: message.propertyName, filename: message.filename, byteLength: message.byteLength, reportName: message.reportName, completedDatePrefix: message.completedDatePrefix, chunks: [] };
        return;
      }
      if (!transfer || message?.transferId !== transfer.id) throw new Error("The workbook transfer is not active.");
      if (message.type === "CHUNK") {
        if (typeof message.data !== "string" || message.data.length > 750000) throw new Error("The workbook transfer chunk is invalid.");
        transfer.chunks.push(message.data);
        return;
      }
      if (message.type !== "END") return;
      const bytes = Uint8Array.from(atob(transfer.chunks.join("")), character => character.charCodeAt(0));
      if (bytes.byteLength !== transfer.byteLength) throw new Error("The received workbook size does not match the verified transfer.");
      const { pair } = await chrome.storage.session.get("pair");
      if (!pair?.capability || pair.portalOrigin !== PORTAL_ORIGIN) throw new Error("Pair the 09/02 delinquency companion in the portal before downloading an eligible workbook.");
      const response = await fetch(`${PORTAL_ORIGIN}${ENDPOINT}`, { method: "POST", headers: { "Authorization": `Bearer ${pair.capability}`, "Content-Type": "application/octet-stream", "X-Onesite-Property": transfer.propertyName, "X-Onesite-Filename": transfer.filename, "X-Onesite-Report": transfer.reportName, "X-Onesite-Completed-Date": transfer.completedDatePrefix }, body: bytes });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(body.error || "The portal rejected this workbook.");
      chrome.tabs.sendMessage(port.sender.tab.id, { channel: CHANNEL, type: "ONESITE_150001_DELINQUENCY_COMPANION_FILED", propertyName: body.propertyName });
      transfer = null;
    } catch (error) {
      chrome.tabs.sendMessage(port.sender?.tab?.id, { channel: CHANNEL, type: "ONESITE_150001_DELINQUENCY_COMPANION_TRANSFER_ERROR", message: error instanceof Error ? error.message : String(error) });
      transfer = null;
    }
  });
});
