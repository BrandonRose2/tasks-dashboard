const CHANNEL = "onesite-150001-delinquency-companion";
const PORTAL_ORIGIN = "https://onesiterepor-tsrr864t.manus.space";
const PROVIDER_ORIGIN = "https://www.realpage.com";

if (location.origin === PORTAL_ORIGIN) {
  const announce = () => window.postMessage({ channel: CHANNEL, type: "ONESITE_150001_DELINQUENCY_COMPANION_READY", extensionId: chrome.runtime.id }, PORTAL_ORIGIN);
  announce();
  window.addEventListener("message", event => {
    if (event.origin !== PORTAL_ORIGIN || event.source !== window || event.data?.channel !== CHANNEL) return;
    if (event.data.type === "ONESITE_150001_DELINQUENCY_COMPANION_DISCOVER") announce();
    if (event.data.type === "ONESITE_150001_DELINQUENCY_COMPANION_PAIR") chrome.runtime.sendMessage(event.data).then(() => window.postMessage({ channel: CHANNEL, type: "ONESITE_150001_DELINQUENCY_COMPANION_PAIRED" }, PORTAL_ORIGIN));
  });
}

if (location.origin === PROVIDER_ORIGIN && location.pathname === "/reporting/my-reports") {
  let active = null;
  let port = null;
  let paired = false;
  const post = payload => window.postMessage({ channel: CHANNEL, ...payload }, PROVIDER_ORIGIN);
  const refreshPairState = () => chrome.runtime.sendMessage({ channel: CHANNEL, type: "ONESITE_150001_DELINQUENCY_COMPANION_STATUS" }).then(response => {
    paired = Boolean(response?.paired);
    post({ type: "ONESITE_150001_DELINQUENCY_COMPANION_PAIR_STATE", paired });
  }).catch(() => {
    paired = false;
    post({ type: "ONESITE_150001_DELINQUENCY_COMPANION_PAIR_STATE", paired });
  });
  refreshPairState();
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === "session" && changes.pair) refreshPairState();
  });
  setInterval(refreshPairState, 5_000);
  window.addEventListener("message", event => {
    if (event.origin !== PROVIDER_ORIGIN || event.source !== window || event.data?.channel !== CHANNEL || event.data.type !== "ONESITE_150001_DELINQUENCY_COMPANION_WORKBOOK" || !active || event.data.transferId !== active.transferId || !(event.data.bytes instanceof ArrayBuffer)) return;
    const { propertyName, transferId } = active;
    const filename = event.data.filename || `${propertyName}-Delinquent-and-Prepaid-2026-09-02.xlsx`;
    active = null;
    if (!port) port = chrome.runtime.connect({ name: CHANNEL });
    const bytes = new Uint8Array(event.data.bytes);
    let binary = "";
    for (let offset = 0; offset < bytes.length; offset += 0x8000) binary += String.fromCharCode(...bytes.subarray(offset, offset + 0x8000));
    const encoded = btoa(binary);
    port.postMessage({ type: "START", transferId, propertyName, filename, byteLength: bytes.byteLength, reportName: "Delinquent and Prepaid (Excel)", completedDatePrefix: "09/02/2026" });
    for (let offset = 0; offset < encoded.length; offset += 500000) port.postMessage({ type: "CHUNK", transferId, data: encoded.slice(offset, offset + 500000) });
    port.postMessage({ type: "END", transferId });
  });
  chrome.runtime.onMessage.addListener(message => { if (message?.channel === CHANNEL) post(message); });
  window.addEventListener("message", event => {
    if (event.origin !== PROVIDER_ORIGIN || event.source !== window || event.data?.channel !== CHANNEL) return;
    if (event.data.type === "ONESITE_150001_DELINQUENCY_COMPANION_PAIR_STATE_REQUEST") { refreshPairState(); post({ type: "ONESITE_150001_DELINQUENCY_COMPANION_PAIR_STATE", paired }); }
    if (event.data.type === "ONESITE_150001_DELINQUENCY_COMPANION_ARM") active = { propertyName: event.data.propertyName, transferId: event.data.transferId };
    if (event.data.type === "ONESITE_150001_DELINQUENCY_COMPANION_TRANSFER_ERROR") active = null;
  });
}
