# OneSite 09/02 Delinquency Direct Filing

This unpacked Microsoft Edge extension is limited to the completed **09/02/2026** OneSite **Delinquent and Prepaid (Excel)** outputs associated with portal **Request #150001**.

It does not sign in to OneSite, access cookies or credentials, create reports, modify report settings, enumerate tabs, or accept broad downloads. It may transfer a workbook only after the portal issues a short-lived pairing capability and only when the visible My Reports row has the exact approved report title, report area, completed date, and an eligible source-scoped property.

## Installation

1. Extract the archive.
2. In Microsoft Edge, open `edge://extensions` and enable **Developer mode**.
3. Select **Load unpacked** and choose this extracted folder.
4. Keep the existing **OneSite Request 60001 Direct Filing** extension enabled; this is a separate companion for the approved 09/02 delinquency batch.
5. In the portal’s **Import Data** workspace, pair this companion from the purple **File 09/02 OneSite delinquency workbooks** card before any eligible provider-side Download action.

Do not use the extension with any other report title, date, provider, or request.
