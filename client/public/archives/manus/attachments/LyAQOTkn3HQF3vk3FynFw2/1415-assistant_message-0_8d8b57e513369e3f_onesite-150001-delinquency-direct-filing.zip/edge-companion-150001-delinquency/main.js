const CHANNEL = "onesite-150001-delinquency-companion";
const PROVIDER_ORIGIN = "https://www.realpage.com";
const REPORT_NAME = "Delinquent and Prepaid (Excel)";
const REPORT_AREA = "Accounts Receivable / Management";
const COMPLETED_DATE_PREFIX = "09/02/2026";

if (location.origin === PROVIDER_ORIGIN && location.pathname === "/reporting/my-reports") {
  let active = null;
  let paired = false;
  const post = payload => window.postMessage({ channel: CHANNEL, ...payload }, PROVIDER_ORIGIN);
  const filenameFrom = (header, fallback) => {
    const extended = /filename\*=UTF-8''([^;]+)/i.exec(header);
    const simple = /filename="?([^";]+)"?/i.exec(header);
    try { return extended ? decodeURIComponent(extended[1]) : (simple?.[1] || fallback); } catch { return fallback; }
  };
  const isWorkbookResponse = response => {
    const disposition = response.headers.get("content-disposition") || "";
    const type = response.headers.get("content-type") || "";
    return disposition.includes("attachment") || /spreadsheet|ms-excel|application\/vnd\.ms-excel/.test(type);
  };
  const isWorkbookHeaders = (disposition, type) => disposition.includes("attachment") || /spreadsheet|ms-excel|application\/vnd\.ms-excel/.test(type);
  const capture = (bytes, disposition, fallback) => {
    if (!active) return;
    const current = active;
    active = null;
    Promise.resolve(bytes).then(value => post({ type: "ONESITE_150001_DELINQUENCY_COMPANION_WORKBOOK", transferId: current.transferId, filename: filenameFrom(disposition || "", fallback || current.filename), bytes: value })).catch(() => post({ type: "ONESITE_150001_DELINQUENCY_COMPANION_TRANSFER_ERROR", message: "The completed workbook could not be copied for direct filing." }));
  };
  const originalFetch = window.fetch.bind(window);
  window.fetch = async (...args) => {
    const response = await originalFetch(...args);
    if (active && isWorkbookResponse(response)) capture(response.clone().arrayBuffer(), response.headers.get("content-disposition") || "", active.filename);
    return response;
  };
  const NativeXMLHttpRequest = window.XMLHttpRequest;
  const xhrPrototype = NativeXMLHttpRequest.prototype;
  if (!xhrPrototype.__onesite150001DelinquencyCaptureInstalled) {
    Object.defineProperty(xhrPrototype, "__onesite150001DelinquencyCaptureInstalled", { value: true });
    const nativeSend = xhrPrototype.send;
    xhrPrototype.send = function (...args) {
      this.addEventListener("load", () => {
        if (!active || this.status < 200 || this.status >= 300) return;
        const disposition = this.getResponseHeader("content-disposition") || "";
        const type = this.getResponseHeader("content-type") || "";
        const response = this.response;
        if (!isWorkbookHeaders(disposition, type) || !(response instanceof Blob || response instanceof ArrayBuffer)) return;
        capture(response instanceof Blob ? response.arrayBuffer() : response, disposition, active.filename);
      }, { once: true });
      return nativeSend.apply(this, args);
    };
  }
  const propertyFromRow = row => row?.querySelector(".report-col-property")?.innerText?.trim() || "";
  const isEligibleCurrentRow = row => {
    const text = row?.innerText || "";
    return text.includes(REPORT_NAME) && text.includes(REPORT_AREA) && text.includes("Completed") && text.includes(COMPLETED_DATE_PREFIX);
  };
  document.addEventListener("click", event => {
    const download = event.composedPath().find(node => node?.innerText?.trim?.() === "Download");
    const row = download?.closest?.("raul-grid-row");
    if (!download || !paired || !isEligibleCurrentRow(row) || download.dataset?.onesite150001DirectTransferReplay === "1") return;
    const propertyName = propertyFromRow(row);
    if (!propertyName) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    active = { transferId: crypto.randomUUID(), filename: `${propertyName}-Delinquent-and-Prepaid-2026-09-02.xlsx` };
    post({ type: "ONESITE_150001_DELINQUENCY_COMPANION_ARM", propertyName, transferId: active.transferId });
    download.dataset.onesite150001DirectTransferReplay = "1";
    download.click();
    queueMicrotask(() => { delete download.dataset.onesite150001DirectTransferReplay; });
  }, true);
  window.addEventListener("message", event => {
    if (event.origin !== PROVIDER_ORIGIN || event.source !== window || event.data?.channel !== CHANNEL) return;
    if (event.data.type === "ONESITE_150001_DELINQUENCY_COMPANION_PAIR_STATE") paired = Boolean(event.data.paired);
  });
  setInterval(() => post({ type: "ONESITE_150001_DELINQUENCY_COMPANION_PAIR_STATE_REQUEST" }), 5_000);
}
